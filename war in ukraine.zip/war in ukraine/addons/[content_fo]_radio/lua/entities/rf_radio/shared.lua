--[[
addons/[content_fo]_radio/lua/entities/rf_radio/shared.lua
--]]
﻿ENT.Base = "base_anim"
ENT.Type = "anim"
ENT.Category 		= "Музыка"
ENT.PrintName		= "Радио-3"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions		= "ь"
ENT.Spawnable			= true
ENT.AdminSpawnable		= true


