--[[
addons/[content_fo]_radio/lua/entities/sssr_radio/shared.lua
--]]
﻿ENT.Base = "base_anim"
ENT.Type = "anim"
ENT.Category 		= "Музыка"
ENT.PrintName		= "Радио-2"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions		= "ь"
ENT.Spawnable			= true
ENT.AdminSpawnable		= true


