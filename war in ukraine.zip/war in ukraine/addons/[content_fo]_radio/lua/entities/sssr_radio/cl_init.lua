--[[
addons/[content_fo]_radio/lua/entities/sssr_radio/cl_init.lua
--]]
include('shared.lua')

ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:Initialize()
end

function ENT:Think()
end

function ENT:OnRestore()
end


