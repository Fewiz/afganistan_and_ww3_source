--[[
addons/[content_fo]_radio/lua/entities/sssr_sounds/shared.lua
--]]
﻿ENT.Base = "base_anim"
ENT.Type = "anim"
ENT.Category 		= "Музыка"
ENT.PrintName		= "Передатчик-2"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions		= "ь"
ENT.Spawnable			= true
ENT.AdminSpawnable		= true


