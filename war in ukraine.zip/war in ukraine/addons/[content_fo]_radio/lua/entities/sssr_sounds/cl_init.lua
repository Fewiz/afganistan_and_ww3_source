--[[
addons/[content_fo]_radio/lua/entities/sssr_sounds/cl_init.lua
--]]
include('shared.lua')

ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:Initialize()
end

function ENT:Think()
end

function ENT:OnRestore()
end


