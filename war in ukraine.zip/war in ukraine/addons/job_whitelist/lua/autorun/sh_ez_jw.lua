--[[
addons/job_whitelist/lua/autorun/sh_ez_jw.lua
--]]
mst_jw = mst_jw or {}

mst_jw.command = "wl"  -- Command to open menu (include '/', '!' automatic)

mst_jw.Ranks = { -- Who can change job and name
	"root","admin+","admin","moderator","vip", "VIP",
}
mst_jw.Job = { -- Who can change job and name
	"Инструктор", 

	"Штабной офицер РФ [✦]", 
	"Командир | 138-я гв. омсбр | [★]", 
	"Командир | 4-я гв. тд | [★]", 
	"Командир | 7-я гв. дшд(г) | [★]", 
	"Командир | ВП | [★]", 
	"Командир | ФСБ | [★]", 
	"Штабной офицер UA [✦]", 
	"Командир | 14-я омбр | [★]", 
	"Командир | 1-я отСб | [★]", 
	"Командир | 79-я одшбр | [★]", 
	"Командир | 3-й оп СпП | [★]", 
	"Командир | СБУ | [★]", 
}

mst_jw.AllowedSteamID = { -- Who can change job and name
	"STEAM_0:0:145530561", -- STEAMID
 
	"STEAM_0:0:114373647", -- КМД ВДВ
	"STEAM_0:1:36668535", -- КМД КГБ
	"",
	
}

