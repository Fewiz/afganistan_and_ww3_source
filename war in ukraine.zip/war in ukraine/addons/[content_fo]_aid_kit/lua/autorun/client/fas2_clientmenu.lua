--[[
addons/[content_fo]_aid_kit/lua/autorun/client/fas2_clientmenu.lua
--]]
local function FAS2_ClientsidePanel(panel)
	 
end

local function FAS2_PopulateToolMenu()
	spawnmenu.AddToolMenuOption("Utilities", "FAS2 SWEPs", "FAS2 Client", "Client", "", "", FAS2_ClientsidePanel)
	spawnmenu.AddToolMenuOption("Utilities", "FAS2 SWEPs", "FAS2 Admin", "Admin", "", "", FAS2_AdminPanel)
end

hook.Add("PopulateToolMenu", "FAS2_PopulateToolMenu", FAS2_PopulateToolMenu)

