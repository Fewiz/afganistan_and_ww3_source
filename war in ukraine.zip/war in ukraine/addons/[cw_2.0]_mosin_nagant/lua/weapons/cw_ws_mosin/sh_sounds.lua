--[[
addons/[cw_2.0]_mosin_nagant/lua/weapons/cw_ws_mosin/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_WS_MOSIN_FIRE", "weapons/ws mosin/mosin_fp.wav", 1, 105, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_WS_MOSIN_SUB", "weapons/ws mosin/mosin_suppressed_fp.wav", 1, 75, CHAN_STATIC)

CustomizableWeaponry:addReloadSound("CW_WS_MOSIN_INSERT", "weapons/ws mosin/handling/mosin_bulletin_3.wav")
CustomizableWeaponry:addReloadSound("CW_WS_MOSIN_BOLTBACK", "weapons/ws mosin/handling/mosin_boltback.wav")
CustomizableWeaponry:addReloadSound("CW_WS_MOSIN_BOLTFORWORD", "weapons/ws mosin/handling/mosin_boltforward.wav")

