--[[
addons/[cw_2.0]_mosin_nagant/lua/cw/shared/attachments/skin_ws_mosinclean.lua
--]]
local att = {}
att.name = "skin_ws_mosinclean"
att.displayName = "Чистая Древесина" -- Clean Wood
att.displayNameShort = "Скин" -- Clean
att.isBG = true

att.statModifiers = {}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/skin_ws_mosinclean")
	att.description = {[1] = {t = "Чистая деревянная отделка на ваше оружие.", c = CustomizableWeaponry.textColors.POSITIVE}} -- Clean wood finish for your weapon
end

function att:attachFunc()
	if SERVER then
		return
	end

	if self.CW_VM then
		self.CW_VM:SetSkin(2)
	end
	if self.WMEnt then
		self.WMEnt:SetSkin(2)
	end
end

function att:detachFunc()
	if SERVER then
		return
	end

	if self.CW_VM then
		self.CW_VM:SetSkin(0)
	end
	if self.WMEnt then
		self.WMEnt:SetSkin(0)
	end
end

CustomizableWeaponry:registerAttachment(att)

