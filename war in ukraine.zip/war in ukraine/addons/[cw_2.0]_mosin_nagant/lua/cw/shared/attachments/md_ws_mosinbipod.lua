--[[
addons/[cw_2.0]_mosin_nagant/lua/cw/shared/attachments/md_ws_mosinbipod.lua
--]]
local att = {}
att.name = "md_ws_mosinbipod"
att.displayName = "Сошки" -- Bipod
att.displayNameShort = "Сошки" -- Bipod

att.statModifiers = {
	OverallMouseSensMult = -0.1,
	DrawSpeedMult = -0.15
}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/bipod")
	att.description = {
	[1] = {t = "При использовании:", c = CustomizableWeaponry.textColors.REGULAR}, -- When deployed:
	[2] = {t = "Разброс меньше на 70%", c = CustomizableWeaponry.textColors.POSITIVE}, -- Decreases recoil by 70%
	[3] = {t = "Значительно увеличивает точность стрельбы от бедра", c = CustomizableWeaponry.textColors.POSITIVE}} -- reatly increases hip fire accuracy
end


function att:attachFunc()
	self.BipodInstalled = true
	self.BipodWasDeployed = false
end

function att:detachFunc()
	self.BipodInstalled = false
	
	self:restoreSound()
end

	
function att:elementRender()
	local yes = self.dt.BipodDeployed	
	local no = self.BipodWasDeployed
	local bipod = self.AttachmentModelsVM.md_ws_mosinbipod.ent	
	
	if yes != no then
	
		if yes then
		
			bipod:SetBodygroup(0,1)
			
		else
		
			bipod:SetBodygroup(0,0)
			
		end	
		
	end
	
	self.BipodWasDeployed = yes
	
end

CustomizableWeaponry:registerAttachment(att)

