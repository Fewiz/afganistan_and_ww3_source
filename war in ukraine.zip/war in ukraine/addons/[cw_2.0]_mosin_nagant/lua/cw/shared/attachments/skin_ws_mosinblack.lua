--[[
addons/[cw_2.0]_mosin_nagant/lua/cw/shared/attachments/skin_ws_mosinblack.lua
--]]
local att = {}
att.name = "skin_ws_mosinblack"
att.displayName = "Натуральное Черное Дерево" -- Natural Ebony
att.displayNameShort = "Скин"
att.isBG = true

att.statModifiers = {}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/skin_ws_mosinblack")
	att.description = {[1] = {t = "Натуральная отделка из черного дерева на ваше оружие.", c = CustomizableWeaponry.textColors.POSITIVE}} -- Natural ebony finish for your weapon.
end

function att:attachFunc()
	if SERVER then
		return
	end

	if self.CW_VM then
		self.CW_VM:SetSkin(1)
	end
	if self.WMEnt then
		self.WMEnt:SetSkin(1)
	end
end

function att:detachFunc()
	if SERVER then
		return
	end

	if self.CW_VM then
		self.CW_VM:SetSkin(0)
	end
	if self.WMEnt then
		self.WMEnt:SetSkin(0)
	end
end

CustomizableWeaponry:registerAttachment(att)

