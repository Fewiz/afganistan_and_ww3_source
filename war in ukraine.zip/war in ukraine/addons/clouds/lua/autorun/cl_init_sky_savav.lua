--[[
addons/clouds/lua/autorun/cl_init_sky_savav.lua
--]]
CreateClientConVar(	 "cloud_distance", 40,  true, true)
CreateClientConVar(	 "cloud_speed", 4,  true, true)
CreateClientConVar(	 "cloud_size", 3,  true, true)
CreateClientConVar(	 "cloud_enable", 1,  true, true)


CreateClientConVar(	 "cloud_red", 255,  true, true)
CreateClientConVar(	 "cloud_green", 255,  true, true)
CreateClientConVar(	 "cloud_blue", 255,  true, true)


local CLOUD1 = Material( "CLOUD-1" )
local CLOUD2 = Material( "CLOUD-2" )
local CLOUD3 = Material( "CLOUD-3" )
local CLOUD4 = Material( "CLOUD-4" )
local CLOUDBOX = Material( "CLOUDBOX" )
local CLOUDBOX2 = Material( "CLOUDBOX2" )
local DARKN = Material( "DARKN" )

local T1 = 0
local T2 = 0
local T3 = 0
local T4 = 0
local T5 = 0
local T6 = 0
local T7 = 0
local T8 = 0

hook.Add( "PopulateToolMenu", "Clouds_Options", function()
	--spawnmenu.AddToolMenuOption( "Options", "Clouds System", "client", "Clouds Options", "", "", function( panel ) 
	spawnmenu.AddToolMenuOption( "Options", "Настройка облаков", "client", "Игрок", "", "", function( panel ) 	
	
		panel:CheckBox( "Включить облака", "cloud_enable" ) -- Enable Clouds?
		--panel:NumSlider( "speed", "cloud_speed", -1000, 1000 )
		--panel:NumSlider( "size", "cloud_size", 0, 10 )
		--panel:NumSlider( "distance", "cloud_distance", -100, 100 )
       --panel:AddControl("Color",  {
     --   Label = "You can change Color! YAY! =D", 
	--	red = "cloud_red",
	--	green = "cloud_green",
	--	blue  ="cloud_blue",
    --})

	end )
end )

--function SkyColorGet()

--local env_skypaint = ents.FindByClass( "env_skypaint" )
--env_skypaint[1]:UpdateTransmitState()
--return env_skypaint[1]:GetBottomColor()

--end
 
 

hook.Add( "PostDraw2DSkyBox", "Clouds", function()
local cloud_distance = "-23.15"  --GetConVar( "cloud_distance" ):GetInt()
local cloud_enable = GetConVar( "cloud_enable" ):GetInt()

local SIZE = "2.18" --GetConVar( "cloud_size" ):GetInt()
local SPEED = "0.03" --GetConVar( "cloud_speed" ):GetInt()/100 -- 0.015








local CloudColor = Color(240,240,240) ----Color(GetConVar( "cloud_red" ):GetInt(),GetConVar( "cloud_green" ):GetInt(),GetConVar( "cloud_blue" ):GetInt(),255)

--local endofclolo = SkyColorGet()
	
--local CloudColor = Color(endofclolo.x*255,endofclolo.y*255,endofclolo.z*255,255)
--local CloudColor = 


if cloud_enable == 1 then
if T1 < 210 then
	T1 = T1+SPEED/15
else
	T1= -210
end

if T2 < 240 then
	T2 = T2+SPEED/10
else
	T2= -240
end

if T3 < 240 then
	T3 = T3+SPEED/20
else
	T3= -240
end

if T4 < 250 then
	T4 = T4+SPEED/13
else
	T4= -250
end

if T5 < 230 then
	T5 = T5+SPEED/25
else
	T5= -230
end

if T6 < 250 then
	T6 = T6+SPEED/8
else
	T6= -250
end

if T7 < 750 then
	T7 = T7+SPEED/20
else
	T7= -210
end


if T8 < 360 then
	T8 = T8+SPEED/500
else
	T8= 0
end
	render.OverrideDepthEnable( true, false ) -- ignore Z to prevent drawing over 3D skybox

	-- Start 3D cam centered at the origin
	
for i=1, 5 do
	cam.Start3D( Vector( (-50+(i*30))-10, 10+(math.cos(i*100)*60), 0 ), EyeAngles() )
	
		render.SetMaterial( CLOUD1 )
		render.DrawQuadEasy( Vector(-(EyePos()/300).x, T1-(EyePos()/300).y, cloud_distance-(EyePos()/200).z ), Vector( -1, 0, -90 ), SIZE*31, SIZE*10, CloudColor, 0 )
		
	cam.End3D()
	
	
	cam.Start3D( Vector( (-50+(i*30))-10, 40-(math.cos(i*100)*60), 0 ), EyeAngles() )
	
		render.SetMaterial( CLOUD2 )
		render.DrawQuadEasy( Vector(-(EyePos()/300).x, ((T2))-(EyePos()/300).y, cloud_distance-(EyePos()/200).z ), Vector( -1, 0, -90 ), SIZE*40, SIZE*20, CloudColor, 0 )
		
	cam.End3D()


	cam.Start3D( Vector( (-50+(i*30)), 100+(math.cos(i*100)*60), 0 ), EyeAngles() )
	
		render.SetMaterial( CLOUD3 )
		render.DrawQuadEasy( Vector((-(EyePos()/300).x), ((T3))-(EyePos()/300).y, cloud_distance-(EyePos()/200).z ), Vector( -1, 0, -90 ), SIZE*40, SIZE*20, CloudColor, 0 )
		
	cam.End3D()

		
	cam.Start3D( Vector( (-50+(i*30))-40, 50-(math.cos(i*100)*60), 0 ), EyeAngles() )
	
		render.SetMaterial( CLOUD4 )
		render.DrawQuadEasy( Vector(-(EyePos()/300).x, T4-(EyePos()/300).y, cloud_distance-(EyePos()/200).z ), Vector( -1, 0, -90 ), SIZE*90, SIZE*20, CloudColor, 0 )
		
	cam.End3D()
		

	cam.Start3D( Vector( (-50+(i*30))+30, -30+(math.cos(i*100)*60), 0 ), EyeAngles() )
	
		render.SetMaterial( CLOUD2 )
		render.DrawQuadEasy( Vector(-(EyePos()/300).x, ((T5))-(EyePos()/300).y, cloud_distance-(EyePos()/200).z ), Vector( -1, 0, -90 ), SIZE*40, SIZE*20, CloudColor, 0 )
		
	cam.End3D()		


	cam.Start3D( Vector( (-50+(i*30))-30, -50+(math.cos(i*100)*60), 0 ), EyeAngles() )
	
		render.SetMaterial( CLOUD4 )
		render.DrawQuadEasy( Vector((-(EyePos()/300).x), ((T6))-(EyePos()/300).y, cloud_distance-(EyePos()/200).z ), Vector( -1, 0, -90 ), SIZE*90, SIZE*20, CloudColor, 0 )
		
	cam.End3D()

	 
	cam.Start3D( Vector( (-50+(i*30)), 300-(math.cos(i*100)*60), 0 ), EyeAngles() )
	
		render.SetMaterial( CLOUD3 )
		render.DrawQuadEasy( Vector((-(EyePos()/300).x), ((T7))-(EyePos()/300).y, cloud_distance-(EyePos()/200).z ), Vector( -1, 0, -90 ), SIZE*40, SIZE*20, CloudColor, 0 )
		
	cam.End3D()		

end

	cam.Start3D( Vector(-20.7, 0, 0 ), EyeAngles()+Angle(0,T8,0) )
	
		render.SetMaterial( CLOUDBOX )
		render.DrawQuadEasy( Vector(0, 0, cloud_distance-(EyePos()/200).z-11 ), Vector( -1, 0, 0 ), -40, -20, CloudColor, 0 )
		
	cam.End3D()	

	cam.Start3D( Vector(0, -19.54, 0 ), EyeAngles()+Angle(0,T8,0) )
	
		render.SetMaterial( CLOUDBOX2 )
		render.DrawQuadEasy( Vector(0, 0, cloud_distance-(EyePos()/200).z-11 ), Vector( -1, -90, 0 ), -40, -20, CloudColor, 0 )
		
	cam.End3D()	

	cam.Start3D( Vector(0, 20.31, 0 ), EyeAngles()+Angle(0,T8-0.33,0) )
	
		render.SetMaterial( CLOUDBOX2 )
		render.DrawQuadEasy( Vector(0, 0, cloud_distance-(EyePos()/200).z-11 ), Vector( -1, 90, 0 ), -41.1,-20, CloudColor, 0 )
		
	cam.End3D()	
	
	cam.Start3D( Vector(0, 20, 0 ), EyeAngles()+Angle(0,90+T8,0) )
	
		render.SetMaterial( CLOUDBOX )
		render.DrawQuadEasy( Vector(0, 0, cloud_distance-(EyePos()/200).z-11 ), Vector( -1, 90, 0 ), -40, -20, CloudColor, 0 )
		
	cam.End3D()	
	
 
	cam.Start3D( Vector( 0, 0, 0 ), EyeAngles() )
	 
		render.SetMaterial( DARKN )
		render.DrawScreenQuad()
		
	cam.End3D()
	

	
	
	render.OverrideDepthEnable( false, false )
end
end )

