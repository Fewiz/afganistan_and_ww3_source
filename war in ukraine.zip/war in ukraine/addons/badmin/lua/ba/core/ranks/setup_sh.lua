--[[
addons/badmin/lua/ba/core/ranks/setup_sh.lua
--]]
-- We'll replace this some day.. maybe
ba.ranks.Create('Root', 10)
	:SetImmunity(10000)
	:SetRoot(true)

ba.ranks.Create('Admin+', 6)
	:SetImmunity(7500)
	:SetFlags('uvmas')
	:SetAdmin(true)
	
ba.ranks.Create('Admin', 5)
	:SetImmunity(6000)
	:SetFlags('uvma')
	:SetAdmin(true)

ba.ranks.Create('Moderator', 4)
	:SetImmunity(5000)
	:SetFlags('uvma') --  uvm
	:SetAdmin(true)

ba.ranks.Create('VIP+', 3)
	:SetImmunity(0)
	:SetFlags('uv')
	:SetVIP(true)

ba.ranks.Create('VIP', 2)
	:SetImmunity(0)
	:SetFlags('uv')
	:SetVIP(true)

ba.ranks.Create('User', 1)
	:SetImmunity(0)
	:SetFlags('u')





