--[[
addons/badmin/lua/ba/core/terms_sh.lua
--]]
ba.AddTerm('PlayerFirstConnect', '# - загрузился первый раз.')
ba.AddTerm('PlayerConnect', '# загрузился, последний раз был в #.')
ba.AddTerm('PlayerDisconnect', '# отключился.')

ba.AddTerm('RankExpired', 'Ваш ранг изменен на #.')

ba.AddTerm('InvalidCommand', 'Команда "#" не найдена.')
ba.AddTerm('NeedFlagToUseCommand', 'Вам нужен флаг "#" чтобы использовать "#"')
ba.AddTerm('MissingArg', 'Вы забыли задать аргумент: #')
ba.AddTerm('FatalError', 'Ошибка.')
ba.AddTerm('TriedToRunCommand', '# пытался запустить "#" на вас!')
ba.AddTerm('SameWeight', 'Этот игрок выше вас по рангу!')
ba.AddTerm('InvalidTimeUnit', 'Неправильно указано время (правильный пример: "1mi - 1 минута"")')

ba.AddTerm('NoPlayerEvents', 'не!')

