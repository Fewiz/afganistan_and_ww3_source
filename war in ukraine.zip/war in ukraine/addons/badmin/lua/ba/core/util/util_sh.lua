--[[
addons/badmin/lua/ba/core/util/util_sh.lua
--]]
-- Misc utils
function ba.Call(event, ...)
	return hook.Call(event, ba, ...)
end



