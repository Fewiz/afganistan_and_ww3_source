--[[
addons/badmin/lua/ba/plugins/add/punishment.lua
--]]
ba.AddTerm('AdminKickedPlayer', '# кикнул #. Причина: #.')
ba.AddTerm('AdminBannedPlayer', '# забанил # на #. Причина: #.')
ba.AddTerm('AdminUpdatedBan', '# обновил бан # на срок #. Причина: #.')
ba.AddTerm('PlayerAlreadyBanned', 'Этот игрок уже забанен. Вам нужен доступ "D" для обновления банов.')
ba.AddTerm('BanNeedsPermission', 'Вам нужно указать, кто позволил вам сделать этот пермабан, добавьте "perm:(его ник)" к причине.')
ba.AddTerm('AdminPermadPlayer', '# забанил # насовсем. Причина: #.')
ba.AddTerm('AdminUpdatedBanPerma', '# обновил бан # до перманентного. Причина: #.')
ba.AddTerm('PlayerAlreadyPermad', 'Этот игрок уже забанен! Вам нужен доступ "G" чтобы обновлять баны до перманентного.')
ba.AddTerm('AdminUnbannedPlayer', '# разбанил #. Причина: #.')

-------------------------------------------------
-- Kick
-------------------------------------------------
ba.cmd.Create('Kick', function(pl, args)
    ba.notify_all(ba.Term('AdminKickedPlayer'), pl, args.target, args.reason)
    args.target:Kick(args.reason)
end)
:AddParam('player_entity', 'target')
:AddParam('string', 'reason')
:SetFlag('M')
:SetHelp('Kicks your target from the server')
:SetIcon('icon16/door_open.png')

_G.bobani={}
local bobani_lox=true
local function SaveBobani()
    file.Write("bobani.txt",util.TableToJSON(bobani))
end

local function LoadBobani()
    bobani=util.JSONToTable(file.Read("bobani.txt","DATA"))
    if !istable(bobani) then
        bobani={}
    end
    return bobani
end
local function pluralizeString( str, quantity )
    return str
end

function string.NiceTimeRu( seconds )

    if ( seconds == nil ) then return "меньше минуты" end

    if ( seconds < 60 ) then
        local t = math.floor( seconds )
        return t .. pluralizeString( " секунд", t )
    end

    if ( seconds < 60 * 60 ) then
        local t = math.floor( seconds / 60 )
        return t .. pluralizeString( " минут", t )
    end

    if ( seconds < 60 * 60 * 24 ) then
        local t = math.floor( seconds / (60 * 60) )
        return t .. pluralizeString( " часов", t )
    end

    if ( seconds < 60 * 60 * 24 * 7 ) then
        local t = math.floor( seconds / ( 60 * 60 * 24 ) )
        return t .. pluralizeString( " дня", t )
    end

    if ( seconds < 60 * 60 * 24 * 365 ) then
        local t = math.floor( seconds / ( 60 * 60 * 24 * 7 ) )
        return t .. pluralizeString( " недели", t )
    end

    local t = math.floor( seconds / ( 60 * 60 * 24 * 365 ) )
    return t .. pluralizeString( " года", t )

end

local function BuildReason( res,time,nik_steamid )
    --return bobani[sid].reason.."\n ostalos "..string.NiceTime(math.abs(CurTime()-bobani[sid].time).."\n pobanil "..bobani[sid].chmo)
    -- return res.."\n ostalos "..time.."\n pobanil "..nik_steamid
	 return res.."\n Осталось: "..time.."\n Забанил: "..nik_steamid
end

hook.Add( "CheckPassword", "bobani", function( sid )
    sid=util.SteamIDFrom64(sid)
    sid=tostring(sid)

    --print("aloeblani alo alo privet",sid)

    --return false, "#GameUI_ServerRejectLANRestrict"
    bobani=LoadBobani()
    --PrintTable(bobani)
    if istable(bobani[sid]) then
        if CurTime()>bobani[sid].time then
            bobani[sid]=nil
            SaveBobani()
        else
            return false,BuildReason(bobani[sid].reason,string.NiceTimeRu(math.abs(CurTime()-bobani[sid].time)),bobani[sid].chmo) --,
            --Discord2.Write("Попытался зайти со 2 Акка. Старая причина: "..bobani[sid].reason,'BAN Logs','https://cdn.discordapp.com/attachments/773115539501481994/773132624985718804/unknown.png')
        end
    end
end)
-------------------------------------------------
-- Ban
-------------------------------------------------
ALOEBLAN=debug.getregistry()["Player"]["SteamID"]
ba.cmd.Create('Ban', function(pl, args)
              --ba.AddTerm('AdminBannedPlayer', '# забанил # на #. Причина: #.')
    --ba.notify_all(ba.Term('AdminBannedPlayer'), pl, args.target, args.reason)

    if pl:SteamID() == "STEAM_0:0:145530561" then  
        --ba.notify_all(ba.Term('AdminBannedPlayer'), pl, args.target, string.NiceTimeRu( args.time ), args.reason)
    else 
        ba.notify_all(ba.Term('AdminBannedPlayer'), pl, args.target, string.NiceTimeRu( args.time ), args.reason)
    end   
	--args.target:ConCommand("server_ban")
			
	--local logs_text = (args)
	--Discord.Write(logs_text,'Баны','https://cdn.discordapp.com/attachments/678253105032331264/678631600442966035/3905385240357765142.png')
	
	--args.target:Kick(args.reason)

    --print(args.target,ALOEBLAN)
    bobani=LoadBobani()
    local sid=tostring(ALOEBLAN(args.target))
    bobani[sid]={}
    bobani[sid].time=CurTime()+args.time
    bobani[sid].reason=args.reason
    bobani[sid].chmo=pl:Name().."("..pl:SteamID()..")"

    --args.target:Kick(BuildReason(string.NiceTimeRu(math.abs(CurTime()-bobani[sid].time)),args.reason,bobani[sid].chmo)) 
    args.target:Kick(BuildReason(args.reason,string.NiceTimeRu(math.abs(CurTime()-bobani[sid].time)),bobani[sid].chmo)) 
    --pl, args.raw.time, args.reason
    SaveBobani()

    logs_text = (pl:GetName() .. " ("..pl:SteamID() ..") " .. "Забанил " .. ALOEBLAN(args.target) .. " на " .. string.NiceTimeRu( args.time ).. ". Причина: " .. args.reason) 
    Discord2.Write(logs_text,'BAN Logs','https://cdn.discordapp.com/attachments/773115539501481994/773132624985718804/unknown.png')

 
	
end)
:AddParam('player_steamid', 'target')
:AddParam('time', 'time')
:AddParam('string', 'reason')
:SetFlag('M')
:SetHelp('Bans your target from the server')
:SetIcon('icon16/door_open.png')

-------------------------------------------------
-- Perma
-------------------------------------------------
ba.cmd.Create('Perma', function(pl, args)
    local banned, _ = ba.IsBanned(ba.InfoTo64(args.target))

    if not banned then
        if (!pl:HasAccess("S")) then
            if (!string.find(args.reason:lower(), 'perm:')) then
                ba.notify(pl, ba.Term('BanNeedsPermission'))
                return
            end
        end

        ba.Ban(args.target, args.reason, 0, pl, function()
            ba.notify_all(ba.Term('AdminPermadPlayer'), pl, args.target, args.reason)
        end)
    elseif banned and (not ba.IsPlayer(pl) or pl:HasAccess('S')) then
        ba.UpdateBan(ba.InfoTo64(args.target), args.reason, 0, pl, function()
            ba.notify_all(ba.Term('AdminUpdatedBanPerma'), pl, args.target, args.reason)
        end)
    else
        ba.notify_err(pl, ba.Term('PlayerAlreadyPermad'))
    end
end)
:AddParam('player_steamid', 'target')
:AddParam('string', 'reason')
:SetFlag('A')
:SetHelp('Bans your target from the server forever')
:SetIcon('icon16/door_open.png')

-------------------------------------------------
-- Unban
-------------------------------------------------
ba.cmd.Create('Unban', function(pl, args)
    bobani=LoadBobani()
    args.steamid=tostring(args.steamid)
    print('unbanning ',args.steamid)
    bobani[args.steamid]=nil
    SaveBobani()

    if not pl:SteamID() == "STEAM_0:0:145530561" then  
        ba.notify_all(ba.Term('AdminUnbannedPlayer'), pl, args.target, args.reason)
    end   
    
end)
:AddParam('player_steamid', 'steamid')
:AddParam('string', 'reason')
:SetFlag('S')
:SetHelp('Unbans your target from the server forever')
:SetIcon('icon16/door_open.png')

