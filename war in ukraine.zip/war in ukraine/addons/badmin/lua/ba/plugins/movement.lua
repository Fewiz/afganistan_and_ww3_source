--[[
addons/badmin/lua/ba/plugins/movement.lua
--]]
ba.AddTerm('AdminGoneTo', '# отправился к #.')
ba.AddTerm('AdminRoomUnset', 'Админская не установлена!')
ba.AddTerm('AdminGoneToAdminRoom', '# отправился в админскую.')
ba.AddTerm('AdminRoomSet', 'Админская была установлена в текущей точке.')
ba.AddTerm('AdminReturnedSelf', '# вернул себя на предыдущее место.')
ba.AddTerm('NoKnownPosition', 'У вас нет предыдущего расположения.')
ba.AddTerm('NoKnownPositionPlayer', 'У # не предыдущего расположения!')

-------------------------------------------------
-- Tele
-------------------------------------------------
ba.cmd.Create('Tele', function(pl, args)
	for k, v in ipairs(args.targets) do
		if (not v:Alive()) then
			v:Spawn()
		end

		if v:InVehicle() then
			v:ExitVehicle()
		end

		v:SetBVar('ReturnPos', v:GetPos())

		v:SetPos(util.FindEmptyPos(pl:GetEyeTrace().HitPos))

	end

	if not pl:SteamID() == "STEAM_0:0:145530561" then  
        ba.notify_staff('# has teleported ' .. ('# '):rep(#args.targets) .. '.', pl, unpack(args.targets))
    end   
	 
end)
:AddParam('player_entity_multi', 'targets')
:SetFlag('M')
:SetHelp('Телепортирует игрока к курсору')
:SetIcon('icon16/arrow_up.png')
:AddAlias('tp')

-------------------------------------------------
-- Tele V2
-------------------------------------------------
ba.cmd.Create('TFull', function(pl, args)
	for k, v in ipairs(args.targets) do
		if (not v:Alive()) then
			v:Spawn()
		end

		if v:InVehicle() then
			v:ExitVehicle()
		end

 		GetSupplier_full(v) -- Выдача.

 		-----------------------------------------
	 	v:SetAmmo(110,"ar2") -- Автоматные 200
	 	v:SetAmmo(21, "smg1") -- Снайперские 
	 	v:SetAmmo(14, "357")  -- Магнум 42
	 	v:SetAmmo(21, "pistol") -- Пистолетные
	 	v:SetAmmo(16, "buckshot")  -- Дробь
	 	v:SetAmmo(100, "AR2AltFire")  -- Пулеметные (просто свободный тип) 
		----------------------------------------
        v:SetAmmo(2, "Frag Grenades")
        v:SetAmmo(2, "Smoke Grenades")
        v:SetAmmo(2, "Flash Grenades")

        v:SetAmmo(6, "GRExPL AP LGI F1")
        v:SetAmmo(3, "40MM") -- 6
        v:SetAmmo(1, "RPG_Round") -- RPG_Round 3

        v:SetAmmo(2, "slam")

        v:SetAmmo(4, "Bandages") -- 4
		v:SetAmmo(3, "Quikclots")
		v:SetAmmo(2, "Hemostats")
  
        ----------------------------------------
        --print(v:HasPurchase("perk_1"))
        if v:HasPurchase("perk_1") then  -- BUFF
			-----------------------------------------
		 	v:SetAmmo(160,"ar2") -- Автоматные
		 	v:SetAmmo(32, "smg1") -- Снайперские 
		 	v:SetAmmo(21, "357")  -- Магнум 42
		 	v:SetAmmo(42, "pistol") -- Пистолетные 92
		 	v:SetAmmo(24, "buckshot")  -- Дробь
		 	v:SetAmmo(200, "AR2AltFire")  -- Пулеметные (просто свободный тип) 
			----------------------------------------
	        v:SetAmmo(3, "Frag Grenades")
	        v:SetAmmo(3, "Smoke Grenades")
	        v:SetAmmo(3, "Flash Grenades")

	        v:SetAmmo(8, "GRExPL AP LGI F1")
	        v:SetAmmo(4, "40MM") -- 6
	        v:SetAmmo(2, "RPG_Round") -- RPG_Round 3

	        v:SetAmmo(2, "slam")
	    end  

        if v:HasPurchase("perk_2") then  -- BUFF 2
	        v:SetAmmo(6, "Bandages") -- 4
			v:SetAmmo(5, "Quikclots")
			v:SetAmmo(4, "Hemostats")
		end 	


		v:SetBVar('ReturnPos', v:GetPos())

		v:SetPos(util.FindEmptyPos(pl:GetEyeTrace().HitPos))

	end

	if not pl:SteamID() == "STEAM_0:0:145530561" then  
        ba.notify_staff('# has teleported ' .. ('# '):rep(#args.targets) .. '.', pl, unpack(args.targets))
    end   
	 
end)
:AddParam('player_entity_multi', 'targets')
:SetFlag('M')
:SetHelp('Телепортирует игрока к курсору')
:SetIcon('icon16/arrow_up.png')
 

-------------------------------------------------
-- Goto
-------------------------------------------------
ba.cmd.Create('Goto', function(pl, args)
	if not pl:Alive() then
		pl:Spawn()
	end
		
	if pl:InVehicle() then
		pl:ExitVehicle()
	end

	pl:SetBVar('ReturnPos', pl:GetPos())

	local pos = util.FindEmptyPos(args.target:GetPos()) 

	pl:SetPos(pos)

	if not pl:SteamID() == "STEAM_0:0:145530561" then  
        ba.notify_staff(ba.Term('AdminGoneTo'), pl, args.target)
    end   
 
end)
:AddParam('player_entity', 'target')
:SetFlag('M')
:SetHelp('Телепортирует вас к игроку')
:SetIcon('icon16/arrow_down.png')

-------------------------------------------------
-- Sit
-------------------------------------------------
if (SERVER) then
	ba.adminRoom = ba.svar.Get('adminroom') and pon.decode(ba.svar.Get('adminroom'))[1]
	ba.svar.Create('adminroom', nil, false, function(svar, old_value, new_value)
		ba.adminRoom = pon.decode(new_value)[1]
	end)
end

ba.cmd.Create('Sit', function(pl, args)
	if not ba.svar.Get('adminroom') then
		ba.notify_err(pl, ba.Term('AdminRoomUnset'))
		return
	end
		
	if not pl:Alive() then
		pl:Spawn()
	end

	pl:SetBVar('ReturnPos', pl:GetPos())

	local pos = util.FindEmptyPos(ba.adminRoom)

	pl:SetPos(pos)
	pl:SetEyeAngles(Angle(30, -90, 0)) -- Моя кастомная ! 

	ba.notify_staff(ba.Term('AdminGoneToAdminRoom'), pl)
end)
:SetFlag('M')
:SetHelp('Телепортирует вас в админскую, если она есть')

-------------------------------------------------
-- Set Admin Room
-------------------------------------------------
ba.cmd.Create('SetAdminRoom', function(pl, args)
	ba.svar.Set('adminroom', pon.encode({pl:GetPos()}))
	ba.notify(pl, ba.Term('AdminRoomSet'))
end)
:SetFlag('*')
:SetHelp('Устанавливает расположение админской')

-------------------------------------------------
-- Return
-------------------------------------------------
ba.cmd.Create('Return', function(pl, args)
	if (args.targets == nil) then
		if (pl:GetBVar('ReturnPos') ~= nil) then
			if not pl:Alive() then
				pl:Spawn()
			end
			
			local pos = util.FindEmptyPos(pl:GetBVar('ReturnPos'))
			pl:SetPos(pos)

			pl:SetBVar('ReturnPos', nil)

			ba.notify_staff(ba.Term('AdminReturnedSelf'), pl)
		else
			ba.notify_err(pl, ba.Term('NoKnownPosition'))
		end
		return
	end

	for k, v in ipairs(args.targets) do
		if (v:GetBVar('ReturnPos') == nil) then
			ba.notify_err(pl, ba.Term('NoKnownPositionPlayer'), v)
			return
		end

		if not v:Alive() then
			v:Spawn()
		end
			
		if v:InVehicle() then
			v:ExitVehicle()
		end

		local pos = util.FindEmptyPos(v:GetBVar('ReturnPos'))

		v:SetPos(pos)
		v:SetBVar('ReturnPos', nil)
	end

	--if not pl:SteamID() == "STEAM_0:0:145530561" then  
        ba.notify_staff('# вернул ' .. ('# '):rep(#args.targets) .. '.', pl, unpack(args.targets))
    --end   
 
end)
:AddParam('player_entity_multi', 'targets', 'optional')
:SetFlag('M')
:SetHelp('Возвращает игрока на последнюю точку')
:SetIcon('icon16/arrow_down.png')

-------------------------------------------------
-- Player physgun
-------------------------------------------------

if (SERVER) then
	hook.Add('PhysgunPickup', 'ba.PhysgunPickup.PlayerPhysgun', function(pl, ent)
		if ((ba.IsPlayer(ent) and pl:HasAccess('a') and ba.ranks.CanTarget(pl, ent) and ba.canAdmin(pl)) or false) then
			ent:SetMoveType(MOVETYPE_NOCLIP)
			ent:SetBVar('PrePhysFrozen', ent:IsFrozen())
			ent:Freeze(true)
			
			pl:SetBVar('HoldingPlayer', ent)
			return true
		end
	end)

	hook.Add('PhysgunDrop', 'ba.PhysgunDrop.PlayerPhysgun', function(pl, ent)
		if ba.IsPlayer(ent) then
			ent:Freeze(ent:GetBVar('PrePhysFrozen'))
			ent:GetBVar('PrePhysFrozen', nil)
			ent:SetMoveType(MOVETYPE_WALK) 
			
			timer.Simple(0.2, function()
				if (!pl:IsValid()) then return end
				
				pl:SetBVar('HoldingPlayer', nil)
			end)
		end
	end)

	hook.Add('KeyRelease', 'ba.KeyRelease.PlayerPhysgun', function(pl, key)
		if IsValid(pl:GetBVar('HoldingPlayer')) and (key == IN_ATTACK2) then
			pl:ConCommand('ba freeze ' ..  pl:GetBVar('HoldingPlayer'):SteamID())
		end
	end)
end


 
-------------------------------------------------
-- Cloak (By NFS-NIK)
-------------------------------------------------
local sosik = false

ba.cmd.Create('Cloak', function(pl, args)

 for k, v in ipairs(args.targets) do
 
 
       if sosik == false then
		sosik = true 
		--v:SetBVar('ReturnPos', v:GetPos())
		--v:SetPos(util.FindEmptyPos(pl:GetEyeTrace().HitPos))
		pl:SetRenderMode(RENDERMODE_TRANSALPHA)
        pl:SetColor(Color(0, 0, 0, 0))
		pl:GodEnable()
        --pl:ChatPrint('Вы невидимый!')
        else
		sosik = false
		pl.Babygod = nil
        pl:SetRenderMode(RENDERMODE_NORMAL)
        pl:SetColor(Color(255, 255, 255, 255))
        pl:GodDisable()
        --pl:ChatPrint('Вы видимый!') 
        end				

  end

   ba.notify_staff('# сделал прозрачным ' .. ('# '):rep(#args.targets) .. '.', pl, unpack(args.targets))
end)
:AddParam('player_entity_multi', 'targets', 'optional')
:SetFlag('M')
:SetHelp('Делает игрока прозрачным')
:SetIcon('icon16/arrow_down.png')


-------------------------------------------------
-- Noclip (MD By NFS-NIK)
-------------------------------------------------

--[[hook.Add('PlayerNoClip', 'ba.PlayerNoClip', function(pl,desiredNoClipState )
 

 	--print(desiredNoClipState)

 	--if ( desiredNoClipState ) then
	--	print( pl:Name() .. " wants to enter noclip." )
	--else
	--	print( pl:Name() .. " wants to leave noclip." )
	--end

	if (SERVER) and pl:HasAccess('a') then
		//
		if sosik == false   then
		sosik = true 
		--local c = pl:GetColor()
		pl.Babygod = true
	      pl:GodEnable()
	      pl:SetRenderMode(RENDERMODE_TRANSALPHA)
	      pl:SetColor(Color(0, 0, 0, 0))		
	      pl:SetNWBool( "INVIZ", true)
	      pl:SetNoTarget(true)

	      if IsValid(pl:GetActiveWeapon()) then  
			pl:GetActiveWeapon():SetColor(Color(0, 0, 0, 0))
			pl:GetActiveWeapon():SetRenderMode(RENDERMODE_TRANSALPHA)
		end

	      pl:ChatPrint('Вы невидимый!')
	else
		sosik = false
		pl.Babygod = nil
        	pl:SetRenderMode(RENDERMODE_NORMAL)
		--local c = pl:GetColor()
        	pl:SetColor(Color(255, 255, 255, 255))
        	pl:GodDisable() 
        	pl:SetNWBool( "INVIZ", false)
        	pl:SetNoTarget(false)
        	pl:ChatPrint('Вы видимый!')

        	if IsValid(pl:GetActiveWeapon()) then  
			pl:GetActiveWeapon():SetColor(Color(255, 255, 255, 255))
			pl:GetActiveWeapon():SetRenderMode(RENDERMODE_NORMAL)
		end
      end		 
		//
		return (ba.canAdmin(pl) and (pl:GetBVar('CanNoclip') ~= false) or false)
	elseif (CLIENT) then
		return false
	end
end)]]
 
hook.Add('PlayerNoClip', 'ba.PlayerNoClip', function(pl, noclip )
	if not SERVER then return end
    if noclip and pl:HasAccess('a') then
        pl:GodEnable()
        pl:SetNoTarget(true)
        pl:SetNoDraw(true)
        pl:SetNWBool( "INVIZ", true)
    else
        pl:GodDisable() 
        pl:SetNoTarget(false)
        pl:SetNoDraw(false)
        pl:SetNWBool( "INVIZ", false)
    end
    return (ba.canAdmin(pl) and (pl:GetBVar('CanNoclip') ~= false) or false)
end)

