--[[
addons/badmin/lua/ba/plugins/motd.lua
--]]
ba.AddTerm('MOTDSet', 'Сообщение дня было изменено на "#".')


