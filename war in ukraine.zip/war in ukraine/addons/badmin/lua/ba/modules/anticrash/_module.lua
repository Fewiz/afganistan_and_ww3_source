--[[
addons/badmin/lua/ba/modules/anticrash/_module.lua
--]]
ba.Module('Anticrash')
	:Author('aStonedPenguin')
	:Include('main_sh.lua')

