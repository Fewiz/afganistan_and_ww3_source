--[[
addons/badmin/lua/ba/modules/notifications/legacy_cl.lua
--]]
surface.CreateFont("GModNotify", {size = 22, weight = 350, antialias = true, extended = true, font = "Roboto Condensed"})

NOTIFY_GENERIC	= 0
NOTIFY_ERROR	= 1
NOTIFY_UNDO		= 2
NOTIFY_HINT		= 3
NOTIFY_CLEANUP	= 4

module("notification", package.seeall)

xoff = ScrW() - 20 - 300
width = 300

local padding = 16

hook.Run("notification")

local LegacyColor = {
	[NOTIFY_GENERIC]	= Color(255,128,51,155),
	[NOTIFY_ERROR]	    = Color(225,0,0,155),
	[NOTIFY_UNDO]	    = Color(51,128,255,155),
	[NOTIFY_HINT]		= Color(0,215,15,155),
	[NOTIFY_CLEANUP]	= Color(51,128,255,155)
}
local ourcolor = Color(0,215,15,155)

Notices = Notices or {}
table.Empty(Notices)

function AddProgress(uid, text)
	error "unsupported"
end

function Kill(uid)
	error "unsupported"
end

local margintop = 4

function AddLegacy(text, type, length)
	--if (type == nil) then
		--type = 0
	--end

    type = type or 0
	text = text:sub(1, 1) == "#" and language.GetPhrase(text:sub(2)) or text

	local notice = {
        text = string.Wrap('GModNotify', text, width - padding * 2),
		--text = DarkRP.textWrap(text, "GModNotify", width - padding * 2):Split("\n"),
		type = type,
		start = SysTime(),
		length = length,
		alpha = 0,
	}
 
	notice.lines = #notice.text
	notice.maxheight = margintop + notice.lines * 22 + padding * 2
	notice.curheight = 0

	--notice.type = type,
	surface.PlaySound("server/ui/click.mp3") -- Балдежные звуки в нотифи =)
	return table.insert(Notices, 1, notice)
end

hook.Remove("Think", "NotificationThink")

hook.Add("HUDPaint", "Notices", function()
	if !LocalPlayer():Alive() then return end
	
	surface.SetFont("GModNotify")
	surface.SetAlphaMultiplier(1)

	local oy = 15 -- 15

	for k, v in pairs(Notices) do
		v.curheight = Lerp(RealFrameTime() * 10, v.curheight, SysTime() < (v.start + v.length) and v.maxheight or 0)

		if SysTime() >= (v.start + v.length) and v.curheight < 1 then
			table.remove(Notices, k)
			continue
		end

		local timeleft = v.start - (SysTime() - v.length)

		do
			local x, y, w, h = notification.xoff, oy, width, v.curheight
			surface.SetDrawColor(ColorAlpha(color_black, 70))
			surface.DrawRect(x, y, w, h)
            
            --local color = notifyTypes[self.NotifyType] or ourcolor
            --local color = Color(25,25,25,150)
            --local color = LegacyColor[v.NotifyType] or ourcolor
           
            local color = LegacyColor[v.type] or ourcolor

			surface.SetDrawColor(color)
			surface.DrawRect(x + 2, y + 2, w - 4, h - 4)
			
			render.SetScissorRect(x, y, x + w, y + h, true)
		end

		for i, l in pairs(v.text) do
			local x = notification.xoff + padding
			local y = oy + padding + (i-1) * 22 -- 22

			surface.SetTextColor(color_black)
			surface.SetTextPos(x + 1, y + 1)
			surface.DrawText(l)

			surface.SetTextColor(color_white)
			surface.SetTextPos(x, y)
			surface.DrawText(l)
		end

		render.SetScissorRect(0, 0, 0, 0, false)

		oy = oy + v.curheight + margintop
	end
end)

--vgui.Register('NoticePanel', PANEL, 'Panel')
vgui.Register("NoticePanel", {Init = function(self) self:Remove() end}, "Panel")



