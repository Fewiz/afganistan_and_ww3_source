--[[
addons/badmin/lua/ba/modules/notifications/_module.lua
--]]
ba.Module('Notifications')
	:Author('aStonedPenguin')
	:Include('legacy_cl.lua')

