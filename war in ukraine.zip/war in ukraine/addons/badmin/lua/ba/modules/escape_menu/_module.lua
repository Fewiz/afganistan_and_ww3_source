--[[
addons/badmin/lua/ba/modules/escape_menu/_module.lua
--]]
ba.Module('Escape Menu')
	:Author('thelastpenguin')
	:Include('main_cl.lua')
	:CustomCheck(function() -- disabled
		return false
	end)

