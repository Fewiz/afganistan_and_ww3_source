--[[
addons/badmin/lua/ba/modules/darkrp/misc_sh.lua
--]]
ba.AddTerm('YourVIPRestored', 'Ваш VIP статус был восстановлен!')
ba.AddTerm('PlayerJoinedSteamGroup', '# получил 300 монет за вход в нашу группу! Введите !steam чтобы вступить.')

