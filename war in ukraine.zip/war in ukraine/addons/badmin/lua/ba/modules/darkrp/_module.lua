--[[
addons/badmin/lua/ba/modules/darkrp/_module.lua
--]]
ba.Module 'DarkRP'
	:Author 'aStonedPenguin'
	:SetGM 'DarkRP'
	:Include {
		'commands_sh.lua',

		'misc_sv.lua',
		'misc_sh.lua',

		'sod/sod_sv.lua',

		'fullserver_sh.lua',

		'logs/loghooks_sh.lua',
		--'logs/nlr_sv.lua',
		--'logs/nlr_sh.lua',

		'bans/bans_sh.lua',
		'bans/bans_sv.lua',

		'jail/jail_sh.lua',
		'jail/jail_sv.lua',
	}

