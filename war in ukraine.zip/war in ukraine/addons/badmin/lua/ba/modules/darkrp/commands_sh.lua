--[[
addons/badmin/lua/ba/modules/darkrp/commands_sh.lua
--]]
ba.AddTerm('EntityNoOwner', 'This entity has no owner.')
ba.AddTerm('CannotUnown', 'You cannot unown this door.')
ba.AddTerm('EntityOwnedBy', '# owns this entity.')
ba.AddTerm('AdminUnownedYourDoor', '# force unowned your door.')
ba.AddTerm('AdminUnownedPlayerDoor', '# force unowned #\'s door.')
ba.AddTerm('AdminChangedYourJob', '# has force changed your job to #.')
ba.AddTerm('AdminChangedPlayerJob', '# has force changed #\'s job to #.')
ba.AddTerm('JobNotFound', 'Job # not found!')
ba.AddTerm('AdminUnwantedYou', '# has force unwanted you.')
ba.AddTerm('AdminUnwantedPlayer', '# has force unwanted #.')
ba.AddTerm('PlayerNotWanted', '# is not wanted!')
ba.AddTerm('AdminUnarrestedYou', '# has force unarrested you.')
ba.AddTerm('AdminUnarrestedPlayer', '# принудительно снял аррест с #.')
ba.AddTerm('PlayerNotArrested', '# не арестован!')
ba.AddTerm('AdminUnwarrantedYou', '# принудительно снял розыск с вас.')
ba.AddTerm('AdminUnwarrantedPlayer', '# принудительно снял розыск с #.')
ba.AddTerm('PlayerNotWarranted', '# не разыскивается!')
ba.AddTerm('EventInvalid', '# не является верным ивентом!')
ba.AddTerm('AdminStartedEvent', '# начал ивент # для #.')
ba.AddTerm('AdminFrozePlayersProps', '# заморозил пропы #.')
ba.AddTerm('AdminFrozeAllProps', '# заморозил все пропы.')
ba.AddTerm('PlayerVoteInvalid', 'Игрок # не голосовал!')
ba.AddTerm('AdminDeniedVote', '# запретил голос #.')
ba.AddTerm('AdminDeniedTeamVote', '# запретил голос команде #.')
ba.AddTerm('AdminAddedYourMoney', '# добавил $# в ваш кошелёк.')
ba.AddTerm('AdminAddedMoney', 'Вы добавили $# в кошелёк #.')
ba.AddTerm('AdminAddedYourCredits', '# добавил # кредитов на ваш аккаунт.')
ba.AddTerm('AdminAddedCredits', 'Вы добавили # кредитов на аккаунт игрока #.')
ba.AddTerm('AdminMovedPlayers', 'Пермещено # игроков на другой сервер.')
ba.AddTerm('PlayerNotFound', 'Не могу найти игрока #.')

ba.cmd.Create('Go', function(pl, args)
	local ent = pl:GetEyeTrace().Entity
	if IsValid(ent) and (ent:CPPIGetOwner() or ent.ItemOwner) then
		ba.notify(pl, ba.Term('EntityOwnedBy'), (ent:CPPIGetOwner() or ent.ItemOwner))
	else
		ba.notify_err(pl, ba.Term('EntityNoOwner'))
	end
end)
:SetFlag('U')
:SetHelp('Shows the owner of a prop')

ba.cmd.Create('Unown', function(pl, args)
	local ent = pl:GetEyeTrace().Entity
	if IsValid(ent) and ent:IsDoor() and ent:DoorGetOwner() then
		ba.notify(ent:DoorGetOwner(), ba.Term('AdminUnownedYourDoor'), pl)
		ba.notify_staff(ba.Term('AdminUnownedPlayerDoor'), pl, ent:DoorGetOwner())
		ent:DoorUnOwn()
	else
		ba.notify_err(pl, ba.Term('CannotUnown'))
	end
end)
:SetFlag('M')
:SetHelp('Принудительно снимает с двери владельца')

ba.cmd.Create('Setjob', function(pl, args)
	for k, v in ipairs(rp.teams) do
		if string.find(v.name:lower(), args.name:lower()) then
			ba.notify(args.target, ba.Term('AdminChangedYourJob'), pl, v.name)
			ba.notify_staff(ba.Term('AdminChangedPlayerJob'), pl, args.target, v.name)
			if not args.target:Alive() then
				args.target:Spawn()
			end
			args.target:ChangeTeam(k, true)
			args.target:Spawn()
			return
		end
	end
	ba.notify_err(pl, ba.Term('JobNotFound'), args.name)
end)
:AddParam('player_entity', 'target')
:AddParam('string', 'name')
:SetFlag('A')
:SetHelp('Принудительно изменяет работу игрока')

ba.cmd.Create('Force Unwant', function(pl, args)
	if args.target:IsWanted() then
		ba.notify(args.target, ba.Term('AdminUnwantedYou'), pl)
		ba.notify_staff(ba.Term('AdminUnwantedPlayer'), pl, args.target)
		args.target:UnWanted(pl, false)
	else
		ba.notify_err(pl, ba.Term('PlayerNotWanted'), args.target)
	end
end)
:AddParam('player_entity', 'target')
:SetFlag('A')
:SetHelp('Принудительно снимает розыск с игрока')
:AddAlias('funwant')

ba.cmd.Create('Force Unarrest', function(pl, args)
	if args.target:IsArrested() then
		ba.notify(args.target, ba.Term('AdminUnarrestedYou'), pl)
		ba.notify_staff(ba.Term('AdminUnarrestedPlayer'), pl, args.target)
		args.target:UnArrest(pl, false)
	else
		ba.notify_err(pl, ba.Term('PlayerNotArrested'), args.target)
	end
end)
:AddParam('player_entity', 'target')
:SetFlag('A')
:SetHelp('Принудительно отпускает игрока из-под арреста')
:AddAlias('funarrest')

ba.cmd.Create('Force UnWarrant', function(pl, args)
	if args.target:IsWarranted() then
		ba.notify(args.target, ba.Term('AdminUnwarrantedYou'), pl)
		ba.notify_staff(ba.Term('AdminUnwarrantedPlayer'), pl, args.target)
		args.target:UnWarrant(pl)
	else
		ba.notify_err(pl, ba.Term('PlayerNotWarranted'), args.target)
	end
end)
:AddParam('player_entity', 'target')
:SetFlag('A')
:SetHelp('Принудительно снимает игрока')
:AddAlias('funwarrant')

ba.cmd.Create('Start Event', function(pl, args)
	local event = string.lower(args.event)
	if (rp.Events[event] == nil) then
		ba.notify_err(pl, ba.Term('EventInvalid'), event)
	else
		rp.StartEvent(event, args.time)
		ba.notify_all(ba.Term('AdminStartedEvent'), pl, event, args.raw.time)
	end
end)
:AddParam('string', 'event')
:AddParam('time', 'time')
:SetFlag('G')
:SetHelp('Запускает ивенты')

ba.cmd.Create('Freeze Props', function(pl, args)
	if IsValid(args.target) then
		ba.notify_staff(ba.Term('AdminFrozePlayersProps'), pl, args.target)
		for k, v in ipairs(ents.GetAll()) do
	        if IsValid(v) and v:IsProp() and (v:CPPIGetOwner() == args.target) then
	            local phys = v:GetPhysicsObject()
	            if IsValid(phys) then
	                phys:EnableMotion(false)
	            end
	            constraint.RemoveAll(v)
	        end
	    end
	else
		ba.notify_staff(ba.Term('AdminFrozeAllProps'), pl)
		for k, v in ipairs(ents.GetAll()) do
	        if IsValid(v) and v:IsProp() then
	            local phys = v:GetPhysicsObject()
	            if IsValid(phys) then
	                phys:EnableMotion(false)
	            end
	            constraint.RemoveAll(v)
	        end
	    end
	end
end)
:AddParam('player_entity', 'target', 'optional')
:SetFlag('A')
:SetHelp('Замораживает все пропы')

ba.cmd.Create('Deny Vote', function(pl, args)
	if (not rp.VoteExists(args.target)) then
		ba.notify_err(pl, ba.Term('PlayerVoteInvalid'), args.target)
	else
		GAMEMODE.vote.DestroyVotesWithEnt(args.target)
		ba.notify_staff(ba.Term('AdminDeniedVote'), pl, args.target)
	end
end)
:AddParam('player_entity', 'target')
:SetFlag('M')
:SetHelp('Запрещает голосование для игрока')

ba.cmd.Create('Deny Team Vote', function(pl, args)
	if (!rp.teamVote.Votes[args.target]) then
		ba.notify_err(pl, ba.Term('PlayerVoteInvalid'), args.target)
	else
		rp.teamVote.Votes[args.target] = nil
		for k, v in ipairs(rp.teams) do
			if (v.name == args.target) then
				v.CurVote = nil
			end
		end
		ba.notify_staff(ba.Term('AdminDeniedTeamVote'), pl, args.target)
	end
end)
:AddParam('string', 'target')
:SetFlag('M')
:SetHelp('Запрещает голосование для команды')
--[[ 
ba.cmd.Create('Donate')
:RunOnClient(function()
	gui.OpenURL(rp.cfg.CreditsURL .. "?sid=" .. LocalPlayer():SteamID())
end)
:SetFlag('U')
:SetHelp('Opens our credit shop')
:AddAlias('shop')

]]
ba.cmd.Create('Add Money', function(pl, args)
	args.target:AddMoney(tonumber(args.amount))
	ba.notify(args.target, ba.Term('AdminAddedYourMoney'), pl, args.amount)
	ba.notify(pl, ba.Term('AdminAddedMoney'), args.amount, args.target)
end)
:AddParam('player_entity', 'target')
:AddParam('string', 'amount')
:SetFlag('*')
:SetHelp('Даёт игроку деньги')

ba.cmd.Create('Add Credits', function(pl, args)
	if ba.IsPlayer(args.target) then
		args.target:AddCredits(args.amount, 'Выдал ' .. pl:NameID(), function()
			ba.notify(args.target, ba.Term('AdminAddedYourCredits'), pl, args.amount)
		end)
	else
		rp.data.AddCredits(ba.InfoTo32(args.target), tonumber(args.amount), 'Выдал ' .. pl:NameID())
	end
	ba.notify(pl, ba.Term('AdminAddedCredits'), args.target, args.amount)
end)
:AddParam('player_steamid', 'target')
:AddParam('string', 'amount')
:SetFlag('*')
:SetHelp('Даёт игроку кредиты')

if (SERVER) then util.AddNetworkString('Pocket.Inspect') end
ba.cmd.Create('View Pocket', function(pl, args)
	net.Start('Pocket.Inspect')
		net.WriteEntity(args.target)
		net.WriteTable(rp.inv.Data[args.target:SteamID64()] or {})
	net.Send(pl)
end)
:AddParam('player_entity', 'target')
:SetFlag('A')
:SetHelp('Показывает, что у игрока в карманах')


local moveCmdCategories = {
	['afk'] = function(pl) return (pl:IsAFK()) end,
	['banned'] = function(pl) return pl:IsBanned() end,
	['dead'] = function(pl) return !pl:Alive() end,
	['all'] = function() return true end
}
ba.cmd.Create('Move', function(ply, args)
	local str = args["Category/Player/Evaluator"]
	local cat = str:lower()
	local eval
	
	if (moveCmdCategories[cat]) then
		eval = moveCmdCategories[cat]
		
		local count = 0
		for k, v in ipairs(player.GetAll()) do
			if (eval(v)) then
				count = count + 1
				
				v:SendLua([[LocalPlayer():ConCommand('connect ]] .. info.AltServerIP .. [[')]])
			end
		end
		
		ba.notify(ply, ba.Term('AdminMovedPlayers'), tostring(count))
	else
		local targ = ba.FindPlayer(str)
		
		if (targ) then
			targ:SendLua([[LocalPlayer():ConCommand('connect ]] .. info.AltServerIP .. [[')]])
			return
		else
			ba.notify(ply, ba.Term('PlayerNotFound'), str)
		end
	end
end)
:AddParam('string', 'Category/Player/Evaluator')
:SetFlag('*')
:SetHelp('Перекидывает игроков на другой сервер. Категории: ' .. table.ConcatKeys(moveCmdCategories, ', ') .. '.')

