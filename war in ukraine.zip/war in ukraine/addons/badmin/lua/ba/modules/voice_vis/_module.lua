--[[
addons/badmin/lua/ba/modules/voice_vis/_module.lua
--]]
ba.Module('Voice Visualizers')
	:Author('aStonedPenguin')
	:Include('init_cl.lua')

