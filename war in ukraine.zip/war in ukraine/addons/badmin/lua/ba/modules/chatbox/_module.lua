--[[
addons/badmin/lua/ba/modules/chatbox/_module.lua
--]]
ba.Module('Chatbox')
	:Author('KingOfBeast, Updated by aStonedPenguin')
	:Include({
		'vgui_cl.lua',
		'init_cl.lua',
		'init_sh.lua',
		'detour_sv.lua'
	})

