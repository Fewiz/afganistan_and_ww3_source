--[[
addons/badmin/lua/ba/modules/chatbox/init_sh.lua
--]]
nw.Register 'IsTyping'
	:Write(net.ReadBool)
	:Read(net.WriteBool)
	:SetPlayer()

function PLAYER:IsTyping()
	return self:GetNetVar('IsTyping') or false
end


