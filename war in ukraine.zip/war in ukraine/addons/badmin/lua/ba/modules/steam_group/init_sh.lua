--[[
addons/badmin/lua/ba/modules/steam_group/init_sh.lua
--]]
ba.cmd.Create('Steam')
:RunOnClient(function(args)
	gui.OpenURL('http://steamcommunity.com/gid/103582791434605559/')
	timer.Simple(30, function()
		RunConsoleCommand('sgr', 'request')
	end)
end)
:SetHelp('Открывает нашу группу стима')

