--[[
addons/badmin/lua/ba/modules/steam_group/_module.lua
--]]
ba.Module('Steam Group Request')
	:Author('KingOfBeast Updated by aStonedPenguin')
	:Include({
		'init_cl.lua',
		'init_sh.lua',
		'init_sv.lua',
	})

