--[[
addons/badmin/lua/ba/modules/ipb4_sync/_module.lua
--]]
ba.Module('IPB Group Sync')
	:Author('aStonedPenguin')
	:Include('init_sv.lua')

