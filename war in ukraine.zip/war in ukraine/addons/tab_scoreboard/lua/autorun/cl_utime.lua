--[[
addons/tab_scoreboard/lua/autorun/cl_utime.lua
--]]
-- Written by Team Ulysses, http://ulyssesmod.net/
module( "Utime", package.seeall )
if not CLIENT then return end
 
local gpanel 
 
--Now convars!
local utime_enable = CreateClientConVar( "utime_enable", "1.0", true, false )
local utime_outsidecolor_r = CreateClientConVar( "utime_outsidecolor_r", "256.0", true, false )
local utime_outsidecolor_g = CreateClientConVar( "utime_outsidecolor_g", "256.0", true, false )
local utime_outsidecolor_b = CreateClientConVar( "utime_outsidecolor_b", "256.0", true, false )
local utime_outsidetext_r = CreateClientConVar( "utime_outsidetext_r", "0.0", true, false )
local utime_outsidetext_g = CreateClientConVar( "utime_outsidetext_g", "0.0", true, false )
local utime_outsidetext_b = CreateClientConVar( "utime_outsidetext_b", "0.0", true, false )
 
local utime_insidecolor_r = CreateClientConVar( "utime_insidecolor_r", "256.0", true, false )
local utime_insidecolor_g = CreateClientConVar( "utime_insidecolor_g", "256.0", true, false )
local utime_insidecolor_b = CreateClientConVar( "utime_insidecolor_b", "256.0", true, false )
local utime_insidetext_r = CreateClientConVar( "utime_insidetext_r", "0", true, false )
local utime_insidetext_g = CreateClientConVar( "utime_insidetext_g", "0", true, false )
local utime_insidetext_b = CreateClientConVar( "utime_insidetext_b", "0", true, false )
 
local utime_pos_x = CreateClientConVar( "utime_pos_x", "0.0", true, false )
local utime_pos_y = CreateClientConVar( "utime_pos_y", "0.0", true, false )
  
function resetCvars()
		RunConsoleCommand( "utime_outsidecolor_r", "0" )
		RunConsoleCommand( "utime_outsidecolor_g", "150" )
		RunConsoleCommand( "utime_outsidecolor_b", "245" )
	   
		RunConsoleCommand( "utime_outsidetext_r", "255" )
		RunConsoleCommand( "utime_outsidetext_g", "255" )
		RunConsoleCommand( "utime_outsidetext_b", "255" )
	   
		RunConsoleCommand( "utime_insidecolor_r", "250" )
		RunConsoleCommand( "utime_insidecolor_g", "250" )
		RunConsoleCommand( "utime_insidecolor_b", "245" )
	   
		RunConsoleCommand( "utime_insidetext_r", "0" )
		RunConsoleCommand( "utime_insidetext_g", "0" )
		RunConsoleCommand( "utime_insidetext_b", "0" )
	   
		RunConsoleCommand( "utime_pos_x", "98" )
		RunConsoleCommand( "utime_pos_y", "8" )
		buildCP( controlpanel.Get( "Utime" ) )
end
concommand.Add( "utime_reset", resetCvars )
 
function buildCP( cpanel )
		cpanel:ClearControls()
		cpanel:AddControl( "Header", { Text = "UTime by Megiddo (Team Ulysses)" } )
		cpanel:AddControl( "Checkbox", { Label = "Enable", Command = "utime_enable" }  )
		cpanel:AddControl( "Slider", { Label = "Позиция X", Command = "utime_pos_x", Type = "Float", Min = "0", Max = "100" }	)
		cpanel:AddControl( "Slider", { Label = "Позиция Y", Command = "utime_pos_y", Type = "Float", Min = "0", Max = "100" }	)	   
		cpanel:AddControl( "Color", { Label = "Outside Color", Red = "utime_outsidecolor_r", Green = "utime_outsidecolor_g", Blue = "utime_outsidecolor_b", ShowAlpha = "0", ShowHSV = "1", ShowRGB = "1", Multiplier = "255" }	 )
		cpanel:AddControl( "Color", { Label = "Outside Text Color", Red = "utime_outsidetext_r", Green = "utime_outsidetext_g", Blue = "utime_outsidetext_b", ShowAlpha = "0", ShowHSV = "1", ShowRGB = "1", Multiplier = "255" }  )
		cpanel:AddControl( "Color", { Label = "Inside Color", Red = "utime_insidecolor_r", Green = "utime_insidecolor_g", Blue = "utime_insidecolor_b", ShowAlpha = "0", ShowHSV = "1", ShowRGB = "1", Multiplier = "255" }	 )
		cpanel:AddControl( "Color", { Label = "Inside Text Color", Red = "utime_insidetext_r", Green = "utime_insidetext_g", Blue = "utime_insidetext_b", ShowAlpha = "0", ShowHSV = "1", ShowRGB = "1", Multiplier = "255" }  )	   
		cpanel:AddControl( "Button", { Text = "Сброс", Label = "Reset colors and position", Command = "utime_reset" } )
end
 
 

