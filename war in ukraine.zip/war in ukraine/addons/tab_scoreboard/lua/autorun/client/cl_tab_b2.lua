--[[
addons/tab_scoreboard/lua/autorun/client/cl_tab_b2.lua
--]]
 
local tab_SCORE_BOARD2 = {
	Init = function( self )
 	end 
}

tab_SCORE_BOARD2 = vgui.RegisterTable( tab_SCORE_BOARD2, "EditablePanel" )



hook.Add('ScoreboardShow', 'tab_scoreboard2_show2', function()
	--if ( !IsValid( tab_scoreboard2 ) ) then
		tab_scoreboard2 = vgui.CreateFromTable( tab_SCORE_BOARD2 )
	--end
	
	if ( IsValid( tab_scoreboard2 ) ) then
		tab_scoreboard2:Show()
		//////
		--print("open")
		--RunConsoleCommand("cl_drawhud", 0)  
		RunConsoleCommand("mcompass_enabled", "1")
		RunConsoleCommand("atmoshud_enabled", "1")
		//////
		--tab_scoreboard2:MakePopup()
		--tab_scoreboard2:SetKeyboardInputEnabled( false )
	end
	return true
end)



hook.Add('ScoreboardHide', 'tab_scoreboard2_hide2', function()
	
	-- На будущее, а то щас виснет ;p
 
	
	if ( IsValid( tab_scoreboard2 ) ) then
		tab_scoreboard2:Hide()
		tab_scoreboard2 = nil
		//////
		--print("close")
		--RunConsoleCommand("cl_drawhud", 1)  
		RunConsoleCommand("mcompass_enabled", "0")
		RunConsoleCommand("atmoshud_enabled", "0")
		//////
	end
	
	 
	return true
end)
 

