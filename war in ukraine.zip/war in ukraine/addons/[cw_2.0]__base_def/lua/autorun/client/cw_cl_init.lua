--[[
addons/[cw_2.0]__base_def/lua/autorun/client/cw_cl_init.lua
--]]
include("cw/client/cw_clientmenu.lua")
include("cw/client/cw_hud.lua")
include("cw/client/cw_umsgs.lua")
include("cw/client/cw_hooks.lua")
include("cw/client/cw_statdisplay.lua")
include("cw/client/cw_iv_message.lua")

