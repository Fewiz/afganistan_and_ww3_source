--[[
addons/[cw_2.0]_rpg/lua/autorun/rpg7particles.lua
--]]
AddCSLuaFile("autorun/rpg7particles.lua")

game.AddParticles("particles/rpg7_particles.pcf")

PrecacheParticleSystem("rpg7_smoke_full")
PrecacheParticleSystem("rpg7_muzzle_full")
PrecacheParticleSystem("rpg7_sparks")
PrecacheParticleSystem("rpg7_explosion_full")

