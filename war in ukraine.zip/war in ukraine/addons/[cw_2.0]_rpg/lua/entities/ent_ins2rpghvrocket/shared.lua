--[[
addons/[cw_2.0]_rpg/lua/entities/ent_ins2rpghvrocket/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.Author = "Spy"
ENT.Spawnable = false
ENT.AdminSpawnable = false 

if CLIENT then
killicon.Add( "ent_ins2rpghvrocket", "vgui/inventory/weapon_rpg7", Color(255, 80, 0, 0))
end

