--[[
addons/[cw_2.0]_rpg/lua/cw/shared/attachments/ins2_atow_dudrocket.lua
--]]
local att = {}
att.name = "ins2_atow_dudrocket"
att.displayName = "Неисправная Ракета"
att.displayNameShort = "DEF"
att.isBG = true

att.statModifiers = {}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/rpg7aloha")
	att.description = {[1] = {t = "Стандартная боеголовка с поврежденной ракетой.", c = CustomizableWeaponry.textColors.NEUTRAL},
	[2] = {t = "Траектория редко совпадают из-за неисправностей боеголовки.", c = CustomizableWeaponry.textColors.NEGATIVE}}
	
end

function att:attachFunc()
self:unloadWeapon()
end

function att:detachFunc()
self:unloadWeapon()
end

CustomizableWeaponry:registerAttachment(att)


