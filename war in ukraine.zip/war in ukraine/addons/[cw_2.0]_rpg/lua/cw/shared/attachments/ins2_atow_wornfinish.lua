--[[
addons/[cw_2.0]_rpg/lua/cw/shared/attachments/ins2_atow_wornfinish.lua
--]]
local att = {}
att.name = "ins2_atow_wornfinish"
att.displayName = "Изношенный расскрас"
att.displayNameShort = "Скин"
att.isBG = true

att.statModifiers = {}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/wornfinish")
end

function att:attachFunc()
	if SERVER then
		return
	end

	if self.CW_VM then
		self.CW_VM:SetSkin(2)
	end
end

function att:detachFunc()
	if SERVER then
		return
	end

	if self.CW_VM then
		self.CW_VM:SetSkin(0)
	end
end

CustomizableWeaponry:registerAttachment(att)

