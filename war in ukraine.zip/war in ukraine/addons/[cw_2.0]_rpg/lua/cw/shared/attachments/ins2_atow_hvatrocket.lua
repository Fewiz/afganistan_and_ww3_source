--[[
addons/[cw_2.0]_rpg/lua/cw/shared/attachments/ins2_atow_hvatrocket.lua
--]]
local att = {}
att.name = "ins2_atow_hvatrocket"
att.displayName = "ОГ-7В" -- HVAT Боеголовка
att.displayNameShort = "ОГ-7В"
att.isBG = true
att.SpeedDec = 4

att.statModifiers = {DamageMult = .265,
ReloadSpeedMult = -.09}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/rpg7hvat")
	att.description = {[1] = {t = "Высокоскоростная противотанковая боеголовка.", c = CustomizableWeaponry.textColors.POSITIVE}, -- Высокоскоростная противотанковая зарядная боеголовка.
	[2] = {t = "Выше урон по транспорту.", c = CustomizableWeaponry.textColors.POSITIVE}} -- Гораздо выше урон и скорость  
	
end

function att:attachFunc()
	self:setBodygroup(self.WarheadBGs.main, self.WarheadBGs.hvat)
	self:unloadWeapon()
end

function att:detachFunc()
	self:setBodygroup(self.WarheadBGs.main, self.WarheadBGs.heat)
	self:unloadWeapon()
end

CustomizableWeaponry:registerAttachment(att)


