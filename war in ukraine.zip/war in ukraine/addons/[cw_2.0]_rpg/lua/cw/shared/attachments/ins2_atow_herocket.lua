--[[
addons/[cw_2.0]_rpg/lua/cw/shared/attachments/ins2_atow_herocket.lua
--]]
local att = {}
att.name = "ins2_atow_herocket"
att.displayName = "ПГ-7ВЛ" -- FRAG Боеголовка
att.displayNameShort = "ПГ-7ВЛ"
att.isBG = true
att.SpeedDec = 5

att.statModifiers = {--DamageMult = -.398,
ReloadSpeedMult = -.15}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/rpg7frag")
	att.description = {[1] = {t = "Противопехотный осколочный заряд.", c = CustomizableWeaponry.textColors.POSITIVE},
	[2] = {t = "Осколки увеличивают радиус поражения.", c = CustomizableWeaponry.textColors.POSITIVE},
	[3] = {t = "Траектория хуже и урон от взрыва меньше.", c = CustomizableWeaponry.textColors.NEGATIVE}}
end

function att:attachFunc()
	self:setBodygroup(self.WarheadBGs.main, self.WarheadBGs.he)
	self:unloadWeapon()
end

function att:detachFunc()
	self:setBodygroup(self.WarheadBGs.main, self.WarheadBGs.heat)
	self:unloadWeapon()
end

CustomizableWeaponry:registerAttachment(att)


