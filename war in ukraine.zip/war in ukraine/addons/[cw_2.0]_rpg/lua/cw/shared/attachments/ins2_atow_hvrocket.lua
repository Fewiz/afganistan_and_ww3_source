--[[
addons/[cw_2.0]_rpg/lua/cw/shared/attachments/ins2_atow_hvrocket.lua
--]]
local att = {}
att.name = "ins2_atow_hvrocket"
att.displayName = "HV Боеголовка"
att.displayNameShort = "HV"
att.isBG = true
att.SpeedDec = -3

att.statModifiers = {DamageMult = -.333,
ReloadSpeedMult = .09}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/rpg7hv")
	att.description = {[1] = {t = "Эффективна для пробивания легкой брони", c = CustomizableWeaponry.textColors.POSITIVE},
	[2] = {t = "Хорошо держит траекторию.", c = CustomizableWeaponry.textColors.POSITIVE},
	[3] = {t = "Меньшает радиус взрыва и урона.", c = CustomizableWeaponry.textColors.NEGATIVE}}
	
end

function att:attachFunc()
	self:setBodygroup(self.WarheadBGs.main, self.WarheadBGs.hv)
	self:unloadWeapon()
end

function att:detachFunc()
	self:setBodygroup(self.WarheadBGs.main, self.WarheadBGs.heat)
	self:unloadWeapon()
end

CustomizableWeaponry:registerAttachment(att)


