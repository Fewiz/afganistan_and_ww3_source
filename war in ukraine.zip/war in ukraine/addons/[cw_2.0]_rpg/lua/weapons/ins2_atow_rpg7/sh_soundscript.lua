--[[
addons/[cw_2.0]_rpg/lua/weapons/ins2_atow_rpg7/sh_soundscript.lua
--]]

SWEP.Sounds = {
	base_draw = {
		{time = 0, sound = "INS2SHARED_DRAW"},
	},
	
	base_reload = {
		{time = 5/33.5, sound = "INS2RPG7_FETCH"},
		{time = 81/33.5, sound = "INS2RPG7_LOAD1"},
		{time = 101/33.5, sound = "INS2RPG7_LOAD2"},
		{time = 140/33.5, sound = "INS2RPG7_RATTLE"},
	}
}


