--[[
addons/[content_fo]_cigarette_swep/lua/weapons/weapon_ciga_cheap.lua
--]]

-- Сигареты SWEP by Mordestein (based on Vape SWEP by Swamp Onions)

if CLIENT then
	include('weapon_ciga/cl_init.lua')
else
	include('weapon_ciga/shared.lua')
end

SWEP.PrintName = "Сигара Беломорканал"

SWEP.Instructions = "ЛКМ: Курить дешевые сигареты"

SWEP.ViewModel = "models/mordeciga/mordes/oldcigshib.mdl"
SWEP.WorldModel = "models/mordeciga/mordes/oldcigshib.mdl"

SWEP.cigaID = 3

SWEP.cigaAccentColor = Vector(1,1,1.1)


