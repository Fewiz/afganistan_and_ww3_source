--[[
addons/equipment_supplier/lua/entities/equipment_ak103_start/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "АК-103 (Полигон)"
ENT.Category = "Оружейная"
ENT.Spawnable = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool",1,"Enabled")
end


