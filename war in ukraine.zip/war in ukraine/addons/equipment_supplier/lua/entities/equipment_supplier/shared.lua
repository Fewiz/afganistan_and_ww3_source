--[[
addons/equipment_supplier/lua/entities/equipment_supplier/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Оружейная"
ENT.Category = "Другое"
ENT.Spawnable = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool",1,"Enabled")
end


