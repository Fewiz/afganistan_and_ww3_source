--[[
addons/equipment_supplier/lua/entities/armor_1/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Броня 1"
ENT.Category = "Другое"
ENT.Spawnable = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool",1,"Enabled")
end


