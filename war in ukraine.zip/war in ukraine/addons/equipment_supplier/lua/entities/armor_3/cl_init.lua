--[[
addons/equipment_supplier/lua/entities/armor_3/cl_init.lua
--]]
include("shared.lua")

surface.CreateFont( "Font_Weapons", {
    font = "DermaLarge",
    size = 80,
    weight = 750
} )

surface.CreateFont( "Font_Weapons_Small", {
    font = "DermaLarge",
    size = 55,
    weight = 450
} )

-- Colors
local white = Color( 255, 255, 255, 255 )
local grey = Color( 130, 130, 130, 200 )
local white_grey = Color( 200, 200, 200, 235 )
local red = Color( 130, 30, 3, 235 )
local background = Color( 30, 30, 50, 245 )

--Pos
local frame_x = ScrW()*.19
local frame_y = ScrH()*.2
local frame_w = 800
local frame_h = 600

local get_button_x = frame_x*.002
local get_button_y = frame_y*.003
local get_button_w = 239
local get_button_h = 70

local select_button_x = 1
local select_button_y = 481
local select_button_w = frame_w*.998
local select_button_h = 118


function ENT:Draw()
	self.Entity:DrawModel()
    
	--[[local pos = self:GetPos() + (self:GetAngles():Forward() * -7) + (self:GetAngles():Up() * 50) -- 62.5 -- Высота
 	local ang = self:GetAngles()-------------* 0------ Вперед/Назад ------------------ Вверх/Низ

	ang:RotateAroundAxis(self:GetAngles():Forward(), 90) -- 
	ang:RotateAroundAxis(self:GetAngles():Up(), 90)  -- Боковой Наклон
	
 	cam.Start3D2D(pos, Angle(ang.p, ang.y, ang.r0), 0.113) -- Размер
	
	--local alpha = 255
	 if math.floor((LocalPlayer():GetPos():Distance(self:GetPos()))) < 500 then
		surface.SetDrawColor( 0, 0, 0, 150 )
		surface.DrawRect( -225, -60, 450, 100 ) -- ( -200, -100, 400, 178 )
		--surface.SetDrawColor( Color( 204,255,0 ))
		--surface.DrawOutlinedRect( -225, -60, 450, 100 )  -- ( -200, -100, 400, 178 )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( -225, 40, 450, 5 )  -- Белая линия

		draw.SimpleText( "Оружейная", "Font_Weapons", 1, -55, Color( 255,255,255 ), 1, 0 )
     end
	cam.End3D2D()]]

end

