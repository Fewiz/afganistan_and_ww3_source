--[[
addons/equipment_supplier/lua/entities/armor_2/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Броня 2"
ENT.Category = "Другое"
ENT.Spawnable = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool",1,"Enabled")
end


