--[[
addons/equipment_supplier/lua/entities/food_npc/shared.lua
--]]
ENT.Type = "ai"
ENT.Base = "base_ai"
ENT.PrintName = "Выдача еды"
ENT.Category = "Другое"
ENT.Spawnable = true
ENT.AutomaticFrameAdvance = true
ENT.AdminOnly = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool",1,"Enabled")
end

ENT.RenderGroup = RENDERGROUP_TRANSLUCENT


