--[[
addons/fastpl/lua/autorun/client/cl_start.lua
--]]
local ButtonGreenColor1 = Color( 0, 255, 0, 255 )
local ButtonGreenColor2 = Color( 0, 255, 0, 128 )

local ButtonRedColor1 = Color( 255, 0, 0, 255 )
local ButtonRedColor2 = Color( 255, 0, 0, 128 )

local ButtonGenerateColor1 = Color( 255, 255, 0, 255 )
local ButtonGenerateColor2 = Color( 255, 255, 0, 128 )

_G.OpenStartMenu =function()
    local alpha = math.abs( math.cos( CurTime() * 1 ) )
    local pan_w, pan_h = ScrW() * .4, ScrW() * .4

    local frame = vgui.Create( "DFrame" )
    frame:SetSize( ScrW() * 0.9, ScrH() * 0.9 )
    frame:SetTitle( "" ) -- "Афганистан РП" 
    frame:SetIcon( "" ) -- icon16/gun.png
    frame:Center()
    frame:MakePopup()
    frame:ShowCloseButton(false)

    function frame:Paint( w, h )
        Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
        surface.SetDrawColor( 36,37,43 )
        surface.DrawRect( 0, 0, w, h )
    end
     
    local sheet = vgui.Create( "DPropertySheet", frame )
    sheet.tabScroller:SetOverlap( -8 )
    sheet:Dock( FILL )


    local ButtonBG1 = vgui.Create( "DButton", sheet ) -- СССР
    ButtonBG1:SetText( "" ) 
    ButtonBG1:SetPos( 0,0 )
    ButtonBG1:SetSize( ScrW() * 0.45, ScrH() * 0.9 )
    ButtonBG1.Paint = function( self, w, h )    
        if ButtonBG1.Hovered then
            surface.SetDrawColor( 255, 0, 0, 16 )
        else 
            surface.SetDrawColor( 0, 0, 0, 0 )
        end
        surface.DrawRect( 0, 0, w, h )
    end


    local ButtonBG2 = vgui.Create( "DButton", sheet ) -- СССР
    ButtonBG2:SetText( "" ) 
    ButtonBG2:SetPos( ScrW() * 0.45,0 )
    ButtonBG2:SetSize( ScrW() * 0.45, ScrH() * 0.9 )
    ButtonBG2.Paint = function( self, w, h )    
        if ButtonBG2.Hovered then
            surface.SetDrawColor( 255, 200, 0, 16 )
        else 
            surface.SetDrawColor( 0, 0, 0, 0 )
        end
        surface.DrawRect( 0, 0, w, h )
    end

    function sheet:Paint( w, h )
        surface.SetDrawColor( 0, 0, 0, 128 )
        surface.DrawRect( 0, 0, w, h )
        surface.SetDrawColor( 255, 255, 255, 16 )
        surface.DrawLine( 0, 0, w, 0 )
     
        
        surface.SetDrawColor( 255, 0, 0, 45 )
        surface.DrawRect( 0, 0, w*2.1, h ) -- СССР
        
        surface.SetDrawColor( 255, 200, 0, 45 )
        surface.DrawRect( ScrW() * 0.45, 0, w*2.1, h ) -- Душманы
     
        surface.SetDrawColor( 255, 255, 255, 255 )
        
        local join_ussr_list = surface.GetTextureID("gui/join_rus_list")   
        surface.SetTexture(join_ussr_list)
    	surface.DrawTexturedRect(ScrW() * 0.045, ScrH() * 0.05, w/2.5, h/2.2)
    	
    	local join_dux_list = surface.GetTextureID("gui/join_usa_list")   
        surface.SetTexture(join_dux_list)
    	surface.DrawTexturedRect(ScrW() * 0.5, ScrH() * 0.05, w/2.4, h/2.1)
        //
        
        local join_ussr = surface.GetTextureID("gui/join_rus")  -- cw2/gui/gradient    addons\cw_2.0_base\materials\cw2\gui
        surface.SetTexture(join_ussr)
    	surface.DrawTexturedRect(ScrW() * 0.020, ScrH() * 0.45, w/2.2, h/2.2)  -- 90  
        local join_dux = surface.GetTextureID("gui/join_usa")
        surface.SetTexture(join_dux)
    	surface.DrawTexturedRect(ScrW() * 0.47,  ScrH() * 0.45, w/2.2, h/2.2)  -- 90  
    	
    	//
     	
    end
 

    ////////////////////////////////////////////
    local SB1 = 1
    local SB2 = 1
    local Button = vgui.Create( "DButton", sheet ) -- СССР
    Button:SetText( "Стать Солдатом РФ!" ) 
    Button:SetPos( 0,0 )
    Button:SetSize( ScrW() * 0.45, 30 )
    Button.Paint = function( self, w, h )    
        if Button.Hovered or ButtonBG1.Hovered then
            if SB1 == 1 then 
                surface.PlaySound("garrysmod/ui_hover.wav")
                SB1 = 0 SB2 = 1
            end     
            surface.SetDrawColor( 255, 0, 0, 255 )
        else 
            surface.SetDrawColor( 255, 0, 0, 128 )
        end
        surface.DrawRect( 0, 0, w, h )
    end
    Button.DoClick=function()
        --surface.PlaySound("garrysmod/ui_hover.wav")

        --ui.StringRequest_ussr('Выберите имя вашему персонажу', 'Вы сможете поменять ник в будущем', '', function(a)
             --rp.RunCommand('dropmoney', tostring(a))
        --end)
        RunConsoleCommand("join_1")

        frame:Close()
    end 

     

 


        local Button = vgui.Create( "DButton", sheet ) -- Душманы
        Button:SetText( "Стать Солдатом США!" ) 
        Button:SetPos( ScrW() * 0.45,0 )
        Button:SetSize( ScrW() * 0.45, 30 )
        Button.Paint = function( self, w, h )    
            --surface.SetDrawColor( 255, 200, 0, 128 )
            --surface.DrawRect( 0, 0, w, h )
            if Button.Hovered or ButtonBG2.Hovered then
                if SB2 == 1 then 
                    surface.PlaySound("garrysmod/ui_hover.wav")
                    SB1 = 1 SB2 = 0
                end     
                surface.SetDrawColor( 255, 200, 0, 255 )
            else 
                surface.SetDrawColor( 255, 200, 0, 128 )
            end
            surface.DrawRect( 0, 0, w, h )
        end

        //////////////////////////////
        Button.DoClick=function()  
            surface.PlaySound("garrysmod/ui_hover.wav")
            --OpenStartMenu_dux()

            --ui.StringRequest_dux('Выберите имя вашему персонажу', 'Вы сможете поменять ник в будущем', '', function(a)
                --rp.RunCommand('dropmoney', tostring(a))
            --end)

            RunConsoleCommand("join_2")

            frame:Close()
        end
 





end

 

