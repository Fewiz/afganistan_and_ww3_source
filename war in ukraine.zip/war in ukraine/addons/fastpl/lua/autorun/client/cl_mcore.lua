--[[
addons/fastpl/lua/autorun/client/cl_mcore.lua
--]]
--
hook.Add("Initialize", "NoExploitsPleaseCL", function( ply )
    concommand.Remove( "lua_run_cl" )
    concommand.Remove( "lua_openscript_cl" )

    concommand.Remove( "rcon_password" )
    concommand.Remove( "rcon" )
end)
--

concommand.Add("show_pos",function()
    local pos=LocalPlayer():GetPos()
    print("Vector("..math.floor(pos.x)..","..math.floor(math.floor(pos.y))..","..math.floor(math.floor(pos.z))..")")
end)

concommand.Add("_F7_Press",function()
    RunConsoleCommand("say","!wl") 
end)

local function PlayerBindNoclip(ply, bind, pressed)
    if string.find(bind, "ulx noclip") then 
        if pressed then
        RunConsoleCommand("noclip")
        end
        return true
    end
end
hook.Add( "PlayerBindPress", "PlayerBindNoclip", PlayerBindNoclip )
 
 
//////////////////////////////////////////////////////////////////////

hook.Add( "DrawPhysgunBeam", "DrawPhysgunBeamAdm", function( ply, wep, enabled, target, bone, deltaPos )
        return false
end )

hook.Add("IGS.Loaded", "changecategory", function()
	local ENT = scripted_ents.Get("npc_igs")
	ENT.Category = "Другое"
	scripted_ents.Register(ENT, "npc_igs")
end)

//////////////////////////////////////////////////////////////////////
    RunConsoleCommand("physgun_wheelspeed", 10)
    RunConsoleCommand("mat_bloomscale", "1")  -- от засветов
       
    RunConsoleCommand("cl_simfphys_althud","0")  -- дефолтный худ для симф

    RunConsoleCommand("cl_simfphys_frontlamps","0")  -- Фары
    RunConsoleCommand("cl_simfphys_rearlamps","0")   -- Фары

    RunConsoleCommand("cw_customhud","0") -- Офаем худ CW2
     
     
     
    RunConsoleCommand("gmod_mcore_test", "16")
    RunConsoleCommand("studio_queue_mode", "1")
    
    //// Из Хлиба, перенос ////
    RunConsoleCommand("cl_interp", "0.2") -- 0.116700  0.3
    RunConsoleCommand("cl_interp_ratio", "2")
    RunConsoleCommand("cl_updaterate", "16")
    RunConsoleCommand("cl_cmdrate", "16")
    RunConsoleCommand("cl_phys_props_enable", "0")
    RunConsoleCommand("cl_phys_props_max", "0")
    RunConsoleCommand("props_break_max_pieces", "0")
    RunConsoleCommand("r_propsmaxdist", "100")
    RunConsoleCommand("violence_agibs", "0")
    RunConsoleCommand("violence_hgibs", "0")
    RunConsoleCommand("cl_threaded_bone_setup", "1")
    RunConsoleCommand("cl_threaded_client_leaf_system", "1")
    RunConsoleCommand("r_threaded_client_shadow_manager", "1")
    RunConsoleCommand("r_threaded_particles", "1")
    RunConsoleCommand("r_threaded_renderables", "1")
    RunConsoleCommand("r_queued_ropes", "1")
    RunConsoleCommand("mat_queue_mode", "-1")
    RunConsoleCommand("r_decals", "250")
    RunConsoleCommand("mat_specular", "0")
    RunConsoleCommand("mat_disable_bloom", "1")
    RunConsoleCommand("r_WaterDrawReflection", "0")
    RunConsoleCommand("r_drawmodeldecals", "0")
    RunConsoleCommand("cl_smooth", "0")
    RunConsoleCommand("mat_parallaxmap", "0")
    RunConsoleCommand("mat_hdr_level", "0")
    /////////////////////////////
    RunConsoleCommand( "r_fastzreject", "-1" )

    RunConsoleCommand( "cl_show_splashes", "0" )
    RunConsoleCommand( "cl_ejectbrass", "0" )
    RunConsoleCommand( "cl_detailfade", "800" )
    RunConsoleCommand( "cl_detaildist", "1" )
  --[[
    RunConsoleCommand( "mat_parallaxmap", "0" )
    RunConsoleCommand( "mat_picmip", "2" )
    RunConsoleCommand( "mat_specular", "0" )
    RunConsoleCommand( "mat_softwarelighting", "1" )
    RunConsoleCommand( "mat_mipmaptextures", "0" )
    RunConsoleCommand( "mat_filtertextures", "0" )
    RunConsoleCommand( "mat_filterlightmaps", "0" )
    RunConsoleCommand( "mat_clipz", "0" )
    RunConsoleCommand( "mat_bumpmap", "0" )
    RunConsoleCommand( "mat_compressedtextures", "1" ) 
    RunConsoleCommand( "r_decal_cullsize", "1" )
    RunConsoleCommand( "r_drawflecks", "0" )
    RunConsoleCommand( "r_dynamic", "0" )
    --RunConsoleCommand( "r_lod", "0" )
    RunConsoleCommand( "r_waterforceexpensive", "0" )
    RunConsoleCommand( "r_cheapwaterend", "1" )
    RunConsoleCommand( "dsp_enhance_stereo", "0" )
    RunConsoleCommand( "ai_expression_optimization", "0" )]]

    RunConsoleCommand("mcompass_enabled", 0)
    RunConsoleCommand("atmoshud_posx", 135)
    RunConsoleCommand("atmoshud_posy", 139)
    RunConsoleCommand('cl_tfa_hud_crosshair_enable_custom',"0")
    RunConsoleCommand('cl_tfa_hud_enabled',"0")  


    RunConsoleCommand('enable_thirdperson',"1")

    
    RunConsoleCommand("cl_rope_maxlength", 500)
    RunConsoleCommand("cl_rope_solid_bait", 0) 
//////////////////////////////////////////////////////////////////////
 
system.FlashWindow()
 

 

