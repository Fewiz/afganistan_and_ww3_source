--[[
addons/fastpl/lua/autorun/client/cl_hud.lua
--]]
surface.CreateFont('KeyCaps', {
    font = 'Roboto Regular',
    size = 24,
    weight = 300,
    extended = true,
    antialias = true
})

surface.CreateFont('KeyCaps_big', {
    font = 'Roboto Regular',
    size = 35,
    weight = 300,
    extended = true,
    antialias = true
})

surface.CreateFont('KeyCaps_mini', {
    font = 'Roboto Regular',
    size = 20,
    weight = 300,
    extended = true,
    antialias = true
})

surface.CreateFont('KeyCaps_mini2', {
    font = 'Roboto Regular',
    size = 12,
    weight = 500,
    extended = true,
    antialias = true
})


surface.CreateFont('KeyCaps_mini3', {
    font = 'Roboto Regular',
    size = 22,
    weight = 500,
    extended = true,
    antialias = true
})

surface.CreateFont('KeyCaps_mini4', {
    font = 'Roboto Regular',
    size = 12,
    weight = 500,
    extended = true,
    antialias = true
})


surface.CreateFont('KeyCaps_mini_wep', {
    font = 'Roboto Regular',
    size = 16,
    weight = 500,
    extended = true,
    antialias = true
})

surface.CreateFont('KeyCaps_shadow', {
    font = 'Roboto Regular',
    size = 24,
    weight = 300,
    blursize = 3,
    extended = true,
    antialias = true
})

local yomaTBL = {
    ['bodyman_closet'] = {
        {
            key = 'E', -- Кнопка ( В квадрате )
            info = 'Переодеться' -- Текст
        },
    }, -- Энтити
    ['equipment_supplier'] = {
        {
            key = 'E',
            info = 'Взять оружие'
        },
    },

    ['mst_radio'] = {
        {
            key = 'E',
            info = 'Вкл / Выкл' -- Музыка из Радио
        },
    },

    ['equipment_supplier2'] = {
        {
            key = 'E',
            info = 'Взять оружие'
        },
    },
    ['sent_ammodispenser'] = {
        {
            key = 'E',
            info = 'Взять патроны'
        },
    },
    ['npc_igs'] = {
        {
            key = 'E',
            info = 'Посмотреть товар'
        },
    },
    ['sent_vj_fireplace'] = {
        {
            key = 'E',
            info = 'Разжечь / Потушить'
        },
    },
    ['sent_vj_fireplace2'] = {
        {
            key = 'E',
            info = 'Разжечь / Потушить'
        },
    },
    ['attachment_vendor'] = {
        {
            key = 'E',
            info = 'Взять обвесы'
        },
    },
    ['kvestor_1'] = {
        {
            key = 'E',
            info = 'Взять квест?'
        },
    },

    ['kvestor_2'] = {
        {
            key = 'E',
            info = 'Взять квест?'
        },
    },

    ['kvestor_3'] = {
        {
            key = 'E',
            info = 'Взять квест?'
        },
    },

    ['kvestor_4'] = {
        {
            key = 'E',
            info = 'Взять квест?'
        },
    },

    ['kvestor_5'] = {
        {
            key = 'E',
            info = 'Взять квест?'
        },
    },

    --['ix_vendor'] = { --	{ --		key = 'E', --		info = 'Посмотреть товар' --	}, --},
    ['prop_door_rotating'] = {
        {
            key = 'E',
            info = 'Открыть / Закрыть'
        },
    },


    --
    ['vendor'] = {
        {
            key = 'E',
            info = 'Открыть ассортимент?'
        },
    },

    ['vendor2'] = {
        {
            key = 'E',
            info = 'Открыть ассортимент?'
        },
    },

    ['vendor3'] = {
        {
            key = 'E',
            info = 'Открыть ассортимент?'
        },
    },

    ['vendor4'] = {
        {
            key = 'E',
            info = 'Запросить воздушную технику?'
        },
    },

    ['vendor5'] = {
        {
            key = 'E',
            info = 'Запросить бронетехнику?'
        },
    },

    ['vendor6'] = {
        {
            key = 'E',
            info = 'Заказать воздушную технику?'
        },
    },

    ['vendor7'] = {
        {
            key = 'E',
            info = 'Открыть ассортимент?'
        },
    },


    ['sent_vj_adminhealthkit'] = {
        {
            key = 'E',
            info = 'Вылечиться?'
        },
    },




}

local IsVehicle,Name,MaxHealth,Health,Fuel,MaxFuel
local sas = ""

local function newText(text, font, x, y, color, alignx, aligny)
    draw.SimpleText(text, font .. '_shadow', x + 1, y + 1, color_black, alignx, aligny)
    draw.SimpleText(text, font .. '_shadow', x - 1, y - 1, color_black, alignx, aligny)
    draw.SimpleText(text, font, x, y, color, alignx, aligny)
end

local function newText2(text, font, x, y, color, alignx, aligny)
    draw.SimpleText(text, font, x, y, color, alignx, aligny)
end

local function box(x, y, w, h, color)
    surface.SetDrawColor(color)
    surface.DrawRect(x, y, w, h)
    surface.SetDrawColor(30, 30, 30, 70)
    surface.DrawOutlinedRect(x, y, w, h)
end

local lerp = math.Approach

local boxsizew, boxsizeh = 28, 28
local alpha, alpha_lerp = 0, 0
local padding = -25
local down = 100

local w, h
local amount -- ! 
local owner 

local function build(key, info, amount, bool)
    alpha = 200

    surface.SetFont('KeyCaps')
    local infosizew, infosizeh = surface.GetTextSize(info)
    w, h = ScrW(), ScrH()

    alpha_lerp = lerp(alpha_lerp, bool and 255 or 0, 4) -- and 255 or 0, 2)

    newText(info, 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    box(w / 2 - boxsizew / 2 - (infosizew + boxsizew + padding) / 2, h / 2 - boxsizeh / 2 + down + (amount / 0.025), boxsizew, boxsizeh, Color( 40, 40, 40, alpha_lerp) )
    newText(key, 'KeyCaps', w / 2 - (infosizew + boxsizew + padding) / 2, h / 2 + down + (amount / 0.025), Color(231,28,92, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end


local function build_ply(ply, bool)
    if ply:GetNWBool( "INVIZ" ,false ) then return end
    alpha = 200

    surface.SetFont('KeyCaps')
    --local infosizew, infosizeh = surface.GetTextSize(info)
    w, h = ScrW(), ScrH()
    amount = 3

    alpha_lerp = lerp(alpha_lerp, bool and 255 or 0, 6) -- and 255 or 0, 2)

    newText(ply:GetName(), 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2.7 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    if (ply:InVehicle()) then return end
    newText(ply:GetJobName(), 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2.9 + down + (amount / 0.025),  ColorAlpha(ply:GetJobColor(),alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    if LocalPlayer():GetActiveWeapon():GetClass()=="fas2_ifak" then 
        if ply:Health() == 100 then 
            newText("Здоров!", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2.5 + down + (amount / 0.025),  Color(25, 200, 25, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        elseif ply:Health() > 75 then 
            newText("Легкие ранения!", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2.5 + down + (amount / 0.025),  Color(25, 155, 25, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
        elseif ply:Health() < 75 and ply:Health() > 25 then 
            newText("Ранения!", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2.5 + down + (amount / 0.025),  Color(255, 155, 25, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)   
        elseif ply:Health() < 25 and ply:Health() > 5  then 
            newText("Тяжелые ранения!", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2.5 + down + (amount / 0.025),  Color(200, 50, 25, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)   
        elseif ply:Health() < 5 then 
            newText("Критическое состояние!", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2.5 + down + (amount / 0.025),  Color(200, 25, 25, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)                  
        end 
    end 
    --newText(info, 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    --box(w / 2 - boxsizew / 2 - (infosizew + boxsizew + padding) / 2, h / 2 - boxsizeh / 2 + down + (amount / 0.025), boxsizew, boxsizeh, Color( 40, 40, 40, alpha_lerp) )
    --newText(key, 'KeyCaps', w / 2 - (infosizew + boxsizew + padding) / 2, h / 2 + down + (amount / 0.025), Color(231,28,92, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local Col = {
    Text = Color(255, 255, 255),
    TextShadow = Color(0, 0, 0),
    Rope = Color(255, 255, 255),
    BoxOutline = Color(0, 0, 0),
    BoxBackground = Color(255, 255, 255, 20),
    BoxLeft = Color(200, 0, 0,200),
    BoxRight = Color(150, 75, 0)
}

local function build_car(ent, bool)
    alpha = 200
    surface.SetFont('KeyCaps')
 
    --local infosizew, infosizeh = surface.GetTextSize(info)
    w, h = ScrW(), ScrH()
    amount = 3


    alpha_lerp = lerp(alpha_lerp, bool and 255 or 0, 4) -- and 255 or 0, 2)
    --print(ent:GetModel())
    if ent:GetModel() == "models/nova/chair_plastic01.mdl" then
        newText("Играть?", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        box(w / 2 - boxsizew / 2 - (75 + boxsizew + padding) / 2, h / 2 - boxsizeh / 2 + down + (amount / 0.025), boxsizew, boxsizeh, Color( 40, 40, 40, alpha_lerp) )
        newText("E", 'KeyCaps', w / 2 - (75 + boxsizew + padding) / 2, h / 2 + down + (amount / 0.025), Color(231,28,92, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    return end

    Name = ent:GetNWString('VName')
    MaxHealth = ent:GetMaxHealth()
    Health = ent:GetCurHealth()
    Fuel = ent:GetFuel()
    MaxFuel = ent:GetMaxFuel()
    sas = ""
    if ent:GetNWBool("carKeysVehicleLocked") then sas = " [Закрыт]" end

    owner = ent:GetNWEntity("carKeysVehicleOwner") 
    if IsValid(owner) then 
        newText(owner:GetName(), 'KeyCaps', w / 2 + boxsizew / 2, h / 2 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    else 
        newText("Нет владельца", 'KeyCaps', w / 2 + boxsizew / 2, h / 2 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end                                                                                                 -- ColorAlpha(owner:GetJobColor(),alpha_lerp)

    newText(Name .. sas, 'KeyCaps', w / 2 + boxsizew / 2, h / 2.12 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
     
    --newText("Целостность: "..Health.." / "..MaxHealth.." ("..math.floor(Health/MaxHealth*100) .."%)", 'KeyCaps', w / 2 + boxsizew / 2, h / 1.85 + down + (amount / 0.025), Color(150, 150, 150, alpha_lerp-50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)  
    --newText("Топливо: "..math.floor(Fuel).." / "..MaxFuel.." ("..math.floor(Fuel/MaxFuel*100) .."%)", 'KeyCaps', w / 2 + boxsizew / 2, h / 1.75 + down + (amount / 0.025), Color(150, 150, 150, alpha_lerp-50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 

    surface.SetDrawColor(Col.BoxOutline)
    surface.DrawOutlinedRect(w * 0.45, h / 1.9 + down + (amount / 0.025), 202, 7) -- 22 ХП
    surface.DrawOutlinedRect(w * 0.45, h / 1.85 + down + (amount / 0.025), 202, 7) -- Бензин

    surface.SetDrawColor(Color(200, 25, 0, alpha_lerp)) -- Col.BoxLeft
    surface.DrawRect((w * 0.45)+1, h / 1.9 + down + (amount / 0.025)+1, (Health/MaxHealth)*200, 5) 
    surface.SetDrawColor(Color(150, 75, 0, alpha_lerp)) -- Col.BoxRight
    surface.DrawRect((w * 0.45)+1, h / 1.85 + down + (amount / 0.025)+1, (Fuel/MaxFuel)*200, 5) 

    --newText2("Целостность: "..Health.." / "..MaxHealth.." ("..math.floor(Health/MaxHealth*100) .."%)", 'KeyCaps_mini4', w / 2 + boxsizew / 2, h / 1.9 + down + (amount / 0.025)+1, Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)  
    --newText2("Топливо: "..math.floor(Fuel).." / "..MaxFuel.." ("..math.floor(Fuel/MaxFuel*100) .."%)", 'KeyCaps_mini4', w / 2 + boxsizew / 2, h / 1.85 + down + (amount / 0.025)+1, Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 

     
    
end

local Wac_Class = ""
local function build_helic(ent, bool)
    alpha = 200
    surface.SetFont('KeyCaps')

    w, h = ScrW(), ScrH()
    amount = 0

    alpha_lerp = lerp(alpha_lerp, bool and 255 or 0, 4) -- and 255 or 0, 2)

    --local owner = ent:GetNWEntity("carKeysVehicleOwner") 
    --if IsValid(owner) then 
    --    newText(owner:GetName(), 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 2 + down + (amount / 0.025), ColorAlpha(owner:GetJobColor(),alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    --end 
    if ent:GetClass() == "wac_hc_mi8" then 
        Wac_Class = "Ми-8"
    elseif ent:GetClass() == "wac_hc_mi8+" then 
        Wac_Class = "Ми-8 HR"
    elseif ent:GetClass() == "wac_hc_mi24" then 
        Wac_Class = "Ми-24"   
    elseif ent:GetClass() == "wac_hc_littlebird_ah6" then 
        Wac_Class = "ЛитллБерд"         
    end    
    newText(Wac_Class, 'KeyCaps', w / 2 + boxsizew / 2, h / 2.15 + down + (amount / 0.025), Color(200, 200, 200, alpha_lerp), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    newText("Целостность: "..math.floor(ent:GetNWFloat('health')).." %", 'KeyCaps', w / 2 + boxsizew / 2, h / 2 + down + (amount / 0.025), Color(150, 150, 150, alpha_lerp-50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)  
     
    --newText("Целостность: "..Health.." / "..MaxHealth.." ("..math.floor(Health/MaxHealth*100) .."%)", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 1.85 + down + (amount / 0.025), Color(150, 150, 150, alpha_lerp-50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)  
    --newText("Топливо: "..math.floor(Fuel).." / "..MaxFuel.." ("..math.floor(Fuel/MaxFuel*100) .."%)", 'KeyCaps', w / 2 + boxsizew / 2 + 5, h / 1.75 + down + (amount / 0.025), Color(150, 150, 150, alpha_lerp-50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)      
    
end

local dis = 200
local dis2 = 125
hook.Add('HUDPaint', 'yoma_info_hp', function()
    local ply = LocalPlayer()
    local te = ply:GetEyeTrace().Entity

    if not IsValid(te) then
        alpha_lerp = 0
        return
    end

    if ply:InVehicle() then return end

    --print(te:GetClass())


    if ply:GetPos():DistToSqr(te:GetPos()) > (dis * dis) then return end
    if te:IsVehicle() then
        --print(te:GetModel())
        --if te:GetModel() == "models/nova/chair_plastic01.mdl" then return end
        build_car(te, true)
    end 
 
    --if te:GetClass() == "wac_hc_mi8" then
     --   build_helic(te, true)
    --end 

    if ply:GetPos():DistToSqr(te:GetPos()) > (dis2 * dis2) then return end

    if yomaTBL[te:GetClass()] then
        for k, v in pairs(yomaTBL[te:GetClass()]) do
            build(v.key, v.info, k, true)
        end
    end

    --if te:IsPlayer() then
        --print("да")
    --   build_ply(te, true)
    --end 

    

end)
 

//////////////////////////////////// HUD

local pl=LocalPlayer()

hook.Add( "HUDPaint", "CarViewInfos", function()
	--[[if !IsValid(pl) then
		pl=LocalPlayer()
		return 
	end
	if IsValid(pl:GetActiveWeapon()) and pl:GetActiveWeapon():GetClass()=="gmod_camera"  then return end
	
	local Ent = pl:GetEyeTrace().Entity

	if not IsValid( Ent ) then return end
	if not Ent:IsVehicle() then return end
	--if CarTrunk.Config.BlackList[ Ent:GetModel() ] then return end
	--if (not pl:IsCP() && !Ent:DoorOwnedBy(pl) && !Ent:DoorCoOwnedBy(pl)) then return end
	if pl:GetPos():Distance( Ent:LocalToWorld( Vector( 0,  - Ent:OBBMaxs().y, 20 ) ) ) > 300 then return end -- 20 -- print("OGO EBLAN") 
	if (pl:InVehicle()) then return end
	
	local cin = (math.sin(CurTime() * 3) + 1) / 2
	local color_white_sin = Color(255,255,255,50+255*cin)
		
	//
	local Trace = pl:GetEyeTrace().Entity
	local ent = Trace.Entity
	
	
	
	--print(ent:GetClass())
	if ent:GetClass() == "prop_vehicle_prisoner_pod" then return end
	local IsVehicle = ent:GetClass():lower() == "gmod_sent_vehicle_fphysics_base"
	local Name = ent:GetNWString('VName')
	local MaxHealth = ent:GetMaxHealth()
	local Health = ent:GetCurHealth()
	local Fuel = ent:GetFuel()
	local MaxFuel = ent:GetMaxFuel()

	local owner = ent:GetNWEntity("carKeysVehicleOwner") 
	--ocal Driver = ent:GetDriver()
	--local owner = ent:GetNWEntity("DOwner")
	//
	--if IsValid( owner:Nick() ) then 
     --
    --else
	-- PrettyText( "Владелец: "..owner:Nick(), "abs_hud", ScrW() / 2, ScrH() - 170, color_white_sin, TEXT_ALIGN_CENTER )
	--end
	---------
	local gradient = surface.GetTextureID("cw2/gui/gradient")   --("cw2/gui/gradient")
	surface.SetDrawColor(0, 0, 0, 200)
	surface.SetTexture(gradient)
	surface.DrawTexturedRect(ScrW() / 2.5, ScrH() - 180, 400, 100) 	 --  400, 75)

	--
	--surface.DrawTexturedRect(ScrW() / 2, ScrH() - 180, 200, 75)  -- 90  -- 130
	--surface.DrawTexturedRectRotated(ScrW() / 2.5, ScrH() - 120, 200, 75,180)
	---------
	local sas = ""
	if ent:GetNWBool("carKeysVehicleLocked") then sas = " [Закрыт]" end

	if IsValid(owner) then 
		--draw.SimpleText( "Владелец: " .. owner:GetName(), "esc_f", ScrW() / 2, ScrH() - 155, color_white_sin, TEXT_ALIGN_CENTER )
		draw.SimpleText( owner:GetName(), "esc_f", ScrW() / 2, ScrH() - 155, color_white_sin, TEXT_ALIGN_CENTER )
	end

	draw.SimpleText( Name..sas, "esc_f", ScrW() / 2, ScrH() - 180, color_white_sin, TEXT_ALIGN_CENTER )
	draw.SimpleText( "Целостность: "..Health.." / "..MaxHealth.." ("..math.floor(Health/MaxHealth*100) .."%)" , "esc_f", ScrW() / 2, ScrH() - 130, color_white_sin, TEXT_ALIGN_CENTER )
	--draw.SimpleText( "Топливо: "..Fuel, "abs_hud", ScrW() / 2, ScrH() - 130, color_white_sin, TEXT_ALIGN_CENTER )
	draw.SimpleText( "Топливо: "..math.floor(Fuel).." / "..MaxFuel.." ("..math.floor(Fuel/MaxFuel*100) .."%)" , "esc_f", ScrW() / 2, ScrH() - 110, color_white_sin, TEXT_ALIGN_CENTER )
	--draw.SimpleText( "Ресурсы: «Отсутствуют»", "abs_hud", ScrW() / 2, ScrH() - 90, color_white_sin, TEXT_ALIGN_CENTER ) -- Ресурсы: (в разработке...)]]
end)





-----------------------

surface.CreateFont('esc_f', {
    size = 24,
    weight = 300,
    antialias = true,
    extended = true,
    font = "Roboto Regular"
})

surface.CreateFont('esc_f2', {
    size = 33,
    weight = 300,
    antialias = true,
    extended = true,
    font = "Roboto Regular"
})

local pnl

local function CloseMenu()
	if IsValid(pnl) then
		pnl:Remove()
		pnl = nil
	end
end

local mat_logo = Material('mst.png', 'smooth mips')

local buttons = {
	{"Продолжить игру", function() CloseMenu() end},
	{"Игровой магазин", function() CloseMenu()  IGS.UI()  end},
	--{"Discrod", function()  --LocalPlayer():ConCommand([[connect  https://discord.gg/CXydx2u]])  


	--	local browser = vgui.Create("DHTML", right)
	--	browser:Dock(FILL)
	--	browser:OpenURL'https://discord.gg/CXydx2u'

	-- end},
	{"Настройки", function() CloseMenu() gui.ActivateGameUI() RunConsoleCommand("gamemenucommand", "openoptionsdialog") end},
	{"Отключиться", function() RunConsoleCommand("gamemenucommand", "disconnect") end},
	{"Выйти", function() RunConsoleCommand("gamemenucommand", "quit") end}
}

function draw.Icon( x, y, w, h, Mat, tblColor )
    surface.SetMaterial(Mat)
    surface.SetDrawColor( Color( 0, 0, 0, 230 ))
    surface.DrawTexturedRect(x + 1, y + 1, w, h)

    surface.SetMaterial(Mat)
    surface.SetDrawColor(tblColor or Color(255,255,255,255))
    surface.DrawTexturedRect(x, y, w, h)
end

local function OpenMenu()

	if IsValid(pnl) then pnl:Remove() end

	local scrw, scrh = ScrW(), ScrH()

	pnl = vgui.Create("EditablePanel")
	pnl:SetSize(scrw, scrh)
	pnl:MakePopup()
	pnl.Paint = function(self, w, h)
		draw.Blur(self, 10)
		--Derma_DrawBackgroundBlur( pnl, pnl.m_fCreateTime )
		draw.RoundedBox(0, 0, 0, w, h, Color(36,37,43, 200)) -- 30, 30, 30
		--draw.Icon( w - 245, 50, 200, 128, mat_logo, color_white )
	end

	local top = vgui.Create("EditablePanel", pnl)
	top:Dock(TOP)
	top:SetTall(pnl:GetWide() * 0.25)

	local left = vgui.Create("EditablePanel", pnl)
	left:Dock(LEFT)
	left:SetWide(200)
	left:DockMargin( pnl:GetWide() * 0.03, 0, 0, 0 )

	for k, v in pairs(buttons) do
		pnl.btn_pnl = vgui.Create("DButton", left)
		pnl.btn_pnl:SetTall(30)
		pnl.btn_pnl:Dock(TOP)
		pnl.btn_pnl:DockMargin(0, 5, 0, 0)
		pnl.btn_pnl:SetText("")
		pnl.btn_pnl.Paint = function(self, w, h)
			local color = Color(157, 157, 157)

			if self:IsDown() or self.m_bSelected then
				color = Color(150, 150, 150, 200)
			elseif self.Hovered then
				color = Color(255, 255, 255)
			end
			draw.SimpleText(v[1], "esc_f", 14, h * 0.5+1, color_black, 0, 1)
			draw.SimpleText(v[1], "esc_f", 13, h * 0.5, color, 0, 1)
			
		end
		pnl.btn_pnl.DoClick = v[2]
	end

end

hook.Add("PreRender", "sescpaemenu", function()
	if input.IsKeyDown(70) and gui.IsGameUIVisible() then
		gui.HideGameUI()
		if IsValid(pnl) then
			CloseMenu()
		else
			OpenMenu()
		end
		return true
	end
end)





-------------------------------------------------

--[[if CLIENT then 
    local function chat_menu()
         
        local menu = vgui.Create( "DFrame" )
        menu:SetPos(ScrW() * 0.025, ScrH() * 0.25 )
        menu:SetSize( ScrW() * 0.35, ScrH() * 0.26 )
        menu:SetTitle( "Быстрая покраска личного авто" ) -- Чат
        --menu:SetIcon( "icon16/gun.png" )
        --menu:Center() 
        menu:MakePopup()  
        menu.Paint=function(s,w,h)
            surface.SetDrawColor(Color(255,45,45))
            surface.DrawOutlinedRect(0, 0, w, h)
            surface.SetDrawColor(Color(45,45,45))
            surface.DrawRect(0, 0, w-1, h-1)
             
        end
 
        local Button = vgui.Create( "DButton", menu ) 
        Button:SetText( ">> Принять <<" ) 
        Button:SetPos( ScrW() * 0.01, 195 )
        Button:SetSize( ScrW() * 0.2, 30 )
        Button.Paint = function( self, w, h )    
            surface.SetDrawColor( 0, 225, 0 )
            surface.DrawRect( 0, 0, w, h )
        end	
        Button.DoClick = function()
        	menu:Close( true )	
        	surface.PlaySound("ambient/water/rain_drip3.wav")
        end		

        local Button_Cl = vgui.Create( "DButton", menu ) 
        Button_Cl:SetText( ">> Закрыть <<" ) 
        Button_Cl:SetPos( ScrW() * 0.22, 195 )
        Button_Cl:SetSize( ScrW() * 0.12, 30 )
        Button_Cl.Paint = function( self, w, h )    
            surface.SetDrawColor( 225, 0, 0 )
            surface.DrawRect( 0, 0, w, h )
        end	
        Button_Cl.DoClick = function()
        	  -----------------
        	  net.Start("car_spawn_color")
    		  net.WriteColor()
              net.SendToServer()
              -----------------
        	menu:Close( true )
        	surface.PlaySound("ambient/water/rain_drip3.wav")
        end		



        local menu_color = vgui.Create( "DButton", menu ) 
        menu_color:SetPos(5, 25)
        menu_color:SetSize(ScrW() * 0.34, ScrH() * 0.18 )
        menu_color.Paint=function(s,w,h) 
            surface.SetDrawColor(Color(75,75,75))
            surface.DrawRect(ScrW() * 0.008, 25, w, h)
        end

        local Mixer = vgui.Create("DColorMixer", menu_color)		
		Mixer:SetPalette(true)  		
		Mixer:Dock(FILL)
	    Mixer:SetAlphaBar(false) 			
	    Mixer:SetWangs(true) 			
	    Mixer:SetColor(color_white)  -- color_white
  
	    function Mixer:ValueChanged(col)
		   --mdl:SetColor(col)
	    end

    end
    if LocalPlayer():SteamID() == "STEAM_0:0:145530561" then
      chat_menu()
    end
end]]

