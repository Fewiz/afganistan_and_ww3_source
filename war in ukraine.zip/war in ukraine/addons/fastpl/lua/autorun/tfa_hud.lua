--[[
addons/fastpl/lua/autorun/tfa_hud.lua
--]]
if SERVER then
	AddCSLuaFile()
end
if LocalPlayer then
	local aalpha = 150 -- МЕНЯЙ ЭТО ДЛЯ ПОНИЖЕНИЯ/ ПОВЫШЕНИЯ ПРОЗРАЧНОСТИ 
	--Color Constants

	local BGColor = Color(10,10,10,150)

	local AccentColor = Color(225,225,225,225)

	local InactiveColor = Color(128,128,128,225)

	local DamageColor = Color(200,10,10,225)

	local ArmorChargeColor = Color(10,255,182,225)

	local ArmorDrainColor = Color(225,10,10,225)

	local HealColor = Color(10,255,182,225)

	local blurTex = Material( "pp/blurscreen" )

	--Constant Tables

	local HUDBounds = {
		['x']=1/64,
		['y']=1/64*ScrW()/ScrH()
	}

	local HiddenElements = {
		['CHudHealth']=true,
		['CHudBattery']=true,
		['CHudAmmo']=true,
		['CHudSecondaryAmmo']=true
	}

	--Text Constants

	local MoneyTextTable = {
		['text'] = "+",
		['font'] = "DermaLarge",
		['pos'] = {0,0},
		['xalign'] = TEXT_ALIGN_LEFT,
		['yalign'] = TEXT_ALIGN_CENTER,
		['color'] = AccentColor
	}
	
	
	local HealthTextTable = {
		['text'] = "+",
		['font'] = "DermaLarge",
		['pos'] = {0,0},
		['xalign'] = TEXT_ALIGN_LEFT,
		['yalign'] = TEXT_ALIGN_CENTER,
		['color'] = AccentColor
	}

	local ArmorTextTable = {
	--	['text'] = '⛨',
		['text'] = '⛊',
		['font'] = "DermaLarge",
		['pos'] = {0,0},
		['xalign'] = TEXT_ALIGN_LEFT,
		['yalign'] = TEXT_ALIGN_CENTER,
		['color'] = AccentColor
	}

	local GunTextTable = {
		['text'] = 'asdf',
		['font'] = "DermaDefault",
		['pos'] = {0,0},
		['xalign'] = TEXT_ALIGN_LEFT,
		['yalign'] = TEXT_ALIGN_TOP,
		['color'] = AccentColor
	}

	local CompassTextTable = {
		['text'] = "NN",
		['font'] = "DermaDefault",
		['pos'] = {0,0},
		['xalign'] = TEXT_ALIGN_LEFT,
		['yalign'] = TEXT_ALIGN_CENTER,
		['color'] = AccentColor
	}

	WeaponNames = {
		['weapon_crowbar'] = "Crowbar",
		['weapon_ar2'] = "Combine AR2",
		['weapon_357'] = ".357 Magnum",
		['weapon_pistol'] = "USP Match",
		['weapon_smg1'] = "H&K MP7A1",
		['weapon_slam'] = "SLAM Anti-Personel",
		['weapon_rpg'] = "RPG-9",
		['weapon_stunstick'] = "Stunstick",
		['weapon_frag'] = "Fragmentation Grenades",
		['weapon_shotgun'] = "SPAS-12",
		['weapon_bugbait'] = "Bug Bait",
		['weapon_physcannon'] = "Zero Point Energy Field Manipulator",
		['weapon_physgun'] = "Physics Gun",
		['weapon_camera'] = "Camera",
		['weapon_crossbow'] = "Resistance Crossbow",
		['weapon_hands'] = "None",
		['hands'] = "None"
	}

	local CompassDirections = {
	"NN",
	"NE",
	"EE",
	"SE",
	"SS",
	"SW",
	"WW",
	"NW"
	}
	
	--Health Fade Stuff

	local HealthColor = Color(AccentColor.r,AccentColor.g,AccentColor.b,AccentColor.a)

	local ArmorColor = Color(AccentColor.r,AccentColor.g,AccentColor.b,AccentColor.a)

	local FlashFade = 200 --Health fade per second

	local OldHealth = 100

	local OldArmor = 0

	--Bullets Code

	local BulletShiftSpeed = 1

	local BulletGravity = 1100 --Pixels per second

	local HUDBullets = {}

	local HUDBulletParticles = {}

	local BulletDefaultSprite = 'bullet'

	local WeaponBulletSpriteCache = {
		['weapon_shotgun'] = 'shotgun'
	}

	local BulletSprites = {
		['bullet'] ={
			['sprite'] = surface.GetTextureID("vgui/hud/tfa_bullet"),
			['sprite_spent'] = surface.GetTextureID("vgui/hud/tfa_bullet_spent"),
			['w'] = 8,
			['h'] = 32,
			['w_spent'] = 8,
			['h_spent'] = 24
		},
		['shotgun'] ={
			['sprite'] = surface.GetTextureID("vgui/hud/tfa_shotgun_shell"),
			['sprite_spent'] = surface.GetTextureID("vgui/hud/tfa_shotgun_shell_spent"),
			['w'] = 14,
			['h'] = 31,
			['w_spent'] = 14,
			['h_spent'] = 25
		},
		['9mm'] ={
			['sprite'] = surface.GetTextureID("vgui/hud/tfa_bullet_9mm"),
			['sprite_spent'] = surface.GetTextureID("vgui/hud/tfa_bullet_9mm_spent"),
			['w'] = 8,
			['h'] = 32,
			['w_spent'] = 8,
			['h_spent'] = 24
		}
	}

	local function WeaponIsShotgun( wep )
		if !IsValid(wep) then return false end
		
		if wep and wep.Primary and wep.Primary.Shotgun then return true end
		
		if wep.Shotgun then return true end
		
		if wep.IsShotgun then return true end
		
		if string.find(string.lower(wep.Category or ""),"shotgun") then return true end
		
		if string.find(string.lower(wep.PrintName or ""),"shotgun") then return true end
		
		if string.find(string.lower(wep:GetClass() or ""),"shotgun") then return true end
		
		if string.find(string.lower(wep.Base or ""),"shotgun") then return true end
		
		local ammotype = string.lower(wep:GetPrimaryAmmoType())
		
		if wep.Primary and wep.Primary.Ammo then
			ammotype = string.lower(wep.Primary.Ammo)
		end
		
		if string.find(string.lower(ammotype or ""),"buck") then return true end
		
		return false
	end

	local function WeaponIsPistol( wep )
		if !IsValid(wep) then return false end
		
		if wep and wep.Primary and wep.Primary.Pistol then return true end
		
		if wep.Pistol then return true end
		
		if wep.Pistol then return true end
		
		if string.find(string.lower(wep.Category or ""),"pistol") then return true end
		
		if string.find(string.lower(wep.PrintName or ""),"pistol") then return true end
		
		if string.find(string.lower(wep:GetClass() or ""),"pistol") then return true end
		
		if string.find(string.lower(wep.Base or ""),"pistol") then return true end
		
		local ammotype = string.lower(wep:GetPrimaryAmmoType())
		
		if wep.Primary and wep.Primary.Ammo then
			ammotype = string.lower(wep.Primary.Ammo)
		end
		
		if string.find(ammotype or "","9mm") or string.find(ammotype or "","pistol") then return true end
		
		return false
	end

	local function GetBulletWidth( bul )
		return BulletSprites[bul.sprite].w
	end

	local function AddHUDBullet( spritename )
		local lastx, lasty, lastbul, bul
		
		lastbul = HUDBullets[#HUDBullets]
		
		bul = {
			['sprite'] = "bullet",
			['x'] = 2,
			['y'] = 0
		}
		
		if lastbul and lastbul.x then
			bul.x = lastbul.x + GetBulletWidth(lastbul) + 1
		end
		
		if spritename then
			bul.sprite = spritename
		end
		
		table.insert(HUDBullets,#HUDBullets+1,bul)
	end

	local function TFAHudAddBulletParticle( spritev, xv, yv, velocityv, velocity_av, drag_liv, drag_av )
		local spritetbl = BulletSprites[spritev]
		local bul = {
			['sprite'] = spritev,
			['x'] = xv,
			['y'] = yv+(spritetbl.h-spritetbl.h_spent)/2,
			['velocity'] = velocityv,
			['velocity_a'] = velocity_av,
			['drag_li'] = drag_liv,
			['drag_a'] = drag_av,
			['rotation'] = 0
		}
		table.insert(HUDBulletParticles,#HUDBulletParticles+1,bul)
	end

	local function TFAHudBulletsProcess()
		local w,h = ScrW(), ScrH()

		local lastbul,targetx
		for k,v in ipairs(HUDBullets) do
			lastbul = HUDBullets[k-1]
			targetx = 2
			
			if lastbul and lastbul.x then
				targetx = lastbul.x + GetBulletWidth(lastbul)+1
			end

			if v.x>targetx then
				v.x = math.max(targetx,v.x-FrameTime()*(w/7)*BulletShiftSpeed)
			elseif v.x<targetx then
				v.x = math.min(targetx,v.x+FrameTime()*(w/7)*BulletShiftSpeed)		
			end
		end
		
		for k,v in ipairs(HUDBulletParticles) do
			v.x = v.x + v.velocity.x*FrameTime()
			v.y = v.y + v.velocity.y*FrameTime()
			v.rotation=v.rotation + v.velocity_a*FrameTime()
			v.velocity.y = v.velocity.y + BulletGravity*FrameTime()
			v.velocity.x = math.Approach(v.velocity.x,0,v.drag_li)
			v.velocity.y = math.Approach(v.velocity.y,0,v.drag_li)
			v.velocity_a = math.Approach(v.velocity_a,0,v.drag_a)
		end
		
		for k,v in ipairs(HUDBulletParticles) do
			if v.y>ScrH()+30 then
				table.remove(HUDBulletParticles,k)
			end
		end
		
	end

	local OldAmmo = -1

	local OldWeapon = nil

	--Main Code

	local function draw_circle( x, y, radius, seg )
		local cir = {}

		table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
		for i = 0, seg do
			local a = math.rad( ( i / seg ) * -360 )
			table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
		end

		local a = math.rad( 0 ) -- This is need for non absolute segment counts
		table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )

		surface.DrawPoly( cir )
	end
	
	local function TFAHudBulletsPopulate(ply, oldwep, newwep)
		table.Empty(HUDBullets)
		ply = ply and ply or LocalPlayer()
		if !IsValid(ply) then return end
		newwep = newwep and newwep or ply:GetActiveWeapon()
		if !IsValid(newwep) then return end
		local wep = newwep
		local i=0
		
		if !WeaponBulletSpriteCache[wep:GetClass()] then
			if WeaponIsShotgun(wep) then
				WeaponBulletSpriteCache[wep:GetClass()] = "shotgun"
			elseif WeaponIsPistol(wep) then
				WeaponBulletSpriteCache[wep:GetClass()] = "9mm"		
			else
				WeaponBulletSpriteCache[wep:GetClass()] = BulletDefaultSprite
			end
		end
		
		while i<wep:Clip1() do
			AddHUDBullet(WeaponBulletSpriteCache[wep:GetClass()])
			i=i+1
		end
	end

	local function DrawBlurRect(x, y, w, h, blur, passes)
		
		surface.SetDrawColor(0,0,0, aalpha)
		render.SetScissorRect(x, y, x+w, y+h, true)
			surface.DrawRect(0, 0, ScrW(), ScrH())
		render.SetScissorRect(0, 0, 0, 0, false)
		--[[
		for i = 1, passes do
			blurTex:SetFloat("$blur", blur)
			blurTex:Recompute()
		
			render.UpdateScreenEffectTexture()
			
			render.SetScissorRect(x, y, x+w, y+h, true)
				surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
			render.SetScissorRect(0, 0, 0, 0, false)
		end]]--
	end

	local function ShouldDraw()
		local ply = LocalPlayer()
		if !IsValid(ply) then return end
		if !ply:Alive() then return false end
		return ( GetConVarNumber("cl_drawhud",1) == 1 ) and true or false
	end

	local function TFAHideHud( el )
		if HiddenElements[el] then return false end
	end

local stm_int = 100
local regen = 0

--local function stmToServer(stm)
--    net.Start("NetForceStamina")
--   	net.WriteUInt(stm, 8)
--    net.SendToServer()
--end

--[[
hook.Add("PlayerTick", "Stamina_System", function(ply)
    if not ply:Alive() then return end

    if not ply:OnGround() and regen ~= 0.02 then
        regen = 0.02
    else
        if ply:IsSprinting() then
            regen = 0
        else
            regen = 0.04
        end
    end

    if stm_int < 100 then
        stm_int = stm_int + regen
        stmToServer(stm_int)
    end
end)

hook.Add("Think", "STM", function()
    local ply = LocalPlayer()
    if not ply:Alive() then return end
    if ply:InVehicle() then return end
    if not ply:OnGround() then return end
    
    local ply = LocalPlayer()

    if ply:KeyDown(IN_SPEED) and not stm_recover then
        if (input.IsKeyDown(33) or input.IsKeyDown(29) or input.IsKeyDown(11) or input.IsKeyDown(14)) then
            stm_int = math.Clamp(stm_int - 0.08, 2, 100)
            stmToServer(stm_int)
        end
    end
end) 

hook.Add("PlayerBindPress", "Input", function(ply, bind, pressed)
    if not ply:Alive() then return end
    if not ply:OnGround() then return end
    if ply:InVehicle() then return end

    if bind == "+jump" and not stm_recover then
        stm_int = math.Clamp(stm_int - 6, 2, 100)
    end
end)

hook.Add("VehicleMove", "Stamina_Vehicle", function(ply)
    if ply:InVehicle() then
        regen = 0.24
    end

    --if stm_int < 100 then
    --    stmToServer(stm_int + regen)
    --end
end)]]

	local function TFAHudDraw()
		if !ShouldDraw() then return end


		
		local ply = LocalPlayer()
		
		local w,h = ScrW(), ScrH()
		
		local xx, yy
		
		local iconx,icony
		
		local textx,texty = 19,16
		
		xx=w*HUDBounds.x
		yy=h-h*(HUDBounds.y)
		
		ss=yy-70
		DrawBlurRect( xx, ss, w/7, 20, 2, 2 )  -- мани
		local col1 = Color(255,255,255)
		local money = ply:GetMoney().. ' рублей'

		draw.DrawText( "Кошелек: "..money, "DermaDefault", xx+5, ss+3, col1, 3)  -- armor text
		 
		
		--ss = yy - 90
		--local hudStamina = stm_int
		--DrawBlurRect( xx, ss, w/7, 15, 2, 2 )
		--surface.SetDrawColor(255,255,255,200)
		--surface.DrawRect( xx + 5, ss + 5, ( w/7 - 10 ) * hudStamina / 100, 5 )
		
		///////////
		ss=yy/30
		--print( #player.GetAll() )
		--#player.GetAll()
		
		--for k, v in pairs(jobs) do
		
		--print(team.NumPlayers(k))
	
	--[[local categories = {}

    for i, data in pairs(RPExtraTeams) do
        categories[data.category] = categories[data.category] or {}
        categories[data.category][i] = data
    end
	
	local dux = 1
    for name, jobs in pairs(categories) do
	--print(categories)	 
	--print(ply:getJobTable().category)
	
	if name == "Душманы" then
	dux = dux+1
	end
	 
    end]]
	
	
  
	--print(ply:getJobTable().category)
	
		
		--end
 
	--print(team.NumPlayers())
		--DrawBlurRect( xx, ss, w/7, 20, 2, 2 )
		 
		--draw.DrawText( "ВС СССР: "..#player.GetAll().."   /   Душманов: [Нет Данных]", "DermaDefault", xx+5, ss+3, col1, 3)  -- armor text
		//////////
		
		
		
		
		
		--[[MoneyTextTable.pos = {xx+5,yy-11}
		MoneyTextTable.text =  "Руб"
		
		MoneyTextTable.font =  "DermaLarge"
		
		MoneyTextTable.xalign = TEXT_ALIGN_LEFT
		MoneyTextTable.yalign = TEXT_ALIGN_CENTER
		
		iconx,icony = draw.Text( MoneyTextTable )
		
		MoneyTextTable.pos[1] = MoneyTextTable.pos[1]+iconx+textx/2+5
		
		MoneyTextTable.pos[2] = MoneyTextTable.pos[2]-1
		
		MoneyTextTable.xalign = TEXT_ALIGN_CENTER
		MoneyTextTable.yalign = TEXT_ALIGN_CENTER
		
		MoneyTextTable.text =  tostring(math.ceil(ply:Health()))
		
		MoneyTextTable.text = string.sub(MoneyTextTable.text,1,math.min(string.len(MoneyTextTable.text),3))
		
		MoneyTextTable.font =  "DermaDefault"
		
		iconx,icony = draw.Text( MoneyTextTable )
		
		--draw.RoundedBox(0,0,yy,w,1,color_white)]]
		
		--Health	
		
		yy=yy-45
		
		--DrawBlurRect( xx, yy, w/7, 20, 2, 2 )
		
		surface.SetDrawColor(BGColor)
		
		surface.DrawRect( xx, yy, w/7,20 )
		
		HealthTextTable.pos = {xx+5,yy+10}
		
		HealthTextTable.text =  "+"
		
		HealthTextTable.font =  "DermaLarge"
		
		HealthTextTable.xalign = TEXT_ALIGN_LEFT
		HealthTextTable.yalign = TEXT_ALIGN_CENTER
		
		if ply:Health()<1 then
			HealthTextTable.color = InactiveColor
		else
			HealthTextTable.color = AccentColor
		end
		
		iconx,icony = draw.Text( HealthTextTable )
		
		HealthTextTable.pos[1] = HealthTextTable.pos[1]+iconx+textx/2+5
		
		HealthTextTable.pos[2] = HealthTextTable.pos[2]-1
		
		HealthTextTable.xalign = TEXT_ALIGN_CENTER
		HealthTextTable.yalign = TEXT_ALIGN_CENTER
		
		HealthTextTable.text =  tostring(math.ceil(ply:Health()))
		
		HealthTextTable.text = string.sub(HealthTextTable.text,1,math.min(string.len(HealthTextTable.text),3))
		
		HealthTextTable.font =  "DermaDefault"
		
		iconx,icony = draw.Text( HealthTextTable )
		
		local healthpercent = math.Clamp( ply:Health() / math.max( ply:GetMaxHealth(), 1 ), 0, 1)
		
		
		if HealthColor.r>AccentColor.r then
			HealthColor.r = math.Clamp(math.max(HealthColor.r-FrameTime()*FlashFade,AccentColor.r),0,255)
		elseif HealthColor.r<AccentColor.r then
			HealthColor.r = math.Clamp(math.min(HealthColor.r+FrameTime()*FlashFade,AccentColor.r),0,255)
		end
		
		if HealthColor.g>AccentColor.g then
			HealthColor.g = math.Clamp(math.max(HealthColor.g-FrameTime()*FlashFade,AccentColor.g),0,255)
		elseif HealthColor.g<AccentColor.g then
			HealthColor.g = math.Clamp(math.min(HealthColor.g+FrameTime()*FlashFade,AccentColor.g),0,255)
		end
		
		if HealthColor.b>AccentColor.b then
			HealthColor.b = math.Clamp(math.max(HealthColor.b-FrameTime()*FlashFade,AccentColor.b),0,255)
		elseif HealthColor.b<AccentColor.b then
			HealthColor.b = math.Clamp(math.min(HealthColor.b+FrameTime()*FlashFade,AccentColor.b),0,255)
		end
		
		if HealthColor.a>AccentColor.a then
			HealthColor.a = math.Clamp(math.max(HealthColor.a-FrameTime()*FlashFade,AccentColor.a),0,255)
		elseif HealthColor.a<AccentColor.a then
			HealthColor.a = math.Clamp(math.min(HealthColor.a+FrameTime()*FlashFade,AccentColor.a),0,255)
		end
		
		if ply:Health()<OldHealth then
			for k,v in pairs(DamageColor) do
				HealthColor[k]=v
			end
		elseif ply:Health()>OldHealth then
			for k,v in pairs(HealColor) do
				HealthColor[k]=v
			end	
		end
		
		OldHealth = ply:Health()
		
		surface.SetDrawColor(HealthColor)
		
		surface.DrawRect( HealthTextTable.pos[1]+textx-5, yy+8, ( (w/7) - (textx+iconx+19) )*healthpercent,4 )
		
		--Armor
		yy = yy - 30
		local ArmColor = Color(255,255,255)
		local armorpercent = math.Clamp( ply:Armor()*100, 0, 1)
		local alpha_high = math.abs( math.cos( CurTime() * 1 ) )
		local alpha_low = math.abs( math.cos( CurTime() * 0.5 ) )
		--print(armorpercent)  -- 100% - 1, 50% - 0.5, 25% - 0.25
		
		
		
		--[[if ply:Armor()<15 then  -- 1
		--local BGColor = Color(255,10,10,150)
	    --surface.SetDrawColor(BGColor)
		--draw.DrawText( "⛊", "DermaDefault", xx*9,yy+11, Color(255,30,30), 3)  -- armor text
		
		
		ArmorTextTable.pos = {xx*9,yy+11}
		
		--ArmorTextTable.color = Color(255*alpha,30,30,200)
		ArmorTextTable.color = Color(200*alpha,0,0,200)
		
		ArmorTextTable.text = '⛊'
		
		ArmorTextTable.font =  "DermaLarge"
		
		iconx,icony = draw.Text( ArmorTextTable ) 
		
		
		else
		
		
		ArmorTextTable.pos = {xx*9,yy+11}
		
		--ArmorTextTable.color = Color(200,200,200)
		ArmorTextTable.color = Color(200,200,200,25*armorpercent)
		print(armorpercent)
		
		ArmorTextTable.text = '⛊'
		
		ArmorTextTable.font =  "DermaLarge"
		
		iconx,icony = draw.Text( ArmorTextTable )
			 
		end]]
		
	
		
		if ply:Armor()<15 then  -- 1
		ArmorTextTable.color = Color(200*alpha_high,0,0,150)
		elseif ply:Armor()>15 and ply:Armor()<30 then
		ArmorTextTable.color = Color(200*alpha_low,50,50,150)
		elseif ply:Armor()>30 and ply:Armor()<45 then
		ArmorTextTable.color = Color(200,100,100,150)
		elseif ply:Armor()>45 and ply:Armor()<60 then
		ArmorTextTable.color = Color(200,150,150,150)
		else
		ArmorTextTable.color = Color(200,200,200,150)
		end
		
		 
		
		ArmorTextTable.pos = {xx*9,yy+11}
		ArmorTextTable.text = '⛊'
		ArmorTextTable.font =  "DermaLarge"
		iconx,icony = draw.Text( ArmorTextTable ) 
		
		draw.DrawText( ply:Armor().."% ", "DermaDefault", xx*9,yy+8, col1, 2)  -- armor text
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		
		--[[ 
		ArmorTextTable.pos = {xx*9,yy+11}
		
		ArmorTextTable.text = '⛊'
		
		ArmorTextTable.font =  "DermaLarge"
		
		iconx,icony = draw.Text( ArmorTextTable )
		
		]]
		
		--[[
		yy = yy - 30
		
		DrawBlurRect( xx, yy, w/7, 25, 2, 2 )
		
		surface.SetDrawColor(BGColor)
		
		surface.DrawRect( xx, yy, w/7,24 )
		
		ArmorTextTable.pos = {xx+1,yy+11}
		
		ArmorTextTable.text = '⛊'
		
		ArmorTextTable.font =  "DermaLarge"
		
		ArmorTextTable.xalign = TEXT_ALIGN_LEFT
		ArmorTextTable.yalign = TEXT_ALIGN_CENTER
		
		if ply:Armor()<1 then
			ArmorTextTable.color = InactiveColor
		else
			ArmorTextTable.color = AccentColor
		end
		
		iconx,icony = draw.Text( ArmorTextTable )
		
		ArmorTextTable.pos[1] = ArmorTextTable.pos[1]+iconx+textx/2-2
		
		ArmorTextTable.pos[2] = ArmorTextTable.pos[2]
		
		ArmorTextTable.xalign = TEXT_ALIGN_CENTER
		ArmorTextTable.yalign = TEXT_ALIGN_CENTER
		
		ArmorTextTable.text =  tostring(math.ceil(ply:Armor()))
		
		ArmorTextTable.text = string.sub(ArmorTextTable.text,1,math.min(string.len(ArmorTextTable.text),3))
		
		ArmorTextTable.font =  "DermaDefault"
		
		iconx,icony = draw.Text( ArmorTextTable )
		
		local armorpercent = math.Clamp( ply:Armor() / 100, 0, 1)
		
		
		if ArmorColor.r>AccentColor.r then
			ArmorColor.r = math.Clamp(math.max(ArmorColor.r-FrameTime()*FlashFade,AccentColor.r),0,255)
		elseif ArmorColor.r<AccentColor.r then
			ArmorColor.r = math.Clamp(math.min(ArmorColor.r+FrameTime()*FlashFade,AccentColor.r),0,255)
		end
		
		if ArmorColor.g>AccentColor.g then
			ArmorColor.g = math.Clamp(math.max(ArmorColor.g-FrameTime()*FlashFade,AccentColor.g),0,255)
		elseif ArmorColor.g<AccentColor.g then
			ArmorColor.g = math.Clamp(math.min(ArmorColor.g+FrameTime()*FlashFade,AccentColor.g),0,255)
		end
		
		if ArmorColor.b>AccentColor.b then
			ArmorColor.b = math.Clamp(math.max(ArmorColor.b-FrameTime()*FlashFade,AccentColor.b),0,255)
		elseif ArmorColor.b<AccentColor.b then
			ArmorColor.b = math.Clamp(math.min(ArmorColor.b+FrameTime()*FlashFade,AccentColor.b),0,255)
		end
		
		if ArmorColor.a>AccentColor.a then
			ArmorColor.a = math.Clamp(math.max(ArmorColor.a-FrameTime()*FlashFade,AccentColor.a),0,255)
		elseif ArmorColor.a<AccentColor.a then
			ArmorColor.a = math.Clamp(math.min(ArmorColor.a+FrameTime()*FlashFade,AccentColor.a),0,255)
		end
		
		if ply:Armor()<OldArmor then
			for k,v in pairs(ArmorDrainColor) do
				ArmorColor[k]=v
			end
		elseif ply:Armor()>OldArmor then
			for k,v in pairs(ArmorChargeColor) do
				ArmorColor[k]=v
			end	
		end
		
		OldArmor = ply:Armor()
		
		surface.SetDrawColor(ArmorColor)
		
		surface.DrawRect(ArmorTextTable.pos[1]+textx-5, yy+10, ( (w/7) - (textx+iconx+19) )*armorpercent,4 )
		]]
		--Ammo
		
		
		xx=w*(1-HUDBounds.x)-(w/7)
		yy=h*(1-HUDBounds.y)-65
		
		--DrawBlurRect( xx, yy, w/7, 65, 2, 2 )
		
		surface.SetDrawColor(BGColor)
		
		surface.DrawRect( xx, yy, w/7,65 )
		
		local AccentColorOld = table.Copy(AccentColor)
		
		surface.SetDrawColor(AccentColor)
		
		local i=5
		
		local oldalph = AccentColor.a
		
		while i<(w/7) do
			AccentColor.a=math.Clamp( math.pow(1 - ( (i-5) / (w/7) ),6 )*255 , 0, 255 )
		
			surface.SetDrawColor(AccentColor)
			
			surface.DrawLine(xx+i,yy+25,xx+i+1,yy+25)
			i=i+1
		end
		
		i=25
		
		while i>5 do
			AccentColor.a=math.Clamp( math.pow(1 - ( (i-5) / (25) ),4 )*255 , 0, 255 )
		
			surface.SetDrawColor(AccentColor)
			
			surface.DrawLine(xx+w/11,yy+i,xx+w/11,yy+i+1)
			i=i-1
		end
		
		AccentColor.a=oldalph
		
		local wep = ply:GetActiveWeapon()
		
		if IsValid(wep) and ( wep.PrintName or WeaponNames[wep:GetClass()] ) then
			GunTextTable.text = wep.PrintName or WeaponNames[wep:GetClass()]
		else
			GunTextTable.text = "Безоружный"  // Invalid Weapon
		end
		
		GunTextTable.pos[1] = xx+5
		GunTextTable.pos[2] = yy+5
		GunTextTable.xalign = TEXT_ALIGN_LEFT
		
		GunTextTable.color = AccentColor
		
		render.SetScissorRect( xx, yy, xx+w/11, h*(1-HUDBounds.y), true )
			draw.Text(GunTextTable)
		render.SetScissorRect( 0, 0, 0, 0, false ) -- Disable after you are done
		
		yy=yy+30
		
		local wep = ply:GetActiveWeapon()
		
		if IsValid(wep) then
			
			local ammo = wep:Clip1()
			
			local ammotype = wep:GetPrimaryAmmoType()
			
			if wep.Primary and wep.Primary.Ammo then
				ammotype = wep.Primary.Ammo
			end
			
			local reserve = ply:GetAmmoCount( ammotype and ammotype or "" )
			
			local ammo2 = wep:Clip2()
			
			local ammotype2 = wep:GetSecondaryAmmoType()
			
			if wep.Secondary and wep.Secondary.Ammo then
				ammotype2 = wep.Secondary.Ammo
			end
			
			local reserve2 = ply:GetAmmoCount( ammotype2 and ammotype2 or "" )
			
			if wep.Primary and wep.Primary.RPM then
				BulletShiftSpeed = math.max(0.5*(wep.Primary.RPM)/500,0.35)
			else
				BulletShiftSpeed = 1
			end
			
			if wep != OldWeapon then
				TFAHudBulletsPopulate()
			elseif ammo != OldAmmo and ammo>=0 then
				if ammo<OldAmmo then
					while (#HUDBullets>ammo and #HUDBullets>0) do
						local bul = HUDBullets[1]
						
						local hspd = -math.random(150,300)
						local vspd = -math.random(200,300)
						TFAHudAddBulletParticle(bul.sprite,bul.x,bul.y,Vector(hspd,vspd,0),math.sqrt(math.abs(hspd*400)),0.025,0.01)
						table.remove(HUDBullets,1)
					end
				else
					TFAHudBulletsPopulate()
				end
			end
			
			TFAHudBulletsProcess()
			
			if ammo>=0 then
			
				render.SetScissorRect( xx, yy, xx+w/7-1, h*(1-HUDBounds.y), true )
					for k,v in ipairs(HUDBullets) do
						surface.SetDrawColor( AccentColor )
						local spritetbl,sprite,spritew,spriteh, bulx, buly
						spritetbl = BulletSprites[v.sprite]
						sprite = spritetbl.sprite
						spritew = spritetbl.w
						spriteh = spritetbl.h		
						surface.SetTexture( sprite	) -- If you use Material, cache it!
						bulx = xx + v.x
						buly = yy + v.y
						surface.DrawTexturedRect( bulx,buly,spritew,spriteh)		
					end		
			end
			
			render.SetScissorRect( xx, yy-30, xx+w/7-1, h*(1-HUDBounds.y), true )
			
				yy=yy-28
				
				if ( tostring(ammotype) != "-1" ) then
					if ammo >= 0 then
						GunTextTable.text = "/"
						GunTextTable.xalign = TEXT_ALIGN_CENTER
						GunTextTable.pos[1] = xx+9*w/77
						GunTextTable.pos[2] = yy
						
						draw.Text(GunTextTable)
						
						GunTextTable.text = ammo	
						GunTextTable.xalign = TEXT_ALIGN_RIGHT
						GunTextTable.pos[1] = GunTextTable.pos[1]-5
						
						draw.Text(GunTextTable)
						
						GunTextTable.text = reserve	
						GunTextTable.xalign = TEXT_ALIGN_LEFT
						GunTextTable.pos[1] = GunTextTable.pos[1]+10
						
						draw.Text(GunTextTable)
						yy=yy+14
					elseif reserve>=0 then
						GunTextTable.text = reserve
						GunTextTable.xalign = TEXT_ALIGN_CENTER
						GunTextTable.pos[1] = xx+9*w/77
						GunTextTable.pos[2] = yy
						
						draw.Text(GunTextTable)
						
						yy=yy+14
					end
				end
				
				if string.lower(ammotype2) != "none" and ammotype != ammotype2 and tostring(ammotype2) != "-1" then
					if ammo2 >= 0 then
						GunTextTable.text = "/"
						GunTextTable.xalign = TEXT_ALIGN_CENTER
						GunTextTable.pos[1] = xx+9*w/77
						GunTextTable.pos[2] = yy
						
						draw.Text(GunTextTable)
						
						GunTextTable.text = ammo2
						GunTextTable.xalign = TEXT_ALIGN_RIGHT
						GunTextTable.pos[1] = GunTextTable.pos[1]-5
						
						draw.Text(GunTextTable)
						
						GunTextTable.text = reserve2
						GunTextTable.xalign = TEXT_ALIGN_LEFT
						GunTextTable.pos[1] = GunTextTable.pos[1]+10
						
						draw.Text(GunTextTable)
					elseif reserve2>-1 then
						
						GunTextTable.text = reserve2
						GunTextTable.xalign = TEXT_ALIGN_CENTER
						GunTextTable.pos[1] = xx+9*w/77
						GunTextTable.pos[2] = yy
						
						draw.Text(GunTextTable)
					
					end
					
				end
			
			render.SetScissorRect( 0, 0, 0, 0, false ) -- Disable after you are done
			
			yy=yy+30
			
			for k,v in ipairs(HUDBulletParticles) do
				surface.SetDrawColor( AccentColor )
				local spritetbl,sprite,spritew,spriteh, bulx, buly, bulrot
				spritetbl = BulletSprites[v.sprite]
				sprite = spritetbl.sprite_spent
				spritew = spritetbl.w_spent
				spriteh = spritetbl.h_spent		
				surface.SetTexture( sprite	) -- If you use Material, cache it!
				bulx = xx + v.x
				buly = yy + v.y
				bulrot = v.rotation
				surface.DrawTexturedRectRotated( bulx,buly,spritew,spriteh,bulrot)		
			end	
			
			OldAmmo = ammo
			
		end
		
		OldWeapon = wep
		
		--Compass
		
		xx=w*HUDBounds.x
		yy=h-h*(HUDBounds.y)
		
		yy=yy-20
		
		local plyang = EyeAngles()
		plyang:Normalize()
		
		local compasspad =0-- w/3
		
		local compasswidth = ScrW()/7
		
		--DrawBlurRect( xx+compasspad, yy, compasswidth , 20, 2, 2 )
		
		surface.SetDrawColor(BGColor)
		
		surface.DrawRect(  xx+compasspad, yy, compasswidth ,20 )
		
		
		CompassTextTable.pos = {xx+1,yy+9}
		
		CompassTextTable.text = '➣'
		
		CompassTextTable.font =  "DermaLarge"
		
		CompassTextTable.xalign = TEXT_ALIGN_LEFT
		CompassTextTable.yalign = TEXT_ALIGN_CENTER
		
		CompassTextTable.color = AccentColor
		
		iconx,icony = draw.Text( CompassTextTable )
		
		CompassTextTable.pos[1] = CompassTextTable.pos[1]+iconx+textx/2-2
		
		CompassTextTable.pos[2] = CompassTextTable.pos[2]
		
		CompassTextTable.xalign = TEXT_ALIGN_CENTER
		CompassTextTable.yalign = TEXT_ALIGN_CENTER
		
		local deg = math.ceil(plyang.y-90)
		
		while deg<0 do
			deg=deg+360
		end
		
		while deg>360 do
			deg=deg-360
		end
		
		CompassTextTable.text =  tostring(math.abs(deg))
		
		CompassTextTable.text = string.sub(CompassTextTable.text,1,math.min(string.len(CompassTextTable.text),3))
		
		CompassTextTable.font =  "DermaDefault"
		
		iconx,icony = draw.Text( CompassTextTable )
		
		compasspad = CompassTextTable.pos[1]+textx-5-xx
		
		compasswidth = ( (w/7) - (textx+iconx+19) )
		
		local i=1
		
		local directioncounter = 3
		
		surface.SetDrawColor( AccentColor )
		draw.NoTexture()
			
		render.SetScissorRect( xx+compasspad, yy, xx+compasspad+compasswidth , yy+20, true ) -- Disable after you are done
		
		xx=xx+math.Round(compasspad-compasswidth*3/2)
		
		xx = xx + plyang.y/180 * compasswidth
		
		ArmorTextTable.font =  "DermaDefault"
		
		while i<=18 do
			local txt = CompassDirections[directioncounter]
		
			draw_circle(math.floor(xx),yy+10,3,24)
			
			CompassTextTable.color = AccentColor
			
			CompassTextTable.xalign = TEXT_ALIGN_RIGHT
			
			CompassTextTable.text = string.sub(txt,1,1)
			
			CompassTextTable.pos[1] = math.floor(xx)-5
			
			CompassTextTable.pos[2] = yy+10
			
			draw.Text(CompassTextTable)
			
			CompassTextTable.pos[1] = math.floor(xx)+5
			
			CompassTextTable.xalign = TEXT_ALIGN_LEFT
			
			CompassTextTable.text = string.sub(txt,2,2)
			
			draw.Text(CompassTextTable)
			
			xx=xx+math.Round(compasswidth/4)
			
			i=i+1
			directioncounter = directioncounter+1
			if directioncounter>#CompassDirections then
				directioncounter = 1
			end
		end
			
		render.SetScissorRect( 0, 0, 0, 0, false ) -- Disable after you are done
		
	end

	hook.Add( 'HUDShouldDraw', 'TFAHideHud', TFAHideHud )

	hook.Add( 'HUDPaint', 'TFAHudDraw', TFAHudDraw )

	hook.Add( 'PlayerSpawn', 'TFAHudBulletsPopulate_WeaponSwitch', TFAHudBulletsPopulate)

	TFAHudBulletsPopulate()
end

local TarkovStand = Material("materials/tarkovstand.png", 'smooth mips')
local TarkovSit = Material("materials/tarkovsit.png", 'smooth mips')
local TarkovLean = Material("materials/tarkovlean.png", 'smooth mips')

local gr = Material('gui/gradient_down')

hook.Add("HUDPaint", "HealthAndArmorPaint", function()
    local scrW, scrH = ScrW(), ScrH()
    local ply = LocalPlayer()

    if not ply:Alive() then return end
    if ply:InVehicle() then return end

    local w, h = 60, 80
    local x = scrW - w - 40

    surface.SetDrawColor(0,0,0,200)
    surface.SetMaterial(gr)
    surface.DrawTexturedRect(x - 20, 15, 100, 100)

    if ply:KeyDown(IN_DUCK) --[[ and !ply:IsProne())--]]  then
        surface.SetDrawColor(255, 255, 255, 220)
        surface.SetMaterial(TarkovSit)
        surface.DrawTexturedRect(x - 5, 25, w, h)
        --drawTriangle(triangleSit)
--[[     elseif (ply:IsProne()) then
        surface.SetDrawColor(255, 255, 255, 220)
        surface.SetMaterial(TarkovLean)
        surface.DrawTexturedRect(x - 5, 25, w, h)
        --drawTriangle(triangleLean)--]] 
    else
        surface.SetDrawColor(255, 255, 255, 220)
        surface.SetMaterial(TarkovStand)
        surface.DrawTexturedRect(x - 5, 25, w, h)
        --drawTriangle(triangleStand)
    end
end)

