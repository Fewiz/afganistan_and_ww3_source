--[[
addons/[cw_2.0]_advanced_ammo/lua/entities/sent_debag/cl_init.lua
--]]
include("shared.lua")
 

