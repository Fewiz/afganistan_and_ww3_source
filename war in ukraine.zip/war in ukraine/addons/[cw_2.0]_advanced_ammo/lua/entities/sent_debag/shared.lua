--[[
addons/[cw_2.0]_advanced_ammo/lua/entities/sent_debag/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName		= "Дебаг Позиций"
ENT.Author			= "Momox, A-10"
ENT.Contact			= "Momoxstudios.net"
ENT.Purpose			= ""
ENT.Instructions	= ""
ENT.Spawnable	= true 
ENT.AdminSpawnable	= true
ENT.Category = "Другое"


ammobox = { }



