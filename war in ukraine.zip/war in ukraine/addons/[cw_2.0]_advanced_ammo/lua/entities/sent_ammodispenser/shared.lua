--[[
addons/[cw_2.0]_advanced_ammo/lua/entities/sent_ammodispenser/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName		= "Ящик С Патронами"
ENT.Author			= "NFS-NIK"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= "Нажать E для пополнения боезопаса."
ENT.Spawnable	= true 
ENT.AdminSpawnable	= true
ENT.Category = "Другое"

ammobox = { }



