--[[
addons/[cw_2.0]_advanced_ammo/lua/entities/sent_ammodispenser/cl_init.lua
--]]
include("shared.lua")

surface.CreateFont( "ammobox_configFont", {font = "Trebuchet24", extended = false, size = 22, weight = 250, } )

local function createVgui()

	if(not LocalPlayer():IsSuperAdmin())then
		chat.AddText(Color(255,0, 0),  "Access denied!")
		return
	end

	local DermaPanel = vgui.Create( "DFrame" )
		DermaPanel:SetSize( 450, 350 )
		DermaPanel:Center()
		DermaPanel:SetTitle( "AAD - Advanced Armor Dispenser" )
		DermaPanel:SetDraggable( true )
		DermaPanel.Paint = function( self, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(255,255,255,255)) --Background
			draw.RoundedBox( 0, 0, 0, w, 23, Color(0,0,0,255) ) -- Header
			surface.SetDrawColor( Color(0,0,0,255) )
			self:DrawOutlinedRect()		
		end
	
	local Btn = vgui.Create("DButton", DermaPanel)
		Btn:Dock(BOTTOM) Btn:SetText("Save")
		Btn:SetFont("ammobox_configFont") 
		Btn:SetColor(Color(255,255,255)) 
		Btn.Paint = function(self) 
			draw.RoundedBox(0,0,0, self:GetWide(), self:GetTall(), Color(0,150,0,255)) 
		end 	
		Btn.DoClick = function()
			local tbl = { }
			tbl.Model = ammobox.txtEntry_Model:GetValue()
			tbl.Secondary = ammobox.Checkbox_Secondary:GetChecked()
			tbl.DynamicAmmo = ammobox.CheckBox_DynamicAmmo:GetChecked()
			tbl.StaticAmmo = ammobox.slider_StaticAmmo:GetValue() 
			tbl.Cooldown = ammobox.slider_Cooldown:GetValue() 
			net.Start("ammobox_sendConfig")
			net.WriteTable(tbl) 
			net.SendToServer() 
			DermaPanel:Close() 
		end 

	local Scroll = vgui.Create( "DScrollPanel", DermaPanel) 
		Scroll:Dock(FILL) 
		Scroll:DockMargin( -5, -6, -5, 0 ) 

	local IconLayout = vgui.Create( "DIconLayout", Scroll )
		IconLayout:Dock(FILL) IconLayout:SetSpaceY( 10 ) IconLayout:SetSpaceX( 0 ) 
		IconLayout:DockMargin( 2, 0, 2, 0 )


	local DPanel = vgui.Create( "DPanel", IconLayout ) 
		DPanel:SetSize( DermaPanel:GetWide(), 32 ) 
		DPanel:DockPadding(7,2.5,16.5,2.5) 
		IconLayout:Add( DPanel )

		ammobox.txtEntry_Model = vgui.Create("DTextEntry", DPanel) 
		ammobox.txtEntry_Model:Dock(RIGHT) 
		ammobox.txtEntry_Model:SetSize(DPanel:GetWide()*0.55,DPanel:GetTall()*0.8) 
		ammobox.txtEntry_Model:SetValue(ammobox.config.Model) 

	local lbl = vgui.Create("DLabel", DPanel) 
		lbl:SetText("Model:") 
		lbl:SetTextColor(Color(20,20,20,255)) 
		lbl:Dock(LEFT) lbl:SetFont("ammobox_configFont") 
		lbl:SetTooltip("Set the model of the ammobox") 
		lbl:SizeToContents() 

	local DPanel = vgui.Create( "DPanel", IconLayout ) 
		DPanel:SetSize( DermaPanel:GetWide(), 32 ) 
		DPanel:DockPadding(7,2.5,16.5,2.5) IconLayout:Add( DPanel ) 


	local lbl = vgui.Create("DLabel", DPanel) 
		lbl:SetText("Secondary ammo:") 
		lbl:SetTextColor(Color(20,20,20,255)) 
		lbl:Dock(LEFT) lbl:SetTooltip("Give the player secondary ammo (SMG grenades etc.)") 
		lbl:SetFont("ammobox_configFont") 
		lbl:SizeToContents() 

		ammobox.Checkbox_Secondary = vgui.Create( "DCheckBox" ,DPanel) 
		ammobox.Checkbox_Secondary:Dock(RIGHT)
		ammobox.Checkbox_Secondary:SetValue( 0 ) 
		ammobox.Checkbox_Secondary:SetSize(DPanel:GetTall()*.75,DPanel:GetTall()*.75) 
		ammobox.Checkbox_Secondary:SetChecked(ammobox.config.Secondary) 

	local DPanel = vgui.Create( "DPanel", IconLayout ) 
		DPanel:SetSize( DermaPanel:GetWide(), 32 ) 
		DPanel:DockPadding(7,2.5,16.5,2.5) 
		IconLayout:Add( DPanel )


	local lbl = vgui.Create("DLabel", DPanel) 
		lbl:SetText("Dynamic ammo:") 
		lbl:SetTextColor(Color(20,20,20,255)) lbl:Dock(LEFT) 
		lbl:SetTooltip("Gives the player one clip for each use") 
		lbl:SetFont("ammobox_configFont") 
		lbl:SizeToContents() 

		ammobox.CheckBox_DynamicAmmo = vgui.Create( "DCheckBox", DPanel ) 
		ammobox.CheckBox_DynamicAmmo:Dock(RIGHT) 
		ammobox.CheckBox_DynamicAmmo:SetChecked(ammobox.config.DynamicAmmo) 
		ammobox.CheckBox_DynamicAmmo:SetSize(DPanel:GetTall()*.75,DPanel:GetTall()*.75) 
	
	local DPanel = vgui.Create( "DPanel", IconLayout ) 
		DPanel:SetSize( DermaPanel:GetWide(), 32 ) 
		DPanel:DockPadding(7,2.5,16.5,2.5) IconLayout:Add( DPanel ) 


	local lbl = vgui.Create("DLabel", DPanel)
		lbl:SetText("Static ammo:")
		lbl:SetTextColor(Color(20,20,20,255))
		lbl:Dock(LEFT)
		lbl:SetTooltip("Static ammount of ammo a player gets. Only works when dynamic ammo is disabled")
		lbl:SetFont("ammobox_configFont")
		lbl:SizeToContents()

	ammobox.slider_StaticAmmo = vgui.Create( "DNumSlider", DPanel )
		ammobox.slider_StaticAmmo:Dock(RIGHT)
		ammobox.slider_StaticAmmo:SetSize(DPanel:GetWide()*0.55,DPanel:GetTall()*0.8)
		ammobox.slider_StaticAmmo:SetText( "" )
		ammobox.slider_StaticAmmo:SetMin( 1 )
		ammobox.slider_StaticAmmo:SetMax( 800 )
		ammobox.slider_StaticAmmo:SetDecimals( 0 )
		ammobox.slider_StaticAmmo:SetValue(ammobox.config.StaticAmmo)

	local DPanel = vgui.Create( "DPanel", IconLayout )
		DPanel:SetSize( DermaPanel:GetWide(), 32 ) 
		DPanel:DockPadding(7,2.5,16.5,2.5) 
		IconLayout:Add( DPanel )


	local lbl = vgui.Create("DLabel", DPanel)
		lbl:SetText("Задержка:")
		lbl:SetTextColor(Color(20,20,20,255))
		lbl:Dock(LEFT) lbl:SetTooltip("Cooldown in sec.")
		lbl:SetFont("ammobox_configFont")
		lbl:SizeToContents()

	ammobox.slider_Cooldown = vgui.Create( "DNumSlider", DPanel )
		ammobox.slider_Cooldown:Dock(RIGHT)
		ammobox.slider_Cooldown:SetSize(DPanel:GetWide()*0.55,DPanel:GetTall()*0.8)
		ammobox.slider_Cooldown:SetText( "" )
		ammobox.slider_Cooldown:SetMin( 0 )
		ammobox.slider_Cooldown:SetTooltip("Cooldown in sec.")
		ammobox.slider_Cooldown:SetMax( 180 )
		ammobox.slider_Cooldown:SetDecimals( 1 )
		ammobox.slider_Cooldown:SetValue(ammobox.config.Cooldown)

	DermaPanel:MakePopup()
end 

local function networking() 
	net.Start("ammobox_reqestConfig") 
	net.SendToServer() net.Receive("ammobox_giveConfig",function() 
		ammobox.config = net.ReadTable() createVgui() 
	end) 
end 

concommand.Add("ammobox_menu",  networking)




include("shared.lua")

surface.CreateFont( "Font_Weapons", {
    font = "DermaLarge",
    size = 80,
    weight = 750
} )

-- Colors
local white = Color( 255, 255, 255, 255 )
local grey = Color( 130, 130, 130, 200 )
local white_grey = Color( 200, 200, 200, 235 )
local red = Color( 130, 30, 3, 235 )
local background = Color( 30, 30, 50, 245 )

--Pos
local frame_x = ScrW()*.19
local frame_y = ScrH()*.2
local frame_w = 800 
local frame_h = 600

local get_button_x = frame_x*.002
local get_button_y = frame_y*.003
local get_button_w = 239
local get_button_h = 70

local select_button_x = 1
local select_button_y = 481
local select_button_w = frame_w*.998
local select_button_h = 118

IGS_NPC_HIDE_ON_DISTANCE = nil -- 100000
function ENT:Draw()

	self.Entity:DrawModel()

	local dist = EyePos():DistToSqr(self:GetPos())
	if IGS_NPC_HIDE_ON_DISTANCE and dist > IGS_NPC_HIDE_ON_DISTANCE then return end -- не отрисовывать
  
	local pos = self:GetPos() + (self:GetAngles():Forward() * -15) + (self:GetAngles():Up() * 35) -- 62.5 -- Высота
 	local ang = self:GetAngles()-------------* 0------ Вперед/Назад ------------------ Вверх/Низ

	ang:RotateAroundAxis(self:GetAngles():Forward(), 90) -- 
	ang:RotateAroundAxis(self:GetAngles():Up(), 90)  -- Боковой Наклон
	
 	cam.Start3D2D(pos, Angle(ang.p, ang.y, ang.r0), 0.113) -- Размер
	 if math.floor((LocalPlayer():GetPos():Distance(self:GetPos()))) < 500 then
		surface.SetDrawColor( 0, 0, 0, 150 )
		surface.DrawRect( -200, -60, 400, 100 ) -- ( -200, -100, 400, 178 )
		--surface.SetDrawColor( Color( 204,255,0 ))
		--surface.DrawOutlinedRect( -200, -60, 400, 100 )  -- ( -200, -100, 400, 178 )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( -200, 40, 400, 5 )  -- Белая линия

		draw.SimpleText( "Арсенал", "Font_Weapons", 1, -55, Color( 255,255,255 ), 1, 0 )
     end
	cam.End3D2D()

end


