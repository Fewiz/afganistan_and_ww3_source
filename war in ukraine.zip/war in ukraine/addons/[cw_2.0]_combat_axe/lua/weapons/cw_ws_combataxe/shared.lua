--[[
addons/[cw_2.0]_combat_axe/lua/weapons/cw_ws_combataxe/shared.lua
--]]
AddCSLuaFile()

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "Тактический Топор" -- Combat Axe   Боевой Топор
	SWEP.CSMuzzleFlashes = true
	
	SWEP.DisableSprintViewSimulation = true
	
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WM = "models/weapons/cw2 melee/w_ws_combataxe.mdl"
	SWEP.WMPos = Vector(-1, 1.5, 0)
	SWEP.WMAng = Vector(-15, -90, 180)
	
	SWEP.IconLetter = "j"
	killicon.Add("cw_ws_combataxe", "vgui/kills/cw_ws_combatAxe", Color(255, 80, 0, 150))
	SWEP.SelectIcon = surface.GetTextureID("vgui/kills/cw_ws_combatAxe")
end


SWEP.Animations = {
	slash_primary = {"hitcenter1", "hitcenter2"},
	slash_secondary = "hitcenter3",
	draw = "draw"
}

SWEP.Sounds = {
	hitcenter1 = {{time = 0.05, sound = "CW_KNIFE_SLASH"}},
	hitcenter2 = {{time = 0.05, sound = "CW_KNIFE_SLASH"}},
	hitcenter3 = {{time = 0.1, sound = "CW_KNIFE_SLASH"}},
	draw = {{time = 0.1, sound = "CW_KNIFE_DRAW"}},
}

SWEP.Slot = 0
SWEP.SlotPos = 0
SWEP.Base = "cw_melee_base"
SWEP.Category = "Холодное оружие"
SWEP.NormalHoldType = "melee"

SWEP.Author			= "White Snow"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 70
SWEP.ViewModelFlip	= false
SWEP.ViewModel = "models/weapons/cw2 melee/v_ws_combataxe.mdl"
SWEP.WorldModel = "models/weapons/cw2 melee/w_ws_combataxe.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 0
SWEP.Primary.DefaultClip	= 0
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= ""

SWEP.PrimaryAttackDelay =  0.70--0.70
SWEP.SecondaryAttackDelay = 1.2  --0.85

SWEP.PrimaryAttackDamage = {45, 55}
SWEP.SecondaryAttackDamage = {55, 75} --{80, 90}

SWEP.PrimaryAttackRange = 60

SWEP.HolsterTime = 0.4
SWEP.DeployTime = 0.6

SWEP.PrimaryAttackImpactTime = 0.2
SWEP.PrimaryAttackDamageWindow = 0.15

SWEP.SecondaryAttackImpactTime = 0.2
SWEP.SecondaryAttackDamageWindow = 0.15

SWEP.PrimaryHitAABB = {
	Vector(-10, -5, -5),
	Vector(10, 5, 5)
}
 

