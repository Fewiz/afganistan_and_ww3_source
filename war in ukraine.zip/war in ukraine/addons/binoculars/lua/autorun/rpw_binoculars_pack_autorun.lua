--[[
addons/binoculars/lua/autorun/rpw_binoculars_pack_autorun.lua
--]]
if (GetConVar( "rpw_binoculars_hold" ) == nil) then	CreateConVar( "rpw_binoculars_hold", 1, FCVAR_ARCHIVE, "0 or 1, whether or not binoculars are toggle-to-use rather than hold-to-use." )endfunction rpw_PopulateOptionsMenu_Binoculars( CPanel )		CPanel:AddControl( "Checkbox", { Label = "Hold to Aim", Command = "rpw_binoculars_hold" } )endhook.Add( "PopulateToolMenu", "rpw_PopulateOptionsMenu_Binoculars", function()	spawnmenu.AddToolMenuOption( "Options", "RPW", "RPW_Binoculars", "Binoculars", "", "", rpw_PopulateOptionsMenu_Binoculars )end )

