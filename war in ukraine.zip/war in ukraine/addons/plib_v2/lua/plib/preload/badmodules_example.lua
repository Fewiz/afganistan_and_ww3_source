--[[
addons/plib_v2/lua/plib/preload/badmodules_example.lua
--]]
-- This folder has total load priority over everything
-- This can be used to kill modules you dont use on your server
-- require 'example'  will now silently ignore this module
plib.BadModules['example'] = true

