--[[
addons/common_computer/lua/weapons/cc_laptop_hands/shared.lua
--]]
local L = ComComp.GetLang

SWEP.PrintName = "Ноутбук" -- L("laptop")
SWEP.Author = "Feeps"
SWEP.Category = "Другое" -- Common Computer
SWEP.Spawnable = true
 
SWEP.ViewModel = "models/weapons/veeds/laptop.mdl"
SWEP.WorldModel = "models/veeds/laptop/laptop.mdl"
SWEP.UseHands = true
SWEP.ViewModelFOV = 46
 
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
 
SWEP.Secondary.ClipSize	= -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo	= "none"

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

table.Merge(SWEP, ComComp.BaseEntStruct)

function SWEP:Initialize()
    self:SetHoldType("duel")
end


-- Prevent the player from holding his weapon directly so we can play the close animation
function SWEP:Holster(target)
	if not IsFirstTimePredicted() then return end

    local vm = self:GetOwner():GetViewModel()
    if not IsValid(vm) then return true end

    if self.WasHolster then 
        self.WasHolster = nil
        return true
    else
        local seq = vm:LookupSequence("close")
        if seq then
            vm:SendViewModelMatchingSequence(seq)
            timer.Create("ComComp:SWEPCloseAnimation:" .. self:EntIndex(), vm:SequenceDuration(seq) - 0.5, 1, function()
                if IsValid(self) then
                    self.WasHolster = true
                    
                    if SERVER then
                        self:GetOwner():SelectWeapon(target)
                    end
                end
            end)
        end

        return false
    end
end

function SWEP:GetCamPos()
    local owner = self:GetOwner()
    if not IsValid(owner) then
        return self:GetPos(), self:GetAngles()
    end

    local pos, ang = owner:EyePos(), owner:EyeAngles()
    ang:RotateAroundAxis(ang:Up(), 180)
    ang.p = math.Clamp(ang.p, 0, 90)

    pos = pos + ang:Forward() * -22.5
    
    return pos, ang
end

