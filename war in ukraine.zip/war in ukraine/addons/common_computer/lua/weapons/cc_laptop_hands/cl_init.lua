--[[
addons/common_computer/lua/weapons/cc_laptop_hands/cl_init.lua
--]]
include("shared.lua")

local L = ComComp.GetLang

local wm = ClientsideModel(SWEP.WorldModel)
wm:SetNoDraw(true)
wm:SetSequence("open")
wm:SetCycle(1)

local offsetVec = Vector(2, -12, -2)
local offsetAng = Angle(170, -5, -8)

function SWEP:DrawWorldModel()
    local owner = self:GetOwner()
    if not IsValid(owner) then return end
    
    local boneid = owner:LookupBone("ValveBiped.Bip01_R_Hand") -- Right Hand
    if not boneid then return end

    local matrix = owner:GetBoneMatrix(boneid)
    if not matrix then return end

    local newPos, newAng = LocalToWorld(offsetVec, offsetAng, matrix:GetTranslation(), matrix:GetAngles())

    wm:SetPos(newPos)
    wm:SetAngles(newAng)
    wm:SetupBones()
    wm:DrawModel()

    local cs = self:GetComputerInstance()
    if cs and self:GetDrawScreen() then
        local frame = cs:GetMainFrame()
        if IsValid(frame) and cs:IsPaused() then
            local ang = wm:GetAngles()
            ang:RotateAroundAxis(ang:Up(), 90)
            ang:RotateAroundAxis(ang:Forward(), 82.35)

            local pos = wm:GetPos()
            pos = pos + ang:Right() * -13.5
            pos = pos + ang:Forward() * -10.3
            pos = pos + ang:Up() * -6.228

            cam.Start3D2D(pos, ang, 0.01074 * 1920/ComComp.GetComputedScrW())
                frame:PaintManual()
            cam.End3D2D()
        end
    end
end

function SWEP:Think() -- Because Deploy isn't called clientside with SelectWeapon
    if not self.CheckedTaked then
        self.CheckedTaked = true
        self:SetDrawScreen(true)
    end
end

function SWEP:ViewModelDrawn(vm)
    local bone = vm:LookupBone("pcrot")
    if not bone then return end

    local pos, ang = vm:GetBonePosition(bone)
    ang:RotateAroundAxis(ang:Up(), -10)
    ang:RotateAroundAxis(ang:Forward(), 180)
    ang:RotateAroundAxis(ang:Right(), 90)

    pos = pos + ang:Right() * -12.63
    pos = pos + ang:Forward() * -10.635
    pos = pos + ang:Up() * -0.1

    local cs = self:GetComputerInstance()
    if cs and self:GetDrawScreen() then -- Check if we can render the screen
        local frame = cs:GetMainFrame()
        if IsValid(frame) and cs:IsPaused() then -- Check if the user isn't in the computer
            cam.Start3D2D(pos, ang, 0.0111 * 1920/ComComp.GetComputedScrW())
                frame:PaintManual()
            cam.End3D2D()
        end
    end

    pos = pos + ang:Right() * 2.75
    pos = pos + ang:Forward() * 21

    cam.Start3D2D(pos, ang, 0.022)
        ComComp.DrawMouse(L("use"), "ComComp22", LEFT, 0, 0, 32)
        ComComp.DrawKey(L("dropoff"), "ComComp22", input.LookupBinding("reload"), 0, 32 + 12, 32)
    cam.End3D2D()
end

-- Remove strange sounds
function SWEP:PrimaryAttack()

end

function SWEP:SecondaryAttack()

end

