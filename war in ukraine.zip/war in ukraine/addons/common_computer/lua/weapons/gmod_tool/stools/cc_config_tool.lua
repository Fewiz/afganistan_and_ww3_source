--[[
addons/common_computer/lua/weapons/gmod_tool/stools/cc_config_tool.lua
--]]
TOOL.Category = "Common Computer"
TOOL.Name = "Configuration"

if CLIENT then
    TOOL.Information = {
        {
            name = "left"
        },
        {
            name = "right"
        }
    }

    language.Add("tool.cc_config_tool.name", "Configuration")
    language.Add("tool.cc_config_tool.desc", "For more specific settings, please go to the application's sh_config.lua file")
    language.Add("tool.cc_config_tool.left", "Start configuration")
    language.Add("tool.cc_config_tool.right", "Select config")
end

TOOL.ClientConVar["current_setting"] = 0

local Settings = {}
Settings.List = {}

function Settings:New(name)
    local t = {
        Name = name or "unamed",
        Run = function(tool, tr)

        end,
        Reload = function(tool)

        end,
        DrawHUD = function(tool)

        end
    }

    table.insert(self.List, t)
    return t
end

hook.Run("CC:ConfigTool:Setup", Settings)

function TOOL:LeftClick(tr)
    if not IsFirstTimePredicted() then return end
    if not ComComp.IsAdmin(self:GetOwner()) then return end

    local v = self:GetClientNumber("current_setting", 0)
    local set = Settings.List[v]
    if set then
        set:Run(self, tr)
    end
end

function TOOL:Reload()
    if not IsFirstTimePredicted() then return end
    if not ComComp.IsAdmin(self:GetOwner()) then return end

    local v = self:GetClientNumber("current_setting", 0)
    local set = Settings.List[v]
    if set then
        set:Reload(self)
    end
end

function TOOL:RightClick(tr)
    if not IsFirstTimePredicted() then return end
    if not ComComp.IsAdmin(self:GetOwner()) then return end

    if CLIENT then
        local con = GetConVar(self:GetMode() .. "_" .. "current_setting")
        local v = con:GetInt() + 1

        if v > #Settings.List then
            v = 1
        end

        con:SetInt(v)
    end
end

function TOOL:DrawHUD()
    if not ComComp.IsAdmin(self:GetOwner()) then return end

    local v = self:GetClientNumber("current_setting", 0)
    local set = Settings.List[v]
    if set then
        set:DrawHUD(self)
    end
end

if CLIENT then
    -- Draw current settings
    function TOOL:DrawToolScreen(w, h)
        surface.SetDrawColor(0, 0, 0)
        surface.DrawRect(0, 0, w, h)

        local v = self:GetClientNumber("current_setting", 0)
        local set = Settings.List[v]
        if set then
            draw.SimpleText(set.Name, "DermaLarge", w/2, 40, nil, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        draw.SimpleText(v .. "/" .. #Settings.List, "DermaLarge", w - 8, h - 8 - 32, nil, TEXT_ALIGN_RIGHT)
    end
end

