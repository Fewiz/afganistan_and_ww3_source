--[[
addons/common_computer/lua/autorun/sh_load_comm_computer.lua
--]]
if SERVER then
	resource.AddWorkshop("2333091730") -- Workshop content
end

ComComp = ComComp or {}

ComComp.Include = function(fileName, state)
	if not file.Exists(fileName, "LUA") then return end

	if ((state == "server" or fileName:find("sv_")) and SERVER) then
		include(fileName)
	elseif (state == "shared" or fileName:find("sh_")) then
		if SERVER then
			AddCSLuaFile(fileName)
		end

		include(fileName)
	elseif (state == "client" or fileName:find("cl_")) then
		if SERVER then
			AddCSLuaFile(fileName)
		else
			include(fileName)
		end
	end
end

--[[
	Don't forget the / at the end of dir :)
]]
ComComp.ThirdInclude = function(dir)
	ComComp.Include(dir .. "shared.lua", "shared")
	ComComp.Include(dir .. "init.lua", "server")
	ComComp.Include(dir .. "cl_init.lua", "client")
end

file.CreateDir("common_computer")
file.CreateDir("common_computer/temp")

ComComp.Include("common_computer/sh_config.lua")
ComComp.ThirdInclude("common_computer/core/utilities/")
ComComp.Include("common_computer/core/cl_fonts.lua")

-- third party
ComComp.Include("common_computer/libs/thirdparty/3d2dvgui.lua", "client") -- Only used for the phone

-- Load libs
ComComp.Include("common_computer/libs/sh_cycle.lua")
ComComp.Include("common_computer/libs/cl_fastmenu.lua")
ComComp.Include("common_computer/libs/cl_gizmo.lua")
ComComp.Include("common_computer/libs/cl_ccvox.lua")

-- Load base
ComComp.Include("common_computer/core/sh_applications.lua")
ComComp.ThirdInclude("common_computer/core/instances/")
ComComp.Include("common_computer/core/sh_baseentity.lua")
ComComp.Include("common_computer/core/cl_clientdata.lua")

-- Load access to database
ComComp.ThirdInclude("common_computer/core/database/")

