--[[
addons/common_computer/lua/common_computer/libs/cl_gizmo.lua
--]]
local color_red = Color(255, 0, 0)
local color_green = Color(0, 255, 0)
local color_blue = Color(0, 0, 255)

local DrawVecEditor = function(pos, dir, size, rayStart, rayDir, thickness, color)
	local mins = Vector(0, -thickness, -thickness)
	local maxs = Vector(size, thickness, thickness)
	local ang = dir:Angle()

	local hover = util.IntersectRayWithOBB(rayStart, rayDir * 1024, pos, ang, mins, maxs)

	local endPos = pos + dir * size
	render.DrawLine(pos, endPos, hover and color_white or color)
	render.DrawLine(endPos, endPos + ang:Up() * 0.045 * size - dir * 0.06 * size, hover and color_white or color)
	render.DrawLine(endPos, endPos + ang:Up() * -0.045 * size - dir * 0.06 * size, hover and color_white or color)
	
	local hit = util.IntersectRayWithPlane(rayStart, rayDir, pos, (rayStart - pos):GetNormalized()) or false

	if hit then
		local _, point = util.DistanceToLine(pos - dir * 128, pos + dir * 128, hit)
		hit = point
	end

	return hover ~= nil, hit, dir
end

local DrawAngEditor = function(pos, normal, radius, rayStart, rayDir, thickness, seg, color)
	seg = (seg + 1) or 180

	local t = Vector(normal.x, normal.y, normal.z)
	local nAng = t:Angle()
	local xAxis = nAng:Right()
	local yAxis = nAng:Up()

	local hit = util.IntersectRayWithPlane(rayStart, rayDir, pos, t)
	local hover = false

	if hit then
		hit = hit - pos

		local l = hit:Length()
		hover = l > radius - thickness and l < radius + thickness
	end

	render.SetColorMaterialIgnoreZ()
	render.StartBeam(seg)
		for i = 0, seg do
			local a = (math.pi * 2)/(seg - 1) * i
			
			local x = xAxis * math.cos(a) * radius
			local y = yAxis * math.sin(a) * radius

			render.AddBeam(pos + x + y, thickness, 1, hover and color_white or color)
		end
	render.EndBeam()

	return hover, hit, normal
end


local Editor = {}
Editor.__index = Editor

AccessorFunc(Editor, "m_thickness", "Thickness")
AccessorFunc(Editor, "m_radius", "Radius")
AccessorFunc(Editor, "m_vec", "Pos")
AccessorFunc(Editor, "m_ang", "Angles")
AccessorFunc(Editor, "m_editingPos", "EditingPos")
AccessorFunc(Editor, "m_clickKey", "ClickKey")

function Editor:OnVectorChange(pos, delta) end
function Editor:OnAnglesChange(ang, delta) end

function Editor:Draw(rayStart, rayDir)
	local pos = self:GetPos()
	local r = self:GetRadius()

	if pos:Distance(rayStart) <= r then
		return
	end

	local ang = self:GetAngles()
	local t = self:GetThickness()
	local key = self:GetClickKey()

	local c = self:GetEditingPos() and {
		{DrawVecEditor(pos, ang:Forward(), r, rayStart, rayDir, t, color_red)},
		{DrawVecEditor(pos, ang:Right(), r, rayStart, rayDir, t, color_green)},
		{DrawVecEditor(pos, ang:Up(), r, rayStart, rayDir, t, color_blue)}
	} or {
		{DrawAngEditor(pos, ang:Forward(), r,  rayStart, rayDir, t, 64, color_red)},
		{DrawAngEditor(pos, ang:Right(), 	r,  rayStart, rayDir, t, 64, color_green)},
		{DrawAngEditor(pos, ang:Up(), 		r,  rayStart, rayDir, t, 64, color_blue)}
	}

	if input.IsButtonDown(key) then
		if not self.dragAxis then
			-- Find the axis to draw
			for i = 1, 3 do
				if c[i][1] then
					self.dragAxis = i
				end
			end
		else
			local axis = c[self.dragAxis]
			local oldHit = self.oldHit
			local hit = axis[2]
			local dir = axis[3]
			
			if self:GetEditingPos()  then
				if hit and oldHit then
					local delta = hit - oldHit
					local nPos = self:GetPos() + delta
					self:SetPos(nPos)
					self:OnVectorChange(nPos, delta)
				end

				self.oldHit = hit
			else
				if hit then
					hit = hit:GetNormalized()
				end
	
				if hit and oldHit then
					local delta = math.acos(math.Clamp(hit:Dot(oldHit), -1, 1))
	
					local cross_x = oldHit.y * hit.z - oldHit.z * hit.y
					local cross_y = oldHit.z * hit.x - oldHit.x * hit.z
					local cross_z = oldHit.x * hit.y - oldHit.y * hit.x
					local scalar = dir.x * cross_x + dir.y * cross_y + dir.z * cross_z
	
					delta = delta * ((scalar < 0 and -1 or 1) or 0) -- Find the sign/direction
					delta = math.deg(delta)

					local nAng = Angle(ang)
					nAng:RotateAroundAxis(dir, delta)
					self:SetAngles(nAng)
					self:OnAnglesChange(nAng, delta)
				end
	
				self.oldHit = hit
			end
		end
	elseif self.dragAxis then
		self.dragAxis = nil
		self.oldHit = nil
	end
end

ComComp.NewGizmo = function()
	local obj = setmetatable({}, Editor)
	obj:SetEditingPos(true)
	obj:SetRadius(16)
	obj:SetThickness(0.5)
	obj:SetPos(Vector())
	obj:SetAngles(Angle())
	obj:SetClickKey(MOUSE_FIRST)

	return obj
end


