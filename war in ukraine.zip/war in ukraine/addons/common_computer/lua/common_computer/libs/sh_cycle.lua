--[[
addons/common_computer/lua/common_computer/libs/sh_cycle.lua
--]]
local Cycle = {}
Cycle.__index = Cycle

function Cycle:new()
    return setmetatable({
        last = -math.huge -- Force condition to be true the first time
    }, Cycle)
end

function Cycle:Delta()
    return CurTime() - self.last
end

function Cycle:Trigger()
    local delta = self:Delta()
    self.last = CurTime()
    return delta
end

setmetatable(Cycle, {__call=Cycle.new})

function ComComp.NewCycle()
    return Cycle()
end

