--[[
addons/common_computer/lua/common_computer/libs/cl_ccvox.lua
--]]
local cubeMat = CreateMaterial( "CompCompVoxEditorCube", "UnlitGeneric", { -- Can't use VertexLitGeneric because render.SuppressEngineLighting doesn't work in IMesh
	["$basetexture"] = "color/white",
	["$model"] = 1,
	["$vertexcolor"] = 1,
	--["$vertexalpha"] = 1 Source engine doesn't support it :'( SADDDD
})

local CCVox = {} -- .ccvox file format
CCVox.__index = CCVox

function CCVox:GetMeshObject()
	return self.IMesh
end

function CCVox:BuildMeshes() -- Used mesh culling optimization (Not using Greedy -> Too slow for Lua (But not tested))
	local verts = {}
	local colors = {} -- List all different colors here

	for x = 0, self.SizeX do
		for y = 0, self.SizeY do
			for z = 0, self.SizeZ do
				local c = self:GetCube(x, y, z)
				if c == nil then goto con end

				local adj = self:GetCube(x + 1, y, z)
				if adj == nil then
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + 0.5), color = c}
				end

				adj = self:GetCube(x - 1, y, z)
				if adj == nil then
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + 0.5), color = c}
				end

				adj = self:GetCube(x, y + 1, z)
				if adj == nil then
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + -0.5), color = c}
				end

				adj = self:GetCube(x, y - 1, z)
				if adj == nil then
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + 0.5), color = c}
				end

				adj = self:GetCube(x, y, z + 1)
				if adj == nil then
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + 0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + 0.5), color = c}
				end

				adj = self:GetCube(x, y, z - 1)
				if adj == nil then
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + 0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + 0.5, y + -0.5, z + -0.5), color = c}
					verts[#verts + 1] = {pos = Vector(x + -0.5, y + 0.5, z + -0.5), color = c}
				end

				-- Add the colors to the colors list
				if colors[c.r] == nil then
					colors[c.r] = {}
				end

				if colors[c.r][c.g] == nil then
					colors[c.r][c.g] = {}
				end

				colors[c.r][c.g][c.b] = true


				::con::
			end
		end
	end

	self:NewMeshObject():BuildFromTriangles(verts)
	self.VertCount = #verts
	self.Colors = colors
end

function CCVox:GetColors()
	return self.Colors or {}
end

function CCVox:GetVerticesCount()
	return self.VertCount or 0
end

function CCVox:Free()
	local mesh = self:GetMeshObject()
	if IsValid(mesh) then
		mesh:Destroy()
	end
end

function CCVox:NewMeshObject()
	self:Free()

	self.IMesh = Mesh()
	return self.IMesh
end

function CCVox:ExportData(fileName)
	local bytes = {}

	bytes[#bytes + 1] = self.SizeX
	bytes[#bytes + 1] = self.SizeY
	bytes[#bytes + 1] = self.SizeZ

	for x = 0, self.SizeX do
		for y = 0, self.SizeY do
			for z = 0, self.SizeZ do
				local c = self:GetCube(x, y, z)

				if c ~= nil then
					bytes[#bytes + 1] = 1
					bytes[#bytes + 1] = c.r
					bytes[#bytes + 1] = c.g
					bytes[#bytes + 1] = c.b
				else
					bytes[#bytes + 1] = 0
				end
			end
		end
	end

	return bytes
end

function CCVox:ImportData(bytes)
	local sizeX = bytes[1]
	local sizeY = bytes[2]
	local sizeZ = bytes[3]

	self:SetCanvasSize(sizeX, sizeY, sizeZ)

	local i = 3
	for x = 0, sizeX do
		for y = 0, sizeY do
			for z = 0, sizeZ do
				i = i + 1
				if bytes[i] == 0 then 
					goto con 
				end
				
				self:SetCube(x, y, z, Color(bytes[i + 1], bytes[i + 2], bytes[i + 3]))
				i = i + 3

				::con::
			end
		end
	end

	self:BuildMeshes()
	return true
end

function CCVox:SetCanvasSize(sx, sy, sz)
	self.SizeX = sx
	self.SizeY = sy
	self.SizeZ = sz
	self.CanSizeVec = Vector(sx, sy, sz)

	local cd = {}
	for x = 0, sx do
		cd[x] = {}
		for y = 0, sy do
			cd[x][y] = {}
		end
	end
	self.Cubes = cd
end

function CCVox:GetCanvasSize()
	return self.CanSizeVec or vector_origin
end

function CCVox:IsInCanvas(x, y, z)
	return x >= 0 and x <= self.SizeX and y >= 0 and y <= self.SizeY and z >= 0 and z <= self.SizeZ
end

function CCVox:GetCube(x, y, z)
	if not self:IsInCanvas(x, y, z) then return end
	return self.Cubes[x][y][z]
end

function CCVox:SetCube(x, y, z, color)
	if color.a == 0 then
		return self:RemoveCube(x, y, z)
	end

	if not self:IsInCanvas(x, y, z) then return false end

	if self:GetCube(x, y, z) == nil then 
		self.CubeCount = self.CubeCount + 1 
	end

	self.Cubes[x][y][z] = color
end

function CCVox:RemoveCube(x, y, z)
	if not self:IsInCanvas(x, y, z) then return false end

	if self:GetCube(x, y, z) ~= nil then
		self.CubeCount = self.CubeCount - 1
		self.Cubes[x][y][z] = nil
	end
end

function CCVox:GetCubeCount()
	return self.CubeCount
end

function CCVox:Draw()
	local meshObj = self:GetMeshObject()
	if IsValid(meshObj) then
		render.SetMaterial(cubeMat)
		meshObj:Draw()
	end
end

-- naive but works well
function CCVox:RayTrace(start, dir, back)
	local test = Vector(start)
	local block

	for i = 0, 1536 do
		test = test + dir * 0.1

		local temp = Vector(test)
		temp.x = math.Round(temp.x)
		temp.y = math.Round(temp.y)
		temp.z = math.Round(temp.z)

		if back then
			block = temp
		end

		if (start.x >= 0 and temp.x < 0)
				or (start.x <= self.SizeX and temp.x > self.SizeX)
				or (start.y >= 0 and temp.y < 0)
				or (start.y <= self.SizeY and temp.y > self.SizeY)
				or (start.z >= 0 and temp.z < 0) 
				or (start.z <= self.SizeZ and temp.z > self.SizeZ) then

			return block
		end

		if self:GetCube(temp.x, temp.y, temp.z) ~= nil then
			return block
		end

		if not back then
			block = temp
		end
	end

	return false
end

function ComComp.NewCCVox(cx, cy, cz)
	local newObj = setmetatable({}, CCVox)
	newObj.CubeCount = 0
	newObj:SetCanvasSize(cx, cy, cz)
	return newObj
end

