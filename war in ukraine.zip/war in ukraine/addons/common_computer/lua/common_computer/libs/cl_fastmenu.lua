--[[
addons/common_computer/lua/common_computer/libs/cl_fastmenu.lua
--]]
local RespX = ComComp.RespX
local RespY = ComComp.RespY

local current = nil

local FASTMENU = {}
FASTMENU.__index = FASTMENU

function FASTMENU:new(w, h, gap)
    local newObject = setmetatable({
        options = {},
        w = w or RespX(230),
        h = h or RespY(25),
        gap = gap or RespY(7),
        y = 0
    }, FASTMENU)

    if current then
        current:Remove()
    end

    current = newObject

    return newObject
end

function FASTMENU:ReleaseKey(key)
    self.releasekey = key
end

function FASTMENU:AddOption(name, callback)
    table.insert(self.options, {name = name, callback = callback})
    self.totalH = #self.options * self.h + (#self.options - 1) * self.gap
end

function FASTMENU:Remove()
    self.options = {}
    current = nil
end

function FASTMENU:GetSelected() 
    for k, v in ipairs(self.options) do
        local pos = ScrH()/2 - self.totalH/2 + (k-1) * self.gap + (k-1) * self.h + self.y
        if pos >= ScrH()/2 - self.h and pos <= ScrH()/2 + self.h/2 then
            -- Is in middle
            return k
        end
    end
end

function FASTMENU:Run()
   local selected = self:GetSelected()
   if selected then
       self.options[selected].callback()
   end
    self:Remove()
end

function FASTMENU:Paint()
    if #self.options == 0 then return end

    -- Run
    if self.releasekey and not input.IsKeyDown(self.releasekey) then
        self:Run()
        return
    end

    local selected = self:GetSelected()
    for k,v in ipairs(self.options) do
        local pos = ScrH()/2 - self.totalH/2 + (k-1) * self.gap + (k-1) * self.h + self.y
        surface.SetDrawColor(selected == k and color_white or color_black)
        surface.DrawRect(ScrW()/2 - self.w/2, pos, self.w, self.h)
        draw.DrawText(v.name, "ComComp18", ScrW()/2, pos + self.h/2 - RespY(18)/2, selected ~= k and color_white or color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        surface.SetDrawColor(255, 255, 255)
        surface.DrawOutlinedRect(ScrW()/2 - self.w/2, pos, self.w, self.h)

        surface.SetDrawColor(0, 0, 0)
	    draw.NoTexture()

        -- Triangle
        surface.DrawPoly({
            {x = ScrW()/2 - self.w/2 - RespX(20), y = ScrH()/2 + RespY(5)},
            {x = ScrW()/2 - self.w/2 - RespX(20), y = ScrH()/2 - RespY(5)},
            {x = ScrW()/2 - self.w/2 - RespX(5), y = ScrH()/2}
        })
    end
end

setmetatable(FASTMENU, {__call=FASTMENU.new})

hook.Add("HUDPaint", "CC:FastMenu:Draw", function()
    if current then
        current:Paint()
    end
end)

hook.Add("InputMouseApply", "CC:FastMenu:LockPitch", function(cmd, x, y, angle)
    if current then
        cmd:SetMouseX(0)
        cmd:SetMouseY(0)

        current.y = current.y + y/8
        current.y = math.Clamp(current.y, -current.totalH/2, current.totalH/2)
        return true
    end
end)

function ComComp.NewFastMenu(w, h, gap)
    return FASTMENU(w, h, gap)
end

-- return the current fast menu
function ComComp.GetFastMenu()
    return current
end

