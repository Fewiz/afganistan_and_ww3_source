--[[
addons/common_computer/lua/common_computer/sh_config.lua
--]]
--[[
	_____                             _____                     __         
	/ ___/__  __ _  __ _  ___  ___    / ___/__  __ _  ___  __ __/ /____ ____
	/ /__/ _ \/  ' \/  ' \/ _ \/ _ \  / /__/ _ \/  ' \/ _ \/ // / __/ -_) __/
	\___/\___/_/_/_/_/_/_/\___/_//_/  \___/\___/_/_/_/ .__/\_,_/\__/\__/_/   
													/_/                      	
	by Feeps.
	Version: 1.1.2
]]
ComComp.Cfg = {}

ComComp.Cfg["Draw3d"] = true -- Draw the 3D screen on the entity
ComComp.Cfg["Lang"] = "en" -- en, fr, ru, tr, sp, de
ComComp.Cfg["AdminGroups"] = {
	["founder"] = true,
	["superadmin"] = true,
	["admin"] = true
}
ComComp.Cfg["DisabledApps"] = {
	--["filebrowser"] = true,
	--["name_of_the_folder_in_applications"] = true
}

-- NOTE If you need to configure the applications, go to the 'sh_config' file corresponding to the application !





--[[
	Ignore the lines bellow if you don't know what you're doing !
]] 

ComComp.Cfg["MaxNetSize"] = 65533 -- Do not change

function ComComp.IsAppDisabled(id)
	return ComComp.Cfg["DisabledApps"][id] or false
end

function ComComp.IsAdmin(ply)
	return ComComp.Cfg["AdminGroups"][ply:GetUserGroup()]
end

local LangTable = {}
ComComp.Lang = LangTable

local lPath = "common_computer/lang/" .. ComComp.Cfg["Lang"] .. ".lua"
if file.Exists(lPath, "LUA") then
	ComComp.Include(lPath, "shared")
else -- Load english if the language wasn't found
	ComComp.Cfg["Lang"] = "en"
	ComComp.Include("common_computer/lang/en.lua", "shared")
end

function ComComp.GetLang(id)
	return LangTable[id]
end

ComComp.Cfg["ZPos"] = {}
ComComp.Cfg["ZPos"]["StartMenu"] = 500
ComComp.Cfg["ZPos"]["NotifMenu"] = 500
ComComp.Cfg["ZPos"]["Notif"] = 350
ComComp.Cfg["ZPos"]["Frame"] = 250
ComComp.Cfg["ZPos"]["DesktopIcon"] = 5


