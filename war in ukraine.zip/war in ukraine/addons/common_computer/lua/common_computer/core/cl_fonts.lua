--[[
addons/common_computer/lua/common_computer/core/cl_fonts.lua
--]]
-- Default fonts
surface.CreateFont("ComComp12", { font = "Roboto", size = ComComp.RespY(12), weight = 500 })
surface.CreateFont("ComComp14", { font = "Roboto", size = ComComp.RespY(14), weight = 500 })
surface.CreateFont("ComComp16", { font = "Roboto", size = ComComp.RespY(16), weight = 500 })
surface.CreateFont("ComComp18", { font = "Roboto", size = ComComp.RespY(18), weight = 500 })
surface.CreateFont("ComComp20", { font = "Roboto", size = ComComp.RespY(20), weight = 500 })
surface.CreateFont("ComComp22", { font = "Roboto", size = ComComp.RespY(22), weight = 500 })
surface.CreateFont("ComComp24", { font = "Roboto", size = ComComp.RespY(24), weight = 500 })
surface.CreateFont("ComComp26", { font = "Roboto", size = ComComp.RespY(26), weight = 500 })
surface.CreateFont("ComComp32", { font = "Roboto", size = ComComp.RespY(32), weight = 500 })
surface.CreateFont("ComComp38", { font = "Roboto", size = ComComp.RespY(38), weight = 500 })

-- Bold fonts
surface.CreateFont("ComComp14Bold", { font = "Roboto", size = ComComp.RespY(14), weight = 1500 })
surface.CreateFont("ComComp16Bold", { font = "Roboto", size = ComComp.RespY(16), weight = 1500 })
surface.CreateFont("ComComp18Bold", { font = "Roboto", size = ComComp.RespY(18), weight = 1500 })
surface.CreateFont("ComComp20Bold", { font = "Roboto", size = ComComp.RespY(20), weight = 1500 })
surface.CreateFont("ComComp24Bold", { font = "Roboto", size = ComComp.RespY(24), weight = 1500 })
surface.CreateFont("ComComp26Bold", { font = "Roboto", size = ComComp.RespY(26), weight = 1500 })

hook.Add("OnScreenSizeChanged", "CC:UpdateFonts", function()
    ComComp.Include("common_computer/core/cl_fonts.lua")
end)

