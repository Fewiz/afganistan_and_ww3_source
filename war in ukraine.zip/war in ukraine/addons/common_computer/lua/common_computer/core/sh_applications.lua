--[[
addons/common_computer/lua/common_computer/core/sh_applications.lua
--]]
ComComp.Apps = {}
ComComp.Apps.List = {}

--[[
	Application meta
--]]

local BaseApp = {}
function BaseApp:Open()

end

function BaseApp:Close()

end

function BaseApp:Pause()

end

function BaseApp:Resume()

end

function BaseApp:SetComputer(computer)
	self.computer = computer
end

function BaseApp:GetComputer()
	return self.computer
end

ComComp.Apps.BaseMeta = BaseApp

--[[
	Load applications
]]

function ComComp.Apps:Register(id, appMeta)
	table.Inherit(appMeta, BaseApp)
	
	appMeta.Id = id
	self.List[id] = appMeta

	hook.Run("CC:Applications:Registered", id, appMeta)
end

function ComComp.Apps:Instantiate(id, computer)
	local meta = self:GetMeta(id)
	if not meta then return end -- App is disabled or just doesn't exists
	
	local newInstance = setmetatable({}, meta)
	newInstance:SetComputer(computer)
	computer:AddApp(newInstance)

	return newInstance
end

function ComComp.Apps:GetMeta(id)
	return self.List[id]
end

ComComp.Apps.BasePath = "common_computer/applications/"

-- Load the applications in the "common_computer/applications" folder
local function LoadApps()
	local _, directories = file.Find(ComComp.Apps.BasePath .. "*", "LUA")
	for _, v in ipairs(directories) do
		if ComComp.IsAppDisabled(v) then goto con end

		APP = {}
		APP.__index = APP
	
		APP.Id = v
		APP.Path = ComComp.Apps.BasePath .. v .. "/"
		ComComp.ThirdInclude(APP.Path)
		
		ComComp.Apps:Register(v, APP)
	
		APP = nil

		::con::
	end

	hook.Run("CC:Applications:Loaded")
end
LoadApps()

