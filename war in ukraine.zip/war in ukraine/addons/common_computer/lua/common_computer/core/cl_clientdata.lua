--[[
addons/common_computer/lua/common_computer/core/cl_clientdata.lua
--]]
ComComp.ClientData = ComComp.ClientData or {}
ComComp.ClientData.Path = "common_computer/client_data.json"
ComComp.ClientData.Data = ComComp.ClientData.Data or {}

function ComComp.ClientData:Save()
	local data = util.TableToJSON(self.Data, true)
	file.Write(self.Path, data)
end

function ComComp.ClientData:Load()
	local data = file.Read(self.Path, "DATA")
	if data then
		data = util.JSONToTable(data)
		table.Merge(self.Data, data)
	end
end

function ComComp.ClientData:Get(id, default)
	return self.Data[id] or default
end

function ComComp.ClientData:Set(id, value)
	self.Data[id] = value
end

hook.Add("Initialize", "CC:ClientData:Load", function()
	hook.Run("CC:ClientData:Setup", ComComp.ClientData.Data)
	
	ComComp.ClientData:Load()
end)

hook.Add("ShutDown", "CC:ClientData::Save", function()
	ComComp.ClientData:Save()
end)

