--[[
addons/common_computer/lua/common_computer/core/sh_baseentity.lua
--]]
--[[
    This is the minimal function required to a "computer" entity.
    (Used by the SWEP and the default computers)
]]

local ENT = {}
ComComp.BaseEntStruct = ENT

if CLIENT then
    function ENT:SetDrawScreen(v)
        self.draw_screen = true
    end
    
    function ENT:GetDrawScreen()
        return self.draw_screen
    end
    
    function ENT:SetComputerInstance(is)
        ComComp.GetCompInstances()[self:EntIndex()] = is
    end
    
    function ENT:GetComputerInstance()
        return ComComp.GetCompInstances()[self:EntIndex()]
    end
end

-- Optimizations
local distToSqr = FindMetaTable("Vector").DistToSqr
local getPos = FindMetaTable("Entity").GetPos
local tickCount = engine.TickCount

local dist = 150^2
ENT.RangeCache = {} -- Cache the values per tick (Don't recalculate the range each time)
function ENT:IsInRange(ent) -- Created this function to have better performance
    local cache = self.RangeCache[ent]
    local tickCount = tickCount()

    if cache and cache.Tick == tickCount then
        return cache.Value
    else
        local inRange = distToSqr(getPos(self), getPos(ent)) <= dist -- TODO Add more conditon later... Or a hook ?

        self.RangeCache[ent] = {
            Value = inRange,
            Tick = tickCount
        }

        return inRange
    end
end

function ENT:GetCamPos()
    return vector_origin, angle_zero
end

