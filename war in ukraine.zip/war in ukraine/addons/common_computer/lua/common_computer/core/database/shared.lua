--[[
addons/common_computer/lua/common_computer/core/database/shared.lua
--]]
ComComp.Database = ComComp.Database or {}
ComComp.Database.DBServer = "https://www.feeps.ovh/"

