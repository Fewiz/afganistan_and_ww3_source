--[[
addons/common_computer/lua/common_computer/core/database/cl_init.lua
--]]
ComComp.Database.ClientKey = ComComp.Database.ClientKey or "" -- To avoid error

net.Receive("ComCompClientKey", function()
	local client_key = net.ReadString()
	ComComp.Database.ClientKey = client_key
end)

