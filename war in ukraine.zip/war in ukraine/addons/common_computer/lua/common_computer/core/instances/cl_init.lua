--[[
addons/common_computer/lua/common_computer/core/instances/cl_init.lua
--]]
local CompInstances = {}
local CurrentlyUsed = nil

local COMPUTER = {}
COMPUTER.__index = COMPUTER

function COMPUTER:PowerOn()
    if self:IsPowered() then
        self:Shutdown()
    end

    self.mainFrame = vgui.Create("ComCompComp")
    self.mainFrame:SetVisible(false)
    self.mainFrame:SetSize(ComComp.RespX(1632), ComComp.RespY(918))
    self.mainFrame:Center()
    self.mainFrame:SetComputerInstance(self)
    
    self.IsOn = true
    
    self.Apps = {}
    hook.Run("CC:Computer:PowerOn", self)
end

function COMPUTER:Use()
    local frame = self:GetMainFrame()
    frame:SetPaintedManually(false)
    frame:SetVisible(true)
    frame:MakePopup()
    self.Paused = false

    CurrentlyUsed = self

    hook.Run("CC:Computer:OnUse", self)
end

function COMPUTER:Pause()
    self.Paused = true

    -- We don't do frame:SetVisible(false) because it'll not render in 3D if so
    local frame = self:GetMainFrame()
    frame:SetPaintedManually(true)
    frame:SetKeyBoardInputEnabled(false)
    frame:SetMouseInputEnabled(false)

    CurrentlyUsed = nil
end

function COMPUTER:IsPaused()
    return self.Paused
end

function COMPUTER:Shutdown()
    self.IsOn = false	

    hook.Run("CC:Computer:Shutdown", self)
    
    for k,v in ipairs(self:GetApps()) do
        v:Close()
    end
    
    local frame = self:GetMainFrame()
    if IsValid(frame) then
        frame:Remove()
    end
end

function COMPUTER:AddApp(app)
    return table.insert(self:GetApps(), app)
end

function COMPUTER:RetrieveApp(id)
    for k, v in ipairs(self:GetApps()) do
        if v.Id == id then
            return v
        end
    end
end

function COMPUTER:CountApp(id)
    local Count = 0 
    for k, v in ipairs(self:GetApps()) do
        if v.Id == id then
            Count = Count + 1
        end
    end
    return Count
end

function COMPUTER:RemApp(app)
    table.RemoveByValue(self:GetApps(), app)
end

function COMPUTER:GetApps()
    return self.Apps
end

function COMPUTER:IsPowered()
    return self.IsOn
end

function COMPUTER:GetMainFrame()
    return self.mainFrame
end

function COMPUTER:SetEntity(ent)
    self.ent = ent
end

function COMPUTER:GetEntity()
    return self.ent or NULL
end

function ComComp:Instantiate(ent)
    local newComputer = setmetatable({}, COMPUTER)
    newComputer:SetEntity(ent)
    return newComputer
end

ComComp.BaseMeta = COMPUTER

function ComComp.GetUsedComputer()
    return CurrentlyUsed
end

function ComComp.GetCompInstances()
    return CompInstances
end

hook.Add("EntityRemoved", "CC:Instance:Remove", function(ent)
    if not ComComp.IsComputer(ent) then return end

    local eIndex = ent:EntIndex()
    timer.Simple(0, function()
        local cs = CompInstances[eIndex]
        if cs then
            cs:Shutdown()
        end
        CompInstances[eIndex] = nil
    end)
end)

net.Receive("ComCompOpen", function(len)
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end
    
    ComComp:Open(LocalPlayer(), ent)
end)

local PendingSwitch = {}
net.Receive("ComCompEntSwitch", function(len, ply)
    local fromIndex = net.ReadUInt(16)
    local from = Entity(fromIndex)
    if not IsValid(from) then return end

    local toIndex = net.ReadUInt(16)
    local to = Entity(toIndex)
    if IsValid(to) then
        ComComp.SwitchEnt(from, to)
    else
        -- Because the client doesn't actually have the new created entity here
        PendingSwitch[toIndex] = fromIndex
    end		
end)

hook.Add("OnEntityCreated", "CC:Instance:Switch", function(to)
    if not ComComp.IsComputer(to) then return end

    if not IsValid(to) then return end
    local toIndex = to:EntIndex()

    local fromIndex = PendingSwitch[toIndex]
    if fromIndex then
        ComComp.SwitchEnt(fromIndex, toIndex)
        PendingSwitch[toIndex] = nil
    end
end)

