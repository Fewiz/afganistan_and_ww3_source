--[[
addons/common_computer/lua/common_computer/core/instances/shared.lua
--]]
local vguiPath = "common_computer/vgui/"
local files, _ = file.Find(vguiPath .. "*", "LUA")
for _, v in ipairs(files) do
	ComComp.Include(vguiPath .. v)
end


--[[
	Open any computer for a player
]]
function ComComp:Open(ply, ent)
	assert(ComComp.IsComputer(ent), "Trying to open a computer instance on an standard entity")

	if SERVER then
		if hook.Run("CC:Computer:CanUse", ply, ent) == false then return end
		
		net.Start("ComCompOpen")
		net.WriteEntity(ent)
		net.Send(ply)
	end
	
	hook.Run("CC:Computer:OnOpen", ply, ent)
	if CLIENT then
		if not ent:GetComputerInstance() then
			ent:SetComputerInstance(ComComp:Instantiate(ent))
		end
		local i = ent:GetComputerInstance()
		if not i:IsPowered() then 
			i:PowerOn()
		end
		
		i:Use()
	end
end


--[[
	This function is used to transfer a computer instance from an entity to another
]]
function ComComp.SwitchEnt(from, to)
	local fromIndex = isnumber(from) and from or from:EntIndex()
	local toIndex = isnumber(to) and to or to:EntIndex()

	if hook.Run("CC:Computer:SwitchEnt", fromIndex, toIndex) == false then return end

	if SERVER then
		net.Start("ComCompEntSwitch")
		net.WriteUInt(fromIndex, 16)
		net.WriteUInt(toIndex, 16)
		net.Broadcast()
		return
	end

	local CompInstances = ComComp.GetCompInstances()

	local cs = CompInstances[fromIndex]
	if not cs then return end

	cs:SetEntity(Entity(toIndex))

	CompInstances[toIndex] = cs
	CompInstances[fromIndex] = nil
end

