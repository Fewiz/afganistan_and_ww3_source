--[[
addons/common_computer/lua/common_computer/core/utilities/shared.lua
--]]
function ComComp.TableCopy(tab)
	if (not tab) then return nil end

	local res = {}
	for k, v in pairs(tab) do
		if (type(v) == "table") then
			res[k] = ComComp.TableCopy(v)
		elseif (type(v) == "Vector") then
			res[k] = Vector(v.x, v.y, v.z)
		elseif (type(v) == "Angle") then
			res[k] = Angle(v.p, v.y, v.r)
		else
			res[k] = v
		end
	end

	return res
end

function ComComp.GetNearestEntity(pos, radius, class)
	local lastDist = math.huge
	local nearestEnt
	for _, v in ipairs(ents.FindInSphere(pos, radius)) do
		if v:GetClass() ~= class then goto con end
	
		local dist = v:GetPos():DistToSqr(pos)
		if dist < lastDist then
			lastDist = dist
			nearestEnt = v
		end
		
		::con::
	end

	return nearestEnt
end

function ComComp.IsImageExtension(ext)
	local images = {
		["png"] = true,
		["jpg"] = true,
		["jpeg"] = true,
		["vmt"] = true,
		["vtf"] = true
	}

	return images[ext] or false
end

function ComComp.IsTextExtension(ext)
	local texts = {
		["txt"] = true,
		["yml"] = true,
		["lua"] = true,
		["sh"] = true,
		["bat"] = true,
		["json"] = true,
		["cfg"] = true
	}

	return texts[ext] or false
end

function ComComp.SecondsToTicks(sec)
	return math.floor(1/engine.TickInterval()) * sec
end

function ComComp.IsComputer(ent)
	return IsValid(ent) and (ent:GetClass() == "cc_laptop" or ent:GetClass() == "cc_laptop_hands" or ent:GetClass() == "cc_desktop")
end

