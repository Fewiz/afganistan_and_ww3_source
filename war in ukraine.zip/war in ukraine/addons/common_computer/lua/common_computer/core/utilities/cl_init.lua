--[[
addons/common_computer/lua/common_computer/core/utilities/cl_init.lua
--]]
local L = ComComp.GetLang
local ScrW = ScrW
local ScrH = ScrH

local leftMouseMat = Material("common_computer/leftmouse.png")
local rightMouseMat = Material("common_computer/rightmouse.png")
local keyMat = Material("common_computer/key.png")


--[[
    Responsive functions
]]

local cW, cH
local function computeScreenSize()
    cH = ScrH() + 1
    repeat
        cH = cH - 1
        cW = cH * 16/9
    until(not (cW > ScrW()))
end
computeScreenSize()
hook.Add("OnScreenSizeChanged", "CC:LockAspectRatio", computeScreenSize)

local function RespX(x)
    return x * (cW/1920) -- Lock aspect ratio to 16/9
end
ComComp.RespX = RespX

local function RespY(y)
    return y * (cH/1080)
end
ComComp.RespY = RespY

function ComComp.Resp(x, y)
    return RespX(x), RespY(y)
end

function ComComp.GetComputedScrW()
    return cW
end

function ComComp.GetComputedScrH()
    return cH
end

--[[
    Material downloading + Document's texture creation
]]

local urlMats = {}
local downloading = {}
-- Download material by id
function ComComp.GetMatByURL(url, iteration, fnc)
    iteration = iteration or 10 -- I think it's better ...
    if urlMats[url] then
        return urlMats[url]
    end

    if downloading[url] then
        return nil
    end

    -- Start "downloading"
    downloading[url] = true

    local html = vgui.Create("DHTML")
    html:SetSize(1920, 1080) -- No responsive !
    html:OpenURL(url)
    if fnc then
        html.OnDocumentReady = fnc
    end
    html:SetAlpha(0)
    html:SetMouseInputEnabled(false)
    html.RenderCount = 0

    local oldThink = html.Think
    html.Think = function()
        oldThink(html)
        local mat = html:GetHTMLMaterial()
        if mat then
            html.RenderCount = html.RenderCount + 1

            if html.RenderCount >= iteration then
                urlMats[url] = mat
                html:Remove()
            end
        end
    end
    html.OnRemove = function()
        downloading[url] = nil
    end

    timer.Simple(10, function()
        if IsValid(html) then
            html:Remove()
        end
    end)
end

local docMats = {}
-- Download material a document by id, correcting his scale
function ComComp.GetDocMat(docId, shader)
    shader = shader or "VertexLitGeneric"

    if not docMats[shader] then
        docMats[shader] = {}
    end

    if docMats[shader][docId] then
        return docMats[shader][docId]
    end

    local mat = ComComp.GetMatByURL(ComComp.Database.DBServer .. "applications/word/?player_key=" .. ComComp.Database.ClientKey .. "&view=" .. docId, 10)
    
    if not mat then
        return nil
    end
    
    local cm = CreateMaterial("ComCompDoc" .. mat:GetName() .. SysTime(), shader, {
        ["$basetexture"] = mat:GetName(),
        ["$basetexturetransform"] = "center 0 0 scale " .. 1920/6850 .. " " .. 1080/2700 .. " rotate 0 translate 0 0",
        ["$model"] = 1
    })
    
    docMats[shader][docId] = cm
    return cm
end

--[[
    Fast code utilities
]]

ComComp.DialogFrame = function(title, text, parent, backColor)
    backColor = backColor or Color(230, 230, 230)

    local frame = vgui.Create("ComCompFrame", parent)
    frame:SetTitle(title)
    frame:SetSize(ComComp.Resp(150, 125))
    frame.OnMaximize = function() end
    frame:SetSizable(false)
    frame:Center()
    frame:MoveToFront()

    local c = frame:Add("Panel")
    c:Dock(FILL)
    c.Paint = function(self, w, h)
        surface.SetDrawColor(backColor:Unpack())
        surface.DrawRect(0, 0, w, h)
    end

    local label = c:Add("DLabel")
    label:DockMargin(RespX(15), RespY(15), RespX(15), 0)
    label:SetFont("ComComp14")
    label:SetText(text)
    label:Dock(FILL)
    label:SetTextColor(color_black)
    label:SetContentAlignment(5)
    label:SetAutoStretchVertical(true)
    label:SetWrap(true)
    
    local btn = c:Add("ComCompButton")
    btn:SetText(L("ok"))
    btn:Dock(BOTTOM)
    btn:DockMargin(RespX(75), 0, RespX(75), RespY(10))
    btn.DoClick = function()
        frame:Remove()
    end

    return frame
end

net.Receive("ComCompNotif", function(len)
    local computer = net.ReadEntity()
    if not IsValid(computer) then return end
    
    local cInstance = computer:GetComputerInstance()
    if not cInstance then return end

    local titleId = net.ReadString()
    local textId = net.ReadString()

    len = len - ((#titleId + 1) + (#textId + 1)) * 8
   
    -- Read arguments (Knowing that string are null terminated -> So we know the amount of args depending on the len)
    local args = {}
    while(len > 0) do
        local a = net.ReadString()
        len = len - (#a + 1) * 8
        table.insert(args, a)
    end

    cInstance:GetMainFrame():Notif(L(titleId), string.format(L(textId), unpack(args)))
end)

--[[
    Draw utilities
]]

function draw.Circle( x, y, radius, seg )
    local cir = {}

    table.insert(cir, {x = x, y = y, u = 0.5, v = 0.5})
    for i = 0, seg do
        local a = math.rad((i / seg) * -360)
        table.insert(cir, { x = x + math.sin(a) * radius, y = y + math.cos(a) * radius, u = math.sin(a) / 2 + 0.5, v = math.cos(a) / 2 + 0.5})
    end

    local a = math.rad(0) -- This is needed for non absolute segment counts
    table.insert(cir, {x = x + math.sin(a) * radius, y = y + math.cos(a) * radius, u = math.sin(a) / 2 + 0.5, v = math.cos(a) / 2 + 0.5})

    surface.DrawPoly(cir)
end

function ComComp.DrawKey(text, font, key, x, y, sqSize)
    key = key and string.upper(input.GetKeyName(input.GetKeyCode(key))) or "?"

    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(keyMat)
    surface.DrawTexturedRect(x, y, sqSize, sqSize)
    
    draw.SimpleText(key, font, x + sqSize/2, y + sqSize/2, nil, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText(text, font, x + sqSize + sqSize/4, y + sqSize/2, nil, nil, TEXT_ALIGN_CENTER)
end

function ComComp.DrawMouse(text, font, side, x, y, sqSize)
    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(side == LEFT and leftMouseMat or rightMouseMat)
    surface.DrawTexturedRect(x, y, sqSize, sqSize)
    
    draw.SimpleText(text, font, x + sqSize + sqSize/4, y + sqSize/2, nil, nil, TEXT_ALIGN_CENTER)
end

