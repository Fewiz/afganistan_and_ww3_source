--[[
addons/common_computer/lua/common_computer/vgui/cl_textentry.lua
--]]
local highColor = Color(48, 128, 255)
local placeColor = Color(120, 120, 120)

local PANEL = {}

AccessorFunc(PANEL, "m_borders", "Borders")
AccessorFunc(PANEL, "m_backColor", "BackgroundColor")

function PANEL:Init()
	self:SetFont("ComComp14")
	self:SetDrawLanguageID(false)
	self:SetBorders(true)
	self:SetBackgroundColor(color_white)
	self:SetTextColor(color_black)
end

function PANEL:Paint(w, h)
	surface.SetDrawColor(self:GetBackgroundColor())
	surface.DrawRect(0, 0, w, h)

	if self:GetBorders() then
		if self:IsEditing() then
			surface.SetDrawColor(71, 175, 255)
		else
			surface.SetDrawColor(195, 195, 195)
		end
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	
	local val = string.Trim(self:GetValue())
	local pt = self:GetPlaceholderText()
	if #val == 0 and pt and #pt ~= 0 then
		draw.SimpleText(pt, self:GetFont(), 3, h/2, placeColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	else
		self:DrawTextEntryText(self:GetTextColor(), highColor, self:GetTextColor())
	end
end

vgui.Register("ComCompTextEntry", PANEL, "DTextEntry")

