--[[
addons/common_computer/lua/common_computer/vgui/cl_computer.lua
--]]
local winIconMat = Material("common_computer/winicon.png")
local notifMat = Material("common_computer/notif.png")

local PANEL = {}

function PANEL:Init()
	self:ShowCloseButton(false)
	self.lblTitle:SetVisible(false)
	self:DockPadding(0, 0, 0, 0)

	-- AppArea
	local appArea = self:Add("Panel")
	appArea:Dock(FILL)
	appArea.NewFrame = function(self, optionalTitle)
		local frame = self:Add("ComCompFrame")
		if optionalTitle then
			frame:SetTitle(optionalTitle)
		end
		
		return frame
	end

	-- This function allows us to move the icons on the desktop
	appArea:Receiver("DesktopIcon", function(self, panels, bDoDrop, cmd, x, y)
		if not bDoDrop then return end
		
		local iconSizeX = ComComp.RespX(56)
		local iconSizeY = ComComp.RespX(64)
		x = x + iconSizeX/2 - iconSizeX
		y = y + iconSizeY/2 - iconSizeY
		
		for k,v in ipairs(panels) do
			local appId = v.appId
			local gX, gY = math.Round(x/iconSizeX), math.Round(y/iconSizeY)

			gX = math.Clamp(gX, 0, math.floor(appArea:GetWide()/iconSizeX))
			gY = math.Clamp(gY, 0, math.floor(appArea:GetTall()/iconSizeY))

			-- Check if an the space is available
			for k, v in ipairs(appArea:GetChildren()) do
				if not v.appId or v:GetName() ~= "DPanel" then goto con end

				if (ComComp.ClientData:Get("IconPos" .. v.appId .. "X") == gX and ComComp.ClientData:Get("IconPos" .. v.appId .. "Y") == gY) then
					return
				end

				::con::
			end

			ComComp.ClientData:Set("IconPos" .. appId .. "X", gX)
			ComComp.ClientData:Set("IconPos" .. appId .. "Y", gY)
			
			v:SetPos(gX * iconSizeX, gY * iconSizeY)
		end
	end)
	appArea.NewFrame = function(self)
		return self:Add("ComCompFrame")
	end

	self.appArea = appArea
	
	-- TaskBar
	local taskBar = self:Add("ComCompTaskBar")
	taskBar:Dock(BOTTOM)
	self.taskBar = taskBar
	
	-- StartMenu
	local st = self:Add("ComCompStartMenu")
	st:SetSize(ComComp.Resp(290, 405))
	st:SetVisible(false)
	self.startMenu = st
	local winIcon = taskBar:AddIcon("startmenu", winIconMat, function()
		st:SetVisible(not st:IsVisible())
	end)
	winIcon:SetUseSysColor(true)
	hook.Add("VGUIMousePressed", st, function(panel, mouseCode)
		if (not (st:IsHovered() or st:IsChildHovered()) and not winIcon:IsHovered()) then -- panel ~= st doesn't work ... st has focus
			st:SetVisible(false)
		end
	end)
	
	-- Notifications Area
	local notif = self:GetAppArea():Add("Panel")
	notif.Paint = function(self, w, h)
		surface.SetDrawColor(50, 50, 60)
		surface.DrawRect(0, 0, w, h)
	end
	notif:Dock(RIGHT)
	notif:SetZPos(ComComp.Cfg["ZPos"]["NotifMenu"])
	notif:SetVisible(false)
	notif:SetWide(ComComp.RespX(300))
	self.notif = notif
	local notifBtn = taskBar:AddIcon("notification", notifMat, function()
		notif:SetVisible(not notif:IsVisible())
	end)
	notifBtn:Dock(RIGHT)
	notifBtn:DockMargin(0, 0, ComComp.RespX(6), 0)
	hook.Add("VGUIMousePressed", notif, function(panel, mouseCode)
		if (not (notif:IsHovered() or notif:IsChildHovered()) and not notifBtn:IsHovered()) then
			notif:SetVisible(false)
		end
	end)
	
	-- Date an hour
	local time = taskBar:AddIcon("time")
	time:Dock(RIGHT)
	time:SetWide(ComComp.RespX(70))
	time.PaintOver = function(self, w, h)
		local offset = (h - ComComp.RespY(12 * 2))/2
		draw.SimpleText(os.date("%H:%M"), "ComComp12", w/2, offset, nil, TEXT_ALIGN_CENTER)
		draw.SimpleText(os.date("%m/%d/%Y"), "ComComp12", w/2, offset +  ComComp.RespY(12), nil, TEXT_ALIGN_CENTER)
	end
	
	-- Show the language (Decoration)
	local lang = taskBar:AddIcon("lang")
	lang:Dock(RIGHT)
	lang:SetWide(ComComp.RespX(25))
	lang.PaintOver = function(self, w, h)
		draw.SimpleText(string.upper(ComComp.Cfg["Lang"]), "ComComp12", w/2, h/2 - ComComp.RespY(12)/2, nil, TEXT_ALIGN_CENTER)
	end
	
	hook.Run("CC:DesktopCreated", self)
end

function PANEL:AddDesktopIcon(id, mat, text, gX, gY, doclick)
	local datX = ComComp.ClientData:Get("IconPos" .. id .. "X")
	local datY = ComComp.ClientData:Get("IconPos" .. id .. "Y")
	gX = datX or gX
	gY = datY or gY

	local iconSizeX = ComComp.RespX(56)
	local iconSizeY = ComComp.RespX(64)

	local icon = self:GetAppArea():Add("DPanel")
	icon.appId = id
	icon:SetZPos(ComComp.Cfg["ZPos"]["DesktopIcon"])
	icon:SetPos(gX * iconSizeX, gY * iconSizeY)
	icon:Droppable("DesktopIcon")
	icon:SetSize(iconSizeX, iconSizeX)
	icon.PerformLayout = function(self, w, h)
		self.markup = markup.Parse("<font=ComComp14>" .. text .. "</font>", w)
	end
	icon.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(mat)
		
		local off = w/5
		surface.DrawTexturedRect(off, off, w - off * 2, h - off * 2)
		
		if self.markup then
			DisableClipping(true)
			for k, v in ipairs(self.markup.blocks) do
				draw.SimpleText(v.text, "ComComp14", w/2, h - off + (k - 1) * ComComp.RespX(14), nil, TEXT_ALIGN_CENTER)
			end
			DisableClipping(false)
		end
	end
	if doclick then
		icon.OnMouseReleased = function(self, mousecode)
			if self:EndBoxSelection() then return end

			self:MouseCapture(false)

			if self:DragMouseRelease(mousecode) then return end
			if not self:IsHovered() then return end

			if (mousecode == MOUSE_LEFT) then
				doclick()
			end
		end

	end
	
	return icon
end

-- Send a notification to the desktop (Right bottom gray square)
function PANEL:Notif(title, text, duration)
	duration = duration or 5

	local appArea = self:GetAppArea()

	local panel = appArea:Add("Panel")
	panel:SetZPos(ComComp.Cfg["ZPos"]["Notif"])
	panel:SetSize(ComComp.Resp(320, 150))
	
	local offX, offY = ComComp.Resp(10, 10)
	panel.PerformLayout = function()
		panel:SetPos(appArea:GetWide() - panel:GetWide() - offX*2, appArea:GetTall() - panel:GetTall() - offY*2)
	end
	panel.Start = CurTime()
	panel.mu = markup.Parse("<font=ComComp24>" .. title .. "</font>\n\n<font=ComComp14>" .. text .. "</font>", panel:GetWide() - offX * 2)
	panel.Paint = function(self, w, h)
		surface.SetDrawColor(40, 40, 50)
		surface.DrawRect(0, 0, w, h)
		
		self.mu:Draw(offX, offY)
		
		if not self.Closed then
			surface.SetDrawColor(255, 255, 255)
			local frac = ((panel.Start + duration) - CurTime())/duration
			surface.DrawRect(0, h-2, frac * w, 2)
		end
	end
	
	panel.Close = function()
		if IsValid(self.notif) then
			self.notif:Add(panel)
			panel:DockMargin(0, 2, 0, 0)
			panel:Dock(TOP)
			panel.mu = markup.Parse(text, self.notif:GetWide() - offX * 2)
			panel.Closed = true
		end
	end
	
	panel.OnMousePressed = function()
		panel:Close()
		panel.OnMousePressed = function()
			panel:Remove()
		end
	end
	
	timer.Simple(duration, function()
		if IsValid(panel) then
			panel:Close()
		end
	end)
end

function PANEL:PerformLayout(w, h)
	self.startMenu:SetPos(0, h - self.taskBar:GetTall() - self.startMenu:GetTall())
end

function PANEL:Paint(w, h)
	if not self:GetComputerInstance():IsPaused() then
		Derma_DrawBackgroundBlur(self, self.m_fCreateTime) -- Blur the screen
	end
	
	local clientWall = ComComp.ClientData:Get("WallpaperPath")
	if self.WallMat and self.WallPath == clientWall then
		if not self.WallMat:IsError() then -- Draw the wallpaper
			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, w, h)
			
			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(self.WallMat)
			surface.DrawTexturedRect(0, 0, w, h)
		else -- Draw the color
			local color = ComComp.ClientData:Get("Color")
			surface.SetDrawColor(color)
			surface.DrawRect(0, 0, w, h)
		end
	elseif self.WallPath ~= clientWall then
		self.WallPath = clientWall
		self.WallMat = Material(clientWall, "smooth") -- Loading the Material only one time
	end
end

function PANEL:SetComputerInstance(is)
	self.com_instance = is
end

function PANEL:GetComputerInstance()
	return self.com_instance
end

function PANEL:GetAppArea()
	return self.appArea
end

function PANEL:GetTaskBar()
	return self.taskBar
end

function PANEL:GetStartMenu()
	return self.startMenu
end

vgui.Register("ComCompComp", PANEL, "DFrame") -- We use a DFrame because keyboard input need it

hook.Add("CC:ClientData:Setup", "CC:DefaultSettings", function(data)
	data["WallpaperPath"] = "common_computer/wallpapers/common_computer.jpg"
	data["Color"] = Color(133, 200, 255)
end)

