--[[
addons/common_computer/lua/common_computer/vgui/cl_taskbar.lua
--]]
local PANEL = {}

function PANEL:Init()
	self.Icons = {}
	self:SetTall(ComComp.RespY(36))
	
	timer.Simple(0, function() -- Icons that are created in cl_computer.lua need to be created before the hook
		hook.Run("CC:TaskbarCreated", self)
	end)
end

function PANEL:AddIcon(id, mat, doclick, startamount, persistent)
	local icon = self:GetIcon(id)
	if not IsValid(icon) then
		icon = self:Add("Panel")
		icon.Amount = startamount or 0
		icon.Persistent = persistent == nil and true or persistent
		icon:Dock(LEFT)
		icon:SetWide(self:GetTall())
		icon.SetUseSysColor = function(_, use)
			icon.SysColor = use
		end
		icon.GetUseSysColor = function()
			return icon.SysColor
		end
		icon.Paint = function(self, w, h)
			if self:IsHovered() then
				surface.SetDrawColor(100, 100, 100, 100)
				surface.DrawRect(0, 0, w, h)
			end
			
			if mat then
				if self:GetUseSysColor() and self:IsHovered() then
					surface.SetDrawColor(ComComp.ClientData:Get("Color"))
				else
					surface.SetDrawColor(color_white)
				end
				
				surface.SetMaterial(mat)
				surface.DrawTexturedRect(w/5, h/5, w - w/5 * 2, h - h/5 * 2)
			end
			
			if self.Amount > 0 then
				local color = ComComp.ClientData:Get("Color")
				surface.SetDrawColor(color)
				if self:IsHovered() then
					local off = ComComp.RespX(2)
					DisableClipping(true)
					surface.DrawRect(-off, h - ComComp.RespY(3), w + off*2, ComComp.RespY(3))
					DisableClipping(false)
				else
					surface.DrawRect(1, h - ComComp.RespY(3), w - 2, ComComp.RespY(3))
				end
			end
		end
		if doclick then
			icon.OnMousePressed = doclick
		end

		self.Icons[id] = icon
	else
		icon.Amount = icon.Amount + 1
	end
	
	return icon
end

function PANEL:DecreaseIcon(id)
	local i = self:GetIcon(id)
	if not IsValid(i) then return end
	
	i.Amount = i.Amount - 1
	if i.Amount <= 0 and not i.Persistent then
		self:RemIcon(id)
	end
end

function PANEL:GetIcon(id)
	return self.Icons[id]
end

function PANEL:RemIcon(id)
	local i = self:GetIcon(id)
	if IsValid(i) then
		i:Remove()
	end
end

function PANEL:Paint(w,h)
	surface.SetDrawColor(20, 20, 20, 220)
	surface.DrawRect(0, 0, w, h)
end

vgui.Register("ComCompTaskBar", PANEL, "Panel")

