--[[
addons/common_computer/lua/common_computer/vgui/cl_button.lua
--]]
local selBlue = Color(71, 175, 255)
local lightGray = Color(215, 215, 215)
local darkGray = Color(190, 190, 190)

local PANEL = {}

function PANEL:Init()
	self:SetTextColor(color_black)
	self:SetFont("ComComp16")
	self:SetCursor("arrow")
end

function PANEL:UpdateColours() end

function PANEL:Paint(w, h)
	surface.SetDrawColor(lightGray)
	surface.DrawRect(0, 0, w, h)

	if self:IsHovered() then
		surface.SetDrawColor(selBlue.r, selBlue.g, selBlue.b, 35)
		surface.DrawRect(0, 0, w, h)
	
		surface.SetDrawColor(selBlue)
		surface.DrawOutlinedRect(0, 0, w, h)
	else
		surface.SetDrawColor(darkGray)
		surface.DrawOutlinedRect(0, 0, w, h)
	end
end

vgui.Register("ComCompButton", PANEL, "DButton")

