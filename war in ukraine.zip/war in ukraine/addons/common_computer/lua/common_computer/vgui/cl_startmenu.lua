--[[
addons/common_computer/lua/common_computer/vgui/cl_startmenu.lua
--]]
local L = ComComp.GetLang
local powerMat = Material("common_computer/power-button.png")
local moreMat = Material("common_computer/more.png")

local PANEL = {}

function PANEL:Init()
	local side = self:Add("Panel")
	side:Dock(LEFT)
	side:DockPadding(0, ComComp.RespY(6), 0, 0)
	side:SetWide(ComComp.RespX(36))
	side.Paint = function(self, w, h)
		surface.SetDrawColor(45, 45, 55)
		surface.DrawRect(0, 0, w, h)
	end
	side.Extended = false
	self.side = side
	
	self:SetZPos(ComComp.Cfg["ZPos"]["StartMenu"])
	
	local moreBtn = self:AddSideButton(moreMat, L("startmenu"), "ComComp18Bold", function()
		side.Extended = not side.Extended
		side:SetWide(side.Extended and self:GetWide() * 0.79 or ComComp.RespX(36))
	end)
	moreBtn:Dock(TOP)
	
	self:AddSideButton(powerMat, L("shutdown"), "ComComp16", function()
		self:GetParent():GetComputerInstance():Pause()
	end)
	

	local fill = self:Add("Panel")
	fill:Dock(FILL)
	self.fill = fill
	
	hook.Run("CC:StartMenuCreated", self)
end

function PANEL:Paint(w, h)
	surface.SetDrawColor(50, 50, 60)
	surface.DrawRect(0, 0, w, h)
end

function PANEL:Close()
	self:SetVisible(false)
end

function PANEL:AddSideButton(mat, name, font, doclick)
	local btn = self.side:Add("Panel")
	btn:Dock(BOTTOM)
	btn:SetTall(ComComp.RespY(36))
	btn.Paint = function(self, w, h)
		if self:IsHovered() then
			surface.SetDrawColor(100, 100, 100, 100)
			surface.DrawRect(0, 0, w, h)
		end
	
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(mat)
		local offset = ComComp.RespX(6)
		surface.DrawTexturedRect(offset, offset, h - offset*2, h - offset*2)
		
		draw.SimpleText(name, font, h + ComComp.RespX(8), h/2 - ComComp.RespY(18)/2)
	end
	btn.OnMousePressed = doclick
	
	return btn
end

vgui.Register("ComCompStartMenu", PANEL, "Panel")

