--[[
addons/common_computer/lua/common_computer/vgui/cl_3dpanel.lua
--]]
local PANEL = {}

local color_red = Color(255, 0, 0)
local color_green = Color(0, 255, 0)
local color_blue = Color(0, 0, 255)

AccessorFunc(PANEL, "3d_fov", "3DFOV", FORCE_NUMBER)
AccessorFunc(PANEL, "3d_pos", "3DPos")
AccessorFunc(PANEL, "3d_ang", "3DAngles")
AccessorFunc(PANEL, "3d_fnc", "DrawFnc")
AccessorFunc(PANEL, "orbit_pos", "OrbitPos")
AccessorFunc(PANEL, "orbit_dist", "OrbitDist", FORCE_NUMBER)
AccessorFunc(PANEL, "texRt", "RenderTarget")
AccessorFunc(PANEL, "mat", "Material")
AccessorFunc(PANEL, "clearColor", "ClearColor")
AccessorFunc(PANEL, "key_orbit", "OrbitKey", FORCE_NUMBER)
AccessorFunc(PANEL, "key_fps", "FPSKey", FORCE_NUMBER)
AccessorFunc(PANEL, "key_forward", "ForwardKey", FORCE_NUMBER)
AccessorFunc(PANEL, "key_left", "LeftKey", FORCE_NUMBER)
AccessorFunc(PANEL, "key_right", "RightKey", FORCE_NUMBER)
AccessorFunc(PANEL, "key_backward", "BackwardKey", FORCE_NUMBER)

function PANEL:Init()
    -- We're using a RenderTarget because otherwise, the drawing will not work in 3D
    self:SetRenderTarget(GetRenderTarget("cc_3dpanel" .. SysTime(), 2048, 2048))
    self:SetMaterial(CreateMaterial(self:GetRenderTarget():GetName(), "UnlitGeneric", {
        ["$basetexture"] = self:GetRenderTarget():GetName()
    }))

    self:Set3DFOV(70)
    self:Set3DPos(Vector())
    self:Set3DAngles(Angle())
    self:SetClearColor(color_black)
    self:SetOrbitPos(Vector())
    self:SetOrbitDist(100)
    self:SetDrawFnc(function()
        render.DrawLine(vector_origin, Vector(1, 0, 0) * 15, color_red)
        render.DrawLine(vector_origin, Vector(0, 1, 0) * 15, color_green)
        render.DrawLine(vector_origin, Vector(0, 0, 1) * 15, color_blue)
    end)

    self:SetOrbitKey(MOUSE_RIGHT)
    self:SetFPSKey(MOUSE_LEFT)
    self:SetForwardKey(input.GetKeyCode(input.LookupBinding("forward") or "") or KEY_W)
    self:SetLeftKey(input.GetKeyCode(input.LookupBinding("moveleft") or "") or KEY_A)
    self:SetBackwardKey(input.GetKeyCode(input.LookupBinding("back") or "") or KEY_S)
    self:SetRightKey(input.GetKeyCode(input.LookupBinding("moveright") or "") or KEY_D)
end

function PANEL:OnMouseWheeled(delta)
    self:SetOrbitDist(self:GetOrbitDist() - delta * 2.5)
    self:Set3DPos(self:GetOrbitPos() - self:Get3DAngles():Forward() * self:GetOrbitDist())
end

function PANEL:Think()
    local orbitKey = input.IsButtonDown(self:GetOrbitKey())
    local fpsKey = input.IsButtonDown(self:GetFPSKey())

    if orbitKey or fpsKey then
        if not self.Capturing then
            if self:IsHovered() then
                self:MouseCapture(true)
                self.Capturing = true
            end
        else
            local scale = self:Get3DFOV()/180
            local x, y = input.GetCursorPos()
    
            if self.mx and self.my then
                x = (x - self.mx) * -0.5 * scale
                y = (y - self.my) * 0.5 * scale
    
                if orbitKey then 
                    -- Orbit mode
                    self:Set3DAngles(self:Get3DAngles() + Angle(y * 4, x * 4, 0))
                    self:Set3DPos(self:GetOrbitPos() - self:Get3DAngles():Forward() * self:GetOrbitDist())
                elseif fpsKey then 
                    -- FPS Mode
                    local ang = self:Get3DAngles()
                    ang = ang + Angle(y, x, 0)
                    ang:Normalize()
                    
                    ang.p = math.Clamp(ang.p, -90, 90)
                    
                    local dir = vector_origin
                    if input.IsButtonDown(self:GetForwardKey()) then dir = dir + ang:Forward() end
                    if input.IsButtonDown(self:GetBackwardKey()) then dir = dir - ang:Forward() end
                    if input.IsButtonDown(self:GetLeftKey()) then dir = dir - ang:Right() end
                    if input.IsButtonDown(self:GetRightKey()) then dir = dir + ang:Right() end
                
                    self:Set3DAngles(ang)
                    self:Set3DPos(self:Get3DPos() + dir * 0.2)
                end
            end
    
            local cx, cy = self:LocalToScreen(self:GetWide() * 0.5, self:GetTall() * 0.5)
            input.SetCursorPos(cx, cy)
            self.mx = cx
            self.my = cy
        end
    elseif self.Capturing then
        self:MouseCapture(false)
        self.Capturing = false
    
        self.mx = nil
        self.my = nil
    end
end

function PANEL:ShouldUpdateRenderTarget()
    return true
end

function PANEL:Paint(w, h)
    if self:ShouldUpdateRenderTarget() ~= false then
        render.PushRenderTarget(self:GetRenderTarget())
            render.ClearDepth()

            local cc = self:GetClearColor()
            render.Clear(cc.r, cc.g, cc.b, cc.a)

            cam.Start3D(self:Get3DPos(), self:Get3DAngles(), self:Get3DFOV(), 0, 0, w, h)
                local drawFnc = self:GetDrawFnc()
                if drawFnc then
                    drawFnc()
                end
            cam.End3D()
        render.PopRenderTarget()
    end

    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(self:GetMaterial())
    surface.DrawTexturedRectUV(0, 0, w, h, 0, 0, w/self:GetMaterial():Width(), h/self:GetMaterial():Height())
end

vgui.Register("ComComp3DPanel", PANEL, "Panel")

