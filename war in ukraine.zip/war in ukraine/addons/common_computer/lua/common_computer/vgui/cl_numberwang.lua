--[[
addons/common_computer/lua/common_computer/vgui/cl_numberwang.lua
--]]
-- Copy of ComCompTextEntry

local highColor = Color(48, 128, 255)
local selBlue = Color(71, 175, 255)
local lightGray = Color(195, 195, 195)

local PANEL = {}
AccessorFunc(PANEL, "m_borders", "Borders")
AccessorFunc(PANEL, "m_backColor", "BackgroundColor")

function PANEL:Init()
	self:SetFont("ComComp14")
	self:SetDrawLanguageID(false)
	self:SetBorders(true)
	self:SetBackgroundColor(color_white)
	self:SetTextColor(color_black)
end

function PANEL:Paint(w, h)
	surface.SetDrawColor(self:GetBackgroundColor())
	surface.DrawRect(0, 0, w, h)

	if self:GetBorders() then
		surface.SetDrawColor(self:IsEditing() and selBlue or lightGray)
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	
	self:DrawTextEntryText(self:GetTextColor(), highColor, self:GetTextColor())
end

vgui.Register("ComCompNumberWang", PANEL, "DNumberWang")

