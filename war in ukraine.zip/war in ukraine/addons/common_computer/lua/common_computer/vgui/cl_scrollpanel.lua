--[[
addons/common_computer/lua/common_computer/vgui/cl_scrollpanel.lua
--]]
-- Light
local lightGray = Color(235, 235, 235)
local middleGray = Color(190, 190, 190)
local darkGray = Color(155, 155, 155)

-- Dark
local lightDark = Color(20, 20, 20)
local middleDark = Color(100, 100, 100)
local darkDark = Color(85, 85, 85)

local PANEL = {}

function PANEL:Init()
	self:SetDark(false)

	local vBar = self:GetVBar()
	vBar.btnUp:SetCursor("arrow")
	vBar.btnDown:SetCursor("arrow")

	vBar.Paint = function(_, w, h)
		surface.SetDrawColor(self:GetDark() and lightDark or lightGray)
		surface.DrawRect(0, 0, w, h)
	end

	vBar.btnUp.Paint = function(_, w, h) 
		if not self:GetDark() then
			surface.SetDrawColor(vBar.btnUp:IsHovered() and middleGray or lightGray)
		else
			surface.SetDrawColor(vBar.btnUp:IsHovered() and middleDark or lightDark)
		end
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("⋀", "ComComp14Bold", w/2, h/2 - ComComp.RespY(14)/2, self:GetDark() and color_white or color_black, TEXT_ALIGN_CENTER)
	end

	vBar.btnDown.Paint = function(_, w, h)
		if not self:GetDark() then
			surface.SetDrawColor(vBar.btnDown:IsHovered() and middleGray or lightGray)
		else
			surface.SetDrawColor(vBar.btnDown:IsHovered() and middleDark or lightDark)
		end
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("⋁", "ComComp14Bold", w/2, h/2 - ComComp.RespY(14)/2, self:GetDark() and color_white or color_black, TEXT_ALIGN_CENTER)
	end

	vBar.btnGrip.Paint = function(_, w, h)
		if not self:GetDark() then
			surface.SetDrawColor(vBar.btnGrip:IsHovered() and darkGray or middleGray)
		else
			surface.SetDrawColor(vBar.btnGrip:IsHovered() and darkDark or middleDark)
		end
		surface.DrawRect(0, 0, w, h)
	end
end

function PANEL:SetDark(dark)
	self.DarkMode = dark
end

function PANEL:GetDark()
	return self.DarkMode
end

vgui.Register("ComCompScrollPanel", PANEL, "DScrollPanel")

