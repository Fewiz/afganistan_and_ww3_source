--[[
addons/common_computer/lua/common_computer/vgui/cl_moveablepanel.lua
--]]
local PANEL = {}

AccessorFunc(PANEL, "m_sizable", "Sizable", FORCE_BOOL)
AccessorFunc(PANEL, "m_draggable", "Draggable", FORCE_BOOL)

function PANEL:Init()
    self:SetSizable(true)
    self:SetDraggable(true)
end

-- Dragging
function PANEL:StartDrag(x, y)
    x = x or (gui.MouseX() - self.x)
    y = y or (gui.MouseY() - self.y)

    if self:OnDragStart(x, y) ~= false then
        self.Dragging = {x, y}
        self:MouseCapture(true)
    end
end

function PANEL:IsDragging()
    return self.Dragging ~= nil
end

function PANEL:StopDrag()
    if self:OnDragStop() ~= false then
        self.Dragging = nil
        self:MouseCapture(false)
    end
end

-- Sizing
function PANEL:StartSize(x, y)
    x = x or (gui.MouseX() - self:GetWide())
    y = y or (gui.MouseY() - self:GetTall())

    if self:OnSizeStart(x, y) ~= false then
        self.Sizing = {x, y}
        self:MouseCapture(true)
    end
end

function PANEL:IsSizing()
    return self.Sizing ~= nil
end

function PANEL:StopSize()
    if self:OnSizeStop() ~= false then
        self.Sizing = nil
        self:MouseCapture(false)
    end
end

-- Empty functions
function PANEL:OnDragStart() end
function PANEL:OnSizeStart() end
function PANEL:OnDragStop() end
function PANEL:OnSizeStop() end

function PANEL:OnMousePressed(code)
    if code ~= MOUSE_FIRST then return end

	if self:GetSizable() and self:CursorInSizeable() then
        self:StartSize()
	elseif self:GetDraggable() then
        self:StartDrag()
    end
end

function PANEL:OnMouseReleased(code)
    if self:IsSizing() then
        self:StopSize()
    end

    if self:IsDragging() then
        self:StopDrag()
    end
end

-- Check if the cursor is in the small area where the panel can start to be resized (bottom right)
function PANEL:CursorInSizeable()
    local screenX, screenY = self:LocalToScreen(0, 0)
    return gui.MouseX() > (screenX + self:GetWide() - 5) and gui.MouseY() > (screenY + self:GetTall() - 5)
end

function PANEL:Think()
	local mousex = math.Clamp(gui.MouseX(), 1, ScrW() - 1)
	local mousey = math.Clamp(gui.MouseY(), 1, ScrH() - 1)

	if self:IsDragging() then
		local x = mousex - self.Dragging[1]
		local y = mousey - self.Dragging[2]

		x = math.Clamp(x, 0, self:GetParent():GetWide() - self:GetWide())
		y = math.Clamp(y, 0, self:GetParent():GetTall() - self:GetTall())

		self:SetPos(x, y)
		return
	end
	
	if self:IsSizing() then
		local x = mousex - self.Sizing[1]
		local y = mousey - self.Sizing[2]

        x = math.Clamp(x, 0, self:GetParent():GetWide() - self.x)
        y = math.Clamp(y, 0, self:GetParent():GetTall() - self.y)

		self:SetSize(x, y)
		self:SetCursor("sizenwse")
		return
	end

	if self:GetSizable() and self:CursorInSizeable() then
		self:SetCursor("sizenwse")
		return
	end
	
	self:SetCursor("arrow")
end

vgui.Register("ComCompMoveablePanel", PANEL, "DFrame")

