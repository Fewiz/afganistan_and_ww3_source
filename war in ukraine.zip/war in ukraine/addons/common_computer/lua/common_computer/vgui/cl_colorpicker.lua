--[[
addons/common_computer/lua/common_computer/vgui/cl_colorpicker.lua
--]]
local colorPickerMat = Material("common_computer/colorpicker.png", "smooth")
local satPickerMat = Material("common_computer/satpicker.png", "smooth")

local PANEL = {}

function PANEL:Init()
    self.pickColor = Color(255, 255, 255)
    self.pickSat = 0 -- Goes from 0 to 1

    -- Color picker
    local wheel = self:Add("Panel")
    wheel:Dock(TOP)
    wheel.Point = Vector(0.5, 0.5)
    wheel.Paint = function(_, w, h)
        local fc = 1 - self.pickSat
        surface.SetDrawColor(255 * fc, 255 * fc, 255 * fc)
        surface.SetMaterial(colorPickerMat)
        surface.DrawTexturedRect(0, 0, w, h)

        -- Draw the cursor
        DisableClipping(true)
            local px, py = wheel.Point.x, wheel.Point.y

            draw.NoTexture()
            surface.SetDrawColor(0, 0, 0)
            draw.Circle(w * px, h * py, 4, 20)
            
            surface.SetDrawColor(255, 255, 255)
            draw.Circle(w * px, h * py, 3, 20)
        DisableClipping(false)

        -- Move behavior
        if wheel.Capture then
            local mx, my = wheel:ScreenToLocal(gui.MouseX(), gui.MouseY())
            
            local tx, ty = mx - w/2, my - w/2
            if math.sqrt(tx * tx + ty * ty) >= h/2 then
                local ang = math.atan2(my - h/2, mx - w/2)
                mx = math.cos(ang) * (w/2 - 2) + w/2
                my = math.sin(ang) * (h/2 - 2) + h/2
            end

            wheel.Point.x = mx/w
            wheel.Point.y = my/h

            local cTab = colorPickerMat:GetColor(mx/w * colorPickerMat:Width(), my/h * colorPickerMat:Height())
            if cTab.a == 255 then
                local nColor = Color(cTab.r, cTab.g, cTab.b)
                if nColor ~= self.pickColor then
                    self.pickColor = nColor
                    self:ValueChanged(self:GetColor())
                end
            end
        end
    end
    wheel.OnMousePressed = function(_, code)
        wheel.Capture = true
        wheel:MouseCapture(true)
    end
    wheel.OnMouseReleased = function(_, code)
        wheel.Capture = false
        wheel:MouseCapture(false)
    end
    self.wheel = wheel

    -- Saturation picker
    local satbar = self:Add("Panel")
    satbar:Dock(TOP)
    satbar:DockMargin(0, ComComp.RespY(5), 0, 0)
    satbar.Paint = function(_, w, h)
        surface.SetDrawColor(self.pickColor:Unpack())
        surface.SetMaterial(satPickerMat)
        surface.DrawTexturedRect(0, 0, w, h)

        -- Draw cursor
        DisableClipping(true)
            draw.NoTexture()
            surface.SetDrawColor(0, 0, 0)
            draw.Circle(self.pickSat * w, h/2, 4, 20)

            surface.SetDrawColor(255, 255, 255)
            draw.Circle(self.pickSat * w, h/2, 3, 20)
        DisableClipping(false)

        if satbar.Capture then
            local mx, _ = satbar:ScreenToLocal(gui.MouseX(), gui.MouseY())
            self.pickSat = math.Clamp(mx, 0, w)/w
        end
    end
    satbar.OnMousePressed = function(_, code)
        satbar.Capture = true
        satbar:MouseCapture(true)
    end
    satbar.OnMouseReleased = function(_, code)
        satbar.Capture = false
        satbar:MouseCapture(false)
    end
    self.satbar = satbar
end

function PANEL:ValueChanged(col)

end

function PANEL:SetColor(col)
    local h, s, v = col:ToHSV()

    local ang = h/360 * math.pi * 2 - math.pi/2

    -- Each color + radius corresponds to a color (+ value)
    local r = self.wheel:GetWide()/2
    local x = math.cos(ang) * s * v * r
    local y = math.sin(ang) * s * v * r

    self.wheel.Point.x = (x + r)/(r*2)
    self.wheel.Point.y = (y + r)/(r*2)

    local cTab = HSVToColor(h, s, 1)
    self.pickColor = Color(cTab.r, cTab.g, cTab.b)
    self.pickSat = (1 - v)

    self:ValueChanged(self:GetColor())
end

function PANEL:GetColor()
    local lc = self.pickColor
    local ls = 1 - self.pickSat
    return Color(lc.r * ls, lc.g * ls, lc.b * ls)
end

function PANEL:SizeToContentsY(a)
    local _, mt = self.satbar:GetDockMargin()
    self:SetTall((a or 0) + self:GetWide() + mt + self.satbar:GetTall())
end

function PANEL:PerformLayout(w, h)
    self.wheel:SetTall(w)
    self.satbar:SetTall(w/7.5)
end

vgui.Register("ComCompColorPicker", PANEL, "Panel")

