--[[
addons/common_computer/lua/common_computer/vgui/cl_menubar.lua
--]]
local PANEL = {}

function PANEL:Paint(w, h)
	surface.SetDrawColor(255, 255, 255)
	surface.DrawRect(0, 0, w, h)
end

vgui.Register("ComCompMenuBar", PANEL, "DMenuBar")

