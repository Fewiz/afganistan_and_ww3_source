--[[
addons/common_computer/lua/common_computer/vgui/cl_frame.lua
--]]
local SelectedFrame = nil

local redColor = Color(255, 0, 0)
local grayColor = Color(220, 220, 220)

local PANEL = {}

function PANEL:Init()
	local header = self:Add("Panel")
	header:SetTall(ComComp.RespY(25))
	header:Dock(TOP)
	header.textColor = color_black
	header.OnMousePressed = function()
		self:StartDrag()
	end
	self.header = header
	
	local icon = header:Add("DImage")
	icon:Dock(LEFT)
	icon:SetSize(ComComp.Resp(16, 16))
	local off = (header:GetTall() - icon:GetTall())/2
	icon:DockMargin(0, off, 0, off)
	self.icon = icon
	
	local newBtn = function(char, hovColor, hovTextColor, fnc)
		local btn = header:Add("Panel")
		-- For editing purposes
		btn.baseColor = color_black
		btn.hovColor = hovColor
		btn.hovTextColor = hovTextColor
		btn:Dock(RIGHT)
		btn:DockMargin(0, 0, 0, ComComp.RespY(2))
		btn:SetWide(ComComp.RespX(42))
		btn.Paint = function(self, w, h)
			if self:IsHovered() then
				surface.SetDrawColor(self.hovColor)
				surface.DrawRect(0, 0, w, h)
			end
		end
		btn.PaintOver = function(self, w, h)
			draw.SimpleText(char, "ComComp18", w/2, h/2 - ComComp.RespY(10), self:IsHovered() and self.hovTextColor or self.baseColor, TEXT_ALIGN_CENTER)
		end
		btn.OnMousePressed = function()
			self[fnc](self)
		end

		return btn
	end
	
	self.CloseBtn = newBtn("x", redColor, color_white, "OnClose")
	self.MaximizeBtn = newBtn("□", grayColor, color_black, "OnMaximize")
	self.ReduceBtn = newBtn("_", grayColor, color_black, "OnReduce")
	
	header.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
	end

	header.PaintOver = function(_, w, h)
		draw.SimpleText(self.text, "ComComp12", 1 + icon:GetWide() + 2, h/2 - ComComp.RespY(12)/2, header.textColor)
	end
	
	self:DockPadding(1, 1, 1, 1)
	self:SetMinimumSize(ComComp.Resp(215, 100))
	self:SetText("No Name")
	self:SetZPos(ComComp.Cfg["ZPos"]["Frame"])
	self:MoveToFront()
end

function PANEL:OnDragStart()
	return self:GetHeader():IsHovered()
end

-- Select things
function PANEL:Select()
	SelectedFrame = self
	self:OnSelect()
end

function PANEL:OnSelect()
	self:MoveToFront()
end

function PANEL:IsSelected()
	return SelectedFrame == self
end

function PANEL:SetIcon(mat)
	self.icon:SetMaterial(mat)
end

function PANEL:SetTitle(text)
	self.text = text
end

function PANEL:GetTitle()
	return self.text
end

function PANEL:Maximize()
	self.oldX, self.oldY, self.oldW, self.oldH = self:GetBounds()
	local pW, pH = self:GetParent():GetSize()
	self:SetPos(0, 0)
	self:SetSize(pW, pH)
	self.Maxi = true
end

function PANEL:Minimize()
	if self.oldX and self.oldY and self.oldW and self.oldH then
		self:SetSize(self.oldW,self.oldH)
		self:SetPos(self.oldX, self.oldY)
	end
	self.Maxi = false
end

function PANEL:GetHeader()
	return self.header
end

-- Functions relative to the 3 buttons
function PANEL:OnClose()
	self:Remove()
end

function PANEL:OnMaximize()
	if self.Maxi then
		self:Minimize()
	else
		self:Maximize()
	end
end

function PANEL:OnReduce()

end

function PANEL:Paint(w, h)
	local color = ComComp.ClientData:Get("Color")
	surface.SetDrawColor(color)
	surface.DrawRect(0, 0, w, h)
end

vgui.Register("ComCompFrame", PANEL, "ComCompMoveablePanel")

-- This hook select a frame when we click on one of his children
hook.Add("VGUIMousePressed", "CC:CheckForFrame", function(panel, mouseCode)
	local p = panel
	while(IsValid(p)) do
		if p:GetName() == "ComCompFrame" then
			
			p:Select()
			break
		else
			p = p:GetParent()
		end
	end
end)

