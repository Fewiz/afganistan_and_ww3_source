--[[
addons/common_computer/lua/common_computer/lang/en.lua
--]]
--[[
    I'm regrouping all strings in one file because it's more easier to translate than
    having to move in each application lang file.
]]

-- Common
ComComp.Lang["startmenu"] = "Start Menu"
ComComp.Lang["disabledapp"] = "The application %q is disabled !"
ComComp.Lang["shutdown"] = "Shutdown"
ComComp.Lang["take"] = "Take"
ComComp.Lang["use"] = "Use"
ComComp.Lang["laptop"] = "Laptop"
ComComp.Lang["desktop_computer"] = "Desktop Computer"
ComComp.Lang["projector"] = "Projector"
ComComp.Lang["printer"] = "Printer"
ComComp.Lang["3dprinter"] = "3D Printer"
ComComp.Lang["phone"] = "Phone"
ComComp.Lang["dropoff"] = "Drop off"
ComComp.Lang["configuration"] = "Configuration"
ComComp.Lang["yes"] = "Yes"
ComComp.Lang["no"] = "No"
ComComp.Lang["ok"] = "Ok"
ComComp.Lang["warning"] = "Warning"
ComComp.Lang["remove"] = "Remove"
ComComp.Lang["back"] = "Back"
ComComp.Lang["buy"] = "Buy"
ComComp.Lang["view"] = "View"
ComComp.Lang["price"] = "Price"
ComComp.Lang["add"] = "Add"
ComComp.Lang["name"] = "Name"
ComComp.Lang["description"] = "Description"
ComComp.Lang["send"] = "Send"
ComComp.Lang["footer"] = "Footer"
ComComp.Lang["camera"] = "Camera"
ComComp.Lang["save"] = "Save"
ComComp.Lang["open"] = "Open"
ComComp.Lang["cancel"] = "Cancel"
ComComp.Lang["file"] = "File"
ComComp.Lang["new"] = "New"
ComComp.Lang["color"] = "Color"
ComComp.Lang["previous"] = "Previous"
ComComp.Lang["next"] = "Next"
ComComp.Lang["chromium_branch"] = "You must use the chromium branch of Garry's Mod to use this feature."

ComComp.Lang["phone_incall"] = "Call in progress..."
ComComp.Lang["phone_dialing"] = "Dialing"
ComComp.Lang["phone_incomingcall"] = "Incoming call"
ComComp.Lang["phone_answer"] = "Pick up"
ComComp.Lang["phone_decline"] = "Hang up"
ComComp.Lang["phone_configure_title"] = "Phone Configuration"
ComComp.Lang["phone_configure"] = "You can configure your phone by right-clicking and changing its name, you can also activate the \"wall\" mode for more style. Once spawn, your phone is accessible from anywhere."

-- Camera
if not ComComp.IsAppDisabled("camera") then -- Don't waste memory
    ComComp.Lang["camera_filesaved"] = "The photo has been saved under %s"
end

-- Connect4
if not ComComp.IsAppDisabled("connect4") then
    ComComp.Lang["connect4"] = "Connect 4"
    ComComp.Lang["connect4_choose_color"] = "Choose your color:"
    ComComp.Lang["connect4_wantplay"] = "Wish to play"
    ComComp.Lang["connect4_sentrequest"] = "Request sent"
    ComComp.Lang["connect4_redwin"] = "Red won !"
    ComComp.Lang["connect4_yellowwin"] = "Yellow won !"
end

-- G-Cord
if not ComComp.IsAppDisabled("gcord") then
    ComComp.Lang["gcord"] = "G-Cord"
    ComComp.Lang["gcord_invaliduser"] = "invalid-user"
    ComComp.Lang["gcord_searchbar"] = "Search/start a new conversation"
    ComComp.Lang["gcord_joincall"] = "Join call"
    ComComp.Lang["gcord_decline"] = "Decline"
    ComComp.Lang["gcord_incomingcall"] = "Incoming Call..."
    ComComp.Lang["gcord_heavy"] = "This file is too heavy !"
    ComComp.Lang["gcord_advanced"] = "Advanced use"
    ComComp.Lang["gcord_sendfiles"] = "You can send files very easily by clicking on the \"plus\" icon, this can be used to send your screenshots or even your voxel creations to your friends !"
end

-- Doc browser
if not ComComp.IsAppDisabled("docbrowser") then
    ComComp.Lang["docbrowser"] = "Document Browser"
    ComComp.Lang["docbrowser_listdoc"] = "List of documents:"
    ComComp.Lang["docbrowser_result"] = "result(s) !"
    ComComp.Lang["docbrowser_title"] = "Title"
    ComComp.Lang["docbrowser_author"] = "Author"
    ComComp.Lang["docbrowser_action"] = "Action"
    ComComp.Lang["docbrowser_remove_title"] = "Remove the document"
    ComComp.Lang["docbrowser_remove_desc"] = "Are you sure you want to delete the document?"
    ComComp.Lang["docbrowser_remove_btn"] = "Remove"
end

-- File browser
if not ComComp.IsAppDisabled("filebrowser") then
    ComComp.Lang["explorer"] = "File Browser"
    ComComp.Lang["explorer_filename"] = "Name of the file :"
    ComComp.Lang["explorer_setaswallpaper"] = "Set as desktop background"
    ComComp.Lang["explorer_editwithnotepad"] = "Edit with notepad"
    ComComp.Lang["recyclebin"] = "Recycle Bin"
end

-- Firefox
if not ComComp.IsAppDisabled("browser") then
    ComComp.Lang["browser"] = "Web Browser"
end

-- Flappy Bird
if not ComComp.IsAppDisabled("flappybird") then
    ComComp.Lang["flappy"] = "Flappy Online"
    ComComp.Lang["flappy_play"] = "Click to play !"
    ComComp.Lang["flappy_score"] = "You scored %u !"
    ComComp.Lang["flappy_mvp"] = "MVP: %s (%u)"
end

-- Notepad
if not ComComp.IsAppDisabled("notepad") then
    ComComp.Lang["notepad"] = "Notepad"
    ComComp.Lang["notepad_file_filesaved"] = "The file has been saved under %s"
end

-- Paint
if not ComComp.IsAppDisabled("paint") then
    ComComp.Lang["paint"] = "Paint"
end

-- Photos
if not ComComp.IsAppDisabled("photos") then
    ComComp.Lang["photos"] = "Photos"
    ComComp.Lang["photos_invalid"] = "Invalid image"
end

-- Safepay
if not ComComp.IsAppDisabled("safepay") then
    ComComp.Lang["safepay"] = "SafePay"
    ComComp.Lang["safepay_goingtobuy"] = "You are going to buy: "
    ComComp.Lang["safepay_buybtn"] = "Buy"
    ComComp.Lang["safepay_price"] = "Price"
    ComComp.Lang["safepay_nomoney"] = "You don't have enough money"
end

-- Security Camera
if not ComComp.IsAppDisabled("security_camera") then
    ComComp.Lang["security_camera"] = "Security Camera"
    ComComp.Lang["security_camera_nosignal"] = "No Signal"
    ComComp.Lang["security_camera_filesaved"] = "The photo has been saved under %s"
    ComComp.Lang["security_camera_nocoowner"] = "No co-owner"
    ComComp.Lang["security_camera_coowner"] = "Co-owner: %s"

    ComComp.Lang["security_camera_adding_coowner_title"] = "Adding a co-owner"
    ComComp.Lang["security_camera_adding_coowner"] = "You can add a co-owner by clicking on the text at the top left of the application."
    ComComp.Lang["security_camera_moving_title"] = "Move the camera"
    ComComp.Lang["security_camera_moving"] = "You can move and zoom in/out the camera using your default motion keys and the scroll wheel of your mouse."
end

-- Settings
if not ComComp.IsAppDisabled("settings") then
    ComComp.Lang["settings"] = "Settings"
    ComComp.Lang["settings_appearance"] = "Appearance"
    ComComp.Lang["settings_wallpaper"] = "Wallpaper"
end

-- Slicer
if not ComComp.IsAppDisabled("slicer") then
    ComComp.Lang["slicer"] = "Slicer"
    ComComp.Lang["slicer_print"] = "Print"
    ComComp.Lang["slicer_print_voxel"] = "Voxel Model"
    ComComp.Lang["slicer_print_import_voxel"] = "Import Voxel"
    ComComp.Lang["slicer_print_heavy"] = "Sorry, this file is too heavy to be print !"
    ComComp.Lang["slicer_print_errorlimit"] = "Please wait %i seconds before printing another object !"
    ComComp.Lang["slicer_print_start"] = "Printing started in the nearest printer"
    ComComp.Lang["slicer_print_nofound"] = "No printer was found"

    ComComp.Lang["slicer_config_modelpath"] = "Model path"
    ComComp.Lang["slicer_config_name"] = "Name"
    ComComp.Lang["slicer_config_class"] = "Class"
    ComComp.Lang["slicer_config_skin"] = "Skin"
    ComComp.Lang["slicer_config_scale"] = "Model scale"
    ComComp.Lang["slicer_config_price"] = "Price"
    ComComp.Lang["slicer_config_duration"] = "Duration"
    ComComp.Lang["slicer_config_speed"] = "Speed"
    ComComp.Lang["slicer_config_simulate"] = "Simulate"
    ComComp.Lang["slicer_config_finish"] = "Save config"
    ComComp.Lang["slicer_config_unnamed"] = "Unnamed"

    ComComp.Lang["slicer_printing_voxel_title"] = "Printing voxel"
    ComComp.Lang["slicer_printing_voxel"] = "You can print your voxel creation by pressing the \"Import Voxel\" button !"
    ComComp.Lang["slicer_printing_result"] = "Here's the result !"
end

-- Onion
if not ComComp.IsAppDisabled("onion") then
    ComComp.Lang["onionbrowser"] = "Onion Browser"
    ComComp.Lang["onion_dn_title"] = "<img style='max-width:85px; height:auto;'src='https://i.imgur.com/sWdKIOI.png'>Your<span style='color: #ff4a4a;'>Target</span>"
    ComComp.Lang["onion_dn_subtitle"] = "Buy weapons and ammunition at low prices"
    ComComp.Lang["onion_dn_categories"] = "Categories: "
    ComComp.Lang["onion_dn_cat_edit"] = "Add/Edit a category"
    ComComp.Lang["onion_dn_art_edit"] = "Add/Edit an article"
    ComComp.Lang["onion_dn_articles"] = "Articles: "
    ComComp.Lang["onion_dn_gmodClass"] = "Gmod class"
    ComComp.Lang["onion_dn_imageUrl"] = "Image URL"
    ComComp.Lang["onion_dn_goingBuy"] = "You are going to buy: "
    ComComp.Lang["onion_dn_locChoose"] = "Select a delivery location: "
    ComComp.Lang["onion_dn_loading"] = "Loading ..."
    ComComp.Lang["onion_dn_footer"] = "<img style='max-width:32px; height:auto;' src='https://i.imgur.com/JUdrQRy.png'><br>We only accept bitcoin payments"
    ComComp.Lang["onion_dn_modalfooter"] = "No refunds can be made. Delivery time can vary greatly, from 1 day to 4 months. Please keep an eye on the delivery address."
    ComComp.Lang["onion_dn_success"] = "Your order has been successfully placed ! Your package will arrive in %G minutes"
    ComComp.Lang["onion_dn_nodeliveryloc"] = "You did not specify the delivery location !"
    ComComp.Lang["onion_usage_title"] = "Use of the darknet"
    ComComp.Lang["onion_usage"] = "To use the darknet, use the <colour=41, 128, 185, 255>%s</colour> link and proceed to your purchases"
end

-- Voxel
if not ComComp.IsAppDisabled("voxel") then
    ComComp.Lang["voxel"] = "Voxel Editor"
    ComComp.Lang["voxel_move"] = "Hold space + wasd to move"
    ComComp.Lang["voxel_movement_title"] = "Movement"
    ComComp.Lang["voxel_movement"] = "You can move around in the editor by holding down space and using your default movement keys. You can also rotate in orbit around a cube by holding down the middle mouse button while moving your mouse."
end

-- Word
if not ComComp.IsAppDisabled("word") then
    ComComp.Lang["word"] = "Word"
    ComComp.Lang["word_placeholder"] = "Type your text..."
    ComComp.Lang["word_doc_publish"] = "Publish the document"
    ComComp.Lang["word_publish_title"] = "Title:"
    ComComp.Lang["word_publish_category"] = "Category:"
    ComComp.Lang["word_publish_btn"] = "Publish"
    ComComp.Lang["word_print"] = "Print"
    ComComp.Lang["word_project"] = "Project"
    ComComp.Lang["word_background"] = "Background"
    ComComp.Lang["word_print_errorlimit"] = "Please wait %i seconds before printing another document !"
    ComComp.Lang["word_print_nofound"] = "No printer was found"
    ComComp.Lang["word_print_start"] = "Printing started in the nearest printer"
    ComComp.Lang["word_project_nofound"] = "No projector was found"
    ComComp.Lang["word_project_start"] = "The document has been projected on the nearest projector"
    
    ComComp.Lang["word_creating_document_title"] = "Documents creations"
    ComComp.Lang["word_creating_document"] = "You can create documents using the Word application, you can format your text by selecting the desired text. You can also choose your sheet style! \n\n <font=ComComp16Bold>Tip:</font> If you want to add an image to your document, copy the image link to your document, select it and click on the \"image\" button."
    ComComp.Lang["word_creating_created_document"] = "Once your document is finished and saved, you can access it from the \"Document Browser\" application, this is where you can print it or project it."
end

-- Help center
if not ComComp.IsAppDisabled("helpcenter") then
    ComComp.Lang["helpcenter"] = "Help Center"
end

