--[[
addons/common_computer/lua/common_computer/applications/onion/shared.lua
--]]
local L = ComComp.GetLang
local APP = APP

ComComp.Include(APP.Path .. "sh_config.lua")
ComComp.ThirdInclude(APP.Path .. "igconfig/")

function APP.TranslateHTML(html)
    html:Lang("title", L("onion_dn_title"))
    html:Lang("subtitle", L("onion_dn_subtitle"))
    html:Lang("categories", L("onion_dn_categories"))
    html:Lang("articles", L("onion_dn_articles"))
    html:Lang("buy", L("buy"))
    html:Lang("add", L("add"))
    html:Lang("back", L("back"))
    html:Lang("view", L("view"))
    html:Lang("goingBuy", L("onion_dn_goingBuy"))
    html:Lang("price", L("price"))
    html:Lang("price:", L("price") .. ": ")
    html:Lang("locChoose", L("onion_dn_locChoose"))
    html:Lang("footer", L("onion_dn_footer"))
    html:Lang("modalFooter", L("onion_dn_modalfooter"))
    html:Lang("loading", L("onion_dn_loading"))
    html:Lang("art-edit", L("onion_dn_art_edit"))
    html:Lang("cat-edit", L("onion_dn_cat_edit"))
    html:Lang("footerLabel", L("footer"))
    html:Lang("send", L("send"))
    html:Lang("name", L("name"))
    html:Lang("desc", L("description"))
    html:Lang("imageUrl", L("onion_dn_imageUrl"))
    html:Lang("gmodClass", L("onion_dn_gmodClass"))

    if not html.InjectedLang then -- Prevent Awesomium from crashing
        html.InjectedLang = true
        html:AddFunction("gmod", "updateLang", function()
            APP.TranslateHTML(html)
        end)
    end
end

