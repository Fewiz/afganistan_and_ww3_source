--[[
addons/common_computer/lua/common_computer/applications/onion/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP
local onionMat = Material("common_computer/onion.png")
local highColor = Color(48, 128, 255)

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	local appArea = mainFrame:GetAppArea()
	
	-- Add icon to taskbar
	taskBar:AddIcon("onionbrowser", onionMat, function()
		local app = self:GetComputer():RetrieveApp(APP.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	local frame = appArea:NewFrame()
	frame:SetIcon(onionMat)
	frame:SetTitle(L("onionbrowser"))
	frame:SetSize(ComComp.Resp(750, 500))
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	frame:Center()
	self.frame = frame

	local incompatibility = false

	local html = frame:Add("DHTML")
	html:Dock(FILL)
	html:OpenURL(ComComp.Cfg["onion"]["default_url"])
	html.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)

		if (incompatibility) then
			draw.SimpleText(L("chromium_branch"), "ComComp20Bold", w/2, h/2, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	html.Callbacks["console.log"] = nil
	html.Exec = html.QueueJavascript
	html.Lang = function(self, id, text)
		self:Exec("ComComp.Lang('" .. string.JavascriptSafe(id) .. "', '" .. string.JavascriptSafe(text) .. "');")
	end
	self.html = html

	local ctrls = frame:Add("DHTMLControls")
	ctrls:Dock(TOP)
	ctrls.BorderSize = 0
	ctrls.Paint = function(self, w, h)
		surface.SetDrawColor(245, 245, 245)
		surface.DrawRect(0, 0, w, h)
	end
	ctrls:SetButtonColor(Color(0, 0, 0, 245))
	ctrls.AddressBar:SetDrawLanguageID(false)
	ctrls.AddressBar.Paint = function(self, w, h)
		surface.SetDrawColor(125, 125, 125)
		surface.DrawOutlinedRect(0, 0, w, h)
		
		self:DrawTextEntryText(color_black, highColor, color_black)
	end
	ctrls:SetHTML(html)

	--[[
		Function used to detect when the player enters to Darknet link
	]]
	html.OnBeginLoadingDocument = function(panel, url)
		if #url < 150 then -- Avoid lags
			ctrls.AddressBar:SetText(url)
		end

		ctrls:StartedLoading()
		ctrls:UpdateHistory(url)

		if self.isDarknet then
			ctrls.AddressBar:SetText(ComComp.Cfg["onion"]["darklink"])
		end
	end
	
	html.OnFinishLoadingDocument = function(_, url)
		if (url == "chrome://chromewebdata/") then
			incompatibility = true
		end
	end

	ctrls.AddressBar.OnEnter = function(_)
		local value = ctrls.AddressBar:GetValue()
		
		if string.Trim(value) == ComComp.Cfg["onion"]["darklink"] then
			self:OpenDarknet()
			self.isDarknet = true
		else
			html:StopLoading()
			html:OpenURL(value)
			self.isDarknet = false
		end
	end
	self.ctrls = ctrls
end

-- Open the darknet + automatically setup the environment like language and callbacks
function APP:OpenDarknet()
	self.html.OnDocumentReady = function()
		APP.TranslateHTML(self.html)

		-- Add on buy function (Open Safepay if enabled)
		self.html:AddFunction("gmod", "buy", function(id, locId, name, price)
			if not locId then
				self.html:Exec("view.Notif(\"" .. string.JavascriptSafe(L("onion_dn_nodeliveryloc")) .. "\", true);")
				return
			end

			local buyFnc = function()
				local ent = self:GetComputer():GetEntity()
				if not IsValid(ent) then return end

				net.Start("ComCompDarkNetBuy")
				net.WriteEntity(ent)
				net.WriteUInt(id, 8)
				net.WriteString(locId)
				net.SendToServer()

				self.html:Exec("view.Notif(\"" .. string.JavascriptSafe(string.format(L("onion_dn_success"), ComComp.Cfg["onion"]["delivery_time"])) .. "\");")
			end

			local safepay = ComComp.Apps:Instantiate("safepay", self:GetComputer())
			if safepay then
				safepay:Open(name, tonumber(price), function()
					safepay:Close()
					buyFnc()
				end, true)
			else
				buyFnc()
			end
		end)

		for k, v in pairs(APP.LocationList) do
			self.html:Exec("view.AddLocation(\"" .. string.JavascriptSafe(k) .. "\");")
		end

		self.html:Exec("gmodCombo.init();")
	end

	self.html:OpenURL(ComComp.Database.DBServer .. "applications/darknet/?player_key=" .. ComComp.Database.ClientKey)
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("onionbrowser")
	
	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:Onion::Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("onionbrowser", onionMat, L("onionbrowser"), 3, 2, function()
		local onionbrowser = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		onionbrowser:Open()
	end)
end)

hook.Add("CC:Applications:Loaded", "CC:Onion:Help", function()
	local help = ComComp.Apps:GetMeta("helpcenter")
	if not help then return end

	local doc = help:NewDocumentation(APP.Id, L("onionbrowser"))
		:AddPage(L("onion_usage_title"))
		:AddText(string.format(L("onion_usage"), ComComp.Cfg["onion"]["darklink"]))
        :AddImage("common_computer/helpcenter/onion.jpg")
end)

