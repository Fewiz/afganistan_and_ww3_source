--[[
addons/common_computer/lua/common_computer/applications/onion/igconfig/shared.lua
--]]
local APP = APP
APP.LocationList = {}

-- Darknet Config
hook.Add("CC:ConfigTool:Setup", "CC:Onion:DarknetConfig", function(settings)
    local darkSet = settings:New("DarkNet")

    function darkSet:Run(tool, tr)
        if CLIENT then
            APP:OpenIGConfig() -- Used to add categories and articles
        end
    end
end)

-- Delivery Locations Config 
hook.Add("CC:ConfigTool:Setup", "CC:Onion:LocationsConfig", function(settings)
    local darkSet = settings:New("Shipments Locations")

    function darkSet:Run(tool, tr)
        -- Create a new location
        if SERVER then
            local newPos = tr.HitPos
            if not newPos then return end

            -- Find an available name
            local t = 1
            while(APP.LocationList["Unnamed " .. t]) do
                t = t + 1
            end

            APP.LocationList["Unnamed " .. t] = newPos

            APP:SaveLocations()
            APP:NetworkLocations()
        end
    end

    if CLIENT then
        function darkSet:Reload(tool)
            APP:OpenLocationConfig() -- Used to rename and remove locations
        end
    
        -- Draw all locations
        function darkSet:DrawHUD()
            for name, pos in pairs(APP.LocationList) do
                local screenpos = pos:ToScreen()
                
                if not screenpos.visible then goto con end
    
                draw.DrawText(name, "TargetID", screenpos.x, screenpos.y - 20, nil, TEXT_ALIGN_CENTER)
                draw.DrawText("Distance: " .. math.ceil(LocalPlayer():GetPos():Distance(pos)/100) .. " m", "TargetID", screenpos.x, screenpos.y, nil, TEXT_ALIGN_CENTER)
                draw.RoundedBox(8, screenpos.x - 7, screenpos.y + 30, 10, 10, color_black)
                
                ::con::
            end
        end
    end
end)

