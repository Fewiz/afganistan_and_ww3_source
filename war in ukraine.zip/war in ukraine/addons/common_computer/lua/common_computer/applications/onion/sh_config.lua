--[[
addons/common_computer/lua/common_computer/applications/onion/sh_config.lua
--]]
ComComp.Cfg["onion"] = {}
ComComp.Cfg["onion"]["darklink"] = "yourtarget.onion"
ComComp.Cfg["onion"]["default_url"] = "google.com"
ComComp.Cfg["onion"]["delivery_time"] = 0.1 -- In minutes

