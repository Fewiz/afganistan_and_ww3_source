--[[
addons/common_computer/lua/common_computer/applications/onion/igconfig/cl_init.lua
--]]
local APP = APP
local L = ComComp.GetLang

-- Used to add categories and articles
function APP:OpenIGConfig()
    local frame = vgui.Create("ComCompFrame")
    frame:SetTitle(L("configuration"))
    frame:SetSize(ComComp.Resp(900, 550))
    frame:Center()
    frame:MakePopup()

    local html = frame:Add("DHTML")
    html:Dock(FILL)
    html.Paint = function(self, w, h)
        surface.SetDrawColor(255, 255, 255)
        surface.DrawRect(0, 0, w, h)
    end
    --html.Callbacks["console.log"] = nil
    html.Exec = html.QueueJavascript
    html.Lang = function(self, id, text)
        self:Exec("ComComp.Lang('" .. string.JavascriptSafe(id) .. "', '" .. string.JavascriptSafe(text) .. "');")
    end

    html.OnDocumentReady = function()
        APP.TranslateHTML(html)
    end

    html:OpenURL(ComComp.Database.DBServer .. "applications/darknet/?player_key=" .. ComComp.Database.ClientKey .. "&view=config")
end

-- Used to rename and remove locations
function APP:OpenLocationConfig()
    local frame = vgui.Create("ComCompFrame")
    frame:SetTitle(L("configuration"))
    frame:SetSize(ComComp.Resp(400, 250))
    frame:Center()
    frame:MakePopup()

    local list = frame:Add("ComCompScrollPanel")
    list:Dock(FILL)

    for name, pos in pairs(APP.LocationList) do
        local panel = list:Add("Panel")
        panel:SetTall(ComComp.RespY(24))
        panel:Dock(TOP)
        panel:DockMargin(0, 0, 0, ComComp.RespY(2))

        local textEntry = panel:Add("ComCompTextEntry")
        textEntry:Dock(FILL)
        textEntry:SetText(name)
        textEntry.OnEnter = function()
            net.Start("CCDarknetAddLocation")
            net.WriteBool(false)
            net.WriteString(name)
            net.WriteString(textEntry:GetText())
            net.SendToServer()
        end

        local remBtn = panel:Add("ComCompButton")
        remBtn:SetText(L("remove"))
        remBtn:Dock(RIGHT)
        remBtn.DoClick = function()
            panel:Remove()

            net.Start("CCDarknetAddLocation")
            net.WriteBool(true)
            net.WriteString(name)
            net.SendToServer()
        end
    end
end

net.Receive("CCDarknetAddLocation", function(len)
    local data = net.ReadData(len/8)
    if not data then return end

    APP.LocationList = util.JSONToTable(util.Decompress(data))
end)

