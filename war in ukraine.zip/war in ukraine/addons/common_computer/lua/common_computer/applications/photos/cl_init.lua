--[[
addons/common_computer/lua/common_computer/applications/photos/cl_init.lua
--]]
local L = ComComp.GetLang
local photoMat = Material("common_computer/photos.png")

AccessorFunc(APP, "ImageMat", "Image")

function APP:Open(imagePath)
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()

	taskBar:AddIcon("photos", photoMat, function() -- Add the icon to the taskbar
		local app = self:GetComputer():RetrieveApp(self.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	-- Creating the new frame
	local frame = appArea:NewFrame()
	frame:SetIcon(photoMat)
	frame:SetTitle(L("photos"))
	frame:SetSize(ComComp.Resp(515, 380))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	if imagePath then
		self:SetImage(Material(imagePath))
	end
	
	local container = frame:Add("Panel")
	container:Dock(FILL)
	container.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0)
		surface.DrawRect(0, 0, w, h)

		local mat = self:GetImage()
		if not mat or mat:IsError() then
			draw.SimpleText(L("photos_invalid"), "ComComp18", w/2, h/2, nil, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end

		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(mat)
		surface.DrawTexturedRect(w/2 - mat:Width()/2, h/2 - mat:Height()/2, mat:Width(), mat:Height())
	end
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("photos")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:Explorer:BuildRightMenu", "CC:Photos:View", function(menu, path, isFolder, computer)
	if isFolder then return end

	local ext = string.GetExtensionFromFilename(path)
	if ComComp.IsImageExtension(ext) and not ComComp.IsAppDisabled("photos") then 
		menu:AddOption(L("open"), function()
			local photo = ComComp.Apps:Instantiate("photos", computer)
			photo:Open()
			photo:SetImage(Material("../" .. path))
		end)
	end
end)

