--[[
addons/common_computer/lua/common_computer/applications/security_camera/sh_config.lua
--]]
ComComp.Cfg["security_camera"] = {}

-- Configure the camera mode (access to cameras)
APP.ALL_MODE = 1 -- Anyone can see all the cameras
APP.TEAM_MODE = 2 -- Only the specified jobs can access the cameras
APP.PLAYER_MODE = 3 -- Players can only access their own cameras (They can add a co-owner)

ComComp.Cfg["security_camera"]["mode"] = APP.PLAYER_MODE -- Current mode
ComComp.Cfg["security_camera"]["team_mode"] = { -- Configure this only if you use the TEAM_MODE !
    ["Citizen"] = true,
    ["Hobo"] = true
}

