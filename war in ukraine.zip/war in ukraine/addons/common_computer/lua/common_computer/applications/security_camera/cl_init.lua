--[[
addons/common_computer/lua/common_computer/applications/security_camera/cl_init.lua
--]]
file.CreateDir("common_computer/pictures")

local L = ComComp.GetLang
local APP = APP

local iconMat = Material("common_computer/security_camera.png")
local sunMat = Material("common_computer/sun.png")
local moonMat = Material("common_computer/moon.png")
local camTakeMat = Material("common_computer/camtake.png")
local colorMat = Material("pp/colour")

-- Material used to make the highlighted player effect on night mode
local playerMat = CreateMaterial("ComCompSecCamPlayer", "VertexLitGeneric", {
	["$basetexture"] = "color/white",
	["$model"] = 1,
})

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("security_camera")
	
	local appArea = mainFrame:GetAppArea()
	local frame = appArea:NewFrame()
	frame:SetIcon(iconMat)
	frame:SetTitle(L("security_camera"))
	frame:SetSize(ComComp.Resp(820, 520))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	-- RenderTarget for the RenderView (Without it, we can't draw the camera in 3D mode)
	local id = SysTime()
	local camRT = GetRenderTarget("ComCompSecurityCam" .. id, 1024, 1024, false)
	local camMat = CreateMaterial("ComCompSecurityCam" .. id, "UnlitGeneric",{
		["$basetexture"] = camRT:GetName(),
	})

	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(self, w, h)
		surface.SetDrawColor(45, 45, 45)
		surface.DrawRect(0, 0, w, h)
	end

	local camPanel = c:Add("Panel")
	self.camPanel = camPanel
	camPanel:Dock(FILL)
	local pX, pY = ComComp.Resp(8, 8)
	camPanel:DockPadding(pX, pY, pX, pY)
	camPanel.CurrentCam = nil
	camPanel.Thermal = false
	camPanel.FOV = 0.5
	camPanel.Drawing = false
	camPanel.Paint = function(_, w, h)
		if not IsValid(camPanel.CurrentCam) then
			-- Noise effect
			surface.SetDrawColor(200, 200, 200)
			surface.DrawRect(0, 0, w, h)

			local glitchesY = math.Round(h/12)
			local offY = h/glitchesY
			local glitchesX = math.Round(w/14)
			local offX = w/glitchesX

			for i = 0, glitchesY + 1 do
				local grayRandom = math.Rand(0, 1) * 120
				surface.SetDrawColor(grayRandom, grayRandom, grayRandom)
				surface.DrawRect(0, i * offY, w, math.random(h/20))
			end

			for i = 0, glitchesX + 1 do
				local grayRandom = math.Rand(0, 1) * 120
				surface.SetDrawColor(grayRandom, grayRandom, grayRandom)
				surface.DrawRect(i * offX, 0, math.random(w/20), h)
			end	

			for i = 0, glitchesY + 1 do
				local grayRandom = math.Rand(0, 1) * 120
				surface.SetDrawColor(grayRandom, grayRandom, grayRandom)
				surface.DrawRect(0, i * offY, w, math.random(h/20))
			end

			local grayRandom = 255 - math.Rand(0, 1) * 80
			draw.SimpleText(L("security_camera_nosignal"), "ComComp26", w/2, h/2, Color(grayRandom, grayRandom, grayRandom), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			return
		end

		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(camMat)
		surface.DrawTexturedRect(0, 0, w, h)
	end
	camPanel.OnMouseWheeled = function(_, delta)
		camPanel.FOV = math.Clamp(camPanel.FOV + delta/-50, 0, 1)
	end

	-- Movement management of the cameras
	camPanel.Think = function()
		if not IsValid(camPanel.CurrentCam) then return end
		if self:GetComputer():IsPaused() then return end

		local left = camPanel:KeyDown("moveleft")
		local right = camPanel:KeyDown("moveright")
		local forward = camPanel:KeyDown("forward")
		local back = camPanel:KeyDown("back")
		local jump = camPanel:KeyDown("jump")
		local use = camPanel:KeyDown("reload")

		if camPanel.Left then
			if not left then
				self:SendMove(camPanel.CurrentCam, self.CAM_LEFT, false)
				camPanel.Left = false
			end
		elseif left and frame:IsSelected() then
			self:SendMove(camPanel.CurrentCam, self.CAM_LEFT, true)
			camPanel.Left = true
		end

		if camPanel.Right then
			if not right then
				self:SendMove(camPanel.CurrentCam, self.CAM_RIGHT, false)
				camPanel.Right = false
			end
		elseif right and frame:IsSelected() then
			self:SendMove(camPanel.CurrentCam, self.CAM_RIGHT, true)
			camPanel.Right = true
		end

		if camPanel.Up then
			if not forward then
				self:SendMove(camPanel.CurrentCam, self.CAM_UP, false)
				camPanel.Up = false
			end
		elseif forward and frame:IsSelected() then
			self:SendMove(camPanel.CurrentCam, self.CAM_UP, true)
			camPanel.Up = true
		end

		if camPanel.Down then
			if not back then
				self:SendMove(camPanel.CurrentCam, self.CAM_DOWN, false)
				camPanel.Down = false
			end
		elseif back and frame:IsSelected() then
			self:SendMove(camPanel.CurrentCam, self.CAM_DOWN, true)
			camPanel.Down = true
		end

		if (camPanel.NextJump or 0) < CurTime() and not camPanel.RequestTake and jump and frame:IsSelected() then
			camPanel.NextJump = CurTime() + 2
			camPanel.RequestTake = true
		end

		if (camPanel.NextUse or 0) < CurTime() and use and frame:IsSelected() then
			camPanel.NextUse = CurTime() + .5
			camPanel.Thermal = not camPanel.Thermal
		end
	end

	camPanel.KeyDown = function(self, str)
		local bind = input.LookupBinding(str)
		if not bind then return false end
		return input.IsKeyDown(input.GetKeyCode(bind))
	end

	camPanel.OnRemove = function()
		if not self:IsCamUsedByAnotherApp(camPanel.CurrentCam) then
			self:SendPVSStatus(camPanel.CurrentCam, false)
		end
	end

	--[[
		Camera Render
	]]
	local maxDist = 350^2 -- Bellow this distance, we don't draw player information (Square on the player's head)
	hook.Add("PreRender", camPanel, function()
		if (camPanel.NextDraw or 0) > CurTime() then return end
		camPanel.NextDraw = CurTime() + 1/25 -- 25 fps

		if not IsValid(camPanel.CurrentCam) then return end

		local comp = self:GetComputer()
		if not comp then
			return
		end

		local compEnt = comp:GetEntity()
		if not IsValid(compEnt) or not compEnt:IsInRange(LocalPlayer()) then
			return
		end

		if hook.Run("CC:SecurityCamera:CanUse", LocalPlayer(), camPanel.CurrentCam) == false then 
			camPanel.CurrentCam = nil
			return
		end

		camPanel.Drawing = true


		cam.Start3D() -- Necessary for ShouldDrawLocalPlayer 
		cam.End3D()

		local oldRT = render.GetRenderTarget()
		render.SetRenderTarget(camRT)

		-- Draw the camera
		local pos, angles = camPanel.CurrentCam:GetViewPos()
		local x, y = camPanel:LocalToScreen()

		cam.Start2D()
			render.RenderView({
				origin = pos,
				angles = angles,
				fov = camPanel.FOV * 55 + 20,
				x = 0, y = 0,
				w = ScrW(), h = ScrH()
			})
		
			if camPanel.Thermal then
				render.CopyRenderTargetToTexture(render.GetScreenEffectTexture())

				colorMat:SetFloat("$pp_colour_brightness", 0)
				colorMat:SetFloat("$pp_colour_colour", 0)
				colorMat:SetFloat("$pp_colour_contrast", 1)
				
				render.SetMaterial(colorMat)
				render.DrawScreenQuad()

				cam.Start3D()
					for k, v in ipairs(player.GetAll()) do
						if not v:Alive() then goto con end
						if v:GetNoDraw() then goto con end

						render.SuppressEngineLighting(true)
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride(playerMat)

						v:DrawModel()

						render.MaterialOverride(nil)
						render.SuppressEngineLighting(false)

						::con::
					end
				cam.End3D()
			else
				for k,v in ipairs(player.GetAll()) do
					local bone = v:LookupBone("ValveBiped.Bip01_Head1")
					if not bone then goto con end

					local headPos = v:GetBonePosition(bone)
			
					local screenPos = headPos:ToScreen()
					if not screenPos.visible then goto con end

					local toPly = (pos - headPos):GetNormalized()
					if toPly:Dot(v:GetAngles():Forward()) <= 0.55 then goto con end

					local dist = pos:DistToSqr(headPos)
					if dist > maxDist then goto con end

					local tr = util.TraceHull({
						start = headPos,
						endpos = pos,
						mask = MASK_ALL,
						mins = Vector(-5, -5, -5),
						maxs = Vector(5, 5, 5),
						filter = {v, camPanel.CurrentCam}
					})

					if tr.Hit then goto con end

					local offX, offY = ComComp.Resp(64 - 48 * (dist/maxDist), 64 - 48 * (dist/maxDist))
					surface.SetDrawColor(color_white:Unpack())
					surface.DrawOutlinedRect(screenPos.x - offX, screenPos.y - offY, offX * 2, offY * 2, 2)
					draw.SimpleText(v:Name() .. "   " .. math.Round(math.sqrt(dist)/100, 1) .. "m", "ComComp38", screenPos.x + 2 + offX, screenPos.y - offY)
				
					::con::
				end
			end
		cam.End2D()

		
		if camPanel.RequestTake then
			camPanel.RequestTake = nil

			self:SendTake(camPanel.CurrentCam)

			local data = render.Capture( {
				format = "jpeg",
				quality = 50,
				x = 0, y = 0,
				w = 1024, h = 1024
			})

			local path = "common_computer/pictures/" .. util.DateStamp() .. ".jpg"
			file.Write(path, data)

			timer.Simple(0, function() -- Wait next tick to have the correct screen size
				mainFrame:Notif(L("security_camera"), string.format(L("security_camera_filesaved"), path))
			end)
		end

        render.SetRenderTarget(oldRT)

		camPanel.Drawing = nil
	end)


	hook.Add("ShouldDrawLocalPlayer", camPanel, function()
		if camPanel.Drawing then
			return true
		end
	end)

	local btnContainer = camPanel:Add("Panel")
	btnContainer:Dock(RIGHT)
	btnContainer:DockMargin(0, 0, ComComp.RespX(8), 0)
	btnContainer:SetWide(ComComp.RespX(32))
	
	local toggleThermal = btnContainer:Add("Panel")
	toggleThermal:Dock(TOP)
	toggleThermal:DockMargin(0, 0, 0, ComComp.RespY(6))
	toggleThermal:SetTall(btnContainer:GetWide())
	toggleThermal.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(camPanel.Thermal and sunMat or moonMat)
		surface.DrawTexturedRect(0, 0, w, h)
	end
	toggleThermal.OnMousePressed = function()
		camPanel.Thermal = not camPanel.Thermal
	end

	local takeBtn = btnContainer:Add("Panel")
	takeBtn:Dock(TOP)
	takeBtn:DockMargin(0, 0, 0, ComComp.RespY(6))
	takeBtn:SetTall(btnContainer:GetWide())
	takeBtn.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(camTakeMat)
		surface.DrawTexturedRect(0, 0, w, h)
	end
	takeBtn.OnMousePressed = function()
		if not IsValid(camPanel.CurrentCam) then return end
		camPanel.RequestTake = true
	end

	local fovEditor = btnContainer:Add("Panel")
	fovEditor:Dock(FILL)
	local offY = ComComp.RespY(8)
	fovEditor:DockMargin(0, offY, 0, offY)
	fovEditor.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255, 200)
		surface.DrawLine(w/2, 0, w/2, h)
		
		local lines = math.Round(h/10)
		local offsetY = h/lines
		for y = 1, lines do
			local offX = y % 5 == 0 and w/14 or w/3
			surface.DrawLine(offX, y * offsetY, w - offX, y * offsetY)
		end

		DisableClipping(true)
			draw.NoTexture()
			surface.SetDrawColor(255, 255, 255)
			draw.Circle(w/2, h * camPanel.FOV, w/6, 30)
		DisableClipping(false)
		
		if input.IsMouseDown(MOUSE_LEFT) then
			if self.Dragging then
				local _, y = self:ScreenToLocal(0, gui.MouseY())
				camPanel.FOV = math.Clamp(y/h, 0, 1)
			elseif self:IsHovered() then
				self.Dragging = true
			end
		elseif self.Dragging then
			self.Dragging = nil
		end
	end

	if ComComp.Cfg["security_camera"]["mode"] == self.PLAYER_MODE then
		local coOwner = camPanel:Add("Panel")
		coOwner:SetSize(ComComp.Resp(175, 32))
		coOwner.Paint = function(self, w, h)
			if not IsValid(camPanel.CurrentCam) then return end

			local coOwner = camPanel.CurrentCam:GetCamCoOwner()
			draw.SimpleText(IsValid(coOwner) and string.format(L("security_camera_coowner"), coOwner:Name()) or L("security_camera_nocoowner"), "ComComp22", w/2, h/2, nil, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		coOwner.OnMousePressed = function()
			if not IsValid(camPanel.CurrentCam) or camPanel.CurrentCam:GetCamOwner() ~= LocalPlayer() then return end

			local menu = DermaMenu()

			menu:AddOption(L("security_camera_nocoowner"), function()
				self:SendCoOwner(camPanel.CurrentCam, NULL)
			end)

			for k, v in ipairs(player.GetHumans()) do
				if v == LocalPlayer() then goto con end

				menu:AddOption(v:Name(), function()
					self:SendCoOwner(camPanel.CurrentCam, v)
				end)

				::con::
			end

			menu:Open()
		end
	end


	local camList = c:Add("ComCompScrollPanel")
	camList:Dock(RIGHT)
	camList:SetDark(true)
	camList:SetWide(ComComp.RespX(156))
	for k, v in ipairs(ents.FindByClass("cc_camera")) do
		if hook.Run("CC:SecurityCamera:CanUse", LocalPlayer(), v) == false then goto con end

		local camSel = camList:Add("Panel")
		camSel:Dock(TOP)
		camSel:SetTall(ComComp.RespY(26))
		camSel.Paint = function(self, w, h)
			if not IsValid(v) or hook.Run("CC:SecurityCamera:CanUse", LocalPlayer(), v) == false then
				self:Remove()
				return
			end

			local selected = camPanel.CurrentCam == v
			
			if selected then
				surface.SetDrawColor(255, 255, 255)
			else
				surface.SetDrawColor(40, 40, 40)
			end
			
			surface.DrawRect(0, 0, w, h)

			local name = v:GetCamName()
			draw.SimpleText(#name == 0 and ("Camera #" .. k) or name, "ComComp16", w/2, h/2, selected and color_black or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		camSel.OnMousePressed = function()
			if camPanel.CurrentCam == v then -- Avoid useless net messages
				return
			end

			if IsValid(camPanel.CurrentCam) then
				-- Check if the camera is used in another application before dropping it...
				if not self:IsCamUsedByAnotherApp(camPanel.CurrentCam) then
					self:SendPVSStatus(camPanel.CurrentCam, false)
				end
			end
			
			self:SendPVSStatus(v, true)
			camPanel.CurrentCam = v
		end

		::con::
	end
end

function APP:IsCamUsedByAnotherApp(camera)
	for k,v in ipairs(self:GetComputer():GetApps()) do
		if v == self then goto con end
		if v.Id ~= APP.Id then goto con end
		if IsValid(v.camPanel) and IsValid(v.camPanel.CurrentCam) then
			if v.camPanel.CurrentCam == camera then
				return v
			end
		end

		::con::
	end
	return false
end

function APP:SendCoOwner(camera, coOwner)
	local ent = self:GetComputer():GetEntity()
	if not IsValid(ent) then return end

	net.Start("ComCompCameraCoOwner")
	net.WriteEntity(ent)
	net.WriteEntity(camera)
	net.WriteEntity(coOwner)
	net.SendToServer()
end

function APP:SendTake(camera)
	local ent = self:GetComputer():GetEntity()
	if not IsValid(ent) then return end

	net.Start("ComCompCameraTake")
	net.WriteEntity(ent)
	net.WriteEntity(camera)
	net.SendToServer()
end

function APP:SendMove(camera, dir, status)
	local ent = self:GetComputer():GetEntity()
	if not IsValid(ent) then return end

	net.Start("ComCompCameraMove")
	net.WriteEntity(ent)
	net.WriteEntity(camera)
	net.WriteUInt(dir, 2)
	net.WriteBool(status)
	net.SendToServer()
end

function APP:SendPVSStatus(camera, status)
	local ent = self:GetComputer():GetEntity()
	if not IsValid(ent) then return end

	net.Start("ComCompCameraStatus")
	net.WriteEntity(ent)
	net.WriteEntity(camera)
	net.WriteBool(status)
	net.SendToServer()
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("security_camera")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:SecurityCamera:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("security_camera", iconMat, L("security_camera"), 3, 0, function()
		local computer = computerFrame:GetComputerInstance()
		if computer:CountApp(APP.Id) >= 4 then return end -- Max 4 cameras

		local security_camera = ComComp.Apps:Instantiate(APP.Id, computer)
		security_camera:Open()
	end)
end)

hook.Add("CC:TaskbarCreated", "CC:SecurityCamera:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("security_camera", iconMat, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local security_camera = ComComp.Apps:Instantiate(APP.Id, computer)
			security_camera:Open()
		end
		
	end, 0, true)
end)

hook.Add("CC:Applications:Loaded", "CC:SecurityCamera:Help", function()
	local help = ComComp.Apps:GetMeta("helpcenter")
	if not help then return end

	local doc = help:NewDocumentation(APP.Id, L("security_camera"))
		:AddPage(L("security_camera_adding_coowner_title"))
		:AddText(L("security_camera_adding_coowner"))
        :AddImage("common_computer/helpcenter/security_camera.jpg")
        :AddPage(L("security_camera_moving_title"))
        :AddText(L("security_camera_moving"))
		:AddImage("common_computer/helpcenter/security_camera-1.jpg")
end)

