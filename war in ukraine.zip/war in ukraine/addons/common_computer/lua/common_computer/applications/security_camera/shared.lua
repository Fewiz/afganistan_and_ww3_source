--[[
addons/common_computer/lua/common_computer/applications/security_camera/shared.lua
--]]
local APP = APP

ComComp.Include(APP.Path .. "sh_config.lua")

-- 2 bits for all
APP.CAM_LEFT = 0
APP.CAM_UP = 1
APP.CAM_RIGHT = 2
APP.CAM_DOWN = 3

-- Default behavior to check if a player has access to use a camera
hook.Add("CC:SecurityCamera:CanUse", "CC:SecurityCamera:DefaultPermissions", function(ply, camera)
    local curMode = ComComp.Cfg["security_camera"]["mode"]

    if curMode == APP.ALL_MODE then
        -- Do nothing (Allow)
    elseif curMode == APP.TEAM_MODE then
        -- Return false if the player doesn't have a valid team
        local cfgTeam = ComComp.Cfg["seacurity_camera"]["team_mode"]
        
        if not cfgTeam[team.GetName(ply:Team())] then
            return false
        end
    elseif curMode == APP.PLAYER_MODE then
        -- Check first for CPPI
        if (camera.CPPIGetOwner and camera:CPPIGetOwner() ~= ply) or camera:GetCamOwner() ~= ply and camera:GetCamCoOwner() ~= ply then
            return false
        end
    end
end)

