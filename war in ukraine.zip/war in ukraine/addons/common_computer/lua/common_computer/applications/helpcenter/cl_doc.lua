--[[
addons/common_computer/lua/common_computer/applications/helpcenter/cl_doc.lua
--]]
APP.DocList = {}

local DOC = {}
DOC.__index = DOC

function DOC:AddPage(title)
    table.insert(self.data, {
        title = title or "",
        data = {}
    })

    return self
end

function DOC:AddText(text)
    table.insert(self.data[#self.data].data, {
        type = "text",
        text = text--"<font=ComComp16><colour=0,0,0,255>" .. text .. "</colour></font>"
    })

    return self
end

-- Using path here because I don't want the image to load if we never use it
function DOC:AddImage(path)
    table.insert(self.data[#self.data].data, {
        type = "image",
        path = path
    })

    return self
end

function APP:NewDocumentation(docId, name)
    local newDoc = setmetatable({
        name = name,
        data = {}
    }, DOC)

    self.DocList[docId] = newDoc
    return newDoc
end

