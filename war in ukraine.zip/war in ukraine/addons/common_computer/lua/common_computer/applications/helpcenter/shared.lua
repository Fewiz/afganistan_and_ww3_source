--[[
addons/common_computer/lua/common_computer/applications/helpcenter/shared.lua
--]]
ComComp.Include(APP.Path .. "cl_doc.lua")

