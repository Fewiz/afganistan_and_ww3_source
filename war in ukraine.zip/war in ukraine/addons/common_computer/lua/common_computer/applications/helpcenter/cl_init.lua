--[[
addons/common_computer/lua/common_computer/applications/helpcenter/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP

local color_blue = Color(52, 152, 219)
local color_darkblue = Color(41, 128, 185)
local color_backblue = Color(154, 186, 208)
local helpMat = Material("common_computer/helpcenter.png")

function APP:Open(docId)
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("helpcenter")
	
	local appArea = mainFrame:GetAppArea()
	local frame = appArea:NewFrame()
	frame:SetIcon(helpMat)
	frame:SetTitle(L("helpcenter"))
	frame:SetSize(ComComp.Resp(600, 550))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(_, w, h)
		surface.SetDrawColor(245, 245, 245)
		surface.DrawRect(0, 0, w, h)
	end

	local list = c:Add("ComCompScrollPanel")
	list:Dock(LEFT)
	list:SetWide(ComComp.RespX(128))
	list.Paint = function(self, w, h)
		surface.SetDrawColor(color_backblue:Unpack())
		surface.DrawRect(0, 0, w, h)
	end
	for k, v in pairs(self.DocList) do
		local btn = list:Add("Panel")
		btn:DockMargin(1, 0, 1, 1)
		btn:Dock(TOP)
		btn:SetTall(ComComp.RespY(24))
		btn.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and color_blue or color_darkblue)
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(v.name, "ComComp16", w/2, h/2, nil, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		btn.OnMousePressed = function()
			self:OpenDocumentation(k)
		end
	end


	local docViewer = c:Add("ComCompScrollPanel")
	docViewer:Dock(FILL)
	self.docViewer = docViewer

	if(docId) then
		self:OpenDocumentation(docId)
	end
end

function APP:OpenDocumentation(docId)
	local data = self.DocList[docId]
	if not data then return end

	self.docViewer:GetCanvas():Clear()

	local title = self.docViewer:Add("Panel")
	title:Dock(TOP)
	title:DockMargin(0, ComComp.RespY(12), 0, 0)
	title.PerformLayout = function(self, w, h)
		self.markup = markup.Parse("<font=ComComp24Bold><colour=0,0,0,255>" .. data.name .. "</colour></font>", w - ComComp.RespX(16))
		self:SetTall(self.markup:GetHeight())
	end
	title.Paint = function(self, w, h)
		if not self.markup then return end
		self.markup:Draw(ComComp.RespX(8), h/2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- Setup page content
	local pContents = {}
	for k, pData in ipairs(data.data) do
		local pCon = {}

		local pTitle = self.docViewer:Add("Panel")
		pTitle:Dock(TOP)
		pTitle.PerformLayout = function(self, w, h)
			self.markup = markup.Parse("<font=ComComp20><colour=0,0,0,255>" .. pData.title .. "</colour></font>", w - ComComp.RespX(16))
			self:SetTall(self.markup:GetHeight())
		end
		pTitle.Paint = function(self, w, h)
			if not self.markup then return end
			self.markup:Draw(ComComp.RespX(8), h/2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		table.insert(pCon, pTitle)

		for _, mediaData in ipairs(pData.data) do
			if (mediaData.type == "text") then
				local text = mediaData.text
				local textPanel = self.docViewer:Add("Panel")
				textPanel:DockMargin(0, ComComp.RespY(8), 0, ComComp.RespY(8))
				textPanel:Dock(TOP)
				textPanel.PerformLayout = function(self, w, h)
					self.markup = markup.Parse("<font=ComComp16><colour=0,0,0,255>" .. text .. "</colour></font>", w - ComComp.RespX(36))
					self:SetTall(self.markup:GetHeight())
				end
				textPanel.Paint = function(self, w, h)
					if not self.markup then return end
					self.markup:Draw(ComComp.RespX(18), h/2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end

				table.insert(pCon, textPanel)
			elseif (mediaData.type == "image") then
				local path = mediaData.path
				local mat = Material(path)
				local aRatio = mat:Width()/mat:Height()

				local imgPanel = self.docViewer:Add("Panel")
				imgPanel:DockMargin(0, ComComp.RespY(8), 0, ComComp.RespY(8))
				imgPanel:Dock(TOP)
				imgPanel.Paint = function(self, w, h)
					surface.SetDrawColor(255, 255, 255)
					surface.SetMaterial(mat)

					local iW = h * aRatio
					surface.DrawTexturedRect(w/2 - iW/2, 0, iW, h)
				end
				imgPanel.PerformLayout = function(self, w, h)
					self:SetTall(math.min(mat:Height(), (w/1.1)/aRatio))
				end

				table.insert(pCon, imgPanel)
			end
		end

		if (k ~= 1) then
			for _, v in ipairs(pCon) do
				v:SetVisible(false)
			end
		end

		table.insert(pContents, pCon)
	end


	-- Add back & next btn if necessary
	if(#data.data > 1) then
		local footer = self.docViewer:Add("Panel")
		local previous = footer:Add("Panel")
		local next = footer:Add("Panel")

		local curPage
		local changePage = function(page)
			local pCon = pContents[page]
			if not pCon then return end
	
			for k, v in ipairs(self.docViewer:GetCanvas():GetChildren()) do
				if (v ~= footer and v ~= title and k ~= 1) then
					v:SetVisible(false)
				end
			end

			previous:SetVisible(page ~= 1)
			next:SetVisible(page ~= #data.data)

			for _, v in ipairs(pCon) do
				v:SetVisible(true) -- Show the selected page
			end

			self.docViewer:InvalidateLayout()
			curPage = page
		end
		
		footer:Dock(TOP)
		footer:DockMargin(0, ComComp.RespY(48), 0, 0)
		footer:SetTall(ComComp.RespY(24))

		previous:Dock(LEFT)
		previous:DockMargin(ComComp.RespX(8), 0, 0, 0)
		previous.PerformLayout = function()
			previous:SetWide(self.docViewer:GetWide()/3.5)
		end
		previous.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and color_blue or color_darkblue)
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(L("previous"), "ComComp16", w/2, h/2, nil, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		previous.OnMousePressed = function()
			changePage(curPage - 1)
		end

		next:Dock(RIGHT)
		next:DockMargin(0, 0, ComComp.RespX(8), 0)
		next.PerformLayout = function()
			next:SetWide(self.docViewer:GetWide()/3.5)
		end
		next.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and color_blue or color_darkblue)
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(L("next"), "ComComp16", w/2, h/2, nil, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		next.OnMousePressed = function()
			changePage(curPage + 1)
		end

		changePage(1)
	end
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("helpcenter")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:TaskbarCreated", "CC:HelpCenter:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("helpcenter", helpMat, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local browser = ComComp.Apps:Instantiate(APP.Id, computer)
			browser:Open()
		end
		
	end, 0, true)
end)


