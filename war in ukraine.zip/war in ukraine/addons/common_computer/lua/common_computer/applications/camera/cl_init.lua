--[[
addons/common_computer/lua/common_computer/applications/camera/cl_init.lua
--]]
file.CreateDir("common_computer/pictures")

local L = ComComp.GetLang
local APP = APP

local camIcon = Material("common_computer/camera.png")
local camRT = GetRenderTarget("ComCompCamera", 1024, 1024, false)
local camMat = CreateMaterial("ComCompCamera", "UnlitGeneric", {
	["$basetexture"] = camRT:GetName(),
})

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()

	taskBar:AddIcon("camera")
	
	local frame = appArea:NewFrame()
	frame:SetIcon(camIcon)
	frame:SetTitle(L("camera"))
	frame:SetSize(ComComp.Resp(650, 660))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	local camPanel = frame:Add("Panel")
	camPanel:Dock(FILL)
	camPanel.FOV = 0.5
	camPanel.DrawLP = false
	camPanel.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(camMat) -- camMat is edited in the PreRender hook
		surface.DrawTexturedRect(0, 0, w, h)
	end

	hook.Add("PreRender", "CC:Camera:Draw", function()
		if not IsValid(camPanel) then return end

		local ent = self:GetComputer():GetEntity()
		if not IsValid(ent) then return end

		if (camPanel.NextDraw or 0) > CurTime() then return end
		camPanel.NextDraw = CurTime() + 1/25 -- 25 fps

		camPanel.DrawLP = true

		cam.Start3D() -- Necessary for ShouldDrawLocalPlayer 
		cam.End3D()

        render.PushRenderTarget(camRT)

		local pos, angles = ent:GetCamPos()

		cam.Start2D()
		render.RenderView({
			origin = pos,
			angles = angles,
			fov = camPanel.FOV * 80 + 10,
			x = 0, y = 0,
			w = ScrW(), h = ScrH()
		})
		cam.End2D()

		-- The player requests a screenshot (Doing it here because we need to be in the RenderTarget)
		if camPanel.Request then
			camPanel.Request = nil

			local data = render.Capture( {
				format = "jpeg",
				quality = 100,
				x = 0, y = 0,
				w = ScrW(), h = ScrH()
			})

			local path = "common_computer/pictures/" .. util.DateStamp() .. ".jpg"
			file.Write(path, data)

			timer.Simple(0, function() -- Wait next tick to have the correct screen size ScrW() & ScrH() returns the RenderTarget size here
				mainFrame:Notif(L("camera"), string.format(L("camera_filesaved"), path))
			end)
		end

        render.PopRenderTarget()
		camPanel.DrawLP = false
	end)

	hook.Add("ShouldDrawLocalPlayer", camPanel, function()
		if camPanel.DrawLP then
			return true
		end
	end)

	-- Requests a screenshot
	local takeBtn = camPanel:Add("Panel")
	takeBtn:SetSize(ComComp.Resp(64, 64))
	takeBtn.Paint = function(self, w, h)
		draw.NoTexture()
		surface.SetDrawColor(255, 255, 255, 100)
		draw.Circle(w/2, h/2, w/2, 30)
		draw.Circle(w/2, h/2, w/3, 30)
	end
	takeBtn.OnMousePressed = function()
		camPanel.Request = true
	end
	camPanel.PerformLayout = function(self, w, h)
		takeBtn:SetPos(w/2 - takeBtn:GetWide()/2, h - takeBtn:GetTall() - ComComp.RespY(12)) -- Correctly position the the takeBtn
	end

	-- Simple slider that edits the FOV of the camera
	local fovEditor = camPanel:Add("Panel")
	fovEditor:Dock(LEFT)
	fovEditor:SetWide(ComComp.RespX(18))
	local offY = ComComp.RespY(8)
	fovEditor:DockMargin(ComComp.RespX(12), offY, 0, offY)
	fovEditor.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255, 200)
		surface.DrawLine(w/2, 0, w/2, h)
		
		-- Draw horizontal bars
		local lines = math.Round(h/28)
		local offsetY = h/lines
		for y = 1, lines do
			local offX = y % 2 == 0 and 0 or w/6
			surface.DrawLine(offX, y * offsetY, w - offX, y * offsetY)
		end

		-- Draw the cursor
		draw.NoTexture()
		surface.SetDrawColor(255, 255, 255)
		draw.Circle(w/2, h * camPanel.FOV, w/2.9, 30)
		
		-- Start Dragging
		if input.IsMouseDown(MOUSE_LEFT) then
			if self.Dragging then
				local _, y = self:ScreenToLocal(0, gui.MouseY())
				camPanel.FOV = math.Clamp(y/h, 0, 1)
			elseif self:IsHovered() then
				self.Dragging = true
			end
		elseif self.Dragging then
			self.Dragging = nil
		end
	end
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("camera")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:Camera:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("camera", camIcon, L("camera"), 2, 2, function()
		local camera = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		camera:Open()
	end)
end)

hook.Add("CC:TaskbarCreated", "CC:Camera:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("camera", camIcon, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local camera = ComComp.Apps:Instantiate(APP.Id, computer)
			camera:Open()
		end
		
	end, 0, true)
end)

