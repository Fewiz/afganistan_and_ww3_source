--[[
addons/common_computer/lua/common_computer/applications/voxel/shared.lua
--]]
ComComp.Include(APP.Path .. "cl_ccvox.lua")

