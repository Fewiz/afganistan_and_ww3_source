--[[
addons/common_computer/lua/common_computer/applications/voxel/cl_init.lua
--]]
file.CreateDir("common_computer/voxels")

local APP = APP
local L = ComComp.GetLang
local RespX = ComComp.RespX
local RespY = ComComp.RespY
local voxelMat = Material("common_computer/voxel.png")

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()

	taskBar:AddIcon("voxel", voxelMat, function() -- Add the icon to the taskbar
		local app = self:GetComputer():RetrieveApp(APP.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	-- Creating the new frame
	local frame = appArea:NewFrame()
	frame:SetIcon(voxelMat)
	frame:SetTitle(L("voxel"))
	frame:SetSize(ComComp.Resp(515, 380))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(self, w, h)
		surface.SetDrawColor(70, 70, 70)
		surface.DrawRect(0, 0, w, h)
	end

	local toolbar = c:Add("ComCompScrollPanel")
	toolbar:Dock(LEFT)

	local colMan = toolbar:Add("Panel")
	colMan:DockPadding(RespX(7), RespY(5), RespX(7), 0)
	colMan:Dock(TOP)

	local colorPicker = colMan:Add("ComCompColorPicker")
	colorPicker:Dock(TOP)

	local colorList = colMan:Add("DIconLayout")
	colorList:Dock(TOP)
	colorList:DockMargin(0, RespY(8), 0, 0)
	colorList.List = {}
	colorList.ListCount = 0
	colorList.AddColor = function(self, c)
		if self.List[c.r] and self.List[c.r][c.g] and self.List[c.r][c.g][c.b] then
			return -- Already exists, ignore
		end

		self.List[c.r] = self.List[c.r] or {}
		self.List[c.r][c.g] = self.List[c.r][c.g] or {}
		
		local nPanel = self:Add("Panel")
		nPanel:SetSize(RespX(16), RespY(16))
		nPanel.Paint = function(self, w, h)
			surface.SetDrawColor(c:Unpack())
			surface.DrawRect(1, 1, w - 2, h - 2)

			if self:IsHovered() then
				surface.SetDrawColor(0, 0, 0)
				surface.DrawOutlinedRect(0, 0, w, h)
			end
		end
		nPanel.OnMousePressed = function()
			colorPicker:SetColor(c)
		end

		colorList.ListCount = colorList.ListCount + 1
		self.List[c.r][c.g][c.b] = nPanel
		
		self:SetTall(math.ceil(colorList.ListCount/(self:GetWide()/RespX(16))) * RespY(16))
		colMan:SizeToChildren(false, true)
	end
	colorList.RemoveColor = function(self, c)
		if self.List[c.r] and self.List[c.r][c.g] then
			local p = self.List[c.r][c.g][c.b]
			if p then
				colorList.ListCount = colorList.ListCount - 1
				self.List[c.r][c.g][c.b] = nil
				p:Remove()
			end
		end
	end

	toolbar.PerformLayout = function(_, w, h)
		local w = math.min(c:GetWide()/4, RespX(128))
		toolbar:SetWide(w)
		colorPicker:SetWide(w - RespX(7) * 2)
		colorPicker:SizeToContentsY()
		colMan:SizeToChildren(false, true)
	end

	self:BuildMenuHeader()

	local viewPanel = c:Add("ComComp3DPanel")
	viewPanel:Dock(FILL)
	viewPanel:SetClearColor(Color(85, 85, 85))
	viewPanel:SetOrbitKey(MOUSE_MIDDLE)
	viewPanel:SetFPSKey(KEY_SPACE)
	viewPanel.ShouldUpdateRenderTarget = function()
        return not self:GetComputer():IsPaused() and self.VoxObj ~= nil
	end
	viewPanel.FileChanged = function(self, voxObj)
		local middle = voxObj:GetCanvasSize()/2

		viewPanel:SetOrbitPos(middle)
		viewPanel:Set3DPos(middle)
		viewPanel:Set3DAngles(Angle(45, 45, 0))
	end
	self.viewPanel = viewPanel

	viewPanel.RayTrace = function(_, back)
		local x, y = viewPanel:ScreenToLocal(gui.MouseX(), gui.MouseY())
		local w, h = viewPanel:GetWide(), viewPanel:GetTall()
		local dir = util.AimVector(viewPanel:Get3DAngles(), viewPanel:Get3DFOV(), x, y, w, h):GetNormalized()
		return self.VoxObj:RayTrace(viewPanel:Get3DPos(), dir, back)
	end

	-- Draw the voxels
	viewPanel:SetDrawFnc(function()
		if not self.VoxObj then return end

		local canSize = self.VoxObj:GetCanvasSize()

		render.DrawWireframeBox(vector_origin - Vector(0.5, 0.5, 0.5), angle_zero, vector_origin, canSize + Vector(1, 1, 1), nil, true)
					
		local hit = viewPanel:RayTrace(true)
		if hit and self.VoxObj:IsInCanvas(hit.x, hit.y, hit.z) then
			render.DrawWireframeBox(hit - Vector(0.5, 0.5, 0.5), angle_zero, vector_origin, Vector(1, 1, 1), color_black, true)
		end

		self.VoxObj:Draw()
	end)

	-- Used to remove/add a cube
	viewPanel.OnMousePressed = function(_, code)
		if not self.VoxObj then return end

		if code == MOUSE_RIGHT then
			local hit = viewPanel:RayTrace(true)
			if hit then
				local c = self.VoxObj:GetCube(hit.x, hit.y, hit.z)
				if c then
					self.VoxObj:RemoveCube(hit.x, hit.y, hit.z)
					self.VoxObj:BuildMeshes()

					local dCols = self.VoxObj:GetColors()
					if (not dCols[c.r] or not dCols[c.r][c.g] or not dCols[c.r][c.g][c.b]) then
						colorList:RemoveColor(c)
					end
				end
			end
		elseif code == MOUSE_FIRST then
			local hit = viewPanel:RayTrace(false)
			if hit then
				colorList:AddColor(colorPicker:GetColor())
				self.VoxObj:SetCube(hit.x, hit.y, hit.z, colorPicker:GetColor())
				self.VoxObj:BuildMeshes()
			end
		elseif code == MOUSE_MIDDLE then
			local hit = viewPanel:RayTrace(true)
			if hit then
				viewPanel:SetOrbitPos(hit) -- Readjust the orbit position
			end
		end
	end


	-- Draw overlay (Vertices count, size, tips)
	viewPanel.PaintOver = function(_, w, h)
		if not self.VoxObj then return end

		local canSize = self.VoxObj:GetCanvasSize()

		-- Draw vertices count
		local _, tH = draw.SimpleText("Vertices: " .. self.VoxObj:GetVerticesCount(), "ComComp18", w - 2, 2, nil, TEXT_ALIGN_RIGHT)

		-- Draw the file size
		local MaxFileLen = ComComp.Cfg["MaxNetSize"] - 16 - 16 * 2
		local size = (3 + (canSize.x + 1) * (canSize.y + 1) * (canSize.z + 1) + self.VoxObj:GetCubeCount() * 3)
		draw.SimpleText("Size: " .. size .. " byte(s)", "ComComp18", w - 2, 2 + tH, size > MaxFileLen and Color(255, 0, 0) or nil, TEXT_ALIGN_RIGHT)

		-- Draw a dot in the center of the screen if we're in FPS mode
		if viewPanel.FirstPerson then
			surface.SetDrawColor(255, 255, 255)
			draw.NoTexture() 	
			draw.Circle(w/2, h/2, 2, 20)
		end

		draw.SimpleText(L("voxel_move"), "ComComp12", w, h - RespX(12), nil, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	end
end

-- MenuBar File -> New,Save,Load
function APP:BuildMenuHeader()
	local menu = self.frame:Add("ComCompMenuBar")
	menu:Dock(TOP)
	menu:SetTall(RespY(24))
	
	local newFrame
	local fileMenu = menu:AddMenu(L("file"))
	fileMenu:AddOption(L("new"), function()
		if IsValid(newFrame) then
			newFrame:Remove()
		end

        newFrame = self.frame:Add("ComCompFrame")
		newFrame:SetTitle(L("new"))
		newFrame:SetIcon(Material("icon16/page_white.png"))
		newFrame:SetSizable(false)
        newFrame:SetSize(ComComp.Resp(200, 156))
		newFrame.OnMaximize = function() end
		newFrame:Center()
		
		local cd = newFrame:Add("Panel")
		cd:Dock(FILL)
		cd.Paint = function(self, w, h)
			surface.SetDrawColor(240, 240, 240)
			surface.DrawRect(0, 0, w, h)
		end
		cd:DockPadding(0, RespY(16), 0, 0)
		
		-- New frame x,y,z inputs
		local t = {'x', 'y', 'z'}
		for i= 1, 3 do
			local p = cd:Add("Panel")
			p:Dock(TOP)
			p:SetTall(RespY(20))
			p:DockMargin(0, RespY(4), 0, 0)

			local label = p:Add("DLabel")
			label:SetFont("ComComp16")
			label:SetTextColor(color_black)
			label:Dock(LEFT)
			label:DockMargin(RespX(6), 0, 0, 0)
			label:SetText(t[i] .. ": ")

			local wang = p:Add("DNumberWang")
			wang:SetMin(1)
			wang:SetMax(256)
			wang:Dock(LEFT)
			wang:SetValue(24)
			
			p.PerformLayout = function()
				label:SetWide(cd:GetWide()/4)
				wang:SetWide(cd:GetWide()/3)
			end

			t[i] = wang
		end

		local newBtn = cd:Add("ComCompButton")
		newBtn:Dock(BOTTOM)
		newBtn:SetTall(RespY(20))
		newBtn:DockMargin(RespX(55), 0, RespX(55), RespY(4))
		newBtn:SetText(L("new"))
		newBtn.DoClick = function()
			newFrame:Remove()

			if self.VoxObj ~= nil then
				self.VoxObj:Free()
				self.VoxObj = nil
			end

			local sizeX = math.Clamp(t[1]:GetValue(), 1, 256) - 1
			local sizeY = math.Clamp(t[2]:GetValue(), 1, 256) - 1
			local sizeZ = math.Clamp(t[3]:GetValue(), 1, 256) - 1

			self.VoxObj = ComComp.NewCCVox(sizeX, sizeY, sizeZ)

			self.viewPanel:FileChanged(self.VoxObj)
		end

	end):SetIcon("icon16/page_white.png")

	fileMenu:AddOption(L("open"), function()
		local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
		if not explorer then
			ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), self.frame)
			return
		end
		explorer:Open()
		explorer:SetOpenMode(true, function(path)
			if not string.EndsWith(path, ".dat") then return end
			path = string.sub(path, 11, #path)

			if self.VoxObj ~= nil then
				self.VoxObj:Free()
				self.VoxObj = nil
			end

			local f = file.Open(path, "rb", "GAME")
			if f then
				local data = f:Read(f:Size())
				f:Close()

				local bytes = {}
				for i = 1, #data do
					bytes[i] = string.byte(data, i)
				end

				self.VoxObj = ComComp.NewCCVox(0, 0, 0)
				self.VoxObj:ImportData(bytes)

				self.viewPanel:FileChanged(self.VoxObj)
			end
		end)
	end):SetIcon("icon16/folder.png")

	fileMenu:AddOption(L("save"), function()
		if self.VoxObj ~= nil then
			local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
			if not explorer then
				ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), self.frame)
				return
			end
			explorer:Open()
			explorer:SetRoot("garrysmod/data/") -- We can only write here :/
			explorer:SetSaveMode(true, function(path)
				local f = file.Open(string.sub(path, #explorer:GetRoot() + 1) .. ".dat", "wb", "DATA")
				if f then
					local bytes = self.VoxObj:ExportData()
					
					local data = ""
					for i = 1, #bytes do
						data = data .. string.char(bytes[i])
					end
					
					f:Write(data)
					f:Close()
				end
			end)
		end
	end):SetIcon("icon16/disk.png")
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("voxel")
	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:Voxel:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("voxel", voxelMat, L("voxel"), 3, 1, function()
		local computer = computerFrame:GetComputerInstance()
		local voxel = ComComp.Apps:Instantiate(APP.Id, computer)
		voxel:Open()
	end)
end)

hook.Add("CC:Applications:Loaded", "CC:Voxel:Help", function()
	local help = ComComp.Apps:GetMeta("helpcenter")
	if not help then return end

	local doc = help:NewDocumentation(APP.Id, L("voxel"))
		:AddPage(L("voxel_movement_title"))
		:AddText(L("voxel_movement"))
        :AddImage("common_computer/helpcenter/voxel.jpg")
end)

