--[[
addons/common_computer/lua/common_computer/applications/browser/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP
local browserMat = Material("common_computer/browser.png")

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("browser")
	
	local appArea = mainFrame:GetAppArea()
	local frame = appArea:NewFrame()
	frame:SetIcon(browserMat)
	frame:SetTitle(L("browser"))
	frame:SetSize(ComComp.Resp(750, 500))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	local incompatibility = false

	local html = frame:Add("DHTML")
	html:Dock(FILL)
	html:OpenURL(ComComp.Cfg["browser"]["default_url"])
	html.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)

		if (incompatibility) then
			draw.SimpleText(L("chromium_branch"), "ComComp20Bold", w/2, h/2, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	html.OnFinishLoadingDocument = function(_, url)
		if (url == "chrome://chromewebdata/") then
			incompatibility = true
		end
	end
	
	local ctrls = frame:Add("DHTMLControls")
	ctrls:Dock(TOP)
	ctrls.BorderSize = 0
	ctrls.Paint = function(self, w, h)
		surface.SetDrawColor(245, 245, 245)
		surface.DrawRect(0, 0, w, h)
	end
	ctrls:SetButtonColor(Color(0, 0, 0, 245))
	ctrls.AddressBar:SetDrawLanguageID(false)

	local highColor = Color(48, 128, 255)
	ctrls.AddressBar.Paint = function(self, w, h)
		surface.SetDrawColor(125, 125, 125)
		surface.DrawOutlinedRect(0, 0, w, h)
		
		self:DrawTextEntryText(color_black, highColor, color_black)
	end
	ctrls:SetHTML(html)
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("browser")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end


hook.Add("CC:DesktopCreated", "CC:Browser:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("browser", browserMat, L("browser"), 2, 0, function()
		local browser = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		browser:Open()
	end)
end)

hook.Add("CC:TaskbarCreated", "CC:Browser:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("browser", browserMat, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local browser = ComComp.Apps:Instantiate(APP.Id, computer)
			browser:Open()
		end
		
	end, 0, true)
end)


