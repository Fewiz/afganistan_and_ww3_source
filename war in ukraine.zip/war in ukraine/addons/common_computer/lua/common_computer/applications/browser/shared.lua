--[[
addons/common_computer/lua/common_computer/applications/browser/shared.lua
--]]
ComComp.Include(APP.Path .. "sh_config.lua")

