--[[
addons/common_computer/lua/common_computer/applications/browser/sh_config.lua
--]]
ComComp.Cfg["browser"] = {}
ComComp.Cfg["browser"]["default_url"] = "google.com"

