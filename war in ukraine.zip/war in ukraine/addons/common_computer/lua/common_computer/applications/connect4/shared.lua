--[[
addons/common_computer/lua/common_computer/applications/connect4/shared.lua
--]]
APP.X_LENGHT = 7
APP.Y_LENGHT = 6
APP.CONNECT = 3 -- Number of piece needed to be connected to win (It includes 0)

