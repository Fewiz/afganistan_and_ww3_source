--[[
addons/common_computer/lua/common_computer/applications/connect4/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP

local color_yellow = Color(255, 255, 0)
local color_red = Color(255, 25, 25)
local color_blue = Color(8, 129, 194)
local connectMat = Material("common_computer/connect4.png")

local RecRequests = {}
local SentRequests = {}

net.Receive("ComCompC4SendRequest", function()
	RecRequests[net.ReadEntity()] = true
end)

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("connect4", connectMat, function()
		local app = self:GetComputer():RetrieveApp(APP.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	local appArea = mainFrame:GetAppArea()
	local frame = appArea:NewFrame()
	frame:SetIcon(connectMat)
	frame:SetTitle(L("connect4"))
	frame:SetSize(ComComp.Resp(750, 500))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	frame.OnRemove = function()
		net.Start("ComCompC4GameCancel")
		net.SendToServer()
	end
	self.frame = frame
	
	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
		
		surface.SetDrawColor(230, 230, 230)
		local t = w/32
		local off = (w + h)/t
		for i = 0, t do
			surface.DrawLine(0, i * off, i * off, 0)
		end
	end
	
	
	local header = c:Add("Panel")
	header:Dock(TOP)
	header:SetTall(ComComp.RespY(48))
	header.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
	end
	header.PaintOver = function(self, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(connectMat)
		local offY = ComComp.RespY(4)
		surface.DrawTexturedRect(offY, offY, h - offY * 2, h - offY * 2)
		draw.SimpleText(L("connect4"), "ComComp24Bold", h, h/2, color_blue, nil, TEXT_ALIGN_CENTER)	
	end
	
	--[[
		STEP 0: Declare default variables
	]]
	self.IsYellow = false
	self.Opponent = nil
	self.Playing = false
	self.Grid = {}
	
	--[[
		STEP 1: Choose an opponent and a color
	]]
	local startGame = c:Add("Panel")
	startGame:Dock(FILL)
	
		local plyList = startGame:Add("ComCompScrollPanel")
		plyList:Dock(FILL)
		plyList.Players = {}
		local offX, offY = ComComp.Resp(125, 16)
		plyList:GetCanvas():DockPadding(offX, offY, offX, offY)
		plyList.Think = function()
			for k,v in ipairs(player.GetHumans()) do
				if v == LocalPlayer() then goto con end
				if IsValid(plyList.Players[v]) then goto con end
				local count = #plyList.Players
			
				local panel = plyList:Add("Panel")
				panel:Dock(TOP)
				panel:SetTall(ComComp.RespY(30))
				panel.Paint = function(self, w, h)
					if self:IsHovered() then
						surface.SetDrawColor(color_blue)
						surface.DrawRect(0, 0, w, h)
					end
					
					if not IsValid(v) then 
						self:Remove()
					else
						local extra
						if RecRequests[v] then
							extra = L("connect4_wantplay")
						elseif SentRequests[v] then
							extra = L("connect4_sentrequest")
						end
						
						draw.SimpleText(count .. ". " .. v:Nick() .. (extra and (" - " .. extra) or ""), "ComComp18", w/2, h/2, self:IsHovered() and color_white or color_blue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
				
				panel.OnMousePressed = function()
					local computer = self:GetComputer()
					local ent = computer:GetEntity() -- Computer
					
					if not IsValid(ent) then return end
				
					if RecRequests[v] then
						-- Accept the request
						net.Start("ComCompC4AcceptRequest")
						net.WriteEntity(ent)
						net.WriteEntity(v)
						net.SendToServer()
						
						RecRequests[v] = nil
					else

						if SentRequests[v] then
							net.Start("ComCompC4GameCancel")
							net.SendToServer()

							SentRequests[v] = nil
						else
							-- Send a request
							net.Start("ComCompC4SendRequest")
							net.WriteEntity(ent)
							net.WriteEntity(v)
							net.WriteBool(self.IsYellow)
							net.SendToServer()
							
							SentRequests[v] = true
						end
					end
				end
				
				plyList.Players[v] = panel

				::con::
			end
		end
		
		local color = header:Add("Panel")
		color:Dock(RIGHT)
		color:SetWide(ComComp.RespX(48 + 120))
		color.Paint = function(_, w, h)
			surface.SetDrawColor(self.IsYellow and color_yellow or color_red)
			draw.NoTexture()
			draw.Circle(w - h/2, h/2, h/3, 25)
			
			draw.SimpleText(L("connect4_choose_color"), "ComComp16", 0, h/2, color_blue, nil, TEXT_ALIGN_CENTER)
		end
		color.OnMousePressed = function()
			if self.Playing then return end
			self.IsYellow = not self.IsYellow
		end
		
	--[[
		STEP 2: Game
	]]
	local gamePanel = c:Add("Panel")
	gamePanel:SetVisible(false)
	gamePanel:Dock(FILL)
	
		local gridPanel = gamePanel:Add("Panel")
		gridPanel:Dock(LEFT)
		gridPanel.GetSquare = function()
			return gridPanel:GetTall()/self.Y_LENGHT
		end
		gridPanel.GetCursor = function()
			local square = gridPanel:GetSquare()
			local cX, cY = gridPanel:ScreenToLocal(gui.MouseX(), gui.MouseY())
			
			cX = math.Clamp(math.floor(cX/square), 0, self.X_LENGHT - 1)
			cY = math.Clamp(math.floor(cY/square), 0, self.Y_LENGHT - 1)
			
			return cX, cY
		end
		gridPanel.Paint = function(_, w, h)
			local square = gridPanel:GetSquare()
			local cX, cY = gridPanel:GetCursor()
			
			surface.SetDrawColor(color_blue)
			surface.DrawRect(0, 0, w, h)
			
			surface.SetDrawColor(255, 255, 255, 20)
			surface.DrawRect(cX * square, cY * square, square, square)
			
			-- Draw the grid
			local offset = ComComp.RespX(5)
			draw.NoTexture()
			for x = 0, self.X_LENGHT - 1 do
				for y = 0, self.Y_LENGHT - 1 do
					if self.Grid[x][y] == nil then
						surface.SetDrawColor(255, 255, 255)
						draw.Circle(x * square + square/2, y * square + square/2, square/2 - offset, w/25)
						goto con
					end

					surface.SetDrawColor(self.Grid[x][y] and color_red or color_yellow)
					draw.Circle(x * square + square/2, y * square + square/2, square/2 - offset, w/25)
					
					::con::
				end	
			end
		end
		gridPanel.OnMousePressed = function()
			if not self.Playing then return end
			
			local computer = self:GetComputer()
			local ent = computer:GetEntity() -- Computer
			if not IsValid(ent) then return end

			local cX, cY = gridPanel:GetCursor()
			
			net.Start("ComCompC4SetPoint")
			net.WriteEntity(ent)
			net.WriteUInt(cX, 3)
			net.SendToServer()
		end
		
		local rightPanel = gamePanel:Add("Panel")
		rightPanel:Dock(RIGHT)
		
		
	gamePanel.PerformLayout = function(_, w, h)
		gridPanel:SetWide(h/self.Y_LENGHT * self.X_LENGHT)
		rightPanel:SetWide(w - gridPanel:GetWide())
	end
		
	--[[
		NETWORK
	]]
	

	net.Receive("ComCompC4StartGame", function()
		if not IsValid(frame) then return end
	
		local red = net.ReadEntity()
		local yellow = net.ReadEntity()
		
		self.Grid = {}
		
		for x = 0, self.X_LENGHT - 1 do
			self.Grid[x] = {}
		end
		
		self.IsYellow = yellow == LocalPlayer()
		self.Opponent = self.IsYellow and red or yellow
		
		SentRequests[self.Opponent] = nil
		
		gamePanel:SetVisible(true)
		startGame:SetVisible(false)

		rightPanel:Clear()
		
		self.Playing = true
	end)
	
	net.Receive("ComCompC4SetPoint", function()
		if not IsValid(frame) then return end

		local x = net.ReadUInt(3)
		local y = net.ReadUInt(3)
		local isYellow = net.ReadBool()
		
		self.Grid[x][y] = !isYellow
	end)
	
	net.Receive("ComCompC4GameEnd", function()
		if not IsValid(frame) then return end
		
		local isYellowWinner = net.ReadBool()
		
		self.Playing = false
		
		local label = rightPanel:Add("DLabel")
		label:Dock(TOP)
		label:SetContentAlignment(5)
		label:SetTextColor(isYellowWinner and color_yellow or color_red)
		label:SetFont("ComComp18")
		label:SetText(isYellowWinner and L("connect4_yellowwin") or L("connect4_redwin"))
		label:SizeToContents()
	end)
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("connect4")
	
	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "AddConnect4Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("connect4", connectMat, L("connect4"), 2, 1, function()
		local app = computerFrame:GetComputerInstance():RetrieveApp(APP.Id)
		if app then
			app:Resume() -- Only one instance of the game !
			return
		end

		local connect = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		connect:Open()
	end)
end)


