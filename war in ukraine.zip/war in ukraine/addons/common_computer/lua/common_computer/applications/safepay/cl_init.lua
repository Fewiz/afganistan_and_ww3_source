--[[
addons/common_computer/lua/common_computer/applications/safepay/cl_init.lua
--]]
--[[
	This application does nothing else than showing purchase information to the screen
]]

local L = ComComp.GetLang
local appId = APP.Id

local safepayMat = Material("common_computer/safepay.png")
local bitcoinMat = Material("common_computer/bitcoinlogo.png")
local safeMat = Material("common_computer/safepaylogo.png", "smooth")

local color_red = Color(200, 0, 0)
local color_blue = Color(0, 156, 222)
local color_orange = Color(247, 147, 26)
local color_gray = Color(77, 77, 77)

function APP:Open(name, price, callback, bitcoinStyle)
	self:SetBitcoinStyle(bitcoinStyle)

	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()
	
	taskBar:AddIcon("safepay", safepayMat, function()
		local app = self:GetComputer():RetrieveApp(appId)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	local frame = appArea:NewFrame()
	frame:SetIcon(safepayMat)
	frame:SetTitle(L("safepay"))
	frame:SetSize(ComComp.Resp(400, 550))
	frame:SetSizable(false)
	frame:MoveToFront()
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	frame.OnMaximize = function() end
	self.frame = frame
	
	-- Always return true on other gamemode
	local hasEnoughMoney = function()
		if DarkRP then
			return LocalPlayer():getDarkRPVar("money") >= price
		end

		return true
	end

	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(_, w, h)
		surface.SetDrawColor(250, 250, 250)
		surface.DrawRect(0, 0, w, h)
	end
	
	local header = c:Add("Panel")
	header:Dock(TOP)
	header:DockMargin(0, ComComp.RespY(25), 0, 0)
	header:SetTall(ComComp.RespY(80))
	header.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(self.bitcoinStyle and bitcoinMat or safeMat)
		surface.DrawTexturedRect(w/2 - ComComp.RespY(300)/2, 0, ComComp.RespY(300), h)
	end
	
	local desc = c:Add("Panel")
	desc:Dock(FILL)
	desc:DockMargin(0, ComComp.RespY(10), 0, ComComp.RespY(10))
	desc.Paint = function(_, w, h)
		local color = self.bitcoinStyle and color_orange or color_blue
		local tW, tH = draw.SimpleText(L("safepay_goingtobuy"), "ComComp26", w/2, 0, color_gray, TEXT_ALIGN_CENTER)
		draw.SimpleText(name, "ComComp26Bold", w/2, tH, color, TEXT_ALIGN_CENTER)
		
		local tW2, tH2 = draw.SimpleText(L("safepay_price"), "ComComp24", w/2, tH*3.5, color_gray, TEXT_ALIGN_CENTER)
		if self.bitcoinStyle then
			draw.SimpleText(math.Round(price/19179, 3) .. " bitcoins = " .. price .. "$", "ComComp24", w/2, tH*3.5 + tH2, color, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText(price .. "$", "ComComp24", w/2, tH*3.5 + tH2, color, TEXT_ALIGN_CENTER)
		end

		if !hasEnoughMoney() then
			draw.SimpleText(L("safepay_nomoney"), "ComComp22", w/2, h - ComComp.RespX(22 + 6), color_red, TEXT_ALIGN_CENTER)
		end
	end
	
	local buyBtn = c:Add("Panel")
	buyBtn:Dock(BOTTOM)
	buyBtn:SetTall(ComComp.RespY(32))
	buyBtn:DockMargin(ComComp.RespX(100), 0, ComComp.RespX(100), ComComp.RespY(12))
	buyBtn.Paint = function(_, w, h)
		local color = !hasEnoughMoney() and color_gray or (self.bitcoinStyle and color_orange or color_blue)
		
		if buyBtn:IsHovered() and hasEnoughMoney() then
			DisableClipping(true)
			local offX, offY = ComComp.Resp(2, 2)
			draw.RoundedBox(ComComp.RespX(4), -offX, -offY, w + offX*2, h + offY*2, color)
			DisableClipping(false)
			draw.SimpleText(L("safepay_buybtn"), "ComComp20Bold", w/2, h/2 - ComComp.RespY(20)/2, color_white, TEXT_ALIGN_CENTER)
		else
			draw.RoundedBox(ComComp.RespX(4), 0, 0, w, h, color)
			draw.SimpleText(L("safepay_buybtn"), "ComComp18Bold", w/2, h/2 - ComComp.RespY(18)/2, color_white, TEXT_ALIGN_CENTER)
		end
	end
	buyBtn.OnMousePressed = function()
		if hasEnoughMoney() then
			callback()
		end
	end
end

function APP:SetBitcoinStyle(s)
	self.bitcoinStyle = s
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("safepay")
	
	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end


