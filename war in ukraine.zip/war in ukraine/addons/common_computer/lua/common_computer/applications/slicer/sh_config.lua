--[[
addons/common_computer/lua/common_computer/applications/slicer/sh_config.lua
--]]
ComComp.Cfg["slicer"] = ComComp.Cfg["slicer"] or {} -- Autorefresh
ComComp.Cfg["slicer"]["voxel_print_cost"] = 200
ComComp.Cfg["slicer"]["config_path"] = "common_computer/slicer_config.json" 

