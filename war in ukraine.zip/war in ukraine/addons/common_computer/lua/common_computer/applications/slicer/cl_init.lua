--[[
addons/common_computer/lua/common_computer/applications/slicer/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP

local slicerMat = Material("common_computer/slicer.png")
local whiteMat = CreateMaterial("SlicerWireframe", "VertexLitGeneric", {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$model"] = 1,
    ["$ignorez"] = 1
})

local color_red = Color(255, 0, 0)
local color_green = Color(0, 255, 0)
local color_blue = Color(0, 0, 255)
local highColor = Color(48, 128, 255)

function APP:Open()
    local mainFrame = self:GetComputer():GetMainFrame()
    local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("slicer")

	local frame = appArea:NewFrame()
	frame:SetIcon(slicerMat)
	frame:SetTitle(L("slicer"))
	frame:SetSize(ComComp.Resp(750, 500))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
    end
    frame.OnRemove = function()
        if IsValid(self.ent) then
            self.ent:Remove()
        end

        if self.voxObj ~= nil then
            self.voxObj:Free()
        end
    end
	self.frame = frame
    
    -- These variables are used to determine what we need to draw and what we need to print.
    local drawFnc, printFnc

	local p = frame:Add("Panel")
	p:Dock(FILL)
    
    local listPanel = p:Add("ComCompScrollPanel")
    listPanel:Dock(LEFT)
    listPanel:SetWide(ComComp.RespX(128))
    listPanel.Paint = function(self, w, h)
        surface.SetDrawColor(0, 0, 0)
        surface.DrawRect(0, 0, w, h)
    end
    listPanel.AddBtn = function(self, name)
        local btn = listPanel:Add("Panel")
        btn:Dock(TOP)
        btn:SetTall(ComComp.RespY(25))
        btn.Paint = function(self, w, h)
            if self:IsHovered() then
                surface.SetDrawColor(255, 255, 255)
                surface.DrawRect(0, 0, w, h)
            end
            draw.SimpleText(name, "ComComp16", w/2, h/2, self:IsHovered() and color_black or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        return btn
    end

    local viewPanel = p:Add("ComComp3DPanel")
    viewPanel:Dock(FILL)
    viewPanel:SetOrbitKey(MOUSE_MIDDLE)
	viewPanel:SetFPSKey(KEY_SPACE)
    viewPanel:SetClearColor(Color(60, 73, 80))
    viewPanel.ShouldUpdateRenderTarget = function()
        return not self:GetComputer():IsPaused()
    end

    viewPanel:SetDrawFnc(function()
        render.SuppressEngineLighting(true)
        render.SetLightingOrigin(vector_origin)
        render.ResetModelLighting(0.2, 0.2, 0.2)
        render.SetColorModulation(1, 1, 1)
        render.SetBlend(1)
        render.SetModelLighting(BOX_TOP, 1, 1, 1)
        render.SetModelLighting(BOX_FRONT, 1, 1, 1)

        if drawFnc then
            drawFnc()
        end

        render.SuppressEngineLighting(false)

        for i = -40, 40, 4 do
            render.DrawLine(Vector(-40, i, 0), Vector(40, i, 0), color_black, true)
            render.DrawLine(Vector(i, -40, 0), Vector(i, 40, 0), color_black, true)
        end
    end)

	for k, v in ipairs(APP:GetConfig()) do
        local btn = listPanel:AddBtn(v.name)
        btn.OnMousePressed = function()
            if IsValid(self.ent) then
                self.ent:Remove()
            end

            self.ent = ents.CreateClientProp()
            self.ent:SetModel(v.model)
            self.ent:SetNoDraw(true)
            self.ent:Spawn()

            drawFnc = function()
                if(IsValid(self.ent)) then
                    self.ent:DrawModel()
                end
            end

            printFnc = function()
                local fncSend = function()
                    net.Start("ComCompPrint3dObject")
                    net.WriteEntity(self:GetComputer():GetEntity())
                    net.WriteBool(false) -- IsVoxel ?
                    net.WriteUInt(k, 16)
                    net.SendToServer()
                end

                local safepay = ComComp.Apps:Instantiate("safepay", self:GetComputer())
                if safepay then
                    safepay:Open(v.name, v.price, function()
                        safepay:Close()
                        fncSend()
                    end)
                else
                    fncSend()
                end
            end
        end
    end
    
    -- Voxel support
    local btn = listPanel:AddBtn(L("slicer_print_import_voxel"))
    btn:DockMargin(0, ComComp.RespY(8), 0, 0)
    btn.OnMousePressed = function()
        local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
        if not explorer then
            ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), frame)
            return
        end
        explorer:Open()
        explorer:SetOpenMode(true, function(path)
            if not string.EndsWith(path, ".dat") then return end
            path = string.sub(path, 11, #path)

            if self.voxObj ~= nil then
                self.voxObj:Free()
                self.voxObj = nil
            end

            local f = file.Open(path, "rb", "GAME")
            if f then
                local data = f:Read(f:Size())
                f:Close()

                local bytes = {}
                for i = 1, #data do
                    bytes[i] = string.byte(data, i)
                end

                self.voxObj = ComComp.NewCCVox(0, 0, 0)
                self.voxObj:ImportData(bytes)
    
                local cSize = self.voxObj:GetCanvasSize()
                local mat = Matrix()
                mat:Translate(Vector(-cSize.x/2, -cSize.y/2, 0.5))

                drawFnc = function()
                    if mat and self.voxObj then
                        cam.PushModelMatrix(mat)
                            self.voxObj:Draw()
                        cam.PopModelMatrix()
                    end
                end

                printFnc = function()
                    if ComComp.Cfg["MaxNetSize"] - (16*2 + 1) <= #data then
                        ComComp.DialogFrame(L("warning"), L("slicer_print_heavy"), frame)
                    else
                        local fncSend = function()
                            net.Start("ComCompPrint3dObject")
                            net.WriteEntity(self:GetComputer():GetEntity())
                            net.WriteBool(true) -- IsVoxel ?
                            net.WriteData(data, #data)
                            net.SendToServer()
                        end

                        local safepay = ComComp.Apps:Instantiate("safepay", self:GetComputer())
                        if safepay then
                            safepay:Open(L("slicer_print_voxel"), ComComp.Cfg["slicer"]["voxel_print_cost"], function()
                                safepay:Close()
                                fncSend()
                            end)
                        else
                            fncSend()
                        end
                    end
                end
            end
        end)
    end

    local options = viewPanel:Add("Panel")
    options:SetTall(ComComp.RespY(25))
    options:DockMargin(ComComp.RespX(10), ComComp.RespY(10), ComComp.RespX(10), 0)
    options:Dock(TOP)

	local printBtn = options:Add("Panel")
    printBtn:Dock(RIGHT)
    printBtn:SetWide(ComComp.RespX(100))
    printBtn.Paint = function(self, w, h)
        surface.SetDrawColor(self:IsHovered() and color_white or color_black)
        surface.DrawRect(0, 0, w, h)

        draw.SimpleText(L("slicer_print"), "ComComp16", w/2, h/2, self:IsHovered() and color_black or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    printBtn.OnMousePressed = function()
        if printFnc then
            printFnc()
        end
    end
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("slicer")
	
	self.frame:Remove()
	
    self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:Slicer:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("slicer", slicerMat, L("slicer"), 1, 2, function()
		local slicer = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		slicer:Open()
	end)
end)

hook.Add("CC:TaskbarCreated", "CC:Slicer:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("slicer", slicerMat, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local slicer = ComComp.Apps:Instantiate(APP.Id, computer)
			slicer:Open()
		end
		
	end, 0, true)
end)

hook.Add("CC:Applications:Loaded", "CC:Slicer:Help", function()
	local help = ComComp.Apps:GetMeta("helpcenter")
	if not help then return end

	local doc = help:NewDocumentation(APP.Id, L("slicer"))
		:AddPage(L("slicer_printing_voxel_title"))
		:AddText(L("slicer_printing_voxel"))
        :AddImage("common_computer/helpcenter/slicer.jpg")
        :AddText(L("slicer_printing_result"))
		:AddImage("common_computer/helpcenter/slicer-1.jpg")
end)

