--[[
addons/common_computer/lua/common_computer/applications/slicer/igconfig/cl_init.lua
--]]
local APP = APP
local L = ComComp.GetLang


--[[
    Powerful configuration used to add custom models to 3D Printer/Slicer
]]
local frame
function APP:OpenIGConfig()
    if IsValid(frame) then
        frame:SetVisible(true)
        return
    end

    frame = vgui.Create("ComCompFrame")
    frame:SetTitle(L("configuration"))
    frame:SetSize(ComComp.Resp(712, 450))
    frame:Center()
    frame:MakePopup()
    frame.OnReduce = function()
        frame:SetVisible(false)
    end

    local printerEnt = ClientsideModel("models/veeds/imprimante3d/imprimante3d.mdl")
    printerEnt:SetNoDraw(true)
    
    local printSeq, printSeqDur = printerEnt:LookupSequence("print")

    frame.OnRemove = function(self)
        printerEnt:Remove()
    end

    local c = frame:Add("Panel")
    c:Dock(FILL)
    c.Paint = function(self, w, h)
        surface.SetDrawColor(0, 0, 0)
        surface.DrawRect(0, 0, w, h)
    end

    local view = c:Add("ComComp3DPanel")
    view:Dock(FILL)
    view:SetClearColor(Color(20, 20, 20))

    local rMin, rMax = printerEnt:GetRenderBounds()
    local rb = rMin + rMax
    view:SetOrbitPos(Vector(rb.x/2, rb.y/2, rb.z/2))

    local baseDrawFnc = function()
        printerEnt:DrawModel()
    end

    local resetPrinterAnim = function()
        hook.Remove("Think", printerEnt)
        printerEnt:ResetSequenceInfo()
        printerEnt:ResetSequence("idle")
        printerEnt:SetCycle(0)
        printerEnt:SetPlaybackRate(1)
    end

    view:SetDrawFnc(baseDrawFnc)
    view:SetFPSKey(KEY_NONE)
    view:Set3DPos(Vector(1, 1, 1):GetNormalized() * view:GetOrbitDist())
    view:Set3DAngles((view:GetOrbitPos() - view:Get3DPos()):Angle())

    local orbitModeBtn = view:Add("Panel")
    orbitModeBtn:SetPos(ComComp.Resp(10, 10))
    orbitModeBtn:SetSize(ComComp.Resp(25, 20))
    orbitModeBtn.Paint = function(self, w, h)
        surface.SetDrawColor(self:IsHovered() and color_white or color_black)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("R", "ComComp16", w/2, h/2, self:IsHovered() and color_black or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local testBtn = view:Add("Panel")
    testBtn:SetPos(ComComp.RespX(15) + orbitModeBtn:GetWide(), ComComp.RespY(10))
    testBtn:SetSize(ComComp.Resp(100, 20))
    testBtn.Paint = function(self, w, h)
        surface.SetDrawColor(self:IsHovered() and color_white or color_black)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText(L("slicer_config_simulate"), "ComComp16", w/2, h/2, self:IsHovered() and color_black or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local options = c:Add("Panel")
    options:Dock(RIGHT)
    options:SetVisible(false)
    options:DockPadding(ComComp.RespX(8), ComComp.RespY(8), ComComp.RespX(8), ComComp.RespY(8))
    options:SetWide(ComComp.RespX(220))
    options.AddOption = function(self, name, isWang)
        local cp = options:Add("Panel")
        cp:Dock(TOP)
        cp:DockMargin(0, ComComp.RespY(4), 0, 0)

        local label = cp:Add("DLabel")
        label:SetFont("ComComp14")
        label:SetTextColor(color_white)
        label:Dock(LEFT)
        label:SetText(name .. " :")
        label:SetWide(options:GetWide() * 0.35)

        local opt = cp:Add(isWang and "ComCompNumberWang" or "ComCompTextEntry")
        opt:Dock(FILL)

        return opt, label
    end

    local left = c:Add("Panel")
    left:Dock(LEFT)
    left:SetWide(ComComp.RespX(128))

    local list = left:Add("ComCompScrollPanel")
    list:Dock(FILL)
    list:SetDark(true)
    list.AddBtn = function(self, name)
        local btn = list:Add("Panel")
        btn:Dock(TOP)
        btn:SetTall(ComComp.RespY(24))
        btn.Text = name
        btn.Paint = function(self, w, h)
            if self:IsHovered() then
                surface.SetDrawColor(255, 255, 255)
                surface.DrawRect(0, 0, w, h)
            end
            draw.SimpleText(self.Text, "ComComp16", w/2, h/2, self:IsHovered() and color_black or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        return btn
    end
    list.AddConfig = function(self, struct)
        struct = struct or {}

        local name = struct.name or L("slicer_config_unnamed")
        local btn = self:AddBtn(name)
        -- NOTE Base Struct here
        btn.Struct = {
            name = name,
            model = struct.model or "models/hunter/blocks/cube025x025x025.mdl",
            class = struct.class or "prop_physics", 
            skin = struct.skin or 1,
            scale = struct.scale or 1,
            posOffset = struct.posOffset or Vector(0, 0, 14.1),
            angOffset = struct.angOffset or Angle(),
            printDur = struct.printDur or 18,
            price = struct.price or 650,
            speed = struct.speed or 1
        }
        btn.ent = NULL
        btn.OnMousePressed = function(self)
            options:Clear()
            options:SetVisible(true)
            
            resetPrinterAnim()

            local gizmo = ComComp.NewGizmo()
            gizmo:SetRadius(14)
            gizmo:SetThickness(0.35)
            gizmo.OnAnglesChange = function(_, ang)
                self.Struct.angOffset = printerEnt:WorldToLocalAngles(ang)
                self.ent:SetAngles(ang)
            end
            gizmo.OnVectorChange = function(_, pos)
                self.Struct.posOffset = printerEnt:WorldToLocal(pos)
                self.ent:SetPos(pos)
            end

            orbitModeBtn.OnMousePressed = function(_)
                gizmo:SetEditingPos(not gizmo:GetEditingPos())
            end

            testBtn.OnMousePressed = function()
                printerEnt:SetSequence(printSeq)
                printerEnt:SetPlaybackRate(self.Struct.speed)
                printerEnt:SetCycle(0)

                local maxDur = self.Struct.printDur
                local elapsed = 0
                
                local seqDur = printSeqDur * 1/printerEnt:GetPlaybackRate()
                hook.Add("Think", printerEnt, function()
                    if elapsed >= maxDur then
                        resetPrinterAnim()
                        return
                    end

                    local dt = FrameTime()
                    elapsed = elapsed + dt

                    printerEnt:SetCycle((seqDur * printerEnt:GetCycle() + dt)/seqDur)
                end)
            end

            local function InitEnt()
                if IsValid(self.ent) then
                    self.ent:Remove()
                end

                self.ent = ents.CreateClientProp()
                self.ent:SetModel(self.Struct.model)
                self.ent:SetNoDraw(true)
                self.ent:SetPos(self.Struct.posOffset)
                self.ent:SetAngles(self.Struct.angOffset)
                self.ent:SetModelScale(self.Struct.scale)
                self.ent:Spawn()

                gizmo:SetPos(self.ent:GetPos())
                gizmo:SetAngles(self.ent:GetAngles())
            end
            InitEnt()

            local bOffset = Vector(1.959017, 0.000019, 8.771914)
            view:SetDrawFnc(function()
                render.SuppressEngineLighting(true)
                render.SetLightingOrigin(vector_origin)
                render.ResetModelLighting(0.2, 0.2, 0.2)
                render.SetColorModulation(1, 1, 1)
                render.SetBlend(1)
                render.SetModelLighting(BOX_TOP, 1, 1, 1)
                render.SetModelLighting(BOX_FRONT, 1, 1, 1)

                baseDrawFnc()

                if printerEnt:GetCycle() >= 0.12 or printerEnt:GetSequence() ~= printSeq then
                    local bone = printerEnt:LookupBone("plateau")
                    if bone then
                        local bMatrix = printerEnt:GetBoneMatrix(bone)
                        if bMatrix then
                            local eAng = printerEnt:GetAngles()
                            local ePos = printerEnt:GetPos()

                            local normal = -eAng:Up()
                            local dot = normal:Dot(ePos + eAng:Up() * 20.85)

                            local oldEC = render.EnableClipping(true)
                            render.PushCustomClipPlane(normal, dot)

                            if IsValid(self.ent) then
                                local sMatrix = Matrix()
                                sMatrix:SetTranslation(self.Struct.posOffset - bOffset)
                                sMatrix:SetAngles(self.Struct.angOffset)

                                local wMatrix = Matrix()
                                wMatrix:SetTranslation(bMatrix:GetTranslation())
                                wMatrix:SetAngles(printerEnt:GetAngles()) -- Not using the bone angles here because I want simplicity.

                                local fMatrix = wMatrix * sMatrix

                                self.ent:SetPos(fMatrix:GetTranslation())
                                self.ent:SetAngles(fMatrix:GetAngles())
                                self.ent:SetupBones()
                                self.ent:DrawModel()
                            end

                            render.PopCustomClipPlane()
                            render.EnableClipping(oldEC)
                        end
                    end
                end
        
                local x, y = view:ScreenToLocal(gui.MouseX(), gui.MouseY())
                local w, h = view:GetWide(), view:GetTall()
                local dir = util.AimVector(view:Get3DAngles(), view:Get3DFOV(), x, y, w, h):GetNormalized()
                gizmo:Draw(view:Get3DPos(), dir)

                render.SuppressEngineLighting(false)
            end)

            local nameEntry = options:AddOption(L("slicer_config_name"))
            nameEntry:SetValue(self.Struct.name)
            nameEntry.OnChange = function()
                self.Struct.name = nameEntry:GetText()
                btn.Text = self.Struct.name
            end

            local classEntry = options:AddOption(L("slicer_config_class"))
            classEntry:SetValue(self.Struct.class)
            classEntry.OnChange = function()
                self.Struct.class = classEntry:GetText()
                btn.Text = self.Struct.class
            end

            local skinEntry = options:AddOption(L("slicer_config_skin"), true)
            skinEntry:SetValue(self.Struct.skin)
            skinEntry.OnValueChanged = function(_, v)
                self.Struct.skin = v 
                self.ent:SetSkin(v)
            end

            local modelEntry = options:AddOption(L("slicer_config_modelpath"))
            modelEntry:SetValue(self.Struct.model)
            modelEntry.OnEnter = function(_, value)
                self.Struct.model = string.Trim(value)
                InitEnt()
            end

            local scaleEntry = options:AddOption(L("slicer_config_scale"), true)
            scaleEntry:SetDecimals(3)
            scaleEntry:SetInterval(0.05)
            scaleEntry:SetMinMax(0.05, math.huge)
            scaleEntry:SetValue(self.Struct.scale)
            scaleEntry.OnValueChanged = function(_, v)
                self.Struct.scale = v 
                self.ent:SetModelScale(v)
            end

            local durEntry = options:AddOption(L("slicer_config_duration"), true)
            durEntry:SetDecimals(3)
            durEntry:SetInterval(0.5)
            durEntry:SetMinMax(0, math.huge)
            durEntry:SetValue(self.Struct.printDur)
            durEntry.OnValueChanged = function(_, v)
                self.Struct.printDur = v
            end

            local speedEntry = options:AddOption(L("slicer_config_speed"), true)
            speedEntry:SetDecimals(3)
            speedEntry:SetInterval(0.1)
            speedEntry:SetMinMax(0.1, math.huge)
            speedEntry:SetValue(self.Struct.speed)
            speedEntry.OnValueChanged = function(_, v)
                self.Struct.speed = v
            end

            local priceEntry = options:AddOption(L("slicer_config_price"), true)
            priceEntry:SetDecimals(1)
            priceEntry:SetInterval(10)
            priceEntry:SetMinMax(0, math.huge)
            priceEntry:SetValue(self.Struct.price)
            priceEntry.OnValueChanged = function(_, v)
                self.Struct.price = v
            end

            local remBtn = list:AddBtn(L("remove"))
            remBtn:SetParent(options)
            remBtn:Dock(BOTTOM)
            remBtn.OnMousePressed = function(self)
                btn:Remove()
                view:SetDrawFnc(baseDrawFnc)
                options:SetVisible(false)
            end
        end
        btn.OnRemove = function(self)
            if IsValid(self.ent) then
                self.ent:Remove()
            end
        end
    end

    local newBtn = list:AddBtn(L("add"))
    newBtn:DockMargin(0, ComComp.RespY(8), 0, 0)
    newBtn:SetParent(left)
    newBtn.OnMousePressed = function()
        list:AddConfig()
    end

    local finishBtn = list:AddBtn(L("slicer_config_finish"))
    finishBtn:DockMargin(0, 0, 0, ComComp.RespY(8))
    finishBtn:SetParent(left)
    finishBtn:Dock(BOTTOM)
    finishBtn.OnMousePressed = function()
        local children = list:GetCanvas():GetChildren()
        local data = {}
        for k, v in ipairs(children) do
            if v.Struct then
                table.insert(data, v.Struct)
            end
        end

        data = util.TableToJSON(data)
        data = util.Compress(data)

        net.Start("ComCompSlicerData")
        net.WriteData(data, #data)
        net.SendToServer()

        frame:Remove()
    end

    local editingConfig = ComComp.TableCopy(APP:GetConfig())
    for _, v in ipairs(editingConfig) do
        list:AddConfig(v)
    end
end

--[[
    Networking
]]
net.Receive("ComCompSlicerData", function(len)
    local data = net.ReadData(len/8)
    data = util.Decompress(data)
    data = util.JSONToTable(data)
    
    if data then
        APP:SetConfig(data)
    end
end)

