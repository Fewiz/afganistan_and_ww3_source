--[[
addons/common_computer/lua/common_computer/applications/slicer/igconfig/shared.lua
--]]
local APP = APP

hook.Add("CC:ConfigTool:Setup", "CC:Slicer:Config", function(settings)
    local slicerSet = settings:New("3D Printing")

    function slicerSet:Run(tool, tr)
        if CLIENT then
            APP:OpenIGConfig()
        end
    end
end)


function APP:SetConfig(t)
	ComComp.Cfg["slicer"]["list"] = t
end

function APP:GetConfig()
	return ComComp.Cfg["slicer"]["list"] or {}
end

