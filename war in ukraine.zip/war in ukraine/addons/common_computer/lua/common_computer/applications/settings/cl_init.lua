--[[
addons/common_computer/lua/common_computer/applications/settings/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP
local settingsMat = Material("common_computer/settings.png")
local colorLightGray = Color(215, 215, 220)
local colorDark = Color(85, 85, 85)

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("settings", settingsMat, function()
		local app = self:GetComputer():RetrieveApp(APP.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	local frame = appArea:NewFrame()
	frame:SetIcon(settingsMat)
	frame:SetTitle(L("settings"))
	frame:SetSize(ComComp.Resp(650, 450))
	frame:Center()
	frame.OnClose = function()
		self:Close() -- Link with the app
	end
	frame.OnReduce = function()
		self:Pause()
	end
	frame.icon:SetVisible(false)
	self.frame = frame
	
	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
	end

	local sheet = c:Add("DColumnSheet")
	sheet:Dock(FILL)
	sheet.Navigation:SetWidth(ComComp.RespX(155))
	sheet.Navigation:DockMargin(0, 0, 0, 0)
	sheet.Navigation.Paint = function(_, w, h)
		surface.SetDrawColor(colorLightGray)
		surface.DrawRect(0, 0, w, h)
	end

	local oldP = frame.header.Paint
	frame.header.Paint = function(self, w, h)
		oldP(self, w, h)
		surface.SetDrawColor(colorLightGray)
		surface.DrawRect(0, 0, sheet.Navigation:GetWide(), h)
	end


	local stylePanel = vgui.Create("ComCompScrollPanel")
	stylePanel:Dock(FILL)
	sheet:AddSheet(L("settings_appearance"), stylePanel)

	local label = stylePanel:Add("DLabel")
	label:SetText(L("settings_wallpaper"))
	label:SetFont("ComComp20")
	label.PaintOver = function(_, w, h)
		surface.SetDrawColor(85, 85, 85)
		surface.DrawLine(0, h-1, w/4, h-1)
	end
	label:DockMargin(ComComp.RespX(30), 0, 0, ComComp.RespY(8))
	label:Dock(TOP)
	label:SetTextColor(colorDark)
	label:SizeToContentsY()

	local wallpaper = stylePanel:Add("Panel")
	wallpaper:Dock(TOP)
	wallpaper:SetTall(ComComp.RespY(180))
	wallpaper.index = 1
	wallpaper:DockMargin(0, 0, 0, ComComp.RespY(25))
	wallpaper.PerformLayout = function()
		wallpaper:SetTall(frame:GetTall() * 0.4)
	end

		local matList = {}
		for k, v in ipairs(ComComp.Cfg["settings"]["default_wallpapers"]) do
			matList[#matList + 1] = {
				mat = Material(v),
				path = v
			}
		end
		local back = wallpaper:Add("Panel")
		back:Dock(LEFT)
		back.Paint = function(self, w, h)
			draw.SimpleText("<", self:IsHovered() and "ComComp16Bold" or "ComComp16", w/2, h/2, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		back.OnMousePressed = function()
			wallpaper.index = wallpaper.index - 1
			if wallpaper.index == 0 then
				wallpaper.index = #matList
			end
			local matT = matList[wallpaper.index]
			if matT then
				ComComp.ClientData:Set("WallpaperPath", matT.path)
			end
		end

		local fill = wallpaper:Add("Panel")
		fill:Dock(FILL)
		fill.Paint = function(self, w, h)
			local matT = matList[wallpaper.index]
			if not matT then return end

			local wT = h/9*16
			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(matT.mat)
			surface.DrawTexturedRect(w/2 - wT/2, 0, wT, h)
		end

		local next = wallpaper:Add("Panel")
		next:Dock(RIGHT)
		next.Paint = function(self, w, h)
			draw.SimpleText(">", self:IsHovered() and "ComComp16Bold" or "ComComp16", w/2, h/2, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		next.OnMousePressed = function()
			wallpaper.index = wallpaper.index + 1
			if wallpaper.index == #matList + 1 then
				wallpaper.index = 1
			end
			local matT = matList[wallpaper.index]
			if matT then
				ComComp.ClientData:Set("WallpaperPath", matT.path)
			end
		end

	local label = stylePanel:Add("DLabel")
	label:SetText(L("color"))
	label:SetFont("ComComp20")
	label:Dock(TOP)
	label:SetTextColor(colorDark)
	label:DockMargin(ComComp.RespX(30), 0, 0, ComComp.RespY(8))
	label.PaintOver = function(_, w, h)
		surface.SetDrawColor(85, 85, 85)
		surface.DrawLine(0, h-1, w/4, h-1)
	end
	label:SizeToContentsY()

	local co = stylePanel:Add("Panel")
	co:Dock(TOP)

	local colorPicker = co:Add("DColorMixer")
	colorPicker:SetWangs(false)
	colorPicker:SetAlphaBar(false)
	colorPicker:SetPalette(false)
	colorPicker:SetTall(ComComp.RespY(180))
	colorPicker.ValueChanged = function(_, color)
		ComComp.ClientData:Set("Color", Color(color.r, color.g, color.b))
	end
	fill.PerformLayout = function(_, w, h)
		co:SetTall(h)
		colorPicker:SetSize(h/9*16, h)
		colorPicker:SetPos(co:GetWide()/2 - colorPicker:GetWide()/2, 0)
	end

	-- Editing the style
	for k, v in ipairs(sheet.Items) do
		local btn = v.Button
		local text = btn:GetText()
		btn:SetText("")
		btn:DockMargin(0, 0, 0, 0)
		btn:SetCursor("arrow")
		btn:SetTall(ComComp.RespY(24))
		btn:SetFont("ComComp16")
		btn.Paint = function(_, w, h)
			if btn:IsHovered() then
				surface.SetDrawColor(0, 0, 0, 20)
				surface.DrawRect(0, 0, w, h)
			end

			if sheet.ActiveButton == btn then
				surface.SetDrawColor(ComComp.ClientData:Get("Color"))
				surface.DrawRect(0, h/12, w/32, h - h/12*2)
			end
			
			draw.SimpleText(text, "ComComp14", w/2, h/2, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("settings")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end

	self.frame:SetVisible(true)
end

hook.Add("CC:StartMenuCreated", "CC:Settings:Icon", function(startMenu)
	startMenu:AddSideButton(settingsMat, L("settings"), "ComComp16", function()
		local set = ComComp.Apps:Instantiate(APP.Id, startMenu:GetParent():GetComputerInstance())
		set:Open()
		startMenu:Close()
	end)
end)

