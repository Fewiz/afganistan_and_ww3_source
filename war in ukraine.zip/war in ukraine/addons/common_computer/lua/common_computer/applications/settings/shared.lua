--[[
addons/common_computer/lua/common_computer/applications/settings/shared.lua
--]]
ComComp.Include(APP.Path .. "sh_config.lua")


