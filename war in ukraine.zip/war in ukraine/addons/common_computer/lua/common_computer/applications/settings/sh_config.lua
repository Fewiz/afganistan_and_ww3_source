--[[
addons/common_computer/lua/common_computer/applications/settings/sh_config.lua
--]]
ComComp.Cfg["settings"] = {}

ComComp.Cfg["settings"]["default_wallpapers"] = {
    "common_computer/wallpapers/common_computer.jpg",
}

