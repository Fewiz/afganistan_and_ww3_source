--[[
addons/common_computer/lua/common_computer/applications/filebrowser/cl_init.lua
--]]
local APP = APP
local L = ComComp.GetLang
local RespX = ComComp.RespX
local RespY = ComComp.RespY

local recycleMat = Material("common_computer/recyclebin.png")
local explorerMat = Material("common_computer/explorer.png")
local gmodMat = Material("common_computer/gmod.png")
local logoIconMat = Material("common_computer/logo_icon.png")
local folderMat = Material("common_computer/folder.png")
local fileMat = Material("common_computer/file.png")

local grayColor = Color(220, 220, 220)
local hovMatColor = Color(133, 200, 255)
local darkGrayColor = Color(100, 100, 100)

--[[
	The explorer is in Open Mode by default
]]
function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	local appArea = mainFrame:GetAppArea()
	
	taskBar:AddIcon("filebrowser", explorerMat, function()
		local app = self:GetComputer():RetrieveApp(APP.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	local frame = appArea:NewFrame()
	frame:SetIcon(explorerMat)
	frame:SetTitle(L("explorer"))
	frame:SetSize(ComComp.Resp(500, 390))
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	frame:Center()

	self.frame = frame
	
	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
	end

	-- Header
	local pathDraw = c:Add("Panel")
	pathDraw:Dock(TOP)

	local backArrow = pathDraw:Add("Panel")
	backArrow:Dock(LEFT)
	backArrow:DockMargin(0, 0, RespX(5), 0)
	backArrow.Paint = function(self, w, h)
		draw.SimpleText("←", "ComComp14", w/2, h/2 - RespY(14 + 4)/2, self:IsHovered() and hovMatColor or darkGrayColor)
	end
	backArrow.OnMousePressed = function()
		local ta = string.Split(self.BrowserPath, '/')
		ta[#ta] = nil
		ta[#ta] = nil
		
		local newPath = ""
		for k, v in ipairs(ta) do
			newPath = newPath .. v .. "/"
		end
		
		self:OpenPath(newPath)
	end
	
	local nextArrow = pathDraw:Add("Panel")
	nextArrow:Dock(LEFT)
	nextArrow.Paint = function(self, w, h)
		draw.SimpleText("→", "ComComp14", w/2, h/2 - RespY(14 + 4)/2, self:IsHovered() and hovMatColor or darkGrayColor)
	end
	
	pathDraw.PerformLayout = function(self, w, h)
		backArrow:SetWide(h)
		nextArrow:SetWide(h)
	end
	
	pathDraw.Paint = function(_, w, h)
		surface.SetDrawColor(grayColor)
		surface.DrawLine(0, 0, w, 0)
		surface.DrawLine(0, h - 1, w, h - 1)
		
		local x, y = nextArrow:GetPos()
		x = x + nextArrow:GetWide() + RespX(10)
		draw.SimpleText(self.BrowserPath, "ComComp14", x, h/2 - RespY(14)/2, darkGrayColor)
	end
	
	-- Divider that allows us to change the size of sidemenu/list
	local div = c:Add("DHorizontalDivider")
	div:Dock(FILL)
	div:SetDividerWidth(2) 
	div:SetLeftMin(RespX(40))
	div:SetRightMin(RespX(100))
	div:SetLeftWidth(RespX(150))
	
	-- Side menu
	local side = div:Add("ComCompScrollPanel")
	side.Paint = function(self, w, h)
		surface.SetDrawColor(grayColor)
		surface.DrawLine(w - 1, 0, w - 1, h)
	end
	self.side = side

	-- List of files
	local fill = div:Add("ComCompScrollPanel")
	self.fill = fill

	div:SetLeft(side)
	div:SetRight(fill)
	
	side.AddPath = function(_, mat, name, path)
		local panel = self:NewListComponent(side, mat, name)
		panel.DoClick = function()
			self:OpenPath(path)
			panel:SetFileSelected(false)
		end
	end
	
	fill.AddFolder = function(_, folder, path)
		local panel = self:NewListComponent(fill, folderMat, folder)
		panel.OnFileSelect = function()
			if self:IsOpenMode() and self.OpenPanel.AllowFolder then
				self.OpenPanel.Entry:SelectPath(path)
			end
		end
		panel.DoDoubleClick = function()
			self:OpenPath(path)
		end
		panel.DoRightClick = function()
			self:BuildRightClickMenu(path, true):Open()
		end
	end
	
	fill.AddFile = function(_, file, path)
		local panel = self:NewListComponent(fill, fileMat, file)
		panel.OnFileSelect = function()
			if self:IsOpenMode() then
				self.OpenPanel.Entry:SelectPath(self:GetBrowserPath(), file)
			end
		end
		panel.DoDoubleClick = function()
			if self:IsOpenMode() then
				if self.OpenPanel:RunCallback() ~= false then
					self:Close()
				end
			else
				hook.Run("CC:Explorer:OpenFile", path, self:GetComputer())
			end
		end
		panel.DoRightClick = function()
			self:BuildRightClickMenu(path, false):Open()
		end
	end
	
	-- Default values
	side:AddPath(gmodMat, "Garry's Mod", "")
	side:AddPath(logoIconMat, "Common Computer", "garrysmod/data/common_computer/")

	self:SetRoot("")
	self:OpenPath("")
	self:SetSaveMode(false)
	self:SetOpenMode(false)
end

--[[
	Set the explorer as save move, so we can ask the user to select a path that we can retrieve on the callback
]]
function APP:SetSaveMode(status, callback)
	self.SaveMode = status

	if IsValid(self.SavePanel) then
		self.SavePanel:Remove()
	end

	if not status then return end

	if self:IsOpenMode() then
		self:SetOpenMode(false)
	end

	local savePanel = self.frame:Add("Panel")
	savePanel:Dock(BOTTOM)
	savePanel:SetTall(RespY(60 + 4))
	savePanel.Paint = function(self, w, h)
		surface.SetDrawColor(230, 230, 230)
		surface.DrawRect(0, 0, w, h)
	end
	self.SavePanel = savePanel

	local cTop = savePanel:Add("Panel")
	cTop:Dock(TOP)
	cTop:DockMargin(0, RespY(4), 0, 0)

	local nameLabel = cTop:Add("DLabel")
	nameLabel:SetText(L("explorer_filename"))
	nameLabel:SetFont("ComComp16")
	nameLabel:Dock(LEFT)
	nameLabel:SetContentAlignment(6)
	nameLabel:SetTextColor(color_black)
	nameLabel:DockMargin(0, 0, RespX(5), 0)
	nameLabel:SetWide(RespX(135))

	local textEntry = cTop:Add("ComCompTextEntry")
	textEntry:Dock(FILL)
	textEntry:DockMargin(0, 0, RespX(5), 0)
	savePanel.Entry = textEntry

	local cancelBtn = savePanel:Add("ComCompButton")
	cancelBtn:Dock(RIGHT)
	cancelBtn:DockMargin(RespX(5), RespY(7), RespX(12), RespY(7))
	cancelBtn:SetText(L("cancel"))
	cancelBtn:SizeToContentsX(RespX(15))
	cancelBtn.DoClick = function()
		self:Close()
	end

	-- Close the app + call the callback with the path as parameter
	local saveBtn = savePanel:Add("ComCompButton")
	saveBtn:Dock(RIGHT)
	saveBtn:DockMargin(RespX(5), RespY(7), RespX(5), RespY(7))
	saveBtn:SetText(L("save"))
	saveBtn:SizeToContentsX(RespX(15))
	saveBtn.DoClick = function()
		local fileName = string.Trim(textEntry:GetValue())
		if callback and #fileName ~= 0 then
			if callback(self:GetRoot() .. self:GetBrowserPath() .. fileName) ~= false then
				self:Close()
			end
		end
	end
end

--[[
	Set the explorer to open mode
]]
function APP:SetOpenMode(status, callback, allowFolder)
	self.OpenMode = status

	if IsValid(self.OpenPanel) then
		self.OpenPanel:Remove()
	end

	if not status then return end

	if self:IsSaveMode() then
		self:SetSaveMode(false)
	end

	local openPanel = self.frame:Add("Panel")
	openPanel:Dock(BOTTOM)
	openPanel:SetTall(RespY(60 + 4))
	openPanel.Paint = function(self, w, h)
		surface.SetDrawColor(230, 230, 230)
		surface.DrawRect(0, 0, w, h)
	end
	openPanel.AllowFolder = allowFolder
	self.OpenPanel = openPanel

	local cTop = openPanel:Add("Panel")
	cTop:Dock(TOP)
	cTop:DockMargin(0, RespY(4), 0, 0)

	local nameLabel = cTop:Add("DLabel")
	nameLabel:SetText(L("explorer_filename"))
	nameLabel:SetFont("ComComp16")
	nameLabel:Dock(LEFT)
	nameLabel:SetContentAlignment(6)
	nameLabel:SetTextColor(color_black)
	nameLabel:DockMargin(0, 0, RespX(5), 0)
	nameLabel:SetWide(RespX(135))

	local textEntry = cTop:Add("ComCompTextEntry")
	textEntry:Dock(FILL)
	textEntry:SetEditable(false)
	textEntry:DockMargin(0, 0, RespX(5), 0)
	textEntry.SelectPath = function(self, path, file)
		local cPath = path .. (file and file or "")
		self:SetText(cPath)
		textEntry.Path = cPath
	end
	openPanel.Entry = textEntry

	openPanel.RunCallback = function()
		if not textEntry.Path then return false end -- the player hasn't selected anything yet
		return callback(self:GetRoot() .. textEntry.Path)
	end

	local cancelBtn = openPanel:Add("ComCompButton")
	cancelBtn:Dock(RIGHT)
	cancelBtn:DockMargin(RespX(5), RespY(7), RespX(12), RespY(7))
	cancelBtn:SetText(L("cancel"))
	cancelBtn:SizeToContentsX(RespX(15))
	cancelBtn.DoClick = function()
		self:Close()
	end

	local openBtn = openPanel:Add("ComCompButton")
	openBtn:Dock(RIGHT)
	openBtn:DockMargin(RespX(5), RespY(7), RespX(5), RespY(7))
	openBtn:SetText(L("open"))
	openBtn:SizeToContentsX(RespX(15))
	openBtn.DoClick = function()
		if openPanel:RunCallback() ~= false then
			self:Close()
		end
	end
end

--[[
	Open the specified path and update the explorer
]]
function APP:OpenPath(path)
	if (not file.Exists(self:GetRoot() .. path, "BASE_PATH")) then return end

	if not IsValid(self.frame) then
		self:Open()
	end
	
	self.BrowserPath = path
	self.fill:Clear()

	local files, directories = file.Find(self:GetRoot() .. path .. "*", "BASE_PATH")
	for k, v in ipairs(directories) do
		self.fill:AddFolder(v, path .. v .. "/")
	end
	
	for k, v in ipairs(files) do
		self.fill:AddFile(v, path .. v)
	end
end

function APP:GetRoot()
	return self.RootPath
end

--[[
	Create the derma for a file/folder in the list (Called by fill.AddFile, fill.AddFolder & side.AddPath)
]]
function APP:NewListComponent(parent, mat, text)
	local panel = vgui.Create("DLabel", parent) -- Use DLabel to have DoubleClick
	panel:SetPaintBackground(true)
	panel:SetMouseInputEnabled(true)
	panel:SetKeyboardInputEnabled(true)
	panel:SetText("")
	panel:Dock(TOP)
	panel:SetTall(RespY(20))
	panel.Paint = function(self, w, h)
		if self:IsFileSelected() then
			surface.SetDrawColor(115, 185, 255, 110)
			surface.DrawRect(0, 0, w, h)

			surface.SetDrawColor(110, 180, 255, 255)
			surface.DrawOutlinedRect(0, 0, w, h)
		elseif self:IsHovered() then
			surface.SetDrawColor(133, 200, 255, 90)
			surface.DrawRect(0, 0, w, h)
		end
	
		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(mat)
		local off = h/6
		surface.DrawTexturedRect(off, off, h - off*2, h - off*2)
		
		draw.SimpleText(text, "ComComp14", h, h/2 - RespY(14)/2, color_black)
	end
	panel.OnFileSelect = function() end
	panel.OnFileSelectInternal = function() end
	panel.IsFileSelected = function(self)
		return self.FileSelected
	end
	panel.SetFileSelected = function(self, status)
		self.FileSelected = status
		if status then
			for k, v in ipairs(self:GetParent():GetChildren()) do
				if v == self then goto con end
				if v:IsFileSelected() then
					v:SetFileSelected(false)
				end

				::con::
			end

			self:OnFileSelect()
			self:OnFileSelectInternal()
		end
	end
	panel.DoClickInternal = function(self)
		if not self:IsFileSelected() then
			self:SetFileSelected(true)
		end
	end

	return panel
end

-- Build a Menu and run a hook to allow all applications to do specific action with the selected file
function APP:BuildRightClickMenu(path, isFolder, computer)
	local menu = DermaMenu() 
	hook.Run("CC:Explorer:BuildRightMenu", menu, path, isFolder, self:GetComputer())
	return menu
end

--[[
	Restrict the explorer at a specific path
]]
function APP:SetRoot(root)
	self.RootPath = root
	self:OpenPath("")
end

function APP:Close()
	local taskBar = self:GetComputer():GetMainFrame():GetTaskBar()
	taskBar:DecreaseIcon("filebrowser")
	
	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:IsSaveMode()
	return self.SaveMode
end

function APP:IsOpenMode()
	return self.OpenMode
end

function APP:GetBrowserPath()
	return self.BrowserPath
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:Explorer:Icon", function(computerFrame)
	computerFrame:AddDesktopIcon("explorer", explorerMat, L("explorer"), 0, 1, function()
		local explorer = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		explorer:Open()
	end)
	
	computerFrame:AddDesktopIcon("recyclebin", recycleMat, L("recyclebin"), 0, 0, function()
		local explorer = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		explorer:Open()
	end)
end)

hook.Add("CC:Explorer:BuildRightMenu", "CC:Explorer:DefaultMenu", function(menu, path, isFolder, computer)
	if isFolder then return end

	local ext = string.GetExtensionFromFilename(path)
	if ComComp.IsImageExtension(ext) then 
		menu:AddOption(L("explorer_setaswallpaper"), function()
			ComComp.ClientData:Set("WallpaperPath", "../" .. path)
		end)
	end
end)

