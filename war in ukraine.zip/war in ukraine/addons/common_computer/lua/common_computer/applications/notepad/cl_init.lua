--[[
addons/common_computer/lua/common_computer/applications/notepad/cl_init.lua
--]]
file.CreateDir("common_computer/notepad")

local L = ComComp.GetLang
local APP = APP

local notepadMat = Material("common_computer/notepad.png")

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()

	taskBar:AddIcon("notepad", notepadMat, function() -- Add the icon to the taskbar
		local app = self:GetComputer():RetrieveApp(APP.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	-- Creating the new frame
	local frame = appArea:NewFrame()
	frame:SetIcon(notepadMat)
	frame:SetTitle(L("notepad"))
	frame:SetSize(ComComp.Resp(360, 475))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	local editor = frame:Add("ComCompTextEntry")
	editor:Dock(FILL)
	editor:SetBorders(false)
	editor:SetMultiline(true)
	self.editor = editor

	-- Top menu
	local menu = frame:Add("ComCompMenuBar")
	menu:Dock(TOP)
	menu:SetTall(ComComp.RespY(24))

	local fileMenu = menu:AddMenu(L("file"))

	-- New file
	fileMenu:AddOption(L("new"), function()
		editor:SetText("")
	end):SetIcon("icon16/page_white.png")

	-- Load a file
	fileMenu:AddOption(L("open"), function()
		local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
		if not explorer then
			ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), frame)
			return
		end
		explorer:Open()
		explorer:SetOpenMode(true, function(path)
			if not ComComp.IsTextExtension(string.GetExtensionFromFilename(path)) then
				return
			end

			self:OpenFile(string.Replace(path, "garrysmod/", ""))
		end)
	end):SetIcon("icon16/folder.png")

	-- Save the current file
	fileMenu:AddOption(L("save"), function()
		local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
		if not explorer then
			ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), self.frame)
			return
		end
		explorer:Open()
		explorer:SetRoot("garrysmod/data/")
		explorer:SetSaveMode(true, function(path)
			local f = file.Open(string.sub(path, #explorer:GetRoot() + 1) .. ".txt", "wb", "DATA")
			if f then
				f:Write(editor:GetText())
				f:Close()
			end
		end)
	end):SetIcon("icon16/disk.png")
end

function APP:OpenFile(path)
	local data = file.Read(path, "GAME")
	if data then
		self.editor:SetText(data)
	end
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("notepad")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:Explorer:BuildRightMenu", "CC:Notepad:EditMenu", function(menu, path, isFolder, computer)
	if isFolder then return end

	local ext = string.GetExtensionFromFilename(path)
	if ComComp.IsTextExtension(ext) and not ComComp.IsAppDisabled("notepad") then
		menu:AddOption(L("explorer_editwithnotepad"), function()
			local notepad = ComComp.Apps:Instantiate("notepad", computer)
			notepad:Open()
			notepad:OpenFile(string.Replace(path, "garrysmod/", ""))
		end)
	end
end)

hook.Add("CC:DesktopCreated", "CC:Notepad::Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("notepad", notepadMat, L("notepad"), 0, 3, function()
		local notepad = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		notepad:Open()
	end)
end)

