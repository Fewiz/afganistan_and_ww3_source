--[[
addons/common_computer/lua/common_computer/applications/gcord/cl_app.lua
--]]
--[[ 
	Only one instance of this APP can be executed !
	Mostly because of the net.Receive being recalled each time the app is built
	So I designed the app in this way.
]]

local APP = APP
local L = ComComp.GetLang
local RespX = ComComp.RespX
local RespY = ComComp.RespY
local Resp = ComComp.Resp

-- Render Target for the camera
local camRT = GetRenderTarget("ComCompGCordCam", 1024, 1024, false)
local camMat = CreateMaterial("ComCompGCordCam", "UnlitGeneric",{
	["$basetexture"] = camRT:GetName()
})

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("gcord")
	
	local frame = self:NewFrame()
	
	-- Main Container
	local c = frame:Add("Panel")
	c:Dock(FILL)

	-- ::START:: ServerList
	local serverList = c:Add("Panel")
	serverList:Dock(LEFT)
	serverList:SetWide(RespX(48))
	serverList.AddBtn = function(self, mat, doclick)
		local btn = serverList:Add("Panel")
		btn:Dock(TOP)
		btn:SetTall(serverList:GetWide())
		local offX, offY = Resp(2, 2)
		btn:DockMargin(offX, offY, offX, offY)
		btn.Paint = function(self, w, h)
			APP:CircleMask(function()
				surface.SetDrawColor(255, 255, 255)
				surface.SetMaterial(mat)
				surface.DrawTexturedRect(0, 0, w, h)
			end, w/2, h/2, self:IsHovered() and w/2 or w/2.1)
		end
		if doclick then
			btn.OnMousePressed = doclick
		end
		return btn
	end
	serverList:AddBtn(APP.GCordMat)
	self.serverList = serverList
	-- ::END:: ServerList
	
	-- Variables used to get the selected user from the userlist (Set in the doclick fnc)
	local CurSteamId64, CurPly

	local main = c:Add("Panel") -- Just a container (Includes messaging)
	main:Dock(FILL)

	local messaging = main:Add("Panel") -- Container (Includes textEntry, chat history & userHeader)
	messaging:Dock(FILL)
	messaging.Paint = function(self, w, h)
		surface.SetDrawColor(APP.MessagingColor:Unpack())
		surface.DrawRect(0, 0, w, h)
	end
	self.messaging = messaging

	-- ::START:: UserHeader
	local userHeader = messaging:Add("Panel")
	local headerMinTall = RespY(36)
	userHeader:Dock(TOP)
	userHeader:SetTall(headerMinTall)

	local header = userHeader:Add("Panel")
	header:Dock(TOP)
	header:SetTall(headerMinTall)
	header.Paint = function(self, w, h)
		draw.SimpleText(IsValid(CurPly) and CurPly:Name() or L("gcord_invaliduser"), "ComComp16Bold", RespX(10), h/2, nil, nil, TEXT_ALIGN_CENTER)
	end
	header.AddBtn = function(self, mat, doclick)
		local btn = header:Add("Panel")
		btn:Dock(RIGHT)
		btn:SetCursor("hand")
		local offX, offY = Resp(6, 6)
		btn:DockMargin(offX, offY, offX, offY)
		btn.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and color_white or APP.TextColor)
			surface.SetMaterial(mat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		btn.PerformLayout = function(self, w, h)
			self:SetWide(h)
		end
		if doclick then
			btn.OnMousePressed = doclick
		end
		return btn
	end
	userHeader.Paint = function(self, w, h)
		if self.CallId then
			surface.SetDrawColor(APP.InCallColor:Unpack())
			surface.DrawRect(0, 0, w, h)

			-- Draw the camera here because we have more space !
			if IsValid(self.callContainer) and IsValid(self.callContainer.answeredPanel) then
				local camWidth = h * (ScrW()/ScrH())
		
				surface.SetDrawColor(255, 255, 255)
				surface.SetMaterial(camMat)
				surface.DrawTexturedRect(w/2 - camWidth/2, 0, camWidth, h)
			end
		else
			surface.SetDrawColor(APP.HeaderColor:Unpack())
			surface.DrawLine(0, headerMinTall - 1, w, headerMinTall - 1)
		end
	end
	userHeader.PerformLayout = function(self, w, h)
		if self.CallId then
			self:SetTall(messaging:GetTall() * 0.41)
		end
	end
	userHeader.ReceiveCall = function(_, call)
		if IsValid(userHeader.callContainer) then -- Avoid strange bug when calling someone when already in call
			userHeader.callContainer:Remove()
		end

		userHeader.CallId = call:GetId()
		userHeader:InvalidateLayout() -- Resize

		local CallList = {} -- Always 2 but so useful when having an AddPlayer fnc

		local callContainer = userHeader:Add("Panel")
		userHeader.callContainer = callContainer
		callContainer:Dock(FILL)
		callContainer:DockMargin(0, headerMinTall/2, 0, RespY(4))
		callContainer.Think = function(self)
			if APP:GetCall(call:GetId()) ~= call then -- Check if the call isn't end
				userHeader:StopCall() -- Stop the call
				self:Remove()
				return
			end

			-- allows the player to use their microphone key to speak
			local voiceInput = input.LookupBinding("voicerecord")
			if voiceInput then
				local voiceCode = input.GetKeyCode(voiceInput)
				if voiceCode then
					if input.IsButtonDown(voiceCode) then
						if not self.VoiceRecording then
							self.VoiceRecording = true
							RunConsoleCommand("+voicerecord")
						end
					elseif self.VoiceRecording then
						self.VoiceRecording = nil
						RunConsoleCommand("-voicerecord")
					end
				end
			end
			
			if call:GetStatus() == APP.CALL_PENDING then
				if not IsValid(self.pendingPanel) then
					self:BuildPending()
				end
			elseif call:GetStatus() == APP.CALL_ANSWERED then
				if IsValid(self.pendingPanel) then
					self.pendingPanel:Remove()
				end

				if not IsValid(self.answeredPanel) then
					self:BuildAnswered()
				end
			end
		end

		local footer = callContainer:Add("Panel")
		footer:Dock(BOTTOM)
		footer:DockMargin(0, RespY(4), 0, 0)
		footer:SetTall(RespY(42))

		local declineBtn = footer:Add("Panel")
		declineBtn:Dock(LEFT)
		declineBtn:SetCursor("hand")
		declineBtn:SetWide(footer:GetTall())
		declineBtn.Paint = function(self, w, h)
			surface.SetDrawColor(APP.DeclineRedColor:Unpack())
			draw.NoTexture()
			draw.Circle(w/2, h/2, h/2, 20)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(APP.DeclineMat)
			local offX, offY = w * 0.25, h * 0.25
			surface.DrawTexturedRect(offX, offY, w - offX * 2, h - offY * 2)
		end
		declineBtn.OnMousePressed = function()
			net.Start("ComCompGCordStop")
			net.WriteEntity(self:GetComputer():GetEntity())
			net.WriteUInt(call:GetId(), 16)
			net.SendToServer()
		end

		callContainer.PerformLayout = function(self, w, h)
			local offX = footer:GetWide()/2 - declineBtn:GetWide()/2
			declineBtn:DockMargin(offX, 0, offX, 0)
		end

		callContainer.BuildPending = function(self)
			local pendingPanel = self:Add("Panel")
			pendingPanel:Dock(FILL)
			pendingPanel.PerformLayout = function(self, w, h) -- Used to center all elements (Avatars & DeclineBtn)
				local c1 = CallList[1]
				local c2 = CallList[#CallList]

				local offX = (pendingPanel:GetWide() - #CallList * c1:GetWide())/2 -- Tall of callContainer equals to wide of avatar
				c1:DockMargin(offX, 0, 0, 0)
				if c2 then
					c2:DockMargin(0, 0, offX, 0)
				end
			end

			pendingPanel.AddPlayer = function(self, ply)
				local avatar = self:Add("Panel")
				CallList[#CallList + 1] = avatar
				avatar.Ply = ply
				avatar:Dock(LEFT)
				avatar.Image = avatar:Add("AvatarImage") -- Add the avatar
				avatar.Image:SetPaintedManually(true)
				avatar.Image:Dock(FILL)
				local offX, offY = Resp(5, 5)
				avatar:DockPadding(offX, offY, offX, offY)
				avatar.Image:SetPlayer(ply, 256)
				avatar.Paint = function(self, w, h)
					if self.Pending then
						-- Moving effect around the circle when the user is called
						local sin = TimedSin(2, 0, 1, 0)
						if sin ~= 0 then
							surface.SetDrawColor(APP.DeclineColor:Unpack())
							draw.NoTexture()
							draw.Circle(w/2, h/2, avatar.Image:GetTall()/2 + sin * 7, 38)
						end
					end

					APP:CircleMask(function() -- Draw the avatar
						self.Image:PaintManual()
					end, h/2, h/2, avatar.Image:GetTall()/2)
				end

				avatar.PerformLayout = function(self, w, h)
					self:SetWide(h)
				end

				avatar.SetPending = function(self, b)
					self.Pending = b
				end
				
				return avatar
			end

			pendingPanel:AddPlayer(call:GetCallee()):SetPending(true)
			pendingPanel:AddPlayer(call:GetCaller())

			self.pendingPanel = pendingPanel
			return pendingPanel
		end

		callContainer.BuildAnswered = function(self)
			local answeredPanel = self:Add("Panel")
			answeredPanel:Dock(FILL)

			-- Draw the camera
			hook.Add("PreRender", answeredPanel, function()
				local compEnt = call:GetCaller() ~= LocalPlayer() and call:GetCallerComp() or call:GetCalleeComp()
				if not IsValid(compEnt) then return end

				if (answeredPanel.NextDraw or 0) > CurTime() then return end
				answeredPanel.NextDraw = CurTime() + 1/25 -- 25 fps
		
				answeredPanel.DrawLP = true
		
				cam.Start3D() -- Necessary for ShouldDrawLocalPlayer 
				cam.End3D()
		
				render.PushRenderTarget(camRT)
		
				local pos, angles = compEnt:GetCamPos()
		
				cam.Start2D()
					render.RenderView({
						origin = pos,
						angles = angles,
						fov = 70,
						x = 0, y = 0,
						w = ScrW(), h = ScrH()
					})
				cam.End2D()
		
				render.PopRenderTarget()
			
				answeredPanel.DrawLP = false
			end)

			hook.Add("ShouldDrawLocalPlayer", answeredPanel, function()
				if answeredPanel.DrawLP then
					return true
				end
			end)

			self.answeredPanel = answeredPanel
			return answeredPanel
		end
	end
	userHeader.StopCall = function(self)
		self.CallId = nil
		self:SetTall(headerMinTall)
	end
	self.userHeader = userHeader

	-- Call btn (No video call icon because it is there by default)
	header:AddBtn(APP.PhoneMat, function()
		if not IsValid(CurPly) then return end

		local ent = self:GetComputer():GetEntity()
		if not IsValid(ent) then return end

		net.Start("ComCompGCordCall")
		net.WriteEntity(ent)
		net.WriteEntity(CurPly)
		net.SendToServer()
	end)
	-- ::END:: UserHeader
	
	local messages = messaging:Add("Panel")
	messages:Dock(FILL)
	messages.UpdateMessages = function(self, steamid64)
		local msgPanel = APP:GetMsgPanel(steamid64)
		for k,v in ipairs(self:GetChildren()) do
			v:SetParent(nil)
			v:SetVisible(false)
		end

		if msgPanel then
			msgPanel:SetParent(self)
			msgPanel:SetVisible(true)

			self.CurMsg = msgPanel
		end
	end
	messages.OnRemove = function(self)
		if self.CurMsg and IsValid(self.CurMsg) then
			self.CurMsg:SetParent(nil)
			self.CurMsg:SetVisible(false)
		end
	end
	self.messages = messages

	-- ::START:: ChatBox
	local chatBox = messaging:Add("Panel")
	chatBox:Dock(BOTTOM)
	chatBox:SetTall(RespY(32))
	chatBox.Paint = function(self, w, h)
		draw.RoundedBox(h/2.2, 0, 0, w, h, APP.ChatboxColor)
	end

	local addImage = chatBox:Add("Panel")
	addImage:Dock(LEFT)
	addImage:SetCursor("hand")
	local offX, offY = Resp(6, 6)
	addImage:DockMargin(offX, offY, offX, offY)
	addImage.Paint = function(self, w, h)
		surface.SetDrawColor(self:IsHovered() and color_white or APP.AddImageColor)
		surface.SetMaterial(APP.AddMat)
		surface.DrawTexturedRect(0, 0, w, h)
	end
	addImage.PerformLayout = function(self, w, h)
		self:SetWide(h)
	end
	addImage.OnMousePressed = function()
		local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
		if not explorer then
			ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), frame)
			return
		end

		explorer:Open()
		explorer:SetOpenMode(true, function(path)
			path = string.sub(path, 11, #path)

			local name = string.GetFileFromFilename(path)
			local f = file.Open(path, "rb", "GAME")
			if f then
				local size = f:Size()
				if size >= ComComp.Cfg["MaxNetSize"] - 16 - 16 - 1 - (#name + 1) then
					ComComp.DialogFrame(L("warning"), L("gcord_heavy"), frame)
					f:Close()
					return
				end

				local data = f:Read(size)
				f:Close()

				if not data then return end

				-- Send a file
				net.Start("ComCompGCordChat")
				net.WriteEntity(self:GetComputer():GetEntity())
				net.WriteEntity(CurPly)
				net.WriteBit(APP.MSG_FILE)
				net.WriteString(name)
				net.WriteData(data, #data)
				net.SendToServer()

				if CurSteamId64 then
					APP.BuildFile(APP:GetMsgPanel(CurSteamId64), LocalPlayer(), name, data)
					messages:UpdateMessages(CurSteamId64)
				end
			end
		end)
	end

	local textEntry = chatBox:Add("ComCompTextEntry")
	textEntry:Dock(FILL)
	textEntry:SetBorders(false)
	textEntry:SetBackgroundColor(color_transparent)
	textEntry:SetTextColor(color_white)
	textEntry.OnEnter = function(_)
		local text = string.Trim(textEntry:GetText())
		if #text == 0 || #text >= 2000 then return end

		-- Send a message
		net.Start("ComCompGCordChat")
		net.WriteEntity(self:GetComputer():GetEntity())
		net.WriteEntity(CurPly)
		net.WriteBit(APP.MSG_TEXT)
		net.WriteString(text)
		net.SendToServer()

		if CurSteamId64 then
			APP.BuildMessage(APP:GetMsgPanel(CurSteamId64), LocalPlayer(), text)
			messages:UpdateMessages(CurSteamId64)
		end

		textEntry:SetText("")
		textEntry:RequestFocus()
	end
	-- ::END:: ChatBox

	-- ::START:: UserList
	local userList = APP:ScrollPanel(main)
	userList:Dock(LEFT)
	userList:SetWide(RespX(164))
	userList.Paint = function(self, w, h)
		surface.SetDrawColor(APP.UserListColor:Unpack())
		surface.DrawRect(0, 0, w, h)
	end
	userList.Select = function(self, steamid64)
		local foundPly = player.GetBySteamID64(steamid64)

		CurSteamId64 = steamid64
		CurPly = foundPly and foundPly or nil

		messages:UpdateMessages(steamid64)
	end
	userList.AddUser = function(self, steamid64)
		local foundPly = player.GetBySteamID64(steamid64)

		local user = userList:Add("Panel")
		user:Dock(TOP)
		user:SetTall(RespY(34))
		

		local avatar = APP:CircleAvatar(foundPly, user)
		avatar:Dock(LEFT)
		avatar:DockMargin(RespX(3), RespY(3), RespX(3), RespY(3))
		avatar.PerformLayout = function(self, w, h)
			self:SetWide(h)
		end

		user.Paint = function(self, w, h)
			draw.SimpleText(IsValid(foundPly) and foundPly:Name() or L("gcord_invaliduser"), "ComComp18", avatar:GetWide() + RespX(4), h/2, CurSteamId64 ~= steamid64 and APP.TextColor or nil, nil, TEXT_ALIGN_CENTER)
		end

		local doclick = function(panel)
			self:Select(steamid64)
		end
		user.OnMousePressed = doclick
		avatar.OnMousePressed = doclick

		user:SetCursor("hand")
		avatar:SetCursor("hand")

		return user
	end
	
	local searchC = userList:Add("Panel")
	searchC:Dock(TOP)
	searchC:SetTall(userHeader:GetTall())
	searchC.Paint = function(self, w, h)
		surface.SetDrawColor(APP.HeaderColor:Unpack())
		surface.DrawLine(0, h - 1, w, h - 1)

		local offX, offY = Resp(4, 8)
		draw.RoundedBox((h - offY * 2)/2, offX, offY, w - offX * 2, h - offY * 2, APP.HeaderColor)
	end

	local searchBar = searchC:Add("ComCompTextEntry")
	searchBar:SetBorders(false)
	local offX, offY = Resp(6, 6)
	searchBar:DockMargin(offX, offY, offX, offY)
	searchBar:SetBackgroundColor(color_transparent)
	searchBar:SetTextColor(APP.TextColor)
	searchBar:Dock(FILL)
	searchBar.PaintOver = function(self, w, h)
		if #self:GetValue() == 0 and not self:IsEditing() then
			draw.SimpleText(L("gcord_searchbar"), "ComComp16", 0, h/2, APP.TextColor, nil, TEXT_ALIGN_CENTER)
		end
	end
	self.userList = userList

	for k, v in ipairs(player.GetHumans()) do -- Add all players to the userList
		if (v == LocalPlayer()) then goto con end
		userList:AddUser(v:SteamID64())

		::con::
	end
	-- ::END:: UserList
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("gcord")
	
	local callId = self.userHeader.CallId
	if callId then -- Stop current call
		net.Start("ComCompGCordStop")
		net.WriteEntity(self:GetComputer():GetEntity())
		net.WriteUInt(callId, 16)
		net.SendToServer()
	end

	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:GCord:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("gcord", APP.GCordMat, L("gcord"), 1, 1, function()
		local gcord = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		gcord:Open()
	end)
end)

hook.Add("CC:TaskbarCreated", "CC:GCord:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("gcord", APP.GCordMat, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local gcord = ComComp.Apps:Instantiate(APP.Id, computer)
			gcord:Open()
		end
		
	end, 0, true)
end)

hook.Add("CC:Applications:Loaded", "CC:GCord:Help", function()
	local help = ComComp.Apps:GetMeta("helpcenter")
	if not help then return end

	local doc = help:NewDocumentation(APP.Id, L("gcord"))
		:AddPage(L("gcord_advanced"))
		:AddText(L("gcord_sendfiles"))
		:AddImage("common_computer/helpcenter/gcord.jpg")
end)

