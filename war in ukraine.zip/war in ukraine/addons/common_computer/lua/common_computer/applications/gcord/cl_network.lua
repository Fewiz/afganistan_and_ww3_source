--[[
addons/common_computer/lua/common_computer/applications/gcord/cl_network.lua
--]]
local APP = APP

--[[
	Make the receiving of call independant of application itself because if no computer
	is powered on, the callee will never receive his call...
]]
local NotReceivedCall = {} -- Not drawed call that are currently pending (Table used in the hook CC:Computer:OnUse bellow)
local function ReceiveCall(call)
	local usedComputer = ComComp.GetUsedComputer()
	if usedComputer == nil then
		NotReceivedCall[call] = true -- Add the call to NotReceivedCall
	else
		local mainFrame = usedComputer:GetMainFrame()
		local appArea = mainFrame:GetAppArea()
		if call:GetCaller() ~= LocalPlayer() then
			APP.NewCallPanel(usedComputer, call)
		else
			local gcordApp = usedComputer:RetrieveApp(APP.Id)
			if gcordApp == nil then
				gcordApp = ComComp.Apps:Instantiate(APP.Id, usedComputer)
				gcordApp:Open()
			elseif not IsValid(gcordApp.frame) then -- In case application isn't open
				NotReceivedCall[call] = true
				return
			end

			gcordApp.userHeader:ReceiveCall(call)
		end
	end
end

hook.Add("CC:Computer:OnUse", "CC:GCord:MissedCall", function(computer)
	for call, _ in pairs(NotReceivedCall) do
		NotReceivedCall[call] = nil -- Put that before, because it can be put back in the ReceiveCall fnc
		ReceiveCall(call)
	end
end)

net.Receive("ComCompGCordCall", function(len)
	local id = net.ReadUInt(16)
	local caller = net.ReadEntity()
	local callee = net.ReadEntity()

	ReceiveCall(APP:NewCall(caller, callee, id))
end)

net.Receive("ComCompGCordStop", function(len)
	local call = APP:GetCall(net.ReadUInt(16))
	call:Stop()

	NotReceivedCall[call] = nil
end)

net.Receive("ComCompGCordCompEnt", function(len)
	local call = APP:GetCall(net.ReadUInt(16))
	local isCaller = net.ReadBool()
	local comp = net.ReadEntity()

	if isCaller then
		call:SetCallerComp(comp)
	else
		call:SetCalleeComp(comp)
	end
end)

net.Receive("ComCompGCordStatus", function(len)
	local call = APP:GetCall(net.ReadUInt(16))
	call:SetStatus(net.ReadBit())

	if call:GetStatus() == APP.CALL_ANSWERED then -- Update the GUI
		if call:GetCallee() == LocalPlayer() then
			local usedComputer = ComComp.GetUsedComputer()
			if not usedComputer then return end

			local gcordApp = usedComputer:RetrieveApp(APP.Id)
			if gcordApp == nil then
				gcordApp = ComComp.Apps:Instantiate(APP.Id, usedComputer)
				gcordApp:Open()
			end

			local userHeader = gcordApp.userHeader
			local userList = gcordApp.userList

			timer.Simple(0.1, function() -- Small delay to avoid rendering bug
				if IsValid(userHeader) and IsValid(userList) then
					userHeader:ReceiveCall(call)
					userList:Select(call:GetCaller())
				end
			end)
		end -- Not doing else here (Because I would need to cache this information and it's like useless...) -> Too big chance that the caller isn't in a computer (Did in the Think hook of the CallPanel)
	end
end)

local NotReceivedMessages = {}
net.Receive("ComCompGCordChat", function(len)
	local from = net.ReadEntity()
	if not IsValid(from) then return end

	local sid64 = from:SteamID64()
	local msgPanel = APP:GetMsgPanel(sid64)

	local msgType = net.ReadBit()
	if msgType == APP.MSG_TEXT then
		APP.BuildMessage(msgPanel, from, net.ReadString())
	elseif msgType == APP.MSG_FILE then
		local fileName = net.ReadString()
		local fileLen = (len - 16 - 1 - (#fileName + 1) * 8)/8
		local fileData = net.ReadData(fileLen)

		APP.BuildFile(msgPanel, from, fileName, fileData)
	end
end)

