--[[
addons/common_computer/lua/common_computer/applications/gcord/cl_derma.lua
--]]
--[[
	Derma utilities for G-Cord
]]

local APP = APP
local L = ComComp.GetLang
local RespX = ComComp.RespX
local RespY = ComComp.RespY
local Resp = ComComp.Resp

-- Materials
APP.FileMat = Material("common_computer/file.png")
APP.GCordMat = Material("common_computer/gcord.png", "smooth")
APP.PhoneMat = Material("common_computer/phone.png", "smooth")
APP.AddMat = Material("common_computer/add.png")
APP.DeclineMat = Material("common_computer/decline.png")
APP.DownloadMat = Material("common_computer/download.png")

-- Colors
APP.InCallColor = Color(24, 25, 28)
APP.TextColor = Color(185, 187, 190)
APP.HeaderColor = Color(32, 34, 37)
APP.UserListColor = Color(47, 49, 54)
APP.MessagingColor = Color(54, 57, 63)
APP.ChatboxColor = Color(64, 68, 75)
APP.AddImageColor = Color(185, 187, 190)
APP.HovColor = Color(60, 63, 68)
APP.PickupColor = Color(66, 181, 129)
APP.DeclineColor = Color(78, 84, 92)
APP.DeclineRedColor = Color(240, 71, 71)
APP.LinkColor = Color(30, 164, 240)

-- Create the "G-Cord" frame with his style
function APP:NewFrame()
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()

	local frame = appArea:NewFrame()
	frame:SetSize(Resp(750, 500))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame
	
	frame.Paint = function(_, w, h)
		surface.SetDrawColor(APP.HeaderColor:Unpack())
		surface.DrawRect(0, 0, w, h)
	end

	-- Change the "Windows" style to G-Cord style
	local header = frame:GetHeader()
	header:SetTall(RespY(18))
	header.Paint = function(self, w, h)
		surface.SetDrawColor(APP.HeaderColor:Unpack())
		surface.DrawRect(0, 0, w, h)
	end
	header.PaintOver = function(self, w, h)
		draw.SimpleText(L("gcord"), "ComComp12", RespX(6), h/2 - RespY(12)/2, color_white)
	end

	local closeBtn = frame.CloseBtn
	local maximizeBtn = frame.MaximizeBtn
	local reduceBtn = frame.ReduceBtn

	local offX = RespX(6)
	closeBtn:DockMargin(0, 0, 0, 0)
	maximizeBtn:DockMargin(offX, 0, offX, 0)
	reduceBtn:DockMargin(0, 0, 0, 0)

	maximizeBtn.hovColor = APP.HovColor
	maximizeBtn.hovTextColor = color_white
	reduceBtn.hovColor = APP.HovColor
	reduceBtn.hovTextColor = color_white

	closeBtn.baseColor = color_white
	maximizeBtn.baseColor = color_white
	reduceBtn.baseColor = color_white

	header.PerformLayout = function(_, w, h)
		closeBtn:SetWide(h)
		maximizeBtn:SetWide(h)
		reduceBtn:SetWide(h)
	end

	return frame
end

-- Circle mask
function APP:CircleMask(drawFnc, x, y, r)
	render.SetStencilWriteMask(0xFF)
	render.SetStencilTestMask(0xFF)
	render.SetStencilPassOperation(STENCIL_KEEP)
	render.SetStencilZFailOperation(STENCIL_KEEP)

	render.SetStencilEnable(true)
	render.SetStencilReferenceValue(1)
	render.SetStencilCompareFunction(STENCIL_NEVER)
	render.SetStencilFailOperation(STENCIL_REPLACE)
	render.ClearStencil()

	surface.SetDrawColor(255, 255, 255)
	draw.NoTexture()
	draw.Circle(x, y, r, 38)

	render.SetStencilCompareFunction(STENCIL_EQUAL)
	render.SetStencilFailOperation(STENCIL_KEEP)

	drawFnc()

	render.SetStencilEnable(false)
end

-- Avatar with a circle mask
function APP:CircleAvatar(player, optParent)
    local panel = vgui.Create("Panel", optParent)
    local avatar = panel:Add("AvatarImage")
    avatar:SetPaintedManually(true)
    avatar:Dock(FILL)
    
    if IsValid(player) then
        avatar:SetPlayer(player)
    end

    avatar.OnMousePressed = function(_, code)
        if panel.OnMousePressed then
            panel:OnMousePressed(code)
        end
    end

    panel.Paint = function(self, w, h)
        APP:CircleMask(function()
            avatar:PaintManual()
        end, h/2, h/2, h/2)
    end

    return panel
end

-- Scroll panel with the G-Cord style
local vBarColor = Color(46, 51, 56)
local gripColor = Color(32, 34, 37)
function APP:ScrollPanel(optParent)
    local panel = vgui.Create("ComCompScrollPanel", optParent)
    local vBar = panel:GetVBar()
    vBar:SetWide(RespX(8))
    vBar:SetHideButtons(true)
    
    vBar.Paint = function(self, w, h)
        draw.RoundedBox(w/2, 0, 0, w, h, vBarColor)
    end

    vBar.btnGrip.Paint = function(self, w, h)
        local rx = w/4
        local rw = w - rx * 2
        draw.RoundedBox(rw/2, rx, 0, rw, h, gripColor)
	end

    return panel
end

--[[
    MsgPanels (Where messages data are stored), basically a list of panels
]]
local MsgPanel = {}

function APP:GetMsgPanel(sid64)
	local msgPanel = MsgPanel[sid64]
	if not msgPanel then
		msgPanel = APP:ScrollPanel()
		msgPanel:SetVisible(false)
		msgPanel:Dock(FILL)

		MsgPanel[sid64] = msgPanel
	end

	return msgPanel
end

-- This is the base panel needed to create a G-Cord Message (Avatar + Name)
local BuildBaseMsg = function(parent, from)
	local sid64 = from:SteamID64()

	local panel = parent:Add("Panel")
	panel:Dock(TOP)
	panel:DockMargin(0, RespY(12), 0, 0)
	panel:DockPadding(RespX(8), RespY(2), RespX(8), RespY(2))
	panel.Paint = function(self, w, h)
		if self:IsHovered() or self:IsChildHovered() then
			surface.SetDrawColor(50, 53, 59)
			surface.DrawRect(0, 0, w, h)
		end
	end

	local left = panel:Add("Panel")
	left:Dock(LEFT)
	left:SetWide(RespX(32))
	left:DockMargin(0, 0, RespX(8), 0)

	local avatar = APP:CircleAvatar(from, left)
	avatar:Dock(TOP)
	avatar:SetTall(left:GetWide())

	local content = panel:Add("Panel")
	content:Dock(FILL)

	local name = content:Add("DLabel")
	name:SetFont("ComComp18")
	name:Dock(TOP)
	name:SetTextColor(color_white)
	name:SetText(from:Name())
	name:SetTall(RespY(18))

	return panel
end

-- Build a simple message from string text
APP.BuildMessage = function(parent, from, msg)
	local panel = BuildBaseMsg(parent, from)
	local content = panel:GetChild(1)
	local name = content:GetChild(0)

	local text = content:Add("Panel")
	text:Dock(FILL)
	text.PerformLayout = function(self, w, h)

		local succ = pcall(function()
			local tc = APP.TextColor
			self.mark = markup.Parse("<font=ComComp16><colour=" .. tc.r .. "," .. tc.g .. "," .. tc.b .. ",255>" .. msg .. "</colour></font>", w)
		end)

		local mHeight = 0
		if succ then
			mHeight = self.mark:GetHeight()
		end
		
		panel:SetTall(name:GetTall() + math.max(RespX(32) - name:GetTall(), mHeight) + RespY(2 * 2))
	end
	text.Paint = function(self, w, h)
		if self.mark then
			self.mark:Draw(0, 0, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	return panel
end

-- Build a message containing a file, if the file is an image, draw it
APP.BuildFile = function(parent, from, fileName, fileData)
	local panel = BuildBaseMsg(parent, from)
	local content = panel:GetChild(1)
	local name = content:GetChild(0)
	local fileLen = #fileData

	local ext = string.GetExtensionFromFilename(fileName)
	if ComComp.IsImageExtension(ext) then
		-- Attempt to create a Material from it
		local tempPath = "common_computer/temp/" .. util.CRC(fileData) .. "." .. ext

		local temp = file.Open(tempPath, "wb", "DATA")
		temp:Write(fileData)
		temp:Close()

		local material = Material("../data/" .. tempPath)
		local ar = material:Height()/material:Width()

		local image = content:Add("Panel")
		image:Dock(TOP)
		image:SetTall(math.min(RespY(128), material:Height()))
		image.Paint = function(self, w, h)
			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(material)
			surface.DrawTexturedRect(0, 0, h * ar, h)
		end
		
		panel:SetTall(name:GetTall() + math.max(RespX(32) - name:GetTall(), image:GetTall()) + RespY(2 * 2))
	else
		local fileContent = content:Add("Panel")
		fileContent:Dock(TOP)
		fileContent:SetTall(RespY(48))
		fileContent.PerformLayout = function(self, w, h)
			self:SetWide(math.min(RespX(256, w)))
		end
		fileContent.Paint = function(self, w, h)
			draw.RoundedBox(h/8, 0, 0, w, h, APP.UserListColor)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(APP.FileMat)
			surface.DrawTexturedRect(h/5, h/5, h -  h/5*2, h -  h/5*2)

			local _, th = draw.SimpleText(fileName, "ComComp16", h, RespY(9), APP.LinkColor)
			draw.SimpleText(fileLen .. " bytes", "ComComp12", h, RespY(9) + th, APP.TextColor)
		end
		
		local downBtn = fileContent:Add("Panel")
		downBtn:Dock(RIGHT)
		downBtn:SetCursor("hand")
		downBtn:DockMargin(RespX(12), RespY(12), RespX(12), RespY(12))
		downBtn.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and color_white or APP.AddImageColor)
			surface.SetMaterial(APP.DownloadMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		downBtn.PerformLayout = function(self, w, h)
			downBtn:SetWide(h)
		end
		downBtn.OnMousePressed = function()
			local explorer = ComComp.Apps:Instantiate("filebrowser", ComComp.GetUsedComputer())
			if not explorer then
				ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), frame)
				return
			end
			explorer:Open()
			explorer:SetRoot("garrysmod/data/")
			explorer:SetSaveMode(true, function(path)
				local f = file.Open(string.sub(path, #explorer:GetRoot() + 1) .. "." .. ext, "wb", "DATA")
				if f then
					f:Write(fileData)
					f:Close()
				end
			end)
		end

		panel:SetTall(name:GetTall() + math.max(RespX(32) - name:GetTall(), fileContent:GetTall()) + RespY(2 * 2))
	end

	return panel
end


-- The little panel (like a popup) we get when we have been called
function APP.NewCallPanel(computer, call)
	local mainFrame = computer:GetMainFrame()
	local appArea = mainFrame:GetAppArea()

	local callPanel = appArea:Add("ComCompMoveablePanel")
	callPanel:SetTitle("")
	callPanel:ShowCloseButton(false)
	callPanel:SetZPos(ComComp.Cfg["ZPos"]["Frame"] + 1)
	callPanel:SetSizable(false)
	callPanel:SetSize(Resp(200, 264))
	callPanel:Center()
	local offX, offY = Resp(8, 8)
	callPanel:DockPadding(offX, offY, offX, offY)
	local oldThink = callPanel.Think
	callPanel.Think = function(self)
		if APP:GetCall(call.Id) ~= call then
			self:Remove() -- The call isn't valid anymore
		end
		oldThink(self)
	end

	local avatar = callPanel:Add("AvatarImage")
	avatar:Dock(TOP)
	avatar:DockMargin(RespX(41), RespY(12), RespX(41), 0)
	avatar:SetPaintedManually(true)
	avatar:SetPlayer(call:GetCaller(), 128)
	avatar.PerformLayout = function(self, w, h)
		avatar:SetTall(w)
	end
	avatar.OnMousePressed = function()
		callPanel:StartDrag()
	end

	local callerName = call:GetCaller():Name()
	callPanel.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, color_black)
		draw.RoundedBox(4, 1, 1, w - 2, h - 2, APP.HeaderColor)

		local y = avatar.y + avatar:GetTall()

		-- Moving effect
		local sin = TimedSin(2, 0, 1, 0)
		if sin ~= 0 then
			surface.SetDrawColor(APP.DeclineColor:Unpack())
			draw.NoTexture()
			draw.Circle(w/2, y - avatar:GetTall()/2, avatar:GetTall()/2 + sin * 6, 38)
		end

		APP:CircleMask(function()
			avatar:PaintManual()
		end, w/2, y - avatar:GetTall()/2, avatar:GetTall()/2)

		local _, tH = draw.SimpleText(callerName, "ComComp20", w/2, y, nil, TEXT_ALIGN_CENTER)
		draw.SimpleText(L("gcord_incomingcall"), "ComComp18", w/2, y + tH, APP.TextColor, TEXT_ALIGN_CENTER)
	end

	local declineBtn = callPanel:Add("DButton")
	declineBtn:SetTextColor(color_white)
	declineBtn:SetFont("ComComp18")
	declineBtn:SetText(L("gcord_decline"))
	declineBtn:SetTall(RespY(32))
	declineBtn:Dock(BOTTOM)
	declineBtn.UpdateColours = function() end
	declineBtn.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, APP.DeclineColor)
	end
	declineBtn.DoClick = function(self, w, h)
		-- Decline the call
		net.Start("ComCompGCordResponse")
		net.WriteEntity(computer:GetEntity())
		net.WriteUInt(call:GetId(), 16)
		net.WriteBool(false) -- Ignore
		net.SendToServer()

		callPanel:Remove()
	end

	local pickBtn = callPanel:Add("DButton")
	pickBtn:SetTall(declineBtn:GetTall())
	pickBtn:SetTextColor(color_white)
	pickBtn:SetFont("ComComp18")
	pickBtn:SetText(L("gcord_joincall"))
	pickBtn:Dock(BOTTOM)
	pickBtn:DockMargin(0, 0, 0, RespY(3))
	pickBtn.UpdateColours = function() end
	pickBtn.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, APP.PickupColor)
	end
	pickBtn.DoClick = function(self, w, h)
		-- Answer to the call
		net.Start("ComCompGCordResponse")
		net.WriteEntity(computer:GetEntity())
		net.WriteUInt(call:GetId(), 16)
		net.WriteBool(true) -- Answer
		net.SendToServer()

		callPanel:Remove()
	end

	return callPanel
end

