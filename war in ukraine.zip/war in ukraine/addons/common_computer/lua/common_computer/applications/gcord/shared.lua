--[[
addons/common_computer/lua/common_computer/applications/gcord/shared.lua
--]]
local APP = APP

ComComp.Include(APP.Path .. "cl_derma.lua")
ComComp.Include(APP.Path .. "cl_app.lua")
ComComp.Include(APP.Path .. "cl_network.lua")
ComComp.Include(APP.Path .. "sv_network.lua")

-- CALL Enums, No DECLINED enum (We directly remove the object)
APP.CALL_PENDING = 0
APP.CALL_ANSWERED = 1

-- MSG Enums
APP.MSG_TEXT = 0
APP.MSG_FILE = 1

local CallList = {}
local BusyPly = {} -- Usefull to retrieve the corresponding call from a player instance

-- CALL object
local CALL = {} -- No encapsulation, this is Lua
CALL.__index = CALL
APP.CALL = CALL

function CALL:SetCallerComp(comp)
    self.CallerComp = comp

    if SERVER then
        net.Start("ComCompGCordCompEnt")
        net.WriteUInt(self.Id, 16)
        net.WriteBool(true) -- IsCaller
        net.WriteEntity(comp)
        net.Send({self:GetCaller(), self:GetCallee()})
    end
end

function CALL:SetCalleeComp(comp)
    self.CalleeComp = comp

    if SERVER then
        net.Start("ComCompGCordCompEnt")
        net.WriteUInt(self.Id, 16)
        net.WriteBool(false) -- IsCaller
        net.WriteEntity(comp)
        net.Send({self:GetCaller(), self:GetCallee()})
    end
end

function CALL:SetStatus(status, noNetwork)
    self.Status = status

    if SERVER and not noNetwork then
        net.Start("ComCompGCordStatus")
        net.WriteUInt(self.Id, 16)
        net.WriteBit(status)
        net.Send({self:GetCaller(), self:GetCallee()})
    end
end

function CALL:Start()
    BusyPly[self:GetCallee()] = self
    self:SetStatus(APP.CALL_ANSWERED)
end

function CALL:Stop()
    CallList[self.Id] = nil
    BusyPly[self:GetCaller()] = nil
    BusyPly[self:GetCallee()] = nil

    if SERVER then
        net.Start("ComCompGCordStop")
        net.WriteUInt(self.Id, 16)
        net.Send({self:GetCaller(), self:GetCallee()})
    end
end

function CALL:GetStatus()
    return self.Status
end

function CALL:GetCaller()
    return self.Caller or NULL
end

function CALL:GetCallee()
    return self.Callee or NULL
end

function CALL:GetCalleeComp()
    return self.CalleeComp or NULL
end

function CALL:GetCallerComp()
    return self.CallerComp or NULL
end

function CALL:GetId()
    return self.Id
end

function APP:NewCall(caller, callee, optId)
    local newObj = setmetatable({}, CALL)

    newObj.Caller = caller
    newObj.Callee = callee

    local id = optId and optId or (#CallList + 1)
    CallList[id] = newObj
    newObj.Id = id

    BusyPly[caller] = newObj

    if SERVER then
        net.Start("ComCompGCordCall")
        net.WriteUInt(id, 16)
        net.WriteEntity(caller)
        net.WriteEntity(callee)
        net.Send({caller, callee})
    end

    newObj:SetStatus(APP.CALL_PENDING, true)

    return newObj
end

-- GCord "API"
-- Busy means that a CALL instance exists for a specific player which accepted it
function APP:IsBusy(ply)
    return BusyPly[ply] ~= nil
end

function APP:GetCall(ply)
    return isnumber(ply) and CallList[ply] or BusyPly[ply]
end

