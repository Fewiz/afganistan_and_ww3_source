--[[
addons/common_computer/lua/common_computer/applications/docbrowser/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP
local wordMat = Material("common_computer/docbrowser.png")

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("docbrowser")
	
	local frame = appArea:NewFrame()
	frame:SetIcon(wordMat)
	frame:SetTitle(L("docbrowser"))
	frame:SetMinimumSize(ComComp.Resp(425, 175))
	frame:SetSize(ComComp.Resp(900, 600))
	frame:Center()
	frame.OnClose = function() self:Close() end
	frame.OnReduce = function() self:Pause() end
	self.frame = frame
	
	local html = frame:Add("DHTML")
	html:Dock(FILL)
	html.Paint = function(self, w, h) -- Paint function is required because the html can be transparent
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
	end
	html.Callbacks["console.log"] = nil
	html.Exec = html.QueueJavascript
	html.Lang = function(self, id, text)
		self:Exec("ComComp.Lang('" .. string.JavascriptSafe(id) .. "', '" .. string.JavascriptSafe(text) .. "');")
	end
	self.html = html
	
	html:OpenURL(ComComp.Database.DBServer .. "applications/word/?player_key=" .. ComComp.Database.ClientKey .. "&view=browser")

	function html.OnDocumentReady()
		-- Translate the steamid64 to name in the "Author" column
		html:AddFunction("gmod", "requestName", function(id, steamid)
			steamworks.RequestPlayerInfo(steamid, function(steamName)
				html:Lang(id, steamName)
			end)
		end)
		
		-- Called by html when the player want to open a document
		html:AddFunction("gmod", "viewDoc", function(id)
			timer.Simple(0, function()
				local word = ComComp.Apps:Instantiate("word", self:GetComputer())
				if not word then
					ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "word"), frame)
					return
				end
				word:Open(id, true)
			end)
		end)
		
		-- Called by html when the player want to edit a document
		html:AddFunction("gmod", "editDoc", function(id)
			timer.Simple(0, function()
				local word = ComComp.Apps:Instantiate("word", self:GetComputer())
				if not word then
					ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "word"), frame)
					return
				end
				word:Open(id, false)
			end)
		end)

		-- Edit languages
		html:Lang("title", L("docbrowser_title"))
		html:Lang("author", L("docbrowser_author"))
		html:Lang("action", L("docbrowser_action"))
		html:Lang("result", " " .. L("docbrowser_result"))
		html:Lang("document", L("docbrowser_listdoc"))
		html:Lang("remTitle", L("docbrowser_remove_title"))
		html:Lang("remDesc", L("docbrowser_remove_desc"))
		html:Lang("remBtn", L("docbrowser_remove_btn"))
	end
end

function APP:Close()
	local taskBar = self:GetComputer():GetMainFrame():GetTaskBar()
	taskBar:DecreaseIcon("docbrowser")
	
	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:DocBrowser:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("docbrowser", wordMat, L("docbrowser"), 1, 3, function()
		local docbrowser = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		docbrowser:Open()
	end)
end)

hook.Add("CC:TaskbarCreated", "CC:DocBrowser:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("docbrowser", wordMat, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local docbrowser = ComComp.Apps:Instantiate(APP.Id, computer)
			docbrowser:Open()
		end
		
	end, 0, true)
end)

