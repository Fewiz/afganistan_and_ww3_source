--[[
addons/common_computer/lua/common_computer/applications/paint/cl_init.lua
--]]
file.CreateDir("common_computer/paint")

local L = ComComp.GetLang
local APP = APP
local paintMat = Material("common_computer/paint.png")

-- Drawing pixel by pixel is quite slow, trying to optimze
local setDrawColor = surface.SetDrawColor
local drawRect = surface.DrawRect
local drawLine = surface.DrawLine
local matGetColor = FindMetaTable("IMaterial").GetColor

function APP:Open()
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()

	taskBar:AddIcon("paint", paintMat, function() -- Add the icon to the taskbar
		local app = self:GetComputer():RetrieveApp(APP.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	-- Creating the new frame
	local frame = appArea:NewFrame()
	frame:SetIcon(paintMat)
	frame:SetTitle(L("paint"))
	frame:SetMinimumSize(ComComp.Resp(332, 300))
	frame:SetSize(ComComp.RespX(532 + 5*2) - frame:GetHeader():GetTall(), ComComp.RespY(500 + 24))
	frame:Center()
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	self.frame = frame

	-- Paint Tools
	local MODE_PAINT, MODE_FILL, MODE_REMOVE, MODE_COPY = 1, 2, 3, 4

	local Drawing = {}
	local CurColor = Color(0, 0, 0)
	local CurrentMode = MODE_PAINT
	local Grid = true
	local RequestSave = false

	-- Menu bar
	local menu = frame:Add("ComCompMenuBar")
	menu:Dock(TOP)
	menu:SetTall(ComComp.RespY(24))
	local fileMenu = menu:AddMenu(L("file"))
	fileMenu:AddOption(L("new"), function()
		Drawing = {}
	end):SetIcon("icon16/page_white.png")

	fileMenu:AddOption(L("open"), function()
		local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
		if not explorer then
			ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), frame)
			return
		end
		explorer:Open()
		explorer:SetOpenMode(true, function(path)
			if not string.EndsWith(path, ".png") then return end
			local img = Material("../" .. path)
			if img:IsError() then return end
			if img:Height() ~= 32 or img:Width() ~= 32 then return end

			local colFnc = Color
			for x = 0, 31 do
				for y = 0, 31 do
					Drawing[x] = Drawing[x] or {}
					local cTable = matGetColor(img, x, y)
					Drawing[x][y] = colFnc(cTable.r, cTable.g, cTable.b)
				end
			end
		end)
	end):SetIcon("icon16/folder.png")

	fileMenu:AddOption(L("save"), function()
		local explorer = ComComp.Apps:Instantiate("filebrowser", self:GetComputer())
		if not explorer then
			ComComp.DialogFrame(L("warning"), string.format(L("disabledapp"), "filebrowser"), self.frame)
			return
		end
		explorer:Open()
		explorer:SetRoot("garrysmod/data/")
		explorer:SetSaveMode(true, function(path)
			RequestSave = string.sub(path, #explorer:GetRoot() + 1) .. ".png"
		end)
		
	end):SetIcon("icon16/disk.png")

	-- Main container
	local c = frame:Add("Panel")
	c:Dock(FILL)
	c.Paint = function(self, w, h)
		setDrawColor(235, 235, 237)
		drawRect(0, 0, w, h)
	end

	-- Paint's toolbar
	local toolBarC = c:Add("ComCompScrollPanel")
	toolBarC:Dock(LEFT)
	local pX, pY = ComComp.Resp(5, 5)
	toolBarC:GetCanvas():DockPadding(pX, pY, pX, pY)

	local toolBar = toolBarC:Add("DIconLayout")
	toolBar:Dock(FILL)
	toolBar:SetSpaceY(0)
	toolBar:SetSpaceY(0)
	toolBar.AddButton = function(self, icon, doclick)
		local btn = toolBar:Add("DImageButton")
        btn:SetSize(ComComp.Resp(32, 32))
		btn:SetMaterial(icon)
		btn.PaintOver = function(self, w, h)
			if self:IsHovered() then
				setDrawColor(255, 255, 255, 50)
				draw.NoTexture()
				draw.Circle(w*0.5, h*0.5, w*0.5, 20)
			end
		end
        btn.DoClick = doclick
	end

	toolBar:AddButton(Material("common_computer/brush.png"), function()
		CurrentMode = MODE_PAINT
	end)

	toolBar:AddButton(Material("common_computer/bucket.png"), function()
		CurrentMode = MODE_FILL
	end)

    toolBar:AddButton(Material("common_computer/picker.png"), function()
        CurrentMode = MODE_COPY
    end)

	toolBar:AddButton(Material("common_computer/eraser.png"), function()
		CurrentMode = MODE_REMOVE
	end)

    local colorframe
    toolBar:AddButton(Material("common_computer/color-wheel.png"), function()
        if IsValid(colorframe) then 
            colorframe:SetVisible(not colorframe:IsVisible())
            return 
        end

        colorframe = frame:Add("ComCompFrame")
		colorframe:SetTitle(L("color"))
		colorframe:SetIcon(Material("icon16/color_wheel.png"))
		colorframe:SetSizable(false)
        colorframe:SetSize(ComComp.Resp(200, 200))
		colorframe.OnClose = function()
			colorframe:SetVisible(false)
		end
		colorframe.OnMaximize = function()

		end
        colorframe:Center()

		local c = colorframe:Add("Panel")
		c:Dock(FILL)
		c.Paint = function(self, w, h)
			setDrawColor(240, 240, 240)
			drawRect(0, 0, w, h)
		end

        local colorSelector = c:Add("DColorMixer")
        colorSelector:Dock(FILL)
        colorSelector:SetPalette(true)
        colorSelector:SetAlphaBar(false)
        colorSelector:SetWangs(true)
        function colorSelector.ValueChanged(_, col)
            CurColor = col
        end

        colorframe.selector = colorSelector
	end)
	
	toolBar:AddButton(Material("common_computer/grid.png"), function()
		Grid = not Grid
	end)

	-- Drawing
	local paintArea = c:Add("Panel")
	paintArea:Dock(FILL)
	paintArea.PerformLayout = function(_, w, h)
		toolBarC:SetWide(c:GetWide() - h)
		paintArea:SetWide(h)
	end
	paintArea.GetPixelSize = function()
		return paintArea:GetWide()/32, paintArea:GetTall()/32
	end
	paintArea.GetCursorPos = function()
		local x, y = paintArea:LocalCursorPos()
		local wP, hP = paintArea:GetPixelSize()
        x = math.Clamp(math.floor(x/wP), 0, 32 - 1)
		y = math.Clamp(math.floor(y/hP), 0, 32 - 1)
		return x, y
	end
	paintArea.Think = function(self)
		if (self:IsHovered() and input.IsMouseDown(MOUSE_LEFT)) then
			local x, y = self:GetCursorPos()
			Drawing[x] = Drawing[x] or {}

			if (CurrentMode == MODE_PAINT) then
				Drawing[x][y] = CurColor
			elseif (CurrentMode == MODE_REMOVE) then
				Drawing[x][y] = nil
			elseif (CurrentMode == MODE_COPY && Drawing[x][y]) then
				CurColor = Drawing[x][y]
				if IsValid(colorframe) then
					colorframe.selector:SetColor(Drawing[x][y])
				end
			elseif (CurrentMode == MODE_FILL) then
				APP:Fill(Drawing, Drawing[x][y], CurColor, x, y)
			end
		end
	end
	paintArea.Paint = function(self, w, h)
		if RequestSave then
			setDrawColor(255, 255, 255)
			drawRect(0, 0, 32, 32)
			for x, v in pairs(Drawing) do
				for y, c in pairs(v) do
					setDrawColor(c)
					drawRect(x, y, 1, 1)
				end
			end

			local x, y = paintArea:LocalToScreen()
			local data = render.Capture({
				format = "png",
				quality = 100,
				x = x,
				y = y,
				w = 32,
				h = 32
			})
			
			local f = file.Open(RequestSave, "wb", "DATA")
			if f then
				f:Write(data)
				f:Close()
			end

			RequestSave = false
		end

		-- *0.5 is faster than /2
		setDrawColor(255, 255, 255)
		drawRect(0, 0, w * 0.5, h * 0.5)
		drawRect(w * 0.5, h * 0.5, w * 0.5, h * 0.5)
		setDrawColor(220, 220, 220)
		drawRect(w * 0.5, 0, w * 0.5, h * 0.5)
		drawRect(0, h * 0.5, w * 0.5, h * 0.5)

		local pX, pH = self:GetPixelSize()

		-- Drawing the pixel data (Optimized as I can)
		local iPX, iPH = pX + 1, pH + 1
		for x = 0, 31 do
			local dx = Drawing[x]
			if not dx then goto gX end

			local iX = x * pX
			for y = 0, 31 do
				local c = dx[y]
				if not c then goto gY end

				setDrawColor(c.r, c.g, c.b)
				drawRect(iX, y * pH, iPX, iPH)
				::gY::
			end

			::gX::
		end
		
		if self:IsHovered() and Grid then
			local x, y = self:GetCursorPos()

            setDrawColor(70, 70, 70)
            drawLine(0, y * pX, w, y * pH)
            drawLine(0, (y + 1) * pH, w, (y + 1) * pH)
            drawLine(x * pX, 0, x * pX, h)
            drawLine((x + 1) * pX, 0, (x + 1) * pX, h)
		end
	end
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("paint")
	
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

--[[
	Utilities
]]

-- Simple algorithm for the bucket tool
function APP:Fill(draw, start_color, end_color, x, y)
    if x < 0 or x > 31 or y < 0 or y > 31 then return end
    draw[x] = draw[x] or {}

    if draw[x][y] == start_color and draw[x][y] ~= end_color then
        draw[x][y] = end_color
        self:Fill(draw, start_color, end_color, x + 1, y)
        self:Fill(draw, start_color, end_color, x - 1, y)
        self:Fill(draw, start_color, end_color, x, y + 1)
        self:Fill(draw, start_color, end_color, x, y - 1)
    end
end

hook.Add("CC:DesktopCreated", "CC:Paint:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("paint", paintMat, L("paint"), 2, 3, function()
		local paint = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		paint:Open()
	end)
end)


