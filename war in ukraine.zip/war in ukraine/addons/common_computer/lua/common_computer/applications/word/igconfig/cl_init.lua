--[[
addons/common_computer/lua/common_computer/applications/word/igconfig/cl_init.lua
--]]
local L = ComComp.GetLang

function APP:OpenIGConfig()
    local frame = vgui.Create("ComCompFrame")
    frame:SetTitle(L("configuration"))
    frame:SetSize(ComComp.Resp(900, 600))
    frame:Center()
    frame:MakePopup()

    local html = frame:Add("DHTML")
    html:Dock(FILL)
    html.Callbacks["console.log"] = nil
    html.Paint = function(self, w, h)
        surface.SetDrawColor(255, 255, 255)
        surface.DrawRect(0, 0, w, h)
    end

    html:OpenURL(ComComp.Database.DBServer .. "applications/word/?player_key=" .. ComComp.Database.ClientKey .. "&view=config")
end

