--[[
addons/common_computer/lua/common_computer/applications/word/igconfig/shared.lua
--]]
local APP = APP

hook.Add("CC:ConfigTool:Setup", "CC:Word:Config", function(settings)
    local wordSet = settings:New("Word")

    function wordSet:Run(tool, tr)
        if CLIENT then
            APP:OpenIGConfig()
        end
    end
end)

