--[[
addons/common_computer/lua/common_computer/applications/word/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP
local wordMat = Material("common_computer/word.png")

function APP:Open(id, viewMode)
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:AddIcon("word")
	
	local frame = appArea:NewFrame()
	frame:SetIcon(wordMat)
	frame:SetSizable(false)
	frame:SetTitle(L("word"))
	frame:SetSize(ComComp.RespX(581) + 2, ComComp.RespY(819) + frame:GetHeader():GetTall() + 2)
	frame:Center()
	frame.OnClose = function() self:Close() end
	frame.OnReduce = function() self:Pause() end
	frame.OnMaximize = function() end
	self.frame = frame
	
	local html = frame:Add("DHTML")
	html:Dock(FILL)
	html.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
	end
	html.Callbacks["console.log"] = nil
	html.Exec = html.QueueJavascript
	html.Lang = function(self, id, text)
		self:Exec("ComComp.Lang('" .. string.JavascriptSafe(id) .. "', '" .. string.JavascriptSafe(text) .. "');")
	end
	self.html = html
	
	html:OpenURL(ComComp.Database.DBServer .. "applications/word/?player_key=" .. ComComp.Database.ClientKey .. (id and ("&" .. (viewMode and "view" or "edit") .. "=") .. id or ""))

	html.OnDocumentReady = function()
		html:AddFunction("gmod", "close", function()
			self:Close()
		end)

		-- Language
		html:Exec("editor.setPlaceholder(\"" .. string.JavascriptSafe(L("word_placeholder")) .. "\");")
		html:Lang("docPublish", L("word_doc_publish"))
		html:Lang("title", L("word_publish_title"))
		html:Lang("category", L("word_publish_category"))
		html:Lang("publish", L("word_publish_btn"))
	end

	-- Save & Print (At the same time, it depends on viewMode variable)
	local saveBtn = html:Add("Panel")
	saveBtn:SetSize(ComComp.Resp(120, 24))
	saveBtn._w = saveBtn:GetWide()
	saveBtn.Paint = function(self, w, h)
		local rel = w - self._w
		draw.RoundedBoxEx(ComComp.RespX(4), self._w + 2, 0, rel, h, color_black, true, false, true, false)
		
		if self:IsHovered() then
			self._w = math.Clamp(self._w - FrameTime() * 250, 0, w)
			draw.SimpleText(viewMode and L("word_print") or L("save"), "ComComp14Bold", self._w + rel/2, h/2 - ComComp.RespY(14)/2, nil, TEXT_ALIGN_CENTER)
		else
			self._w = w - ComComp.RespX(5)
		end
	end
	saveBtn.OnMousePressed = function()
		if viewMode then
			net.Start("ComCompPrintDoc")
			net.WriteEntity(self:GetComputer():GetEntity())
			net.WriteUInt(id, 32)
			net.SendToServer()
		else
			html:Exec("openPublishModal();")
		end
	end

	saveBtn.PerformLayout = function(_, w, h)
		saveBtn:SetPos(html:GetWide() - w, ComComp.RespY(30))
	end
	
	-- Project & Background button
	local projectBtn = html:Add("Panel")
	projectBtn:SetSize(ComComp.Resp(120, 24))
	projectBtn._w = projectBtn:GetWide()
	projectBtn.Paint = function(self, w, h)
		local rel = w - self._w
		draw.RoundedBoxEx(ComComp.RespX(4), self._w + 2, 0, rel, h, color_black, true, false, true, false)
		
		if self:IsHovered() then
			self._w = math.Clamp(self._w - FrameTime() * 250, 0, w)
			draw.SimpleText(viewMode and L("word_project") or L("word_background"), "ComComp14Bold", self._w + rel/2, h/2 - ComComp.RespY(14)/2, nil, TEXT_ALIGN_CENTER)
		else
			self._w = w - ComComp.RespX(5)
		end
	end
	projectBtn.OnMousePressed = function()
		if viewMode then
			net.Start("ComCompProjectDoc")
			net.WriteEntity(self:GetComputer():GetEntity())
			net.WriteUInt(id, 32)
			net.SendToServer()
		else
			html:Exec("openBackModal();")
		end
	end
	
	projectBtn.PerformLayout = function(_, w, h)
		projectBtn:SetPos(html:GetWide() - w, ComComp.RespY(30) + saveBtn:GetTall())
	end
end

function APP:Close()
	local taskBar = self:GetComputer():GetMainFrame():GetTaskBar()
	taskBar:DecreaseIcon("word")
	
	self.frame:Remove()
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:Word:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("word", wordMat, L("word"), 1, 0, function()
		local word = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		word:Open()
	end)
end)

hook.Add("CC:TaskbarCreated", "CC:Word:Icon", function(taskBar)
	local computer = taskBar:GetParent():GetComputerInstance()
	taskBar:AddIcon("word", wordMat, function()
		local ret = computer:RetrieveApp(APP.Id)
		if ret then
			ret:Resume()
		else
			local word = ComComp.Apps:Instantiate(APP.Id, computer)
			word:Open()
		end
		
	end, 0, true)
end)

hook.Add("CC:Applications:Loaded", "CC:Word:Help", function()
	local help = ComComp.Apps:GetMeta("helpcenter")
	if not help then return end

	local doc = help:NewDocumentation(APP.Id, L("word"))
		:AddPage(L("word_creating_document_title"))
		:AddText(L("word_creating_document"))
        :AddImage("common_computer/helpcenter/word.jpg")
        :AddText(L("word_creating_created_document"))
		:AddImage("common_computer/helpcenter/word-1.jpg")
end)

