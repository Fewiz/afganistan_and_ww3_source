--[[
addons/common_computer/lua/common_computer/applications/word/shared.lua
--]]
ComComp.ThirdInclude(APP.Path .. "igconfig/")

