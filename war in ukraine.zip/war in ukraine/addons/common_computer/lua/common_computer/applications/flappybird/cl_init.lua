--[[
addons/common_computer/lua/common_computer/applications/flappybird/cl_init.lua
--]]
local L = ComComp.GetLang
local APP = APP
local Builder = APP:GetBuilder()

local RespX = ComComp.RespX
local RespY = ComComp.RespY
local Resp = ComComp.Resp

local backMat = Material("common_computer/flappy/background-day.png")
local pipeMat = Material("common_computer/flappy/pipe-green.png")
local groundMat = Material("common_computer/flappy/base.png", "noclamp")
local playMat = Material("common_computer/flappy/play-button.png")
local birdMat = {
	Material("common_computer/flappy/yellowbird-downflap.png"),
	Material("common_computer/flappy/yellowbird-midflap.png"),
	Material("common_computer/flappy/yellowbird-upflap.png")
}

function APP:Open(imagePath)
	local mainFrame = self:GetComputer():GetMainFrame()
	local appArea = mainFrame:GetAppArea()
	local taskBar = mainFrame:GetTaskBar()

	taskBar:AddIcon("flappy", birdMat[1], function() -- Add the icon to the taskbar
		local app = self:GetComputer():RetrieveApp(self.Id)
		if app then
			app:Resume()
		end
	end, 1, false)
	
	-- Creating the new frame
	local frame = appArea:NewFrame()
	frame:SetIcon(birdMat[1])
	frame:SetSize(RespX(288) + 2, RespY(512) + frame:GetHeader():GetTall() + 2)
	frame:Center()
	frame:SetSizable(false)
	frame:SetTitle(L("flappy"))
	frame.OnMaximize = function()
		-- Nothing
	end
	frame.OnClose = function()
		self:Close()
	end
	frame.OnReduce = function()
		self:Pause()
	end
	frame.OnRemove = function()
		-- Putting that here in case APP:Close isn't called :)
		net.Start("ComCompFlappy")
		net.WriteEntity(self:GetComputer():GetEntity())
		net.WriteUInt(APP.GAME_LEAVE, 2)
		net.SendToServer()
	end
	self.frame = frame

	-- Notify the server that the app is launched
	net.Start("ComCompFlappy")
	net.WriteEntity(self:GetComputer():GetEntity())
	net.WriteUInt(APP.GAME_JOIN, 2)
	net.SendToServer()

	--[[
		GAME LOGIC
	]]

	local Pipes = {}
	local Birds = {}
	local MVP -- Look at the net receiver for the structure

	net.Receive("ComCompFlappy", function(len)
		if len == 46 then -- Normally, only jump
			local ply = net.ReadEntity()
			if ply == LocalPlayer() then return end

			local bird = Birds[ply]
			if not bird then return end	

			local tick = net.ReadUInt(23)
			local expectedPos = net.ReadUInt(7)

			Builder.SimulateJump(bird, tick, expectedPos/100)
			bird.Rotation = APP.JumpRotation
		else
			local mode = net.ReadUInt(2)
			if mode == APP.GAME_JOIN then -- Used to receive MVP
				local sid64 = net.ReadString()
				local score = net.ReadUInt(14)

				steamworks.RequestPlayerInfo(sid64, function(steamName)
					MVP = {
						Name = steamName,
						Score = score
					}
				end)
			elseif mode == APP.BIRD_START then
				local ply = net.ReadEntity()
				if not IsValid(ply) then return end

				local nBird = Builder.NewBird()
				local started = net.ReadUInt(23)
				nBird.Started = started

				Builder.PhysIterate(nBird, engine.TickInterval(), engine.TickCount() - started)

				Birds[ply] = nBird

				if LocalPlayer() == ply then
					-- Reset pipes
					Pipes = {}
				end
			elseif mode == APP.BIRD_DEAD then
				local ply = net.ReadEntity()
				if not IsValid(ply) then return end

				local pBird = Birds[ply]
				if not pBird then return end

				pBird.Dead = CurTime()
			end
		end
	end)

	hook.Add("Tick", frame, function()
		local lBird = Birds[LocalPlayer()]
		if not lBird then return end

		local localBirdTick = engine.TickCount() - lBird.Started
		local dt = engine.TickInterval()

		if (localBirdTick % ComComp.SecondsToTicks(1.5) == 0) and not lBird.Dead then
			local _, switch = Builder.NewPipe(Pipes, localBirdTick)
			if switch then
				lBird.Score = lBird.Score + 1
			end
		end

		for k, v in pairs(Birds) do
			Builder.PhysIterate(v, dt)

			if not v.Dead then
				v.Rotation = math.Clamp(v.Rotation + APP.RotationSpeed * dt, -90, APP.JumpRotation)
			end
		end
	end)

	--[[
		GAME DRAW
	]]

	local game = frame:Add("Panel")
	game:Dock(FILL)
	game.OnMousePressed = function()
		local lBird = Birds[LocalPlayer()]
		if not lBird or lBird.Dead then
			net.Start("ComCompFlappy")
			net.WriteEntity(self:GetComputer():GetEntity())
			net.WriteUInt(APP.BIRD_START, 2)
			net.SendToServer()
			return
		end

		net.Start("ComCompFlappy")
		net.WriteUInt(engine.TickCount(), 23) -- compressed to 23 or 32 bits but 31 unsigned so https://github.com/ValveSoftware/source-sdk-2013/blob/0d8dceea4310fde5706b3ce1c70609d72a38efdf/mp/src/public/globalvars_base.h#L64
		net.WriteUInt(lBird.PosY * 100, 7)
		net.SendToServer()

		lBird.Velocity = APP.JumpPower
		lBird.Rotation = APP.JumpRotation
	end
	game.Paint = function(self, w, h)
		local lBird = Birds[LocalPlayer()]
		local floorHeight = APP.GroundHeight * h
		local BirdWidth = APP.BirdHitBoxX * w
		local BirdHeight = APP.BirdHitBoxY * h

		surface.SetDrawColor(255, 255, 255)
		surface.SetMaterial(backMat)
		surface.DrawTexturedRect(0, 0, w, h)

		-- Draw pipes
		surface.SetMaterial(pipeMat)

		local PipeMatWidth = pipeMat:Width()
		local PipeMatHeight = pipeMat:Height()
		for i = 1, 2 do
			local pipe = Pipes[i]
			if not pipe then goto con end
			
			local x = w - ((lBird.Dead and lBird.Dead or CurTime()) - pipe.Created) * APP.PipeSpeed * w
			local y = h * pipe.Value

			surface.DrawTexturedRectUV(x, -RespY(PipeMatHeight) + y, APP.PipeWidth * w, RespY(PipeMatHeight), 0, 1, 1, 0)
			surface.DrawTexturedRect(x, y + APP.PipeBetweenDist * h, APP.PipeWidth * w, RespY(PipeMatHeight))
			
			::con::
		end

		local GroundMatWidth = groundMat:Width()
		local GroundMatHeight = groundMat:Height()
		local GroundScroll = (lBird and not lBird.Dead) and ((CurTime() * APP.PipeSpeed * w)/GroundMatWidth) or 0

		surface.SetMaterial(groundMat)
		surface.DrawTexturedRectUV(0, h - floorHeight, w, floorHeight, GroundScroll, 0, GroundScroll + w/GroundMatWidth, floorHeight/GroundMatHeight)

		if lBird then
			for k, v in pairs(Birds) do
				if not IsValid(k) then goto con end

				local tps = 1/engine.TickInterval()
				local lStart = lBird.Started/tps
				local vStart = v.Started/tps
				lStart = lBird.Dead and (CurTime() - (lBird.Dead - lStart)) or lStart
				vStart = v.Dead and (CurTime() - (v.Dead - vStart)) or vStart

				local PosX = (lStart - vStart) * APP.PipeSpeed * w + APP.BirdX * w

				if PosX > w or PosX + BirdWidth < 0 then goto con end -- Don't draw it if we can't see it..

				if v == lBird then
					surface.SetDrawColor(255, 255, 255)
				else
					surface.SetDrawColor(255, 255, 255, 130)
					draw.SimpleText(k:Name(), "ComComp16", PosX + BirdWidth, v.PosY * h - RespY(16 + 2), nil, TEXT_ALIGN_CENTER)
				end

				local matIndex = v.Dead and 1 or math.floor((TimedSin(1.2, 0, 1, 0) + 1)/2 * 3 + 1)
				surface.SetMaterial(birdMat[matIndex])
				surface.DrawTexturedRectRotated(PosX + BirdWidth/2, v.PosY * h + BirdHeight/2, BirdWidth, BirdHeight, v.Rotation)

				::con::
			end

			if not lBird.Dead then
				if MVP then
					draw.SimpleText(string.format(L("flappy_mvp"), MVP.Name, MVP.Score), "ComComp22", RespX(6), RespY(6))
				end
				draw.SimpleText(lBird.Score, "ComComp24", w - RespX(6), RespY(6), nil, TEXT_ALIGN_RIGHT)
			end
		end

		if not lBird or lBird.Dead then
			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(playMat)

			local PlayMatWidth = RespX(playMat:Width() * 2.5)
			local PlayMatHeight = RespY(playMat:Height() * 2.5)
			surface.DrawTexturedRect(w/2 - PlayMatWidth/2, h - PlayMatHeight * 4.5 + TimedSin(0.7, 0, 1, 0) * RespY(4), PlayMatWidth, PlayMatHeight)

			local _, tH = draw.SimpleText(L("flappy_play"), "ComComp32", w/2, PlayMatHeight * 2.5, nil, TEXT_ALIGN_CENTER)
			if lBird then
				draw.SimpleText(string.format(L("flappy_score"), lBird.Score), "ComComp22", w/2, PlayMatHeight * 2.5 + tH, nil, TEXT_ALIGN_CENTER)
			end
		end
	end
end

function APP:Close()
	local mainFrame = self:GetComputer():GetMainFrame()
	local taskBar = mainFrame:GetTaskBar()
	taskBar:DecreaseIcon("flappy")
	self.frame:Remove()
	
	self:GetComputer():RemApp(self)
end

function APP:Pause()
	self.frame:SetVisible(false)
end

function APP:Resume()
	if self.frame:IsVisible() then
		self:Pause()
		return
	end
	self.frame:SetVisible(true)
end

hook.Add("CC:DesktopCreated", "CC:FlappyOnline:Icon", function(computerFrame)
	local icon = computerFrame:AddDesktopIcon("flappy", birdMat[1], L("flappy"), 0, 2, function()
		local flappy = ComComp.Apps:Instantiate(APP.Id, computerFrame:GetComputerInstance())
		flappy:Open()
	end)
end)

