--[[
addons/common_computer/lua/common_computer/applications/flappybird/shared.lua
--]]
local APP = APP

-- The height and width is represented between 0 and 1
APP.Acceleration = 2.5 -- Gravity
APP.PipeSpeed = 0.5 -- Unit per seconds
APP.PipeBetweenDist = 0.24
APP.PipeHeaderHeight = 32/512 -- Default is 24/512 but it makes the game so hard
APP.PipeWidth = 52/288 -- 52 is the width of the texture
APP.JumpPower = -0.65
APP.BirdX = 0.1
APP.BirdHitBoxX = 38/288
APP.BirdHitBoxY = 28/512
APP.GroundHeight = 56/512

if CLIENT then
    APP.JumpRotation = 40
    APP.RotationSpeed = -105
end

-- Network enums (TAP happen when there's no data)
APP.GAME_JOIN = 0
APP.GAME_LEAVE = 1
APP.BIRD_START = 2
APP.BIRD_DEAD = 3

local GameBuilder = {}

function GameBuilder.NewBird()
    local nBird = {}
    nBird.Started = engine.TickCount()
    nBird.PosY = 0.5 - APP.BirdHitBoxY/2 -- Center the bird
    nBird.Velocity = 0
    nBird.Score = 0

    -- Extra vars
    if SERVER then
        nBird.Pipes = {}
    else
        nBird.Dead = false
        nBird.Rotation = 0 -- Not used serverside !
    end

    return nBird
end

function GameBuilder.NewPipe(container, seed) -- Max size of the container -> 2 (We never see more than 2 pipes in Flappy Bird)
    -- Move the first pipe to the key "2"
    local fPipe = container[1]
    if fPipe then
        container[2] = fPipe
    end

    local nPipe = {}
    nPipe.Created = CurTime()
    nPipe.Value = util.SharedRandom("cc_flappy", APP.PipeHeaderHeight, 1 - APP.PipeBetweenDist - APP.PipeHeaderHeight - APP.GroundHeight, seed)
    
    container[1] = nPipe

    return nPipe, fPipe ~= nil
end

function GameBuilder.PhysIterate(bird, dt, num)
    if bird.PosY + APP.BirdHitBoxY > 1 - APP.GroundHeight then
        bird.Velocity = 0
    else
        bird.Velocity = bird.Velocity + APP.Acceleration * dt
    end

	bird.PosY = bird.PosY + bird.Velocity * dt

    if num and num > 1 then
        GameBuilder.PhysIterate(bird, dt, num - 1)
    end
end

function GameBuilder.SimulateJump(bird, tick, expectedPos)
	if CLIENT or math.abs(bird.PosY - expectedPos) < 0.1 then -- Client trying to fuck us x1
		bird.PosY = expectedPos
	end

	bird.Velocity = APP.JumpPower

	-- Physics "reconciliation"
	local elapsedTick = engine.TickCount() - tick
    local dt = engine.TickInterval()

	if CLIENT or elapsedTick < math.Round((1/dt)/2) then -- If more than 500ms ping, the player is trying to fuck us x2
		APP:GetBuilder().PhysIterate(bird, dt)
	end
end

-- Builder's getter
function APP:GetBuilder()
    return GameBuilder
end

