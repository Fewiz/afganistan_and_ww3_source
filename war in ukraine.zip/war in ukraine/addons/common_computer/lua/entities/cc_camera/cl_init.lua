--[[
addons/common_computer/lua/entities/cc_camera/cl_init.lua
--]]
include("shared.lua")

local lightMat = Material("sprites/light_ignorez")

function ENT:Initialize()
	self.pixHandle = util.GetPixelVisibleHandle()
end

function ENT:Draw()
    self:DrawModel()

    -- Draw a red sprite when the camera is used by a player
    if self:GetCamUsed() then
        local pos, ang = self:GetViewPos()
        pos = pos + ang:Up() * -2.35

        local vis = util.PixelVisible(pos, 1, self.pixHandle)

		render.SetMaterial(lightMat)
        render.DrawSprite(pos, 4, 4, Color(255, 0, 0, vis * 255))
        render.DrawSprite(pos, 10, 10, Color(255, 0, 0, vis * 20))
    end
end


