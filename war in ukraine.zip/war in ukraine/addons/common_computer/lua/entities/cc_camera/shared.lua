--[[
addons/common_computer/lua/entities/cc_camera/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = ComComp.GetLang("camera")
ENT.Spawnable = true
ENT.Author = "Feeps"
ENT.Category = "Common Computer"
ENT.Editable = true

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "CamName", {
        KeyName = "Name",
    	Edit = {
            type = "Generic",
            waitforenter = true
        }
    })
    self:NetworkVar("Bool", 0, "CamUsed")
    self:NetworkVar("Entity", 0, "CamOwner") -- For Sandbox support
    self:NetworkVar("Entity", 1, "CamCoOwner")
end

function ENT:GetViewPos()
    local bone = self:LookupBone("rot")
    if not bone then return end

    local pos, ang = self:GetBonePosition(bone)
    pos = pos + ang:Up() * -7
    pos = pos + ang:Right() * -5.6

    ang:RotateAroundAxis(ang:Right(), -90)
    ang:RotateAroundAxis(ang:Forward(), -90)

    return pos, ang
end

function ENT:GetCamBonePosition()
    local bone = self:LookupBone("rot")
    if not bone then return end

    local pos, ang = self:GetBonePosition(bone)
    return pos, ang, bone
end

