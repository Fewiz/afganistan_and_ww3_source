--[[
addons/common_computer/lua/entities/cc_phone/cl_init.lua
--]]
local L = ComComp.GetLang

include("shared.lua")

local aColor = Color(31, 33, 31)
local bColor = Color(73, 84, 66)

local shownPerPage = 4

function ENT:CreatePanel()
    local page = 0

    local panel = vgui.Create("DPanel")
    panel:SetSize(55, 100)
    panel:SetPaintedManually(true)
    panel.List = {}

    local lClick = 0
    local function onClick(fnc) -- Used to make a delay between clicks
        return function()
            if (lClick + 0.1) <= CurTime() then
                lClick = CurTime()
                fnc()
            end
        end
    end

    local upBtn = panel:Add("Panel")
    upBtn:Dock(TOP)
    upBtn:SetTall(14)
    upBtn.Paint = function(self, w, h)
        draw.SimpleText("▲", "DermaDefault", w/2, 0, aColor, TEXT_ALIGN_CENTER)
    end
    upBtn.OnMousePressed = onClick(function()
        page = math.Clamp(page - 1, 0, math.floor(#panel.List/shownPerPage))
    end)

    local downBtn = panel:Add("Panel")
    downBtn:Dock(BOTTOM)
    downBtn:SetTall(14)
    downBtn.Paint = function(self, w, h)
        draw.SimpleText("▼", "DermaDefault", w/2, 1, aColor, TEXT_ALIGN_CENTER)
    end
    downBtn.OnMousePressed = onClick(function()
        page = math.Clamp(page + 1, 0, math.floor(#panel.List/shownPerPage))
    end)

    for i = 1, shownPerPage do
        local pBtn = panel:Add("Panel")
        pBtn:Dock(TOP)
        pBtn:SetTall((panel:GetTall() - downBtn:GetTall() - upBtn:GetTall())/shownPerPage)
        pBtn.GetPhone = function()
            return panel.List[i + page * shownPerPage]
        end
        pBtn.Paint = function(self, w, h)
            local phone = pBtn:GetPhone()
            if IsValid(phone) then
                if self.Hovered then
                    surface.SetDrawColor(bColor:Unpack())
                    surface.DrawRect(0, 0, w, h)
                end
                draw.SimpleText(phone:GetPhoneName():sub(1, 9), "Default", w/2, h/2, self.Hovered and aColor or bColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
        pBtn.OnMousePressed = onClick(function()
            local phone = pBtn:GetPhone()
            if IsValid(phone) then
                net.Start("ComCompPhoneCall")
                net.WriteEntity(self)
                net.WriteEntity(phone)
                net.SendToServer()
            end
        end)
    end

    panel.Paint = function(self, w, h)
        surface.SetDrawColor(aColor:Unpack())
        surface.DrawRect(0, upBtn:GetTall(), w, h - upBtn:GetTall() - downBtn:GetTall())

        surface.SetDrawColor(bColor:Unpack())
        surface.DrawRect(0, 0, w, upBtn:GetTall())
        surface.DrawRect(0, h - downBtn:GetTall(), w, downBtn:GetTall())
    end

    panel.UpdatePhones = function()
        panel.List = ents.FindByClass("cc_phone")
        table.RemoveByValue(panel.List, self)
    end

    self.panel = panel

    return panel
end

function ENT:OnRemove()
    if IsValid(self.panel) then
        self.panel:Remove()
    end
end

function ENT:Draw()
    self:DrawModel()

    if IsValid(self:GetInCall()) then
        local pos = self:GetPos()
        local angles = self:GetAngles()
        angles:RotateAroundAxis(angles:Up(), 180)

        pos = pos + angles:Forward() * -2.7
        if not self:IsWall() then
            pos = pos + angles:Up() * 3.62
            pos = pos + angles:Right() * -4.33

            angles:RotateAroundAxis(angles:Forward(), 45)
        else
            pos = pos + angles:Up() * 1.25
            pos = pos + angles:Right() * -5.05
        end

        cam.Start3D2D(pos, angles, 0.025)
            surface.SetDrawColor(51, 59, 45)
            surface.DrawRect(0, 0, 200, 56)

            surface.SetTextPos(5, 0)
            surface.SetFont("DermaDefaultBold")
            surface.SetTextColor(0, 0, 0)

            if self:GetAnswered() then
                surface.DrawText(L("phone_incall"))
            else
                surface.DrawText(self:GetIsCaller() and L("phone_dialing") or L("phone_incomingcall"))
            end

            surface.SetFont("DermaDefault")
            surface.SetTextPos(5, 13)
            surface.DrawText(self:GetInCall():GetPhoneName())

            draw.SimpleText(os.date("%H:%M"), "DermaDefault", 200 - 10, 0, color_black, TEXT_ALIGN_RIGHT)
            draw.SimpleText("====", "DermaDefaultBold", 100 + 160 * TimedSin(1, 0, 1, 1), 56 - 20, color_black, TEXT_ALIGN_CENTER)
        cam.End3D2D()
    end
end

hook.Add("PreDrawHUD", "CC:Phone:Tooltip", function()
    local ent = LocalPlayer():GetEyeTrace().Entity
    if (IsValid(ent) and ent:GetClass() == "cc_phone" and ent:IsInRange(LocalPlayer()) and IsValid(ent:GetInCall())) then

        cam.Start2D()
            local data2D = ent:GetPos():ToScreen()
            if data2D.visible then
                if(not (ent:GetIsCaller() and not ent:GetAnswered())) then
                    ComComp.DrawKey(ent:GetAnswered() and L("phone_decline") or L("phone_answer"), "ComComp20", input.LookupBinding("use"), data2D.x, data2D.y, 32)
                end
            end
	    cam.End2D()
    end
end)

hook.Add("PostDrawTranslucentRenderables", "CC:Phone:3DMenu", function(bDepth, bSkybox)
    if bSkybox then return end

    local phonesEnt = ents.FindByClass("cc_phone")
    for _, ent in ipairs(phonesEnt) do
        if not ent:IsInRange(LocalPlayer()) then goto con end

        local panel = ent.panel
        if not IsValid(panel) then
            panel = ent:CreatePanel()
        end

        if (#panel.List ~= #phonesEnt - 1) then
            panel:UpdatePhones(phonesEnt)
        end

        local pos = ent:GetPos()
        local angles = ent:GetAngles()

        pos = pos + angles:Forward() * (ent:IsWall() and -4 or -6.5)
        pos = pos + angles:Up() * 1
        pos = pos + angles:Right() * 5

        angles:RotateAroundAxis(angles:Up(), 180)

        if ent:IsWall() then
            angles:RotateAroundAxis(angles:Right(), 15)
        end

        vgui.Start3D2D(pos, angles, 0.1)
            panel:Paint3D2D()
        vgui.End3D2D()

        ::con::
    end
end)

hook.Add("CC:Applications:Loaded", "CC:Phone:Help", function()
	local help = ComComp.Apps:GetMeta("helpcenter")
	if not help then return end

	local doc = help:NewDocumentation("phone", L("phone"))
		:AddPage(L("phone_configure_title"))
		:AddText(L("phone_configure"))
        :AddImage("common_computer/helpcenter/phone.jpg")
end)

