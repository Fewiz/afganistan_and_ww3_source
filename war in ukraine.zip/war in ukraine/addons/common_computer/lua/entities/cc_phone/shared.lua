--[[
addons/common_computer/lua/entities/cc_phone/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = ComComp.GetLang("phone")
ENT.Spawnable = true
ENT.Author = "Feeps"
ENT.Category = "Common Computer"
ENT.Editable = true

ENT.AvailableDistance = 150
ENT.RingTime = 25

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "PhoneName", {
        KeyName = "phone_name",
        Edit = {
            type = "Generic"
        } 
    })
    self:NetworkVar("Bool", 3, "WallMode", {
        KeyName = "wall_mode",
        Edit = {
            type = "Boolean"
        } 
    })

    self:NetworkVar("Entity", 0, "InCall")
    self:NetworkVar("Bool", 0, "Answered")
    self:NetworkVar("Bool", 1, "IsCaller")

    self:SetPhoneName("Unnamed")

    if SERVER then
        self:NetworkVarNotify("WallMode", function(_, name, old, new)
            self:SetBodygroup(0, new and 1 or 0)
		end)
    end
end


local distToSqr = FindMetaTable("Vector").DistToSqr
local getPos = FindMetaTable("Entity").GetPos
local tickCount = engine.TickCount

ENT.RangeCache = {}
function ENT:IsInRange(ent)
    local cache = self.RangeCache[ent]
    local tickCount = tickCount()

    if cache and cache.Tick == tickCount then
        return cache.Value
    else
        local inRange = distToSqr(getPos(self), getPos(ent)) <= self.AvailableDistance * self.AvailableDistance

        self.RangeCache[ent] = {
            Value = inRange,
            Tick = tickCount
        }

        return inRange
    end
end

function ENT:IsWall()
    return self:GetBodygroup(self:FindBodygroupByName("mybody")) == 1
end

sound.Add( {
    name = "cc_phone_ring",
    channel = CHAN_STATIC,
    level = 90,
    sound = "common_computer/phone/ring.ogg"
})

sound.Add( {
    name = "cc_phone_wait",
    channel = CHAN_STATIC,
    level = 90,
    sound = "common_computer/phone/ring_wait.ogg"
})

sound.Add( {
    name = "cc_phone_pickup",
    channel = CHAN_STATIC,
    level = 90,
    sound = "common_computer/phone/pick_up.ogg"
})

sound.Add( {
    name = "cc_phone_putdown",
    channel = CHAN_STATIC,
    level = 90,
    sound = "common_computer/phone/put_down.ogg"
})

