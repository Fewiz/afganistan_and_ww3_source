--[[
addons/common_computer/lua/entities/cc_voxel/cl_init.lua
--]]
include("shared.lua")

function ENT:Draw()
    if self.voxObj then
		local cs = self.voxObj:GetCanvasSize()
		local max = math.max(cs.x, cs.y, cs.z)
		local scale = 12/(max + 1)

        local offsetMat = Matrix()
        offsetMat:SetTranslation(-self:OBBMaxs() + Vector(0.5, 0.5, 0.5) * scale)
        offsetMat:Scale(Vector(scale, scale, scale))
        
		cam.PushModelMatrix(self:GetWorldTransformMatrix() * offsetMat)
            self.voxObj:Draw()
		cam.PopModelMatrix()
    else
        render.DrawWireframeBox(self:GetPos(), self:GetAngles(), self:OBBMins(), self:OBBMaxs(), color_white, true)
    end

    local dlight = DynamicLight(self:EntIndex())
	if dlight then
		dlight.pos = self:GetPos()
		dlight.r = 255
		dlight.g = 255
		dlight.b = 255
		dlight.brightness = 1
		dlight.Decay = 1000
		dlight.Size = 64
		dlight.DieTime = CurTime() + 1
	end
end

net.Receive("ComCompVoxelData", function(len)
    local ent = net.ReadEntity()
    local data = net.ReadData((len - 16)/8)

    local bytes = {}
    for i = 1, #data do
        bytes[i] = string.byte(data, i)
    end
    
    local voxObj = ComComp.NewCCVox(0, 0, 0)
    voxObj:ImportData(bytes)

    ent.voxObj = voxObj
end)

