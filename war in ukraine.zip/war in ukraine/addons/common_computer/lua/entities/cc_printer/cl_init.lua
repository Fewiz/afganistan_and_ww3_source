--[[
addons/common_computer/lua/entities/cc_printer/cl_init.lua
--]]
include("shared.lua")

function ENT:Draw()
	if self:GetPrinting() then
		local mat = ComComp.GetDocMat(self:GetDocId())
		if mat then
			render.MaterialOverrideByIndex(2, mat)
		end
	end

	self:DrawModel()
	render.ModelMaterialOverride(nil)
end

