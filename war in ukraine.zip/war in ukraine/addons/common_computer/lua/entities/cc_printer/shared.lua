--[[
addons/common_computer/lua/entities/cc_printer/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = ComComp.GetLang("printer")
ENT.Spawnable = true
ENT.Author = "Feeps"
ENT.Category = "Common Computer"
ENT.AutomaticFrameAdvance = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "Printing")
	self:NetworkVar("Int", 0, "DocId")
end

