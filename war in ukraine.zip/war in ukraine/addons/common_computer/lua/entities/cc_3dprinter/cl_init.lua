--[[
addons/common_computer/lua/entities/cc_3dprinter/cl_init.lua
--]]
include("shared.lua")

function ENT:Draw()
	self:DrawModel()
	
	if not self:GetPrinting() or self:GetCycle() < 0.12 then return end

	local bone = self:LookupBone("plateau")
	if not bone then return end

	local bMatrix = self:GetBoneMatrix(bone)
	if not bMatrix then return end

	local eAng = self:GetAngles()
	local ePos = self:GetPos()

	local normal = -eAng:Up()
	local dot = normal:Dot(ePos + eAng:Up() * 20.85)

	local oldEC = render.EnableClipping(true)
	render.PushCustomClipPlane(normal, dot)

	if self.DrawFnc then
		self.DrawFnc(bMatrix)
	end

	render.PopCustomClipPlane()
	render.EnableClipping(oldEC)
end

function ENT:PrintVoxel(voxObj)
	self.DrawFnc = function(bMatrix)
		local cs = voxObj:GetCanvasSize()
		local max = math.max(cs.x, cs.y, cs.z)
		local scale = 12/(max + 1)

		local s = Vector(scale, scale, scale)
		
		local sMatrix = Matrix()
		sMatrix:SetTranslation(Vector(-cs.x/2, -cs.y/2, 0.5) * s)
		sMatrix:Scale(s)

		local wMatrix = Matrix()
		wMatrix:SetTranslation(bMatrix:GetTranslation())
		wMatrix:Rotate(self:GetAngles())

		local mat = wMatrix * sMatrix

		cam.PushModelMatrix(mat)
			voxObj:Draw()
		cam.PopModelMatrix()
	end
end

function ENT:PrintStruct(id)
	local appMeta = ComComp.Apps:GetMeta("slicer")
	if not appMeta then return end

	local struct = appMeta:GetConfig()[id]
	if not struct then return end

	local ent = ents.CreateClientProp()
	ent:SetModel(struct.model)
	ent:SetModelScale(struct.scale)
	ent:SetNoDraw(true)
	ent:Spawn()

	timer.Simple(struct.printDur, function()
		if IsValid(ent) then
			ent:Remove()
		end
	end)

	self.DrawFnc = function(bMatrix)
		if not IsValid(ent) then return end
		
		local sMatrix = Matrix()
		sMatrix:SetTranslation(struct.posOffset - self.BOffset)
		sMatrix:SetAngles(struct.angOffset)

		local wMatrix = Matrix()
		wMatrix:SetTranslation(bMatrix:GetTranslation())
		wMatrix:SetAngles(self:GetAngles())

		local fMatrix = wMatrix * sMatrix

		ent:SetPos(fMatrix:GetTranslation())
		ent:SetAngles(fMatrix:GetAngles())
		ent:SetupBones()
		ent:DrawModel()
	end
end

net.Receive("ComCompPrint3dObject", function(len)
	local printer = net.ReadEntity()
	local isVoxel = net.ReadBool()

	if isVoxel then
		local data = net.ReadData(len - 16 - 1)

		local bytes = {}
		for i = 1, #data do
			bytes[i] = string.byte(data, i)
		end
	
		local voxObj = ComComp.NewCCVox(0, 0, 0)
		voxObj:ImportData(bytes)

		printer:PrintVoxel(voxObj)
	else
		printer:PrintStruct(net.ReadUInt(16))
	end
end)

