--[[
addons/common_computer/lua/entities/cc_3dprinter/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = ComComp.GetLang("3dprinter")
ENT.Spawnable = true
ENT.Author = "Feeps"
ENT.Category = "Common Computer"
ENT.AutomaticFrameAdvance = true

ENT.BOffset = Vector(1.959017, 0.000019, 8.771914) -- Offset from the bone and the tray

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "Printing")
	self:NetworkVar("Entity", 0, "PrintedEntity")
end

function ENT:IsAvailable()
	if self:GetPrinting() then
		return false
	end

	if IsValid(self:GetPrintedEntity()) and self:GetPrintedEntity():GetPos():DistToSqr(self:GetPos() + self:GetAngles():Up() * 13.5) <= 20 * 20 then
		return false
	end

	return true
end

