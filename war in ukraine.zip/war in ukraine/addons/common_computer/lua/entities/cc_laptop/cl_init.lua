--[[
addons/common_computer/lua/entities/cc_laptop/cl_init.lua
--]]
local L = ComComp.GetLang

include("shared.lua")

function ENT:Initialize()
	self:SetDrawScreen(true) -- Default
end

function ENT:Draw()
	self:DrawModel()

	if halo.RenderedEntity() ~= self then -- Avoid a strange rendering bug with stencils
		local cs = self:GetComputerInstance()
		if cs and self:GetDrawScreen() then -- Check if we can render the screen
			local frame = cs:GetMainFrame()
			if frame and IsValid(frame) and cs:IsPaused() then -- Check if the user isn't in the computer
				-- Only draw the computer if the player is in front of the screen
				local toPly = (EyePos() - self:GetCamPos()):GetNormalized()
				if toPly:Dot(self:GetAngles():Forward()) <= 0 then return end
				if EyePos():DistToSqr(self:GetPos()) >= 400 * 400 then return end

				local angles = self:GetAngles()
				angles:RotateAroundAxis(angles:Up(), 90)
				angles:RotateAroundAxis(angles:Forward(), 82.35)

				local pos = self:GetPos()
				pos = pos + angles:Right() * -13.5
				pos = pos + angles:Forward() * -10.3
				pos = pos + angles:Up() * -6.2---6.228

				cam.Start3D2D( pos, angles, 0.01074 * 1920/ComComp.GetComputedScrW())
					frame:PaintManual()
				cam.End3D2D()
			end
		end
	end
end

net.Receive("ComCompPress", function()
	local computer = net.ReadEntity()
	if not IsValid(computer) then return end

	local openComp = function(st)
		net.Start("ComCompPress")
		net.WriteEntity(computer)
		net.WriteBool(st)
		net.SendToServer()
	end

	local menu = ComComp.NewFastMenu()
	menu:ReleaseKey(input.GetKeyCode(input.LookupBinding("use")))
	menu:AddOption(L("use"), function()
		openComp(true)
	end)

	menu:AddOption(L("take"), function()
		openComp(false)
	end)
end)


