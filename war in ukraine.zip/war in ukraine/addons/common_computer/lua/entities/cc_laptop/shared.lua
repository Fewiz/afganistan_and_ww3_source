--[[
addons/common_computer/lua/entities/cc_laptop/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = ComComp.GetLang("laptop")
ENT.Spawnable = true
ENT.Author = "Feeps"
ENT.Category = "Common Computer"
ENT.AutomaticFrameAdvance = true

table.Merge(ENT, ComComp.BaseEntStruct)

function ENT:GetCamPos()
    local pos, ang = self:GetPos(), self:GetAngles()
    pos = pos + ang:Up() * 12.4 + ang:Forward() * -7.85
    
    return pos, ang
end

