--[[
addons/common_computer/lua/entities/cc_projector/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = ComComp.GetLang("projector")
ENT.Spawnable = true
ENT.Author = "Feeps"
ENT.Category = "Common Computer"
ENT.Editable = true

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "DocId")
	self:NetworkVar("Int", 1, "FOV", {
		KeyName = "FOV",
		Edit = {
			type = "Int",
			order = 1,
			min = 10,
			max = 150
		}	
	})
	self:NetworkVar("Float", 2, "Brightness", {
		KeyName = "Brightness",
		Edit = {
			type = "Float",
			order = 1,
			min = 0,
			max = 16
		}	
	})

	self:SetFOV(60)
	self:SetBrightness(2)
	
	if CLIENT then
		self:NetworkVarNotify("DocId", function(_, name, old, new)
			if old and IsValid(self.pt) then
				self.pt:Remove()
			end
		
			self.Pending = new
		end)
		
		self:NetworkVarNotify("FOV", function(_, name, old, new)
			if IsValid(self.pt) then
				self.pt:SetFOV(new) -- Update is in the thing hook :=)
			end
		end)
		
		self:NetworkVarNotify("Brightness", function(_, name, old, new)
			if IsValid(self.pt) then
				self.pt:SetBrightness(new)
			end
		end)
	end
end


