--[[
addons/common_computer/lua/entities/cc_projector/cl_init.lua
--]]
include("shared.lua")

local lMatrix = Matrix()
lMatrix:SetTranslation(Vector(7.1, 4.2, 2.8))

local lightMat = Material("sprites/light_ignorez")

function ENT:Initialize()
	self.pixHandle = util.GetPixelVisibleHandle()
end

function ENT:Draw()
	self:DrawModel()

	if IsValid(self.pt) then
		local startPos = self:GetStartPos()
		local vis = util.PixelVisible(startPos, 1, self.pixHandle)
		
		render.SetMaterial(lightMat)
		render.DrawSprite(startPos, 16, 16, Color(190, 190, 255, vis * 200 * math.Rand(0.6, 0.9)))
	end
end

function ENT:Think()
	if self.Pending and not IsValid(self.pt) then
		local mat = ComComp.GetDocMat(self.Pending, "UnlitGeneric")
		if mat then
			-- Creating a RenderTarget because we need to center the downloaded material
			local tex = GetRenderTarget("ComCompdProj" .. self.Pending, 1024, 1024)
			render.PushRenderTarget(tex)	
			render.ClearDepth()
			render.Clear(0, 0, 0, 0)

			-- Drawing only one time
			cam.Start2D()
				surface.SetDrawColor(255, 255, 255)
				surface.SetMaterial(mat)
				surface.DrawTexturedRect(250, 0, 581, 819)
			cam.End2D()

			render.PopRenderTarget()

			local pt = ProjectedTexture()
			self.pt = pt
			
			pt:SetTexture(tex)
			pt:SetFarZ(1000)
			pt:SetFOV(self:GetFOV())
		end
	end

	if IsValid(self.pt) then
		local startPos = self:GetStartPos()
		self.pt:SetPos(startPos)
		self.pt:SetAngles(self:GetAngles())
		self.pt:Update()
		
		local dlight = DynamicLight(self:EntIndex())
		if dlight then
			dlight.pos = startPos
			dlight.r = 120
			dlight.g = 120
			dlight.b = 120
			dlight.brightness = 1
			dlight.Decay = 2000
			dlight.Size = 64
			dlight.DieTime = CurTime() + 1
		end
	end
end

function ENT:GetStartPos()
	return (self:GetWorldTransformMatrix() * lMatrix):GetTranslation()
end

function ENT:OnRemove()
	if IsValid(self.pt) then
		self.pt:Remove()
	end
end

