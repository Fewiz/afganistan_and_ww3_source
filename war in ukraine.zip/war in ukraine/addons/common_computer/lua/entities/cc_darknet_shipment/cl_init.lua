--[[
addons/common_computer/lua/entities/cc_darknet_shipment/cl_init.lua
--]]
include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

