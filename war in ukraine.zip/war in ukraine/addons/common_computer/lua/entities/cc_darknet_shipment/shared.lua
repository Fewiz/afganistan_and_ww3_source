--[[
addons/common_computer/lua/entities/cc_darknet_shipment/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = "Darknet Shipment"
ENT.Category = "Common Computer"
ENT.Author = "Feeps"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true

