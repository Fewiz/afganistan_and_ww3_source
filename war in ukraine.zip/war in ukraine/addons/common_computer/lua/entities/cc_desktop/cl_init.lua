--[[
addons/common_computer/lua/entities/cc_desktop/cl_init.lua
--]]
local L = ComComp.GetLang

include("shared.lua")

function ENT:Initialize()
	self:SetDrawScreen(true) -- Default
end

function ENT:Draw()
	self:DrawModel()

	if halo.RenderedEntity() ~= self then -- Avoid a strange rendering bug with stencils
		local cs = self:GetComputerInstance()
		if cs and self:GetDrawScreen() then -- Check if we can render the screen
			local frame = cs:GetMainFrame()
			if frame and IsValid(frame) and cs:IsPaused() then -- Check if the user isn't in the computer
				-- Only draw the computer if the player is in front of the screen
				local toPly = (EyePos() - self:GetCamPos()):GetNormalized()
				if toPly:Dot(self:GetAngles():Forward()) <= 0 then return end
				if EyePos():DistToSqr(self:GetPos()) >= 400 * 400 then return end

				local angles = self:GetAngles()
				angles:RotateAroundAxis(angles:Up(), 90)
				angles:RotateAroundAxis(angles:Forward(), 180)
				angles:RotateAroundAxis(angles:Right(), -90)

				local pos = self:GetPos()
				pos = pos + angles:Right() * -24.34
				pos = pos + angles:Forward() * -12.05
				pos = pos + angles:Up() * -10

				cam.Start3D2D(pos, angles, 0.0169 * 1920/ComComp.GetComputedScrW())
					frame:PaintManual()
				cam.End3D2D()
			end
		end
	end
end

