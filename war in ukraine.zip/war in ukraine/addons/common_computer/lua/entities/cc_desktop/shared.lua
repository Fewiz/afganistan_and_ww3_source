--[[
addons/common_computer/lua/entities/cc_desktop/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = ComComp.GetLang("desktop_computer")
ENT.Spawnable = true
ENT.Author = "Feeps"
ENT.Category = "Common Computer"
ENT.AutomaticFrameAdvance = true

table.Merge(ENT, ComComp.BaseEntStruct)

function ENT:GetCamPos()
    local pos, ang = self:GetPos(), self:GetAngles()
    ang:RotateAroundAxis(ang:Right(), -90)
    ang:RotateAroundAxis(ang:Up(), 90)

    pos = pos + ang:Up() * 22 + ang:Forward() * -10.5 + ang:Right() * -4.2
    
    return pos, ang
end

