--[[
addons/common_computer/lua/entities/cc_paper/shared.lua
--]]
ENT.Type = "anim"
ENT.PrintName = "Paper"
ENT.Spawnable = false
ENT.Author = "Feeps"
ENT.Category = "Common Computer"

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "DocId")
end

