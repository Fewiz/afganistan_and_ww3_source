--[[
addons/common_computer/lua/entities/cc_paper/cl_init.lua
--]]
include("shared.lua")

function ENT:Draw()
	local mat = ComComp.GetDocMat(self:GetDocId())
	if mat then
		render.MaterialOverrideByIndex(0, mat)
	end
	
	self:DrawModel()
	render.MaterialOverrideByIndex(0, nil)
end

--[[
	Zoom to the paper when the player press E on it
]]

local lastPaper
net.Receive("ComCompOpenPaper", function(len)
	local paper = net.ReadEntity()
	if not IsValid(paper) then return end

	if IsValid(lastPaper) then
		lastPaper:SetNoDraw(false)
	end

	lastPaper = paper
	paper:SetNoDraw(true)

	local start = CurTime()
	local animPos = paper:GetPos()
	local animAng = paper:GetAngles()
	local restrainDir = LocalPlayer():GetAimVector()

	hook.Add("PostDrawTranslucentRenderables", "CC:Paper:Draw", function(bDepth, bSkybox)
		if bSkybox then return end

		local eyeDir = LocalPlayer():GetAimVector()
		local eyePos = LocalPlayer():GetShootPos()
		local toPaper = paper:GetPos() - eyePos
		local len = toPaper:Length()

		if len > 100 or eyeDir:Dot(toPaper)/len < math.cos(math.pi/5) then -- 36 degrees
			hook.Remove("PostDrawTranslucentRenderables", "CC:Paper:Draw")
			paper:SetNoDraw(false)
			return
		end

		local delta = (CurTime() - start)/2.5
		if delta < 1 then
			local restrainPos = eyePos + restrainDir * 15
			local restrainAng = eyeDir:Angle()
			restrainAng:RotateAroundAxis(restrainAng:Right(), 90)

			animPos = LerpVector(delta, animPos, restrainPos)
			animAng = LerpAngle(delta, animAng, restrainAng)
		end

		-- Idk why matrix doesn't work with Entity:DrawModel here
		-- Using Entity:SetPos instead ...
		local oldPos = paper:GetPos()
		local oldAngles = paper:GetAngles()

		paper:SetPos(animPos)
		paper:SetAngles(animAng)

		paper:SetupBones()
		paper:DrawModel()

		paper:SetPos(oldPos)
		paper:SetAngles(oldAngles)
	end)
end)

