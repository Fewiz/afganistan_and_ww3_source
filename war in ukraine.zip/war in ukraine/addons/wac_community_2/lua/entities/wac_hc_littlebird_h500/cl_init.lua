--[[
addons/wac_community_2/lua/entities/wac_hc_littlebird_h500/cl_init.lua
--]]
include('shared.lua')

ENT.thirdPerson = {
	distance = 400,
	position = Vector(0,0,50)
}

