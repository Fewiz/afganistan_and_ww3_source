--[[
addons/wac_community_2/lua/entities/wac_hc_mh53_pavelow/cl_init.lua
--]]
include('shared.lua')

ENT.thirdPerson = {
	distance = 1000
}

