--[[
addons/wac_community_2/lua/entities/wac_hc_mi35/cl_init.lua
--]]
include("shared.lua")

ENT.thirdPerson = {
	distance = 700
}

