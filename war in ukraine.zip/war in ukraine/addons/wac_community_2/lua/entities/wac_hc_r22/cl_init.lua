--[[
addons/wac_community_2/lua/entities/wac_hc_r22/cl_init.lua
--]]
include('shared.lua')

ENT.thirdPerson = {
	distance = 400
}


