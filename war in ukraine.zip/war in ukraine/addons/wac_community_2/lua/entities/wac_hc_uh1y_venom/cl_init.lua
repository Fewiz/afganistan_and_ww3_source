--[[
addons/wac_community_2/lua/entities/wac_hc_uh1y_venom/cl_init.lua
--]]
include("shared.lua")

ENT.thirdPerson = {
	distance = 500
}

