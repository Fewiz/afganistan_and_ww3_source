--[[
addons/wac_community_2/lua/entities/wac_hc_uh1y_venom/shared.lua
--]]
if not wac then return end

ENT.Base 				= "wac_hc_base"
ENT.Type 				= "anim"
ENT.PrintName			= "UH-1Y «Венон»"
ENT.Author				= "}{ornet/Vest"
ENT.Category			= "Воздушная техника"
ENT.Spawnable		= true
ENT.AdminSpawnable	= true

ENT.Model			= "models/flyboi/uh1yvenom/uh1yvenom_fb.mdl"
ENT.SmokePos		= Vector(-65,0,80)
ENT.FirePos			= Vector(-25,0,130)

ENT.TopRotor = {
	dir = -1,
	pos = Vector(-6.2,-1.5,140),
	model = "models/flyboi/uh1yvenom/venomrotorm_fb.mdl"
}

ENT.BackRotor = {
	dir = -1,
	pos = Vector(-357.5,5.5,134),
	model = "models/flyboi/uh1yvenom/venomrotort_fb.mdl"
}


ENT.Seats = {
	{
		pos=Vector(95, -20, 48),
		exit=Vector(90,-80,10),
		weapons={"Ракеты"},
	},
	{
		pos=Vector(95, 20, 48),
		exit=Vector(90,80,10),
	},
	{
		pos=Vector(-5, -45, 40),
		ang=Angle(0,-90,0),
		exit=Vector(-5,-80,10),
	},
	{
		pos=Vector(-5, 45, 40),
		ang=Angle(0,90,0),
		exit=Vector(-5,80,10),
	},
	
	
		{
		pos=Vector(54, 25, 46),
		ang=Angle(0,-90,0),
		exit=Vector(0,80,10),
	},
	{
		pos=Vector(54, -25, 46),
		ang=Angle(0,90,0),
		exit=Vector(0,-80,10),
	},
	
	
	
	
	
	
	
	
	
	
	
	{
		pos=Vector(17, -22, 46),   --------------   
		--ang=Angle(0,180,0),
		exit=Vector(0,80,10),
	},
	{
		pos=Vector(17, 22, 46),
		--ang=Angle(0,180,0),
		exit=Vector(0,-80,10),
	},
	{
		pos=Vector(17, 0, 46),
		--ang=Angle(0,180,0),
		exit=Vector(0,-80,10),
	},
	
}

ENT.Weapons = {
	["Ракеты"] = {
		class = "wac_pod_hydra",
		info = {
			Pods = {
				Vector(40.25,60,32.93),
				Vector(40.25,-60,32.93),
				Sequential = true,
			},
		}
	}
}

ENT.Camera = {
	model = "models/props_junk/PopCan01a.mdl",
	pos = Vector(155,2,25),
	offset = Vector(1,0,0),
	viewPos = Vector(7, 0, -5),
	maxAng = Angle(90, 90, 0),
	minAng = Angle(-5, -90, 0),
	seat = 2
}



ENT.Sounds={
	Start="WAC/Heli/ah1_start.wav",
	Blades="npc/attack_helicopter/aheli_rotor_loop1.wav",
	Engine="WAC/Heli/jet_whine.wav",
	MissileAlert="HelicopterVehicle/MissileNearby.mp3",
	MissileShoot="HelicopterVehicle/MissileShoot.mp3",
	MinorAlarm="HelicopterVehicle/MinorAlarm.mp3",
	LowHealth="HelicopterVehicle/LowHealth.mp3",
	CrashAlarm="HelicopterVehicle/CrashAlarm.mp3",
}


