--[[
addons/wac_community_2/lua/entities/wac_hc_ec655/cl_init.lua
--]]
include("shared.lua")

ENT.thirdPerson = {
	distance = 700
}

