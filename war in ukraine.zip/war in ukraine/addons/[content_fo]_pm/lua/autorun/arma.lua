--[[
addons/[content_fo]_pm/lua/autorun/arma.lua
--]]
player_manager.AddValidModel( "RFS1", "models/arma/rfsold_01.mdl" )
player_manager.AddValidHands( "RFS1", "models/arma/rfsold_01_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS1", "models/arma/rfsold_01.mdl" )

player_manager.AddValidModel( "RFS2", "models/arma/rfsold_02.mdl" )
player_manager.AddValidHands( "RFS2", "models/arma/rfsold_02_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS2", "models/arma/rfsold_02.mdl" )

player_manager.AddValidModel( "RFS3", "models/arma/rfsold_03.mdl" )
player_manager.AddValidHands( "RFS3", "models/arma/rfsold_03_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS3", "models/arma/rfsold_03.mdl" ) 

player_manager.AddValidModel( "RFS4", "models/arma/rfsold_04.mdl" )
player_manager.AddValidHands( "RFS4", "models/arma/rfsold_04_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS4", "models/arma/rfsold_04.mdl" ) 

player_manager.AddValidModel( "RFS5", "models/arma/rfsold_05.mdl" )
player_manager.AddValidHands( "RFS5", "models/arma/rfsold_05_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS5", "models/arma/rfsold_05.mdl" ) 

player_manager.AddValidModel( "RFS6", "models/arma/rfsold_06.mdl" )
player_manager.AddValidHands( "RFS6", "models/arma/rfsold_06_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS6", "models/arma/rfsold_06.mdl" ) 

player_manager.AddValidModel( "RFS Black", "models/arma/rfsoldoff_d.mdl" )
player_manager.AddValidHands( "RFS Black", "models/arma/rfsoldoff_d_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS Black", "models/arma/rfsoldoff_d.mdl" )
player_manager.AddValidModel( "RFS KMD VMF", "models/arma/rfsoldoff_kmd_vmf.mdl" )
player_manager.AddValidHands( "RFS KMD VMF", "models/arma/rfsoldoff_d_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS KMD VMF", "models/arma/rfsoldoff_kmd_vmf.mdl" )
player_manager.AddValidModel( "RFS MP", "models/arma/rfsoldoff_mp.mdl" )
player_manager.AddValidHands( "RFS MP", "models/arma/rfsoldoff_d_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS MP", "models/arma/rfsoldoff_mp.mdl" )
player_manager.AddValidModel( "RFS MF", "models/arma/rfsoldoff_mf.mdl" )
player_manager.AddValidHands( "RFS MF", "models/arma/rfsoldoff_d_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS MF", "models/arma/rfsoldoff_mf.mdl" )

player_manager.AddValidModel( "RFS Green", "models/arma/rfsoldoff_g.mdl" )
player_manager.AddValidHands( "RFS Green", "models/arma/rfsoldoff_g_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS Green", "models/arma/rfsoldoff_g.mdl" )
player_manager.AddValidModel( "RFS MSV", "models/arma/rfsoldoff_msv.mdl" )
player_manager.AddValidHands( "RFS MSV", "models/arma/rfsoldoff_g_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS MSV", "models/arma/rfsoldoff_msv.mdl" )
player_manager.AddValidModel( "RFS GSH", "models/arma/rfsoldoff_gsh.mdl" )
player_manager.AddValidHands( "RFS GSH", "models/arma/rfsoldoff_g_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS GSH", "models/arma/rfsoldoff_gsh.mdl" )
player_manager.AddValidModel( "RFS BTV", "models/arma/rfsoldoff_btv.mdl" )
player_manager.AddValidHands( "RFS BTV", "models/arma/rfsoldoff_g_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS BTV", "models/arma/rfsoldoff_btv.mdl" )
player_manager.AddValidModel( "RFS oSpN", "models/arma/rfsoldoff_ospn.mdl" )
player_manager.AddValidHands( "RFS oSpN", "models/arma/rfsoldoff_g_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS oSpN", "models/arma/rfsoldoff_ospn.mdl" )
player_manager.AddValidModel( "RFS VP", "models/arma/rfsoldoff_vp.mdl" )
player_manager.AddValidHands( "RFS VP", "models/arma/rfsoldoff_g_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS VP", "models/arma/rfsoldoff_vp.mdl" )

player_manager.AddValidModel( "RFS Blue", "models/arma/rfsoldoff_b.mdl" )
player_manager.AddValidHands( "RFS Blue", "models/arma/rfsoldoff_b_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS Blue", "models/arma/rfsoldoff_b.mdl" )
player_manager.AddValidModel( "RFS KMD VVS", "models/arma/rfsoldoff_kmd_vvs.mdl" )
player_manager.AddValidHands( "RFS KMD VVS", "models/arma/rfsoldoff_b_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS KMD VVS", "models/arma/rfsoldoff_kmd_vvs.mdl" )
player_manager.AddValidModel( "RFS DSHV", "models/arma/rfsoldoff_dshv.mdl" )
player_manager.AddValidHands( "RFS DSHV", "models/arma/rfsoldoff_b_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS DSHV", "models/arma/rfsoldoff_dshv.mdl" )
player_manager.AddValidModel( "RFS AE", "models/arma/rfsoldoff_ae.mdl" ) --AE86?
player_manager.AddValidHands( "RFS AE", "models/arma/rfsoldoff_b_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "RFS AE", "models/arma/rfsoldoff_ae.mdl" )


