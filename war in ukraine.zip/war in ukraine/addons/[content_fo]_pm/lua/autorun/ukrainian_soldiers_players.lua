--[[
addons/[content_fo]_pm/lua/autorun/ukrainian_soldiers_players.lua
--]]
player_manager.AddValidModel( "Ukrainian Soldier", "models/player/ukrainian_soldier_pm.mdl" )
player_manager.AddValidHands( "Ukrainian Soldier", "models/player/ukrainian_army_hands.mdl", 0, "00000000" )


