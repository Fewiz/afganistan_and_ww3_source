--[[
addons/[cw_2.0]_weapons/lua/cw/shared/attachments/md_cyber45acp.lua
--]]
local att = {}
att.name = "md_cyber45acp"
att.displayName = "Pistol Silencer"
att.displayNameShort = "Sil"
att.isSuppressor = true

att.statModifiers = {OverallMouseSensMult = -0.1,
RecoilMult = -0.1,
DamageMult = -0.1}

if CLIENT then
	att.displayIcon = surface.GetTextureID("cybericons/supp")
	att.description = {[1] = {t = "Decreases firing noise.", c = CustomizableWeaponry.textColors.POSITIVE}}
end

function att:attachFunc()
	self.dt.Suppressed = true
end

function att:detachFunc()
	self.dt.Suppressed = false
end

CustomizableWeaponry:registerAttachment(att)

