--[[
addons/[cw_2.0]_weapons/lua/cw/shared/attachments/extendedmagasval.lua
--]]
local att = {}
att.name = "bg_extendedmagasval"
att.displayName = "Extended Magazine"
att.displayNameShort = "Extended"
att.isBG = true

att.statModifiers = {ReloadSpeedMult = -0.1}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/makarov")
	att.description = {[1] = {t = "Increases magazine size by 10.", c = CustomizableWeaponry.textColors.POSITIVE}}
end

function att:attachFunc()
	self:setBodygroup(self.MagBGs.main, self.MagBGs.asvalmagazine)
	self:unloadWeapon()
	if self.Primary.ClipSize_ORIG_REAL >= 80 then
		self.Primary.ClipSize = self.Primary.ClipSize_ORIG_REAL * 1.5
		self.Primary.ClipSize_Orig = self.Primary.ClipSize_ORIG_REAL * 1.50
	else
		self.Primary.ClipSize = self.Primary.ClipSize_ORIG_REAL * 1.50
		self.Primary.ClipSize_Orig = self.Primary.ClipSize_ORIG_REAL * 1.50
	end
end

function att:detachFunc()
	self:setBodygroup(self.MagBGs.main, self.MagBGs.regular)
	self:unloadWeapon()
	self.Primary.ClipSize = self.Primary.ClipSize_ORIG_REAL
	self.Primary.ClipSize_Orig = self.Primary.ClipSize_ORIG_REAL
end

CustomizableWeaponry:registerAttachment(att)

