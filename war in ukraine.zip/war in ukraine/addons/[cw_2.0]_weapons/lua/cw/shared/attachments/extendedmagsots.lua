--[[
addons/[cw_2.0]_weapons/lua/cw/shared/attachments/extendedmagsots.lua
--]]
local att = {}
att.name = "bg_otsmagazine"
att.displayName = "Extended Magazine"
att.displayNameShort = "Extended"
att.isBG = true

att.statModifiers = {ReloadSpeedMult = -0.15}

if CLIENT then
	att.displayIcon = surface.GetTextureID("atts/makarov")
	att.description = {[1] = {t = "Increases magazine size.", c = CustomizableWeaponry.textColors.POSITIVE}}
end

function att:attachFunc()
	self:setBodygroup(self.MagBGs.main, self.MagBGs.otsmagazine)
	self:unloadWeapon()
	if self.Primary.ClipSize_ORIG_REAL >= 100 then
		self.Primary.ClipSize = self.Primary.ClipSize_ORIG_REAL * 1.0
		self.Primary.ClipSize_Orig = self.Primary.ClipSize_ORIG_REAL * 1.0
	else
		self.Primary.ClipSize = self.Primary.ClipSize_ORIG_REAL + 9.0
		self.Primary.ClipSize_Orig = self.Primary.ClipSize_ORIG_REAL + 9
	end
end

function att:detachFunc()
	self:setBodygroup(self.MagBGs.main, self.MagBGs.regular)
	self:unloadWeapon()
	self.Primary.ClipSize = self.Primary.ClipSize_ORIG_REAL
	self.Primary.ClipSize_Orig = self.Primary.ClipSize_ORIG_REAL
end

CustomizableWeaponry:registerAttachment(att)

