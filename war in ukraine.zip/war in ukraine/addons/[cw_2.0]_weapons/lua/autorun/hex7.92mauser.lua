--[[
addons/[cw_2.0]_weapons/lua/autorun/hex7.92mauser.lua
--]]
CustomizableWeaponry:registerAmmo("7.92x57MM", "7.92x57MM Rounds", 7, 92)

