--[[
addons/[cw_2.0]_weapons/lua/autorun/hex9by39ammoscript.lua
--]]
CustomizableWeaponry:registerAmmo("9×39MM", "9×39MM Rounds", 9, 39)

