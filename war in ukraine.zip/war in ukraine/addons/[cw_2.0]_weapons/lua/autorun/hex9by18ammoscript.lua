--[[
addons/[cw_2.0]_weapons/lua/autorun/hex9by18ammoscript.lua
--]]
CustomizableWeaponry:registerAmmo("9x18MM", "9x18MM Rounds", 9, 18)

