--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_ak74m/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "AK-74M"
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.3
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_6"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.5
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 2, y = -0, z = -2.5}
	SWEP.SightWithRail = true
	SWEP.ForeGripOffsetCycle_Draw = 0.5
	SWEP.ForeGripOffsetCycle_Reload = 0.88
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.88
	SWEP.BoltShootOffset = Vector(-0, 1.5, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "Bolt"
	SWEP.ADSFireAnim = false
	
	SWEP.WM = "models/weapons/w_rifak74m.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-1.0, 3.3, -2)
	SWEP.WMAng = Vector(170, 180, -0)
	
	
	SWEP.IronsightPos = Vector(2.045, -3.547, 0.879)
	SWEP.IronsightAng = Vector(1.32, -0.013, 0)
		
	SWEP.EoTechPos = Vector(2.052, -3.254, 0.35)
	SWEP.EoTechAng = Vector(0, 0.0, 0)
	
	SWEP.AimpointPos = Vector(2.035, -2.428, 0.409)
	SWEP.AimpointAng = Vector(0.0, 0.0, 0)
	
	SWEP.KobraPos = Vector(2.029, -1.88, 0.711)
	SWEP.KobraAng = Vector(0, 0.0, 0)
	
	SWEP.PSOPos = Vector(1.922, -1.823, 0.665)
	SWEP.PSOAng = Vector(0, -0.0, 0)
	
	SWEP.M203Pos = Vector(0.091, -4.321, 0.839)
	SWEP.M203Ang = Vector(0, 0, 0)
	
	SWEP.ShortDotPos = Vector(2.019, -1.884, 0.416)
	SWEP.ShortDotAng = Vector(-0.0, 0.0, 0)
	
	SWEP.AlternativePos = Vector(1.169, -1.82, 0)
	SWEP.AlternativeAng = Vector(2.065, -0.629, 0)
	
	SWEP.CustomizePos = Vector(-2.451, -1.632, 0.368)
	SWEP.CustomizeAng = Vector(7.668, -16.562, 0)
	
	SWEP.SprintPos = Vector(-2.717, 0, -0.172)
	SWEP.SprintAng = Vector(-9.053, -22.486, 0) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-5.08, -2.698, -0.78), [2] = Vector(-2, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	SWEP.SchmidtShortDotAxisAlign = {right = 0, up = -0.0, forward = 0}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "Base", rel = "", pos = Vector(0.175, 7.91, -1.675), angle = Angle(0, -180, 0), size = Vector(0.62, 0.62, 0.62)},
		["md_kobra"] = {model = "models/cw2/attachments/kobra.mdl", bone = "Base", rel = "", pos = Vector(-0.45, 3.19, -2.372), angle = Angle(0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "Base", rel = "", pos = Vector(-0.137, 11.378, -5.15), angle = Angle(0, 90, 0), size = Vector(0.649, 0.649, 0.649)},
		["md_schmidt_shortdot"] = {model = "models/cw2/attachments/schmidt.mdl", bone = "Base", rel = "", pos = Vector(0.233, 7.499, -1.591), angle = Angle(0, 90, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "Base", rel = "", pos = Vector(0.016, -17.788, -0.982), angle = Angle(0, 1, 0), size = Vector(0.699, 0.699, 0.699)},
		["md_foregrip"] = { model = "models/wystan/attachments/foregrip1.mdl", bone = "Base", rel = "", pos = Vector(-8.061, -3.945, -2.221), angle = Angle(0, 90, 0), size = Vector(0.54, 0.54, 0.54)},
		["md_pso1"] = {model = "models/cw2/attachments/pso.mdl", bone = "Base", rel = "", pos = Vector(0.004, 5.158, -0.936), angle = Angle(-0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_rail"] = {model = "models/wystan/attachments/akrailmount.mdl", bone = "Base", rel = "", pos = Vector(0.228, 3.911, 0.345), angle = Angle(0, 180, 0), size = Vector(0.8, 0.8, 0.8)},
		
	}
	
	SWEP.M203HoldPos = {
		["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
	["r-forearm-twist"] = { scale = Vector(1, 1, 1), pos = Vector(0.15, 0, 0), angle = Angle(0, -18.573, 0) },
	["r-pinky-mid"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, -3.554, 0) },
	["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(-3.968, 7.236, -40.832) },
	["r-forearm"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, 3.805, -25.427) },
	["r-rist"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, -1.004, -41.47) }

}

	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.2, 0, 0)
	SWEP.LaserAngAdjust = Angle(0.0, 180, 0) 
end
SWEP.PSO1AxisAlign = {right = -0.01, up = 0.0, forward = 90}
SWEP.SchmidtShortDotAxisAlign = {right = 0.0, up = 0.0, forward = 0}
SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 0, regular = 0, fastmag = 1, exmagmk1 = 2}
SWEP.LuaViewmodelRecoil = true

SWEP.CustomizationMenuScale = 0.02

SWEP.Attachments = {[1] = {header = "Прицел", offset = {500, -300}, atts = {"md_kobra", "md_eotech", "md_aimpoint", "md_schmidt_shortdot"}},
	[2] = {header = "Ствол", offset = {-200, -200}, atts = {"md_pbs1"}},
	[3] = {header = "Рукоять", offset = {100, 200}, atts = {"md_foregrip"}}}
	--["+reload"] = {header = "Ammo", offset = {650, 200}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"Shoot1", "Shoot2", "Shoot3"},
	reload = "reload",
	idle = "idle",
	draw = "draw"}
	
SWEP.Sounds = {draw = {{time = 0.1, sound = "CW_FOLEY_MEDIUM"}},

	reload = {[1] = {time = 0.2, sound = "CW_FOLEY_MEDIUM"},
	[2] = {time = 0.5, sound = "CW_AK12_MAGOUT"},
	[3] = {time = 1.3, sound = "CW_AK12_MAGIN"},
	[4] = {time = 1.3, sound = "CW_AK74M_MAGINOFFICIAL"},
	[5] = {time = 2.2, sound = "CW_AK74M_BOLTPULL"},
	[6] = {time = 2.55, sound = "CW_AK74M_BOLTRELEASE"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"auto", "semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие"

SWEP.Author			= "Silent"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 65
SWEP.ViewModelFlip	= true
SWEP.ViewModel		= "models/weapons/v_rifak74m.mdl"
SWEP.WorldModel		= "models/weapons/w_rifak74m.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 30
SWEP.Primary.DefaultClip	= 60
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2" --"5.45x39MM"

SWEP.FireDelay = 0.0923
SWEP.FireSound = "CW_AK74M_FIRE"
SWEP.FireSoundSuppressed = "CW_AK74M_FIRE_SUPPRESSED"
SWEP.Recoil = 1.3

SWEP.HipSpread = 0.05
SWEP.AimSpread = 0.01
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.05
SWEP.SpreadPerShot = 0.036
SWEP.SpreadCooldown = 0.03
SWEP.Shots = 1
SWEP.Damage = 34
SWEP.DeployTime = 0.6

SWEP.ReloadSpeed = 0.9
SWEP.ReloadTime = 3.5
SWEP.ReloadTime_Empty = 3.5
SWEP.ReloadHalt = 3.5
SWEP.ReloadHalt_Empty = 3.5
SWEP.SnapToIdlePostReload = true


