--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_ak74m/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_AK74M_FIRE", "weapons/cw_ak74m/ak74m.wav", 1, 100, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_AK74M_FIRE_SUPPRESSED", "weapons/cw_ak74m/ak74m_sup.wav", 1, 75, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_AK12_MAGOUT", "weapons/cw_ak12/magout.wav")
CustomizableWeaponry:addReloadSound("CW_AK12_MAGIN", "weapons/cw_ak12/magin.wav")
CustomizableWeaponry:addReloadSound("CW_AK74M_MAGINOFFICIAL", "weapons/cw_ak74m/maginofficial.wav")
CustomizableWeaponry:addReloadSound("CW_AK74M_BOLTPULL", "weapons/cw_ak74m/boltpull.wav")
CustomizableWeaponry:addReloadSound("CW_AK74M_BOLTRELEASE", "weapons/cw_ak74m/boltrelease.wav")


