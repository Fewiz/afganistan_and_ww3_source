--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_asval/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_ASVAL_FIRE", "weapons/cw_asval/asval.wav", 1, 70, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_ASVAL_MAGOUT", "weapons/cw_asval/magout.wav")
CustomizableWeaponry:addReloadSound("CW_ASVAL_MAGIN", "weapons/cw_asval/magin.wav")
CustomizableWeaponry:addReloadSound("CW_ASVAL_BOLTBACK", "weapons/cw_asval/boltback.wav")
CustomizableWeaponry:addReloadSound("CW_ASVAL_BOLTRELEASE", "weapons/cw_asval/boltrelease.wav")


