--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_asval/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "АС ВАЛ" -- AS VAL
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.3
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_suppressed"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.5
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 1.5, y = 1, z = -0}
	SWEP.SightWithRail = true
	SWEP.ForeGripOffsetCycle_Draw = 0.4
	SWEP.ForeGripOffsetCycle_Reload = 0.7
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.9
	SWEP.BoltShootOffset = Vector(-0, 1, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "Bolt"
	SWEP.ADSFireAnim = false
	
	SWEP.WM = "models/weapons/w_hex_vally.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-10, 0.5, 3)
	SWEP.WMAng = Vector(170, 90, -0)
	
	SWEP.M203OffsetCycle_Reload = 0.65
	SWEP.M203OffsetCycle_Reload_Empty = 0.73
	SWEP.M203OffsetCycle_Draw = 0
	
	SWEP.IronsightPos = Vector(-2.388, -3.322, 1.312)
	SWEP.IronsightAng = Vector(-1.818, 0.027, 0)
	
	SWEP.FoldSightPos = Vector(-2.208, -4.3, 0.143)
	SWEP.FoldSightAng = Vector(0.605, 0, -0.217)
		
	SWEP.EoTechPos = Vector(-2.391, -3.405, 0.098)
	SWEP.EoTechAng = Vector(0, 0.0, 0)
	
	SWEP.AimpointPos = Vector(-2.389, -4.437, 0.365)
	SWEP.AimpointAng = Vector(-1.275, 0.064, 0)
	
	SWEP.KobraPos = Vector(-2.337, -3.754, 0.375)
	SWEP.KobraAng = Vector(-0.588, 0.199, 0)
	
	SWEP.PSOPos = Vector(1.922, -1.823, 0.665)
	SWEP.PSOAng = Vector(0, -0.0, 0)
	
	SWEP.M203Pos = Vector(0.091, -4.321, 0.839)
	SWEP.M203Ang = Vector(0, 0, 0)
	
	SWEP.ShortDotPos = Vector(-2.297, -3.812, -0.493)
	SWEP.ShortDotAng = Vector(-0.0, 0.0, 0)
	
	SWEP.AlternativePos = Vector(-0.78, -0.445, 0)
	SWEP.AlternativeAng = Vector(0.721, 1.294, 0)
	
	SWEP.CustomizePos = Vector(3.334, 0, 0)
	SWEP.CustomizeAng = Vector(5.77, 22.652, 0)
	
	SWEP.SprintPos = Vector(5.1, 0, -2.55)
	SWEP.SprintAng = Vector(-0.911, 45.784, 0) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-5.08, -2.698, -0.78), [2] = Vector(-2, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	SWEP.SchmidtShortDotAxisAlign = {right = 0, up = -0.0, forward = 0}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "Weapon", rel = "", pos = Vector(-0.269, -5.455, -0.769), angle = Angle(0, 0, 0), size = Vector(0.5, 0.5, 0.5)},
		["md_kobra"] = {model = "models/cw2/attachments/kobra.mdl", bone = "Weapon", rel = "", pos = Vector(0.363, -1.64, -2.043), angle = Angle(0, 180, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "Weapon", rel = "", pos = Vector(0.021, -8.905, -4.395), angle = Angle(0, -90, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_m203"] = {model = "models/cw2/attachments/m203.mdl", bone = "body", rel = "", pos = Vector(1.713, -2.566, 1.774), angle = Angle(0, -90, 0), size = Vector(0.737, 0.737, 0.737)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "body", rel = "", pos = Vector(0, 18.471, -0.406), angle = Angle(0, 180, 0), size = Vector(0.649, 0.649, 0.649)},
		["md_foregrip"] = {model = "models/wystan/attachments/foregrip1.mdl", bone = "weapon", rel = "", pos = Vector(8.963, 0.578, 10.032), angle = Angle(90, 180, 90), size = Vector(0.6, 0.6, 0.6)},
		["md_pso1"] = {model = "models/cw2/attachments/pso.mdl", bone = "Base", rel = "", pos = Vector(0.004, 5.158, -0.936), angle = Angle(-0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_rail"] = {model = "models/wystan/attachments/akrailmount.mdl", bone = "Weapon", rel = "", pos = Vector(-0.287, -2.385, 0.938), angle = Angle(0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		
	}
	
	SWEP.M203HoldPos = {
		["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
		["l_thumb_tip"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, 3.582, 47.046) },
	["L Hand"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0.01, 0), angle = Angle(3.2, 19.788, 59.991) },
	["L UpperArm"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0.245, 0.181), angle = Angle(1.236, 0, 0) },
	["l_thumb_mid"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(12.939, -9.054, 0) },
	["L Finger0"] = { scale = Vector(1, 1, 1), pos = Vector(0, -0.519, -0.125), angle = Angle(49.625, 21.764, 0) },
	["L Clavicle"] = { scale = Vector(1, 1, 1), pos = Vector(2.299, 0.924, -2.333), angle = Angle(-2.648, 0.328, -0.987) },
	["l_pinky_tip"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(55.604, 16.679, 0) }


	}	
	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.2, 0, 0)
	SWEP.LaserAngAdjust = Angle(0.0, 180, 0) 
end
SWEP.PSO1AxisAlign = {right = -0.01, up = 0.0, forward = 90}
SWEP.SchmidtShortDotAxisAlign = {right = 0.0, up = 0.0, forward = 0}
SWEP.MagBGs = {main = 0, regular = 0, asvalmagazine = 1}
SWEP.LuaViewmodelRecoil = false

SWEP.CustomizationMenuScale = 0.02

SWEP.Attachments = {[1] = {header = "Прицел", offset = {600, -100}, atts = {"md_kobra", "md_eotech", "md_aimpoint"}},
	[2] = {header = "Магазин", offset = {100, 300}, atts = {"bg_extendedmagasval"}}}
	--["+reload"] = {header = "Ammo", offset = {600, 300}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"base_fire"},
	reload = "base_reloadempty",
	idle = "base_idle",
	draw = "base_draw"}
	
SWEP.Sounds = {base_draw = {{time = 0.2, sound = "CW_FOLEY_MEDIUM"}},

	base_reloadempty = {[1] = {time = 0.1, sound = "CW_FOLEY_MEDIUM"},
	[2] = {time = 0.65, sound = "CW_ASVAL_MAGOUT"},
	[3] = {time = 2.0, sound = "CW_ASVAL_MAGIN"},
	[4] = {time = 3.2, sound = "CW_ASVAL_BOLTBACK"},
	[5] = {time = 3.4, sound = "CW_ASVAL_BOLTRELEASE"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"auto", "semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие" -- CW 2.0 Putin CollectionОружие

SWEP.Author			= "Silent"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 75
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/v_assfukval.mdl"
SWEP.WorldModel		= "models/weapons/w_hex_vally.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 20
SWEP.Primary.DefaultClip	= 40
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2" --"9×39MM"

SWEP.FireDelay = 0.07
SWEP.FireSound = "CW_ASVAL_FIRE"
SWEP.Recoil = 0.75

SWEP.HipSpread = 0.05
SWEP.AimSpread = 0.009
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadPerShot = 0.03
SWEP.SpreadCooldown = 0.02
SWEP.Shots = 1
SWEP.Damage = 25
SWEP.DeployTime = 0.5

SWEP.ReloadSpeed = 1.15
SWEP.ReloadTime = 2.7
SWEP.ReloadTime_Empty = 3.7
SWEP.ReloadHalt = 2.7
SWEP.ReloadHalt_Empty = 3.7
SWEP.SnapToIdlePostReload = true


