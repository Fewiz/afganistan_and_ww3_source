--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_mp443/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_MP443_FIRE", "weapons/cw_mp443/mp443.wav", 1, 85, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_MP443_FIRE_SUPPRESSED", "weapons/cw_mp443/mp443_sup.wav", 1, 65, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_MP443_MAGOUT", "weapons/cw_mp443/magout.wav")
CustomizableWeaponry:addReloadSound("CW_MP443_MAGENTER", "weapons/cw_mp443/magenter.wav")
CustomizableWeaponry:addReloadSound("CW_MP443_MAGIN", "weapons/cw_mp443/magfinish.wav")
CustomizableWeaponry:addReloadSound("CW_MP443_SLIDEPULL", "weapons/cw_mp443/slidestart.wav")
CustomizableWeaponry:addReloadSound("CW_MP443_SLIDERELEASE", "weapons/cw_mp443/slidefinish.wav")
CustomizableWeaponry:addRegularSound("CW_DRAWMP443", "weapons/cw_mp443/draw.wav")


