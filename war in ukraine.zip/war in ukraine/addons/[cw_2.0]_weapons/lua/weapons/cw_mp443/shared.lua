--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_mp443/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "MP-443"
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.5
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_ots"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.6
	SWEP.ShellOffsetMul = 0.0
	SWEP.Shell = "smallshell"
	SWEP.ShellPosOffset = {x = -0, y = -0, z = -0.0}
	SWEP.SightWithRail = true
	SWEP.ForeGripOffsetCycle_Draw = 0
	SWEP.ForeGripOffsetCycle_Reload = 0.65
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.9
	SWEP.BoltBone = "usp_slide"
	SWEP.BoltShootOffset = Vector(-1.5, 0, 0)
	SWEP.EmptyBoltHoldAnimExclusion = "shoot_empty"
	SWEP.StopReloadBoneOffset = 0.9
	SWEP.HoldBoltWhileEmpty = "true"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WM = "models/weapons/w_pist_p228.mdl"
	SWEP.WMPos = Vector(-0.7, 2.7, -2)
	SWEP.WMAng = Vector(-0.013, -0.052, -180)
	
	SWEP.IronsightPos = Vector(-2.529, -1.744, 0.763)
	SWEP.IronsightAng = Vector(0.0, 0, 0)
	
	SWEP.SprintPos = Vector(0, -9.332, -7.321)
	SWEP.SprintAng = Vector(65.332, 0, 0)
	
	SWEP.EoTechPos = Vector(2.301, -5.036, 0.2)
	SWEP.EoTechAng = Vector(0, 0, -0)
	
	SWEP.SprintPos = Vector(0, -3, -3.8)
	SWEP.SprintAng = Vector(27.962, 0, 0) 
	
	SWEP.CustomizePos = Vector(-0, -0, -5)
	SWEP.CustomizeAng = Vector(21.86, 0, 0)
	
	SWEP.AlternativePos = Vector(-1.267, -2.366, 0)
	SWEP.AlternativeAng = Vector(0.855, 1.659, -3.816)
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-5.08, -2.698, -0.78), [2] = Vector(-2, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.5, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "slide", rel = "", pos = Vector(-0.246, 9.619, -9.367), angle = Angle(0, 90, 0), size = Vector(0.915, 0.915, 0.915)},
		["md_tundra9mm"] = {model = "models/cw2/attachments/9mmsuppressor.mdl", bone = "usp_main", rel = "", pos = Vector(6.584, -0.459, -0.004), angle = Angle(90, 180, 90), size = Vector(0.5, 0.5, 0.5)},
		["md_muzzlebrake"] = {model = "models/rageattachments/pistolmuzzlebreak.mdl", bone = "gun", pos = Vector(-0.031, 17.274, -0.232), angle = Angle(0, -90, 0), size = Vector(1.072, 1.072, 1.072)},
		["md_lasersight"] = {model = "models/rageattachments/anpeqbf.mdl", bone = "gun", rel = "", pos = Vector(0.705, -3.092, 0.458), angle = Angle(0, 90, -90), size = Vector(0.7, 0.7, 0.7)},
		
	}
	
	SWEP.M203HoldPos = {
		["arm_controller_01"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
		["Bip01 L Finger3"] = {pos = Vector(0, 0, 0), angle = Angle(0, 42.713, 0) },
		["Bip01 L Clavicle"] = {pos = Vector(-3.299, 1.235, -1.79), angle = Angle(-55.446, 11.843, 0) },
		["Bip01 L Forearm"] = {pos = Vector(0, 0, 0), angle = Angle(0, 0, 42.41) },
		["Bip01 L Finger02"] = {pos = Vector(0, 0, 0), angle = Angle(0, 71.308, 0) },
		["Bip01 L Finger11"] = {pos = Vector(0, 0, 0), angle = Angle(0, 25.795, 0) },
		["Bip01 L Finger4"] = {pos = Vector(0, 0, 0), angle = Angle(0, 26.148, 0) },
		["Bip01 L Finger1"] = {pos = Vector(0, 0, 0), angle = Angle(6.522, 83.597, 0) },
		["Bip01 L Finger0"] = {pos = Vector(0, 0, 0), angle = Angle(23.2, 16.545, 0) },
		["Bip01 L Finger42"] = {pos = Vector(0, 0, 0), angle = Angle(0, 31.427, 0) },
		["Bip01 L Finger32"] = {pos = Vector(0, 0, 0), angle = Angle(0, 29.565, 0) },
		["Bip01 L Hand"] = {pos = Vector(0, 0, 0), angle = Angle(9.491, 14.793, -15.926) },
		["Bip01 L Finger12"] = {pos = Vector(0, 0, 0), angle = Angle(0, -9.195, 0) },
		["Bip01 L Finger21"] = {pos = Vector(0, 0, 0), angle = Angle(0, 10.164, 0) },
		["Bip01 L Finger01"] = {pos = Vector(0, 0, 0), angle = Angle(0, 18.395, 0) },
		["Bip01 L Finger2"] = {pos = Vector(0, 0, 0), angle = Angle(2.411, 57.007, 0) }
	}	
	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.1, 0, 1.2)
	SWEP.LaserAngAdjust = Angle(0.4, 0, 4) 
end
SWEP.PSO1AxisAlign = {right = -0, up = 0.4, forward = 90}
SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 0, regular = 0, mp443magazine = 1}
SWEP.LuaViewmodelRecoil = false

SWEP.Attachments = {[1] = {header = "Ствол", offset = {-100, -250}, atts = {"md_tundra9mm"}}}
		--[2] = {header = "Магазин", offset = {100, 200}, atts = {"bg_mp443magazine"}}}
	--["+reload"] = {header = "Ammo", offset = {-500, -100}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"shoot1", "shoot2", "shoot3"},
	reload = "reload",
	idle = "idle",
	draw = "draw"}
	
SWEP.Sounds = {draw = {[1]= {time = 0.2, sound = "CW_FOLEY_MEDIUM"},
			[2]= {time = 0.5, sound = "CW_DRAWMP443"}},
			
	reload = {[1] = {time = 0.2, sound = "CW_MP443_MAGOUT"},
	[2] = {time = 1, sound = "CW_MP443_MAGENTER"},
	[3] = {time = 1.4, sound = "CW_MP443_MAGIN"},
	[4] = {time = 1.7, sound = "CW_MP443_SLIDEPULL"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 1
SWEP.SlotPos = 0
SWEP.NormalHoldType = "revolver"
SWEP.RunHoldType = "normal"
SWEP.FireModes = {"semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие" -- "CW 2.0 Putin Collection"

SWEP.Author			= "Soma"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 70
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/v_pistmp443.mdl"
SWEP.WorldModel		= "models/weapons/w_pist_p228.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 17
SWEP.Primary.DefaultClip	= 34
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "pistol" --"9x19MM"

SWEP.ADSFireAnim = true
SWEP.FireDelay = 0.13
SWEP.FireSound = "CW_MP443_FIRE"
SWEP.FireSoundSuppressed = "CW_MP443_FIRE_SUPPRESSED"
SWEP.Recoil = 1.5

SWEP.HipSpread = 0.07
SWEP.AimSpread = 0.01
SWEP.VelocitySensitivity = 0.5
SWEP.MaxSpreadInc = 0.07
SWEP.SpreadPerShot = 0.009
SWEP.SpreadCooldown = 0.08
SWEP.Shots = 1
SWEP.Damage = 25
SWEP.DeployTime = 1.0

SWEP.ReloadSpeed = 1
SWEP.ReloadTime = 2.5
SWEP.ReloadTime_Empty = 2.5
SWEP.ReloadHalt = 2.5
SWEP.ReloadHalt_Empty = 2.5
SWEP.SnapToIdlePostReload = true


