--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_ots/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_OTS_FIRE", "weapons/cw_ots/ots.wav", 1, 100, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_OTS_FIRE_SUPPRESSED", "weapons/cw_ots/ots_sup.wav", 1, 75, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_OTS_MAGOUT", "weapons/cw_ots/magout.wav")
CustomizableWeaponry:addReloadSound("CW_OTS_MAGIN", "weapons/cw_ots/magin.wav")
CustomizableWeaponry:addReloadSound("CW_OTS_SLIDERELEASE", "weapons/cw_ots/sliderelease.wav")



