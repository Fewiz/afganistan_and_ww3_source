--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_aks74/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "АКС-74" -- AKS-74
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.7
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_6"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.5
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 0.5, y = 1, z = -1}
	SWEP.SightWithRail = true
	SWEP.ForeGripOffsetCycle_Draw = 0.5
	SWEP.ForeGripOffsetCycle_Reload = 0.7
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.95
	SWEP.BoltShootOffset = Vector(-2.5, 0, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "Bolt"
	SWEP.ADSFireAnim = false
	
	SWEP.WM = "models/weapons/w_rifaks74.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-1.0, 3.3, -2)
	SWEP.WMAng = Vector(168, 180, -0)
	
	
	SWEP.IronsightPos = Vector(-2.518, -2.954, 0.601)
	SWEP.IronsightAng = Vector(0.052, -0.091, 0)
		
	SWEP.EoTechPos = Vector(-2.471, -3.192, -0.294)
	SWEP.EoTechAng = Vector(0, 0.0, 0)
	
	SWEP.AimpointPos = Vector(-2.527, -3.665, -0.225)
	SWEP.AimpointAng = Vector(0, -0.105, 0)
	
	SWEP.KobraPos = Vector(-2.464, -3.085, 0.123)
	SWEP.KobraAng = Vector(0, 0.0, 0)
	
	SWEP.ACOGPos = Vector(-2.487, -3.958, -0.332)
	SWEP.ACOGAng = Vector(0, 0, 0)
	
	SWEP.PSOPos = Vector(1.922, -1.823, 0.665)
	SWEP.PSOAng = Vector(0, -0.0, 0)
	
	SWEP.M203Pos = Vector(0.091, -4.321, 0.839)
	SWEP.M203Ang = Vector(0, 0, 0)
	
	SWEP.ShortDotPos = Vector(-2.297, -3.812, -0.493)
	SWEP.ShortDotAng = Vector(-0.0, 0.0, 0)
	
	SWEP.AlternativePos = Vector(-1.297, -1.614, 0)
	SWEP.AlternativeAng = Vector(1.615, 1.212, 0)
	
	SWEP.CustomizePos = Vector(4.083, 0, -2.254)
	SWEP.CustomizeAng = Vector(10.998, 25.957, 0)
	
	SWEP.SprintPos = Vector(0.101, 0, 0)
	SWEP.SprintAng = Vector(-12, 5.551, 0) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-2.491, -3.958, -0.962), [2] = Vector(-0.496, -0.031, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	SWEP.SchmidtShortDotAxisAlign = {right = 0, up = -0.0, forward = 0}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "AK", rel = "", pos = Vector(-1.525, -3.464, 4.478), angle = Angle(0, 0, -180), size = Vector(0.699, 0.699, 0.699)},
		["md_kobra"] = {model = "models/cw2/attachments/kobra.mdl", bone = "AK", rel = "", pos = Vector(-0.879, -8.556, 4.274), angle = Angle(0, 180, -180), size = Vector(0.55, 0.55, 0.55)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "AK", rel = "", pos = Vector(-1.122, 0.145, 7.997), angle = Angle(0, 90, -180), size = Vector(0.699, 0.699, 0.699)},
		["md_m203"] = {model = "models/cw2/attachments/m203.mdl", bone = "body", rel = "", pos = Vector(1.713, -2.566, 1.774), angle = Angle(0, -90, 0), size = Vector(0.737, 0.737, 0.737)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "AK", rel = "", pos = Vector(-1.208, -29.25, 1.472), angle = Angle(0, -1, 0), size = Vector(0.8, 0.8, 0.8)},
		["md_foregrip"] = {model = "models/wystan/attachments/foregrip1.mdl", bone = "AK", rel = "", pos = Vector(7.73, -14.799, 5.117), angle = Angle(0, 90, 180), size = Vector(0.6, 0.6, 0.6)},
		["md_acog"] = {model = "models/wystan/attachments/2cog.mdl", bone = "AK", rel = "", pos = Vector(-1.553, -3.856, 3.918), angle = Angle(0, 0, -180), size = Vector(0.6, 0.6, 0.6)},
		["md_rail"] = {model = "models/wystan/attachments/akrailmount.mdl", bone = "AK", rel = "", pos = Vector(-1.515, -7.632, 1.998), angle = Angle(0, 0, -180), size = Vector(0.8, 0.8, 0.8)},
		
	}
	
	SWEP.M203HoldPos = {
		["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
	["Left10"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(16.035, -1.341, -3.464) },
	["Left15"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, 27.916, 8.286) },
	["Left9"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(51.026, 0, 0) },
	["Left_L_Arm"] = { scale = Vector(1, 1, 1), pos = Vector(-0.881, 0.536, 1.554), angle = Angle(-6.798, -3.32, 62.46) },
	["Left1"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(42.08, 22.83, 11.543) }

}

	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.2, 0, 0)
	SWEP.LaserAngAdjust = Angle(0.0, 180, 0) 
end
SWEP.PSO1AxisAlign = {right = -0.01, up = 0.0, forward = 90}
SWEP.SchmidtShortDotAxisAlign = {right = 0.0, up = 0.0, forward = 0}
SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 0, regular = 0, fastmag = 1, exmagmk1 = 2}
SWEP.LuaViewmodelRecoil = true

SWEP.CustomizationMenuScale = 0.02

SWEP.Attachments = {[1] = {header = "Прицел", offset = {500, -300}, atts = {"md_kobra", "md_eotech", "md_aimpoint", "md_acog"}},
	[2] = {header = "Ствол", offset = {-200, -200}, atts = {"md_pbs1"}},
	[3] = {header = "Рукоять", offset = {100, 200}, atts = {"md_foregrip"}}}
	--["+reload"] = {header = "Ammo", offset = {650, 200}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"shot1", "shot2", "shot3"},
	reload = "reload_non_empty",
	reload_empty = "reload_empty2",
	idle = "idle",
	draw = "second_draw"}
	
SWEP.Sounds = {second_draw = {{time = 0.0, sound = "CW_FOLEY_HEAVY"},
				{time = 0.7, sound = "CW_DRAWAKS74"}},

	reload_empty2 = {[1] = {time = 0.6, sound = "CW_AKS74_MAGOUT"},
	[2] = {time = 1.3, sound = "CW_AKS74_MAGIN"},
	[3] = {time = 3.0, sound = "CW_AKS74_BOLTPULL"}},

	reload_non_empty = {[1] = {time = 0.6, sound = "CW_AKS74_MAGOUT"},
	[2] = {time = 1.3, sound = "CW_AKS74_MAGIN"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"auto", "semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие"

SWEP.Author			= "Silent"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 70
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/v_rifaks74.mdl"
SWEP.WorldModel		= "models/weapons/w_rifaks74.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 30
SWEP.Primary.DefaultClip	= 60
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2" --"5.45x39MM"

SWEP.FireDelay = 0.0923
SWEP.FireSound = "CW_AKS74_FIRE"
SWEP.FireSoundSuppressed = "CW_AKS74_FIRE_SUPPRESSED"
SWEP.Recoil = 1.2

SWEP.HipSpread = 0.05
SWEP.AimSpread = 0.005
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.05
SWEP.SpreadPerShot = 0.036
SWEP.SpreadCooldown = 0.03
SWEP.Shots = 1
SWEP.Damage = 32
SWEP.DeployTime = 1.5

SWEP.ReloadViewBobEnabled = true
SWEP.ReloadSpeed = 1
SWEP.ReloadTime = 2.6
SWEP.ReloadTime_Empty = 4.5
SWEP.ReloadHalt = 2.6
SWEP.ReloadHalt_Empty = 4.5
SWEP.SnapToIdlePostReload = true


