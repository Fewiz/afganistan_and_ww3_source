--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_aks74/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_AKS74_FIRE", "weapons/cw_aks74/aks74.wav", 1, 100, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_AKS74_FIRE_SUPPRESSED", "weapons/cw_aks74/aks74_sup.wav", 1, 75, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_AKS74_MAGOUT", "weapons/cw_aks74/magout.wav")
CustomizableWeaponry:addReloadSound("CW_AKS74_MAGIN", "weapons/cw_aks74/magin.wav")
CustomizableWeaponry:addReloadSound("CW_AKS74_BOLTPULL", "weapons/cw_aks74/boltpull.wav")
CustomizableWeaponry:addRegularSound("CW_DRAWAKS74", "weapons/cw_aks74/draw.wav")

