--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_ak12/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_AK12_FIRE", "weapons/cw_ak12/ak12.wav", 1, 100, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_AK12_FIRE_SUPPRESSED", "weapons/cw_ak12/ak12_sup.wav", 1, 75, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_AK12_MAGOUT", "weapons/cw_ak12/magout.wav")
CustomizableWeaponry:addReloadSound("CW_AK12_MAGIN", "weapons/cw_ak12/magin.wav")
CustomizableWeaponry:addReloadSound("CW_AK12_BOLTRELEASE", "weapons/cw_ak12/boltrelease.wav")


