--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_ak12/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "AK-12"
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.3
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_6"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.55
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 1, y = 0, z = 0}
	SWEP.SightWithRail = false
	SWEP.ForeGripOffsetCycle_Draw = 0.5
	SWEP.ForeGripOffsetCycle_Reload = 0.7
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.95
	SWEP.BoltShootOffset = Vector(-3.0, 0, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "AK12_Bolt"
	SWEP.ADSFireAnim = false
	
	SWEP.WM = "models/weapons/w_rif_aek9.mdl"-- "models/weapons/w_rif_ak47.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-0.8, 13.5, -3.5)
	SWEP.WMAng = Vector(170, 180, -0)
	
	
	SWEP.IronsightPos = Vector(-1.935, -2.072, 0.451)
	SWEP.IronsightAng = Vector(0.508, 0.014, 0)
	
		
	SWEP.EoTechPos = Vector(-1.93, -3.205, 0.059)
	SWEP.EoTechAng = Vector(0, 0.0, 0)
	
	SWEP.AimpointPos = Vector(-1.93, -3.205, 0.059)
	SWEP.AimpointAng = Vector(0.0, 0.0, 0)
	
	SWEP.KobraPos = Vector(-1.935, -4.429, -0.072)
	SWEP.KobraAng = Vector(0.219, 0, 0)
	
	SWEP.HoloPos = Vector(-1.93, -3.205, 0.059)
	SWEP.HoloAng = Vector(0, 0, 0)
	
	SWEP.PSOPos = Vector(1.922, -1.823, 0.665)
	SWEP.PSOAng = Vector(0, -0.0, 0)
	
	SWEP.M203Pos = Vector(0.091, -4.321, 0.839)
	SWEP.M203Ang = Vector(0, 0, 0)
	
	SWEP.ShortDotPos = Vector(-1.941, -1.754, 0.118)
	SWEP.ShortDotAng = Vector(-0.0, 0.0, 0)
	
	SWEP.AlternativePos = Vector(-0.599, 0, -0.982)
	SWEP.AlternativeAng = Vector(1.442, 0, 0)
	
	SWEP.CustomizePos = Vector(3.989, -0.313, 0.199)
	SWEP.CustomizeAng = Vector(6.018, 18.659, 0)
	
	SWEP.SprintPos = Vector(0.55, 0, -2.084)
	SWEP.SprintAng = Vector(-11.37, 17.856, -12.433) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-5.08, -2.698, -0.78), [2] = Vector(-2, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	SWEP.SchmidtShortDotAxisAlign = {right = 0, up = -0.0, forward = 0}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "body_new", rel = "", pos = Vector(4.883, -0.125, -0.982), angle = Angle(0, -90, 0), size = Vector(0.55, 0.55, 0.55)},
		["md_kobra"] = {model = "models/cw2/attachments/kobra.mdl", bone = "AK12_Body", rel = "", pos = Vector(0.508, -2.47, 0.674), angle = Angle(0, -180, 0), size = Vector(0.55, 0.55, 0.55)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "AK12_Body", rel = "", pos = Vector(0.286, -11.941, -4.191), angle = Angle(0, -90, 0), size = Vector(0.75, 0.75, 0.75)},
		["md_m203"] = {model = "models/cw2/attachments/m203.mdl", bone = "body", rel = "", pos = Vector(1.713, -2.566, 1.774), angle = Angle(0, -90, 0), size = Vector(0.737, 0.737, 0.737)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "AK12_Body", rel = "", pos = Vector(0.079, 15.298, 1.411), angle = Angle(0, 180, 0), size = Vector(0.75, 0.75, 0.75)},
		["md_foregrip"] = {model = "models/wystan/attachments/foregrip1.mdl", bone = "Plane02", rel = "", pos = Vector(7.541, -7.441, -1.976), angle = Angle(0, 0, 0), size = Vector(0.5, 0.5, 0.5)},
		["md_pso1"] = {model = "models/cw2/attachments/pso.mdl", bone = "Base", rel = "", pos = Vector(0.004, 5.158, -0.936), angle = Angle(-0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_schmidt_shortdot"] = {model = "models/cw2/attachments/schmidt.mdl", bone = "AK12_Body", rel = "", pos = Vector(-0.18, -7.421, -0.109), angle = Angle(0, -90, 0), size = Vector(0.699, 0.699, 0.699)},
		
	}
	
	SWEP.M203HoldPos = {
		["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
	["Left1"] = { scale = Vector(1, 1, 1), pos = Vector(0, -0.124, 0), angle = Angle(-10.671, 0, 0) },
	["Left_L_Arm"] = { scale = Vector(1, 1, 1), pos = Vector(1.361, -0.608, 1.889), angle = Angle(0, 0, 0) },
	["Left2"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0.162), angle = Angle(-3.866, 21.604, -5.273) },
	["Left_Hand"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, -33.07, 0) },
	["Left_U_Arm"] = { scale = Vector(1, 1, 1), pos = Vector(-2.632, 0.398, -1.318), angle = Angle(0, -17.779, 88.009) }
}

	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.2, 0, 0)
	SWEP.LaserAngAdjust = Angle(0.0, 180, 0) 
end
SWEP.PSO1AxisAlign = {right = -0.01, up = 0.0, forward = 90}
SWEP.SchmidtShortDotAxisAlign = {right = -0.9, up = -0.27, forward = 0}
SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 0, regular = 0, ak12magazine = 1, exmagmk1 = 2}
SWEP.LuaViewmodelRecoil = true

SWEP.CustomizationMenuScale = 0.02

SWEP.Attachments = {[1] = {header = "Прицел", offset = {500, -300}, atts = {"md_kobra", "md_eotech", "md_schmidt_shortdot"}},
	[2] = {header = "Ствол", offset = {-200, -200}, atts = {"md_pbs1"}}}
	--[3] = {header = "Магазин", offset = {-200, 200}, atts = {"bg_ak12magazine"}}}
	--["+reload"] = {header = "Ammo", offset = {650, 200}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"shoot3_unsil"},
	reload = "reload_unsil",
	idle = "idle_unsil",
	draw = "draw_unsil"}
	
SWEP.Sounds = {draw_unsil = {{time = 0.1, sound = "CW_FOLEY_MEDIUM"}},

	reload_unsil = {[1] = {time = 0.25, sound = "CW_FOLEY_MEDIUM"},
	[2] = {time = 0.6, sound = "CW_AK12_MAGOUT"},
	[3] = {time = 1.3, sound = "CW_AK12_MAGIN"},
	[4] = {time = 2.2, sound = "CW_AK12_BOLTRELEASE"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"auto", "3burst", "semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие"

SWEP.Author			= "Silent"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 65
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/v_hex_ak12.mdl"
SWEP.WorldModel		= "models/weapons/w_rif_ak47.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 30
SWEP.Primary.DefaultClip	= 60
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2" --"5.45x39MM"

SWEP.FireDelay = 0.1
SWEP.FireSound = "CW_AK12_FIRE"
SWEP.FireSoundSuppressed = "CW_AK12_FIRE_SUPPRESSED"
SWEP.Recoil = 0.9

SWEP.HipSpread = 0.05
SWEP.AimSpread = 0.005
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.08
SWEP.SpreadPerShot = 0.03
SWEP.SpreadCooldown = 0.04
SWEP.Shots = 1
SWEP.Damage = 30
SWEP.DeployTime = 0.6

SWEP.ReloadSpeed = 0.85
SWEP.ReloadTime = 1.8
SWEP.ReloadTime_Empty = 3
SWEP.ReloadHalt = 2.05
SWEP.ReloadHalt_Empty = 3
SWEP.SnapToIdlePostReload = true


