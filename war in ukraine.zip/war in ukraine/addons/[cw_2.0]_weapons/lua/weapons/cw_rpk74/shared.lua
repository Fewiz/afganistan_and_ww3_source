--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_rpk74/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "РПК-74" -- "RPK-74
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.3
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_6"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.5
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 0.5, y = 1, z = -1}
	SWEP.SightWithRail = true
	SWEP.ForeGripOffsetCycle_Draw = 0.4
	SWEP.ForeGripOffsetCycle_Reload = 0.7
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.9
	SWEP.BoltShootOffset = Vector(-1, 0, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "bolt"
	SWEP.ADSFireAnim = false
	
	SWEP.WM = "models/weapons/wkalashnikovrpk.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-1.4, 2.0, -1)
	SWEP.WMAng = Vector(170, 180, -0)
	
	SWEP.M203OffsetCycle_Reload = 0.65
	SWEP.M203OffsetCycle_Reload_Empty = 0.73
	SWEP.M203OffsetCycle_Draw = 0
	
	SWEP.IronsightPos = Vector(-1.708, -5.664, 0.689)
	SWEP.IronsightAng = Vector(2.052, -0.009, 0)
	
	SWEP.FoldSightPos = Vector(-2.208, -4.3, 0.143)
	SWEP.FoldSightAng = Vector(0.605, 0, -0.217)
		
	SWEP.EoTechPos = Vector(-1.716, -1.622, -0.019)
	SWEP.EoTechAng = Vector(0, 0.0, 0)
	
	SWEP.AimpointPos = Vector(-1.726, -1.111, 0.006)
	SWEP.AimpointAng = Vector(0.0, 0.0, 0)
	
	SWEP.KobraPos = Vector(-1.719, -1.754, 0.324)
	SWEP.KobraAng = Vector(-0, 0, 0)

	SWEP.PSOPos = Vector(-1.629, 0, 0.379)
	SWEP.PSOAng = Vector(0, -0.0, 0)
	
	SWEP.M203Pos = Vector(0.091, -4.321, 0.839)
	SWEP.M203Ang = Vector(0, 0, 0)
	
	SWEP.ShortDotPos = Vector(-2.297, -3.812, -0.493)
	SWEP.ShortDotAng = Vector(-0.0, 0.0, 0)
	
	SWEP.AlternativePos = Vector(-0.387, 0.218, -0.612)
	SWEP.AlternativeAng = Vector(3.947, 0, 0)
	
	SWEP.CustomizePos = Vector(3.989, -0.313, 0.199)
	SWEP.CustomizeAng = Vector(6.018, 18.659, 0)
	
	SWEP.SprintPos = Vector(2.378, 0, -0.401)
	SWEP.SprintAng = Vector(-10.801, 24.122, 0) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-5.08, -2.698, -0.78), [2] = Vector(-2, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	SWEP.SchmidtShortDotAxisAlign = {right = 0, up = -0.0, forward = 0}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "rpk", rel = "", pos = Vector(0.166, -3.191, -1.895), angle = Angle(0, 0, 0), size = Vector(0.699, 0.699, 0.699)},
		["md_kobra"] = { model = "models/cw2/attachments/kobra.mdl", bone = "rpk", rel = "", pos = Vector(0.73, 1.613, -1.301), angle = Angle(0, 180, 0), size = Vector(0.5, 0.5, 0.5)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "rpk", rel = "", pos = Vector(0.536, -6.803, -5.457), angle = Angle(0, -90, 0), size = Vector(0.699, 0.699, 0.699)},
		["md_m203"] = {model = "models/cw2/attachments/m203.mdl", bone = "body", rel = "", pos = Vector(1.713, -2.566, 1.774), angle = Angle(0, -90, 0), size = Vector(0.737, 0.737, 0.737)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "rpk", rel = "", pos = Vector(0.351, 20.885, -0.862), angle = Angle(0, 180, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_bipod"] = {model = "models/wystan/attachments/bipod.mdl", bone = "rpk", rel = "", pos = Vector(0.416, 8.628, -1.127), angle = Angle(0, 0, 0), size = Vector(0.75, 0.75, 0.75)},
		["md_pso1_fixed"] = {model = "models/cw2/attachments/pso.mdl", bone = "rpk", rel = "", pos = Vector(0.351, -1.823, -0.217), angle = Angle(0, 180, 0), size = Vector(0.5, 0.5, 0.5)},
		["md_rail"] = {model = "models/wystan/attachments/akrailmount.mdl", bone = "rpk", rel = "", pos = Vector(0.187, 0.75, 0.755), angle = Angle(0, 0, 0), size = Vector(0.699, 0.699, 0.699)},
		
	}
	
	SWEP.M203HoldPos = {
		["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
		["l_thumb_tip"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, 3.582, 47.046) },
	["L Hand"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0.01, 0), angle = Angle(3.2, 19.788, 59.991) },
	["L UpperArm"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0.245, 0.181), angle = Angle(1.236, 0, 0) },
	["l_thumb_mid"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(12.939, -9.054, 0) },
	["L Finger0"] = { scale = Vector(1, 1, 1), pos = Vector(0, -0.519, -0.125), angle = Angle(49.625, 21.764, 0) },
	["L Clavicle"] = { scale = Vector(1, 1, 1), pos = Vector(2.299, 0.924, -2.333), angle = Angle(-2.648, 0.328, -0.987) },
	["l_pinky_tip"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(55.604, 16.679, 0) }


	}	
	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.2, 0, 0)
	SWEP.LaserAngAdjust = Angle(0.0, 180, 0) 
end
SWEP.PSO1AxisAlign = {right = -0.01, up = 0.0, forward = 90}
SWEP.SchmidtShortDotAxisAlign = {right = 0.0, up = 0.0, forward = 0}
SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 0, regular = 0, fastmag = 1, exmagmk1 = 2}
SWEP.LuaViewmodelRecoil = false

SWEP.CustomizationMenuScale = 0.02

SWEP.Attachments = {[1] = {header = "Прицел", offset = {600, -300}, atts = {"md_kobra", "md_eotech", "md_aimpoint", "md_pso1_fixed"}},
	[2] = {header = "Ствол", offset = {-200, -300}, atts = {"md_pbs1"}},
	[3] = {header = "Рукоять", offset = {100, 100}, atts = {"md_bipod"}}}
	--["+reload"] = {header = "Ammo", offset = {700, 400}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"shoot1", "shoot2", "shoot3"},
	reload = "reload",
	idle = "idle",
	draw = "draw"}
	
SWEP.Sounds = {draw = {{time = 0.2, sound = "CW_FOLEY_HEAVY"}},

	reload = {[1] = {time = 0.2, sound = "CW_FOLEY_MEDIUM"},
	[2] = {time = 1.8, sound = "CW_RPK74MAGOUT"},
	[3] = {time = 2.9, sound = "CW_RPK74MAGIN"},
	[4] = {time = 3.1, sound = "CW_RPK74MAGFINISH"},
	[5] = {time = 4.6, sound = "CW_RPK74BOLTRELEASE"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"auto", "3burst", "semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие" --  "CW 2.0 Putin Collection"

SWEP.Author			= "Silent"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 75
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/kalashnikovrpk7.mdl"
SWEP.WorldModel		= "models/weapons/wkalashnikovrpk.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 45
SWEP.Primary.DefaultClip	= 90
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2" --"5.45x39MM"

SWEP.FireDelay = 0.1
SWEP.FireSound = "CW_RPK74_FIRE"
SWEP.FireSoundSuppressed = "CW_RPK74FIRE_SUPPRESSED"
SWEP.Recoil = 1.4

SWEP.HipSpread = 0.07
SWEP.AimSpread = 0.004
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadPerShot = 0.06
SWEP.SpreadCooldown = 0.02
SWEP.Shots = 1
SWEP.Damage = 35
SWEP.DeployTime = 0.6

SWEP.ReloadSpeed = 1.2
SWEP.ReloadTime = 3.7
SWEP.ReloadTime_Empty = 5.1
SWEP.ReloadHalt = 3.7
SWEP.ReloadHalt_Empty = 5.1
SWEP.SnapToIdlePostReload = true


