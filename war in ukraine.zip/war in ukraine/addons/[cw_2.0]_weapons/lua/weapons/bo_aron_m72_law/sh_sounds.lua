--[[
addons/[cw_2.0]_weapons/lua/weapons/bo_aron_m72_law/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("ARON_M72_FIRE", "my_weapons/bo_m72_law/m72_law_fire.mp3", 1, 160, CHAN_STATIC)
CustomizableWeaponry:addFireSound("ARON_M72_FIRE2", "my_weapons/bo_m72_law/m72_law_fire.mp3", 1, 160, CHAN_STATIC)

