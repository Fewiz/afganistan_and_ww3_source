--[[
addons/[cw_2.0]_weapons/lua/weapons/bo_aron_m72_law/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "РПГ-26" -- M72 LAW
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 1
	
	SWEP.IconLetter = "w"
	killicon.Add( "cw_aron_bo_m72", "aron_icons/m72", Color(255, 80, 0, 150))
	SWEP.SelectIcon = surface.GetTextureID("aron_icons/m72")
	
	
	SWEP.MuzzleEffect = "muzzleflash_6"
	SWEP.PosBasedMuz = true
	SWEP.DryFire = true
	SWEP.ViewbobEnabled = true
	SWEP.ViewbobIntensity = 1
	SWEP.ZoomAmount = 5	
	SWEP.ReloadViewBobEnabled = true
	SWEP.CanCustomize = false
	
	SWEP.Shell = ""
	SWEP.ShellScale = 0
	SWEP.ShellOffsetMul = 0
	SWEP.ShellPosOffset = {x = 0, y = 1, z = 1}
	SWEP.MuzzlePosOffset = {x = -10, y = 0, z = 0}
	
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WM = "models/my_black_ops_weapons/m72_law/w_aron_m72law.mdl"
	SWEP.WMPos = Vector(-0.9, 1, 1)
	SWEP.WMAng = Vector(-10, 0, 180)

		
    SWEP.IronsightPos = Vector(-3.228, -0.603, -3.05)
	SWEP.IronsightAng = Vector(11, 0, 0) -- Vector(11.96, 0, 0)

	SWEP.LaserPosAdjust = Vector(0, -4, 0)
	SWEP.LaserAngAdjust = Angle(0, 0, 0) 
	
	SWEP.SprintPos = Vector(3.417, 4.421, -2.01)
	SWEP.SprintAng = Vector(-12.664, 30.25, 0)
	
	SWEP.CustomizePos = Vector(7.839, 0.402, -2.412)
	SWEP.CustomizeAng = Vector(23.215, 46.431, 21.809)
	
	SWEP.AlternativePos = Vector(0, 0, 0)
	SWEP.AlternativeAng = Vector(0, 0, 0)

	
	SWEP.MoveType = 1
	SWEP.ViewModelMovementScale = 1.5
  
	SWEP.CustomizationMenuScale = 0.01
	SWEP.BoltBonePositionRecoverySpeed = 20 -- how fast does the bolt bone move back into it's initial position after the weapon has fired
	 

end
SWEP.LuaViewmodelRecoil = false
SWEP.CanRestOnObjects = false
SWEP.ADSFireAnim = true

SWEP.AttachmentModelsVM = {
}

SWEP.Attachments = {
}

SWEP.Attachments = {}


SWEP.Animations = {fire = "fire",
	reload = "reload",
	idle = "idle",
	draw = "draw"}
	
	
	SWEP.Sounds = {
	
	reload = {[1] = {time = 0.2, sound = "my_weapons/bo_m72_law/m72_law_tap.wav"},
	[2] = {time = 0.8, sound = "my_weapons/bo_m72_law/m72_law_tap.wav"},
	[3] = {time = 1.0, sound = "my_weapons/bo_m72_law/foly_generic_gun_drop01.wav", "my_weapons/bo_m72_law/foly_generic_gun_drop02.wav"},
	[4] = {time = 1.9, sound = "my_weapons/bo_m72_law/m72_law_tap.wav"}},
	
	draw = {{time = 0.0, sound = "my_weapons/bo_generic2.wav"},
	{time = 0.6, sound = "my_weapons/bo_m72_law/m72_law_arm.wav"},
	{time = 1.3, sound = "my_weapons/bo_m72_law/m72_law_open.mp3"},
	{time = 1.7, sound = "my_weapons/bo_m72_law/m72_law_tap.wav"}}}
	
SWEP.AimViewModelFOV = 70
SWEP.SpeedDec = 0

SWEP.Slot = 4
SWEP.SlotPos = 0
SWEP.NormalHoldType = "rpg"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Взрывное оружие" -- [CW2.0] Vietnam
SWEP.SuppressedOnEquip = false

SWEP.SpeedDec = 60	

SWEP.Author			= "Doni Danger"
SWEP.Contact		= "Google.com"
SWEP.Purpose		= "Take out that fucking tank,Mason!"
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 70
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/my_black_ops_weapons/m72_law/fix/v_aron_m72law.mdl"
SWEP.WorldModel		= "models/my_black_ops_weapons/m72_law/w_aron_m72law.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 1
SWEP.Primary.DefaultClip	= 5
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "RPG_Round" --"rpg_round"

SWEP.FireDelay = 0.5
SWEP.FireSound = "ARON_M72_FIRE"
SWEP.FireSoundSuppressed = "ARON_M72_FIRE2"
SWEP.Recoil = 5

--
SWEP.HipSpread = 0.05 -- 0.15
SWEP.AimSpread = 0.0
SWEP.VelocitySensitivity = 0.9 -- 
SWEP.MaxSpreadInc = 0.01 --  0.15  0.05
SWEP.SpreadPerShot = 0.0
SWEP.SpreadCooldown = 0.001
SWEP.Shots = 1
SWEP.Damage = 1500
SWEP.DeployTime = 2.4
SWEP.Chamberable = false
--

SWEP.HipSpread = 0.15
SWEP.AimSpread = 0.0
SWEP.VelocitySensitivity = 0.9
SWEP.MaxSpreadInc = 0.01 --  0.15
SWEP.SpreadPerShot = 0.0
SWEP.SpreadCooldown = 0.001
SWEP.Shots = 1
SWEP.Damage = 2215  -- 200  150
SWEP.DeployTime = .85
SWEP.HolsterTime = .75

SWEP.ReloadSpeed = 0.5 -- 0.7
SWEP.ReloadTime = 2.4
SWEP.ReloadHalt = 2.4

SWEP.ReloadTime_Empty = 2.4
SWEP.ReloadHalt_Empty = 2.4
SWEP.SnapToIdlePostReload = false

local isAiming

if CLIENT then
	function SWEP:enteredAim()
		return self._KK_DODS_wasAiming == false and self:isAiming()
	end
	
	function SWEP:leftAim()
		return self._KK_DODS_wasAiming == true and not self:isAiming()
	end
	
	function SWEP:IndividualThink_DODS()
		if self:enteredAim() then
			self:playAnim("aim_enter", 0, 0)
		end
			
		if self:leftAim() then
			self:playAnim("aim_leave", 0, 0)
		end
		
		self._KK_DODS_wasAiming = self:isAiming()
	end
end
function SWEP:PrimaryAttack()
	if not self:canFireWeapon(1) then
			return
	end
	
	 
	--self.Owner:EmitSound("mili_terrorist/idle6.wav") 
	-- mili_terrorist/idle2.wav mili_terrorist/idle3.wav mili_terrorist/idle3.wav


	if self.Owner:KeyDown(IN_USE) then
		if self.Owner:GetCat() == "Моджахеды" then
			self.Owner:EmitSound( "weapons/doipack/shared/snackbar1.wav", 75 ) -- math.random (75,125) 
			self.Weapon:SetNextPrimaryFire( CurTime() + 1.45 )
			local TauntSounds = {
			"weapons/doipack/shared/snackbar1.wav",
			"weapons/doipack/shared/snackbar2.wav",
			"weapons/doipack/shared/snackbar3.wav",
			"weapons/doipack/shared/snackbar4.wav"}
			local random = math.random(1, #TauntSounds)   -- 
			--self.Owner:EmitSound(TauntSounds[random]) 
			--if (!SERVER) then return end
			--	return
		end 	
	end

	if not self:canFireWeapon(2) then
		return
	end
	
	if self.dt.Safe then
		self:CycleFiremodes()
		return
	end
	
	if not self:canFireWeapon(3) then
		return
	end
	
	mag = self:Clip1()
	CT = CurTime()
	
	if mag == 0 then
		self:EmitSound("CW_EMPTY", 100, 100)
		self:SetNextPrimaryFire(CT + 0.25)
		return
	end
	
	if self.BurstAmount and self.BurstAmount > 0 then
		if self.dt.Shots >= self.BurstAmount then
			return
		end
		
		self.dt.Shots = self.dt.Shots + 1
	end
	
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	if IsFirstTimePredicted() then
		local muzzleData = EffectData()
		muzzleData:SetEntity(self)
		util.Effect("cw_muzzleflash", muzzleData)
		
		if self.dt.Suppressed then
			self:EmitSound(self.FireSoundSuppressed, 105, 100)
		else
			self:EmitSound(self.FireSound, 105, 100)
		end
		
		if self.fireAnimFunc then
			self:fireAnimFunc()
		else
			if self.dt.State == CW_AIMING then
				if self.ADSFireAnim then
					self:playFireAnim()
				end
			else
				self:playFireAnim()
			end
		end
	end
	
			-- apply a global delay after shooting, if there is one

	Dist = self.Owner:GetShootPos():Distance(self.Owner:GetEyeTrace().HitPos)
	
	if Dist <= 45 then
		return
	end

	if self:Clip1() == 0 then
		return
	end

	aimVec = self.Owner:GetAimVector()
		
		local pos = self.Owner:GetShootPos()
		local eyeAng = self.Owner:EyeAngles()
		local forward = eyeAng:Forward()
		local offset = forward * 30 + eyeAng:Right() * 3.5 - eyeAng:Up() * 2.5
		
		if self:isAiming() then offset = forward * 35 + eyeAng:Right() * 0.5 - eyeAng:Up() * 2.5
		end
	
	if SERVER  then
			missile = ents.Create("ent_ins2rpghvatrocket")
			missile:SetPos(pos + offset)
			missile:SetAngles(eyeAng)
			missile:Spawn()
			missile:Activate()
			missile:SetOwner(self.Owner)
			local phys = missile:GetPhysicsObject()
			
		
		if IsValid(phys) then
			missile:SetVelocity(forward * 8500) -- 2996 4000
		end
 	end
	
	self:delayEverything(.65)
	self:setGlobalDelay(.65)
	
	self.Owner:ViewPunch(Angle(-12, 0, 1))
	
	
	self:SetClip1(0)
	
end


