--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_zastam76/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_ZASM76_FIRE", "weapons/cw_zastava/zastava.wav", 1, 100, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_ZASM76_FIRE_SUPPRESSED", "weapons/cw_zastava/zastava_sup.wav", 1, 75, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_ZASM76_MAGOUT", "weapons/cw_zastava/magout.wav")
CustomizableWeaponry:addReloadSound("CW_ZASM76_MAGIN", "weapons/cw_zastava/magin.wav")
CustomizableWeaponry:addReloadSound("CW_ZASM76_BOLTPULL", "weapons/cw_zastava/boltback.wav")
CustomizableWeaponry:addReloadSound("CW_ZASM76_BOLTRELEASE", "weapons/cw_zastava/boltrelease.wav")


