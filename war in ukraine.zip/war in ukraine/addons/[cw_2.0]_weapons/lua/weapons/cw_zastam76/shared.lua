--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_zastam76/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "«Застава» M76" -- Zastava M76
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.5
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_6"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.6
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 0.5, y = 1, z = -1}
	SWEP.SightWithRail = true
	SWEP.ForeGripOffsetCycle_Draw = 0.5
	SWEP.ForeGripOffsetCycle_Reload = 0.7
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.95
	SWEP.BoltShootOffset = Vector(-0, 3.0, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "Stars Fell On Alabama"
	SWEP.ADSFireAnim = false
	SWEP.WM = "models/weapons/w_snip_zasta.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-0.5, 0.3, -0)
	SWEP.WMAng = Vector(170, 180, -0)
	
	
	SWEP.IronsightPos = Vector(3.549, -4.066, 1.73)
	SWEP.IronsightAng = Vector(0.43, 0, 0)
		
	SWEP.EoTechPos = Vector(-2.464, -3.847, -0.168)
	SWEP.EoTechAng = Vector(0, 0.0, 0)
	
	SWEP.AimpointPos = Vector(-1.614, 0.632, -0.366)
	SWEP.AimpointAng = Vector(0.0, 0.0, 0)
	
	SWEP.KobraPos = Vector(3.526, -3.179, 1.169)
	SWEP.KobraAng = Vector(0, 0.0, 0)
	
	SWEP.HoloPos = Vector(-2.28, -4.172, -0.513)
	SWEP.HoloAng = Vector(0, 0, 0)
	
	SWEP.PSOPos = Vector(3.519, 0, 1.225)
	SWEP.PSOAng = Vector(0, -0.0, 0)
	
	SWEP.NXSPos = Vector(3.54, -3.491, 1.121)
	SWEP.NXSAng = Vector(0, 0, 0.0)
	
	SWEP.ShortDotPos = Vector(-2.297, -3.812, -0.493)
	SWEP.ShortDotAng = Vector(-0.0, 0.0, 0)
	
	SWEP.AlternativePos = Vector(2.536, -1.246, 1.034)
	SWEP.AlternativeAng = Vector(0.954, 0, 1.164)
	
	SWEP.CustomizePos = Vector(-2.892, 0, 0)
	SWEP.CustomizeAng = Vector(9.838, -30.97, 0)
	
	SWEP.SprintPos = Vector(0, 0, -1.15)
	SWEP.SprintAng = Vector(-3.431, -16.609, 0) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-5.08, -2.698, -0.78), [2] = Vector(-2, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.NXSAlign = {right = -0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	SWEP.SchmidtShortDotAxisAlign = {right = 0, up = -0.0, forward = 0}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "body_new", rel = "", pos = Vector(4.883, -0.125, -0.982), angle = Angle(0, -90, 0), size = Vector(0.55, 0.55, 0.55)},
		["md_kobra"] = {model = "models/cw2/attachments/kobra.mdl", bone = "Havana Daydreamin", rel = "", pos = Vector(-0.561, 0.268, -2.043), angle = Angle(0, 0, 0), size = Vector(0.649, 0.649, 0.649)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "Plane02", rel = "", pos = Vector(-8.337, -0.265, -4.751), angle = Angle(0, 0, 0), size = Vector(0.649, 0.649, 0.649)},
		["md_nightforce_nxs"] = {model = "models/cw2/attachments/l96_scope.mdl", bone = "Havana Daydreamin", rel = "", pos = Vector(0.008, 0.671, 2.944), angle = Angle(0, 90, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "Havana Daydreamin", rel = "", pos = Vector(-0.038, -24.99, -0.419), angle = Angle(0, 0, 0), size = Vector(0.649, 0.649, 0.649)},
		["md_bipod"] = {model = "models/wystan/attachments/bipod.mdl", bone = "Havana Daydreamin", rel = "", pos = Vector(-0.038, -12.917, -0.419), angle = Angle(0, 180, 0), size = Vector(0.75, 0.75, 0.75)},
		["md_pso1_fixed"] = {model = "models/cw2/attachments/pso.mdl", bone = "Havana Daydreamin", rel = "", pos = Vector(0.037, 3.483, -0.406), angle = Angle(0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_rail"] = {model = "models/wystan/attachments/akrailmount.mdl", bone = "Havana Daydreamin", rel = "", pos = Vector(0.128, 0.867, 0.899), angle = Angle(0, 180, 0), size = Vector(0.75, 0.75, 0.75)},
		
	}
	
	SWEP.M203HoldPos = {
		["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
	["Left1"] = { scale = Vector(1, 1, 1), pos = Vector(0, -0.124, 0), angle = Angle(-10.671, 0, 0) },
	["Left_L_Arm"] = { scale = Vector(1, 1, 1), pos = Vector(1.361, -0.608, 1.889), angle = Angle(0, 0, 0) },
	["Left2"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0.162), angle = Angle(-3.866, 21.604, -5.273) },
	["Left_Hand"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, -33.07, 0) },
	["Left_U_Arm"] = { scale = Vector(1, 1, 1), pos = Vector(-2.632, 0.398, -1.318), angle = Angle(0, -17.779, 88.009) }
}

	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.2, 0, 0)
	SWEP.LaserAngAdjust = Angle(0.0, 180, 0) 
end
SWEP.PSO1AxisAlign = {right = -0.01, up = 0.0, forward = 90}
SWEP.SchmidtShortDotAxisAlign = {right = 0.0, up = 0.0, forward = 0}
SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 0, regular = 0, fastmag = 1, exmagmk1 = 2}
SWEP.LuaViewmodelRecoil = false

SWEP.CustomizationMenuScale = 0.02

SWEP.Attachments = {[1] = {header = "Прицел", offset = {500, -300}, atts = {"md_kobra", "md_pso1_fixed", "md_nightforce_nxs"}},
	[2] = {header = "Ствол", offset = {-200, -200}, atts = {"md_pbs1"}},
	[3] = {header = "Сошки", offset = {100, 200}, atts = {"md_bipod"}}}
	--["+reload"] = {header = "Ammo", offset = {650, 200}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"Fire1", "Fire2"},
	reload = "Reload",
	idle = "Idle",
	draw = "Draw"}
	
SWEP.Sounds = {Draw = {{time = 0.1, sound = "CW_FOLEY_MEDIUM"}},

	Reload = {[1] = {time = 0.25, sound = "CW_FOLEY_MEDIUM"},
	[2] = {time = 0.6, sound = "CW_ZASM76_MAGOUT"},
	[3] = {time = 1.8, sound = "CW_ZASM76_MAGIN"},
	[4] = {time = 3.2, sound = "CW_ZASM76_BOLTPULL"},
	[5] = {time = 3.65, sound = "CW_ZASM76_BOLTRELEASE"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие"

SWEP.Author			= "Silent"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 70
SWEP.ViewModelFlip	= true
SWEP.ViewModel		= "models/weapons/zastavam76.mdl"
SWEP.WorldModel		= "models/weapons/w_snip_zasta.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 10
SWEP.Primary.DefaultClip	= 20
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "smg1" -- "7.92x57MM"

SWEP.FireDelay = 0.15
SWEP.FireSound = "CW_ZASM76_FIRE"
SWEP.FireSoundSuppressed = "CW_ZASM76_FIRE_SUPPRESSED"
SWEP.Recoil = 2.1

SWEP.HipSpread = 0.1
SWEP.AimSpread = 0.003
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.06
SWEP.SpreadPerShot = 0.035
SWEP.SpreadCooldown = 0.05
SWEP.Shots = 1
SWEP.Damage = 60
SWEP.DeployTime = 0.4

SWEP.ReloadSpeed = 1.2
SWEP.ReloadTime = 2.6
SWEP.ReloadTime_Empty = 4
SWEP.ReloadHalt = 2.6
SWEP.ReloadHalt_Empty = 4
SWEP.SnapToIdlePostReload = true


