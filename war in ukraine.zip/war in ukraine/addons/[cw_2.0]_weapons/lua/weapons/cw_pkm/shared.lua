--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_pkm/shared.lua
--]]

AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "ПКМ" -- PKM
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.5
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzle_center_M82"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.7
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 0.5, y = 1, z = -1}
	SWEP.SightWithRail = true
	SWEP.NoSilMuz = false
	SWEP.ForeGripOffsetCycle_Draw = 0.4
	SWEP.ForeGripOffsetCycle_Reload = 0.7
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.9
	SWEP.BoltShootOffset = Vector(-1, 0, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "bolt"
	SWEP.ADSFireAnim = false
	
	SWEP.WM = "models/weapons/w_machinepkmlmg.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-0, 3.0, -1)
	SWEP.WMAng = Vector(170, 180, -0)
	
	SWEP.IronsightPos = Vector(-2.22, -4.493, 0.37)
	SWEP.IronsightAng = Vector(-0.311, 0.024, 0)
	
	SWEP.FoldSightPos = Vector(-2.208, -4.3, 0.143)
	SWEP.FoldSightAng = Vector(0.605, 0, -0.217)
		
	SWEP.EoTechPos = Vector(-2.195, -3.977, -0.401)
	SWEP.EoTechAng = Vector(0.094, 0.114, 0.739)
	
	SWEP.AimpointPos = Vector(-2.224, -3.639, -0.346)
	SWEP.AimpointAng = Vector(-0, 0, -0.0)
	
	SWEP.MicroT1Pos = Vector(-2.208, 1, 0.83)
	SWEP.MicroT1Ang = Vector(-1.938, 0, -0.217)
	
	SWEP.ACOGPos = Vector(-2.227, -6.14, -0.382)
	SWEP.ACOGAng = Vector(-0, 0, 0)
	
	SWEP.ShortDotPos = Vector(-2.22, -4.536, -0.201)
	SWEP.ShortDotAng = Vector(0, 0, 0)
	
	SWEP.AlternativePos = Vector(0, -1.931, -0.728)
	SWEP.AlternativeAng = Vector(2.263, 1.485, 0)
	
	SWEP.CustomizePos = Vector(3.989, -0.313, 0.199)
	SWEP.CustomizeAng = Vector(6.018, 18.659, 0)
	
	SWEP.SprintPos = Vector(6.652, 0, 0)
	SWEP.SprintAng = Vector(-12.867, 45.099, 0) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-2.234, -6.12, -0.918), [2] = Vector(-0.653, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.SchmidtShortDotAxisAlign = {right = -0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	
	SWEP.BaseArm = "Bip01 L Clavicle"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "back", rel = "", pos = Vector(-0.083, 7.428, -2.852), angle = Angle(0, 180, 0), size = Vector(0.699, 0.699, 0.699)},
		["md_acog"] = {model = "models/wystan/attachments/2cog.mdl", bone = "back", rel = "", pos = Vector(-0.053, 6.453, -1.887), angle = Angle(0, 180, 0), size = Vector(0.529, 0.529, 0.529)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "back", rel = "", pos = Vector(-0.476, 11.192, -6.408), angle = Angle(0, 90, 0), size = Vector(0.699, 0.699, 0.699)},
		["md_schmidt_shortdot_fixed"] = {model = "models/cw2/attachments/schmidt.mdl", bone = "back", rel = "", pos = Vector(-0.053, 6.451, -1.905), angle = Angle(0, 89.986, 0), size = Vector(0.529, 0.529, 0.529)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "PKM", rel = "", pos = Vector(0.344, -21.342, -0.543), angle = Angle(0, 0, 0), size = Vector(0.8, 0.8, 0.8)},
		["md_bipod"] = {model = "models/wystan/attachments/bipod.mdl", bone = "lock", rel = "", pos = Vector(0, -17.646, -2.342), angle = Angle(0, 0, 9.388), size = Vector(0.009, 0.009, 0.009)},
		["md_pso1"] = {model = "models/cw2/attachments/pso.mdl", bone = "Base", rel = "", pos = Vector(0.004, 5.158, -0.936), angle = Angle(-0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_rail"] = {model = "models/wystan/attachments/rail.mdl", bone = "back", rel = "", pos = Vector(-0.051, 3.273, -0.115), angle = Angle(0, 89.986, 0), size = Vector(0.699, 0.809, 0.66)},
		
	}
	

	SWEP.ForeGripHoldPos = {
		["Bip01 L Finger3"] = {pos = Vector(0, 0, 0), angle = Angle(0, 42.713, 0) },
		["Bip01 L Clavicle"] = {pos = Vector(-3.299, 1.235, -1.79), angle = Angle(-55.446, 11.843, 0) },
		["Bip01 L Forearm"] = {pos = Vector(0, 0, 0), angle = Angle(0, 0, 42.41) },
		["Bip01 L Finger02"] = {pos = Vector(0, 0, 0), angle = Angle(0, 71.308, 0) },
		["Bip01 L Finger11"] = {pos = Vector(0, 0, 0), angle = Angle(0, 25.795, 0) },
		["Bip01 L Finger4"] = {pos = Vector(0, 0, 0), angle = Angle(0, 26.148, 0) },
		["Bip01 L Finger1"] = {pos = Vector(0, 0, 0), angle = Angle(6.522, 83.597, 0) },
		["Bip01 L Finger0"] = {pos = Vector(0, 0, 0), angle = Angle(23.2, 16.545, 0) },
		["Bip01 L Finger42"] = {pos = Vector(0, 0, 0), angle = Angle(0, 31.427, 0) },
		["Bip01 L Finger32"] = {pos = Vector(0, 0, 0), angle = Angle(0, 29.565, 0) },
		["Bip01 L Hand"] = {pos = Vector(0, 0, 0), angle = Angle(9.491, 14.793, -15.926) },
		["Bip01 L Finger12"] = {pos = Vector(0, 0, 0), angle = Angle(0, -9.195, 0) },
		["Bip01 L Finger21"] = {pos = Vector(0, 0, 0), angle = Angle(0, 10.164, 0) },
		["Bip01 L Finger01"] = {pos = Vector(0, 0, 0), angle = Angle(0, 18.395, 0) },
		["Bip01 L Finger2"] = {pos = Vector(0, 0, 0), angle = Angle(2.411, 57.007, 0) }
	}

	
	SWEP.LaserPosAdjust = Vector(1, 0, 0)
	SWEP.LaserAngAdjust = Angle(2, 180, 0) 
end

SWEP.MuzzleVelocity = 900 -- in meter/s

SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.BarrelBGs = {main = 3, longris = 4, long = 3, magpul = 2, ris = 1, regular = 0}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 5, regular = 0, round60 = 1}
SWEP.LuaViewmodelRecoil = false

SWEP.Attachments = {[1] = {header = "Прицел", offset = {800, -500}, atts = {"md_eotech", "md_aimpoint", "md_schmidt_shortdot_fixed", "md_acog"}},
	[2] = {header = "Ствол", offset = {-100, -200}, atts = {"md_pbs1"}},
	[3] = {header = "Сошки", offset = {100, 200}, atts = {"md_bipod"}}}
	--["+reload"] = {header = "Ammo", offset = {800, 300}, atts = {"am_magnum", "am_matchgrade"}}}
	
SWEP.Animations = {fire = {"shoot1", "shoot2"},
	reload = "reload",
	idle = "idle",
	draw = "draw"}
	
SWEP.Sounds = {draw = {{time = 0.2, sound = "CW_FOLEY_HEAVY"}},

	reload = {[1] = {time = 0.2, sound = "CW_FOLEY_HEAVY"},
	[2] = {time = 0.7, sound = "CW_PKPCHENEG_COVERUP"},
	[3] = {time = 1.2, sound = "CW_PKPCHENEG_BULLETMOVE"},
	[4] = {time = 2.5, sound = "CW_PKPCHENEG_BOXOUT"},
	[5] = {time = 3.6, sound = "CW_PKPCHENEG_BOXIN"},
	[6] = {time = 4.2, sound = "CW_PKPCHENEG_CHAIN"},
	[7] = {time = 4.8, sound = "CW_PKPCHENEG_COVERDOWN"},
	[8] = {time = 5.3, sound = "CW_PKPCHENEG_COVERTAP"},
	[9] = {time = 5.9, sound = "CW_PKPCHENEG_BOLT"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 3
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"auto", "semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие" --  "CW 2.0 Putin Collection"

SWEP.Author			= "Spy"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 75
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/v_pulemyotpkmlmg.mdl"
SWEP.WorldModel		= "models/weapons/w_machinepkmlmg.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 100
SWEP.Primary.DefaultClip	= 200
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2" --"7.62x54MMR"

SWEP.FireDelay = 0.075
SWEP.FireSound = "CW_PKPCHENEG_FIRE"
SWEP.FireSoundSuppressed = "CW_PKPCHENEG_FIRE_SUPPRESSED"
SWEP.Recoil = 1.1

SWEP.HipSpread = 0.06
SWEP.AimSpread = 0.006
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.06
SWEP.SpreadPerShot = 0.09
SWEP.SpreadCooldown = 0.02
SWEP.Shots = 1
SWEP.Damage = 38
SWEP.DeployTime = 0.6

SWEP.ReloadSpeed = 1.05
SWEP.ReloadTime = 7
SWEP.ReloadTime_Empty = 7
SWEP.ReloadHalt = 7
SWEP.ReloadHalt_Empty = 7
SWEP.Chamberable = false
SWEP.SnapToIdlePostReload = true

