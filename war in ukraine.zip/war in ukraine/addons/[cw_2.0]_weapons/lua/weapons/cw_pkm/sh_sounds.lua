--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_pkm/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_PKPCHENEG_FIRE", "weapons/cw_pkpcheneg/pkm.wav", 1, 100, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_PKPCHENEG_FIRE_SUPPRESSED", "weapons/cw_pkpcheneg/pkm_sup.wav", 1, 80, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_COVERUP", "weapons/cw_pkpcheneg/coverup.wav")
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_BULLETMOVE", "weapons/cw_pkpcheneg/movebullet.wav")
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_BOXOUT", "weapons/cw_pkpcheneg/boxout.wav")
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_BOXIN", "weapons/cw_pkpcheneg/boxin.wav")
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_CHAIN", "weapons/cw_pkpcheneg/chainmove.wav")
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_COVERDOWN", "weapons/cw_pkpcheneg/coverdown.wav")
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_COVERTAP", "weapons/cw_pkpcheneg/covertap.wav")
CustomizableWeaponry:addReloadSound("CW_PKPCHENEG_BOLT", "weapons/cw_pkpcheneg/bolt.wav")


