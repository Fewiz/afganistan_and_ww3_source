--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_aek971/shared.lua
--]]
AddCSLuaFile()
AddCSLuaFile("sh_sounds.lua")
include("sh_sounds.lua")

if CLIENT then
	SWEP.DrawCrosshair = false
	SWEP.PrintName = "АЕК-971"
	SWEP.CSMuzzleFlashes = true
	SWEP.ViewModelMovementScale = 0.3
	
	SWEP.IconLetter = "w"
	killicon.AddFont("cw_ar15", "CW_KillIcons", SWEP.IconLetter, Color(255, 80, 0, 150))
	
	SWEP.MuzzleEffect = "muzzleflash_6"
	SWEP.PosBasedMuz = true
	SWEP.SnapToGrip = true
	SWEP.ShellScale = 0.5
	SWEP.ShellOffsetMul = 0.0
	SWEP.ShellPosOffset = {x = 0.5, y = 1, z = -1}
	SWEP.SightWithRail = true
	SWEP.ForeGripOffsetCycle_Draw = 0.3
	SWEP.ForeGripOffsetCycle_Reload = 0.7
	SWEP.ForeGripOffsetCycle_Reload_Empty = 0.95
	SWEP.BoltShootOffset = Vector(-2, 0, -0)
	SWEP.OffsetBoltOnBipodShoot = false
	SWEP.BoltBone = "slide"
	SWEP.ADSFireAnim = false
	
	SWEP.WM = "models/weapons/w_rif_aek9.mdl"
	SWEP.DrawTraditionalWorldModel = false
	SWEP.WMPos = Vector(-1.0, 3.3, -2)
	SWEP.WMAng = Vector(170, 180, -0)
	
	
	SWEP.IronsightPos = Vector(-2.445, -4.467, 0.49)
	SWEP.IronsightAng = Vector(1.057, 0.685, 0)
	
	SWEP.FoldSightPos = Vector(-2.208, -4.3, 0.143)
	SWEP.FoldSightAng = Vector(0.605, 0, -0.217)
		
	SWEP.EoTechPos = Vector(-2.464, -3.847, -0.168)
	SWEP.EoTechAng = Vector(0, 0.0, 0)
	
	SWEP.AimpointPos = Vector(-1.614, 0.632, -0.366)
	SWEP.AimpointAng = Vector(0.0, 0.0, 0)
	
	SWEP.KobraPos = Vector(-2.406, -4.231, 0.137)
	SWEP.KobraAng = Vector(0, 0.679, 0)
	
	SWEP.HoloPos = Vector(-2.28, -4.172, -0.513)
	SWEP.HoloAng = Vector(0, 0, 0)
	
	SWEP.PSOPos = Vector(1.922, -1.823, 0.665)
	SWEP.PSOAng = Vector(0, -0.0, 0)
	
	SWEP.M203Pos = Vector(0.091, -4.321, 0.839)
	SWEP.M203Ang = Vector(0, 0, 0)
	
	SWEP.ShortDotPos = Vector(-2.297, -3.812, -0.493)
	SWEP.ShortDotAng = Vector(-0.0, 0.0, 0)
	
	SWEP.AlternativePos = Vector(-0.82, 0, -1.374)
	SWEP.AlternativeAng = Vector(1.444, 1.205, 0)
	
	SWEP.CustomizePos = Vector(3.989, -0.313, 0.199)
	SWEP.CustomizeAng = Vector(6.018, 18.659, 0)
	
	SWEP.SprintPos = Vector(2.378, 0, -0.401)
	SWEP.SprintAng = Vector(-10.801, 24.122, 0) 
	
	SWEP.BackupSights = {["md_acog"] = {[1] = Vector(-5.08, -2.698, -0.78), [2] = Vector(-2, 0, 0)}}

	SWEP.ACOGAxisAlign = {right = -0.0, up = 0, forward = 0}
	SWEP.M203CameraRotation = {p = -90, y = 0, r = -90}
	SWEP.SchmidtShortDotAxisAlign = {right = 0, up = -0.0, forward = 0}
	
	SWEP.BaseArm = "arm_controller_01"
	SWEP.BaseArmBoneOffset = Vector(-50, 0, 0)
	
	SWEP.AttachmentModelsVM = {
		["md_aimpoint"] = {model = "models/wystan/attachments/aimpoint.mdl", bone = "body_new", rel = "", pos = Vector(4.883, -0.125, -0.982), angle = Angle(0, -90, 0), size = Vector(0.55, 0.55, 0.55)},
		["md_kobra"] = {model = "models/cw2/attachments/kobra.mdl", bone = "Plane02", rel = "", pos = Vector(-0.401, -0.456, -1.145), angle = Angle(0, -90, 0), size = Vector(0.5, 0.5, 0.5)},
		["md_eotech"] = {model = "models/wystan/attachments/2otech557sight.mdl", bone = "Plane02", rel = "", pos = Vector(-8.337, -0.265, -4.751), angle = Angle(0, 0, 0), size = Vector(0.649, 0.649, 0.649)},
		["md_m203"] = {model = "models/cw2/attachments/m203.mdl", bone = "body", rel = "", pos = Vector(1.713, -2.566, 1.774), angle = Angle(0, -90, 0), size = Vector(0.737, 0.737, 0.737)},
		["md_pbs1"] = {model = "models/cw2/attachments/pbs1.mdl", bone = "Plane02", rel = "", pos = Vector(18.124, 0.175, -0.682), angle = Angle(0, -89.201, 0), size = Vector(0.819, 0.819, 0.819)},
		["md_foregrip"] = {model = "models/wystan/attachments/foregrip1.mdl", bone = "Plane02", rel = "", pos = Vector(7.541, -7.441, -1.976), angle = Angle(0, 0, 0), size = Vector(0.5, 0.5, 0.5)},
		["md_pso1"] = {model = "models/cw2/attachments/pso.mdl", bone = "Base", rel = "", pos = Vector(0.004, 5.158, -0.936), angle = Angle(-0, 0, 0), size = Vector(0.6, 0.6, 0.6)},
		["md_rail"] = {model = "models/wystan/attachments/akrailmount.mdl", bone = "Plane02", rel = "", pos = Vector(-1.27, 0.078, 0.925), angle = Angle(0, 89.759, 0), size = Vector(0.699, 0.699, 0.699)},
		
	}
	
	SWEP.M203HoldPos = {
		["r-upperarm-movement"] = { scale = Vector(1, 1, 1), pos = Vector(2.956, -0.082, -1.928), angle = Angle(0, 0, 0) }
	}

	SWEP.ForeGripHoldPos = {
	["Left1"] = { scale = Vector(1, 1, 1), pos = Vector(0, -0.124, 0), angle = Angle(-10.671, 0, 0) },
	["Left_L_Arm"] = { scale = Vector(1, 1, 1), pos = Vector(1.361, -0.608, 1.889), angle = Angle(0, 0, 0) },
	["Left2"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0.162), angle = Angle(-3.866, 21.604, -5.273) },
	["Left_Hand"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, -33.07, 0) },
	["Left_U_Arm"] = { scale = Vector(1, 1, 1), pos = Vector(-2.632, 0.398, -1.318), angle = Angle(0, -17.779, 88.009) }
}

	
	SWEP.AttachmentPosDependency = {[""] = {[""] = Vector(-0.225, 13, 3.15)},
	[""] = {[""] = Vector(-0.042, 9, -0.1), [""] = Vector(-0.042, 9, -0.1)}}
	
	SWEP.LaserPosAdjust = Vector(-0.2, 0, 0)
	SWEP.LaserAngAdjust = Angle(0.0, 180, 0) 
end
SWEP.PSO1AxisAlign = {right = -0.01, up = 0.0, forward = 90}
SWEP.SchmidtShortDotAxisAlign = {right = 0.0, up = 0.0, forward = 0}
SWEP.SightBGs = {main = 4, carryhandle = 0, foldsight = 1, none = 2}
SWEP.StockBGs = {main = 2, regular = 0, heavy = 1, sturdy = 2}
SWEP.MagBGs = {main = 0, regular = 0, fastmag = 1, exmagmk1 = 2}
SWEP.LuaViewmodelRecoil = true

SWEP.CustomizationMenuScale = 0.02

SWEP.Attachments = {[1] = {header = "Sight", offset = {500, -300}, atts = {"md_kobra", "md_eotech"}},
	[2] = {header = "Barrel", offset = {-200, -200}, atts = {"md_pbs1"}},
	[3] = {header = "Grip", offset = {100, 200}, atts = {"md_foregrip"}}}
	--["+reload"] = {header = "Ammo", offset = {650, 200}, atts = {"am_magnum", "am_matchgrade"}}}
	

SWEP.Animations = {fire = {"fire1", "fire2", "fire3"},
	reload = "reload",
	idle = "idle",
	draw = "draw"}
	
SWEP.Sounds = {draw = {{time = 0.2, sound = "CW_FOLEY_MEDIUM"}},

	reload = {[1] = {time = 0.25, sound = "CW_FOLEY_MEDIUM"},
	[2] = {time = 0.5, sound = "CW_AEK971MAGOUT"},
	[3] = {time = 1.0, sound = "CW_AEK971MAGIN"},
	[4] = {time = 1.9, sound = "CW_AEK971BOLTRELEASE"}}}

SWEP.SpeedDec = 30

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.RunHoldType = "passive"
SWEP.FireModes = {"auto", "3burst", "semi"}
SWEP.Base = "cw_base"
SWEP.Category = "Оружие" -- CW 2.0 Putin CollectionОружие

SWEP.Author			= "Silent"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 65
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/v_rif_aek9.mdl"
SWEP.WorldModel		= "models/weapons/w_rif_aek9.mdl"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= 30
SWEP.Primary.DefaultClip	= 60
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2" -- "5.45x39MM"

SWEP.FireDelay = 0.0667
SWEP.FireSound = "CW_AEK971_FIRE"
SWEP.FireSoundSuppressed = "CW_AEK971FIRE_SUPPRESSED"
SWEP.Recoil = 1.1

SWEP.HipSpread = 0.05
SWEP.AimSpread = 0.005
SWEP.VelocitySensitivity = 1.0
SWEP.MaxSpreadInc = 0.045
SWEP.SpreadPerShot = 0.035
SWEP.SpreadCooldown = 0.02
SWEP.Shots = 1
SWEP.Damage = 30
SWEP.DeployTime = 0.6

SWEP.ReloadSpeed = 0.8
SWEP.ReloadTime = 1.6
SWEP.ReloadTime_Empty = 3.0
SWEP.ReloadHalt = 1.6
SWEP.ReloadHalt_Empty = 3.0
SWEP.SnapToIdlePostReload = true


