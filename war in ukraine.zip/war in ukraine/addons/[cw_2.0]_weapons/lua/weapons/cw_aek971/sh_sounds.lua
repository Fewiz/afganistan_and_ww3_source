--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_aek971/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_AEK971_FIRE", "weapons/cw_aek971/aek971.wav", 1, 100, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_AEK971FIRE_SUPPRESSED", "weapons/cw_aek971/aek971_sup.wav", 1, 75, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_AEK971MAGOUT", "weapons/cw_aek971/magout.wav")
CustomizableWeaponry:addReloadSound("CW_AEK971MAGIN", "weapons/cw_aek971/magin.wav")
CustomizableWeaponry:addReloadSound("CW_AEK971BOLTRELEASE", "weapons/cw_aek971/boltpull.wav")


