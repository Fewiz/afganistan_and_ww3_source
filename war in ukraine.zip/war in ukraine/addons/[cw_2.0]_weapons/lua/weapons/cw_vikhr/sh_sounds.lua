--[[
addons/[cw_2.0]_weapons/lua/weapons/cw_vikhr/sh_sounds.lua
--]]
CustomizableWeaponry:addFireSound("CW_VIKHR_FIRE", "weapons/cw_vikhr/vikhr.wav", 1, 90, CHAN_STATIC)
CustomizableWeaponry:addFireSound("CW_VIKHR_SUPPRESSED", "weapons/cw_vikhr/vikhr_sup.wav", 1, 65, CHAN_STATIC)
CustomizableWeaponry:addReloadSound("CW_AEK971MAGOUT", "weapons/cw_aek971/magout.wav")
CustomizableWeaponry:addReloadSound("CW_AEK971MAGIN", "weapons/cw_aek971/magin.wav")
CustomizableWeaponry:addReloadSound("CW_AEK971BOLTRELEASE", "weapons/cw_aek971/boltpull.wav")


