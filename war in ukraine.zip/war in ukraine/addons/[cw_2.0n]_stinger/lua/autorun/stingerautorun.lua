--[[
addons/[cw_2.0n]_stinger/lua/autorun/stingerautorun.lua
--]]
if CLIENT then
	killicon.Add( "sent_stinger_missile", "hud/swepicons/weapon_mw2_stinger", Color( 255, 255, 255, 255 ) )
end

resource.AddFile( "sound/stinger/locked.wav" );
resource.AddFile( "sound/stinger/check.wav" );
resource.AddFile( "sound/stinger/rocketfire.wav" );
resource.AddFile( "sound/stinger/ignite.wav" );
sound.Add( { name = "locked", channel = CHAN_STATIC, volume = 1.0, soundlevel = 80, pitchstart = 100, pitchend = 100, sound = "stinger/locked.wav" } )

