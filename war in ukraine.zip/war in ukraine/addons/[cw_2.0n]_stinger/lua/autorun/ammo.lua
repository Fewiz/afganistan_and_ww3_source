--[[
addons/[cw_2.0n]_stinger/lua/autorun/ammo.lua
--]]
game.AddAmmoType({
name = "fim_92_missile",
dmgtype = DMG_BULLET,
force = 2000,
plydmg = 0,
npcdmg = 0
})

