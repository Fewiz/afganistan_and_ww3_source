--[[
addons/[cw_2.0n]_stinger/lua/entities/sent_stinger_missile/shared.lua
--]]
ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "Stinger"
ENT.Author		= "Feihc"



