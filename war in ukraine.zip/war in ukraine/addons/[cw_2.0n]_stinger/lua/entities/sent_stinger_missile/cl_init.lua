--[[
addons/[cw_2.0n]_stinger/lua/entities/sent_stinger_missile/cl_init.lua
--]]

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

include('shared.lua')

language.Add( "sent_rocket", "Rocket" )

