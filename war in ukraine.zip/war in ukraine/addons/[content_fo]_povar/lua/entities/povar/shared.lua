--[[
addons/[content_fo]_povar/lua/entities/povar/shared.lua
--]]
ENT.Type = "ai"
ENT.Base = "base_ai"
ENT.PrintName = "(1) Продавец СССР"
ENT.Category = "Продавцы"
ENT.Spawnable = true
ENT.AutomaticFrameAdvance = true
ENT.AdminOnly = true
  
function ENT:SetupDataTables()
  self:NetworkVar("String", 1, "ThreeDeeTwoDee")
  self:NetworkVar("Bool", 2, "ThreeDeeStare")
end

