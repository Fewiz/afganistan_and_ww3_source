--[[
addons/igsmodification/lua/igs/settings/sh_additems.lua
--]]

local vip_description = [[
(при покупке VIP на 6 месяцев, в подарок вы получаете 5000 рублей на игровой счёт!)
]]


IGS("VIP на месяц", "vip_na_mesyac"):SetULXGroup("VIP")
--:SetPrice(190):SetDiscountedFrom(300)  
:SetPrice(270)
:SetBAdminGroup("VIP", 1)
:SetHighlightColor(Color(225,175,0))
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false) 
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889872812012097656/2.png") 
:SetTerm(30) -- 30 дней
:SetCategory("Группы")
:SetDescription(vip_description)
--:SetGlobal(true)
 

IGS("VIP (3 месяца)", "vip_na_3mesyac"):SetULXGroup("VIP")
--:SetPrice(190):SetDiscountedFrom(300)  
:SetPrice(450)
:SetBAdminGroup("VIP", 2)
:SetHighlightColor(Color(225,175,0))
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false) 
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873125498552410/3.png") 
:SetTerm(90) -- 30 дней
:SetCategory("Группы")
:SetDescription(vip_description)


IGS("VIP (6 месяца)", "vip_na_6mesyac"):SetULXGroup("VIP") -- vip_na_vsegda
--:SetPrice(390):SetDiscountedFrom(900) 
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false) 
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetPrice(850)
:SetBAdminGroup("VIP", 3)
:SetHighlightColor(Color(225,175,0))
:SetCategory("Группы")
:SetDescription(vip_description)
:SetTerm(180)
:SetOnActivate(function(pl)
	pl:AddMoney(5000)
end)


-------------------------------------

PL_MILLIONS = PL.Add("millions",{"₽", "₽", "₽"})
local GROUP_MONEY = IGS.NewGroup("Игровая валюта")
	:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889854395586592878/3.png")

for _,t in ipairs({
	-- кол-во к рублей, цена
	{500,100},   -- 150
	{2500,500},   -- 500
	{5000,1000},  -- 750
	{10000,2000}, --  1500
    {25000,4000}, -- 2500
}) do

	local ITEM = IGS(PL_MILLIONS(t[1]),"money_" .. t[1]) -- money_10mi
		:SetPrice(t[2])
		:SetDescription("Мгновенно и без проблем пополняет баланс игровой валюты на " .. t[1] .. " ₽! Чем больше валюты вы покупаете - тем выгоднее цена!\nЗа валюту вы сможете покупать себе оружие, машины или выкупать из плена.")
		--:SetDarkRPMoney(t[1])
		:SetCategory("Разное")
		:SetOnActivate(function(pl)
			pl:AddMoney(t[1])
		end)
		:SetStackable(true)

	GROUP_MONEY:AddItem(ITEM)
end

-------------------------------------

IGS("Гитара", "guitar"):SetWeapon("guitar")
--:SetPrice(45):SetDiscountedFrom(65) 
:SetPrice(120)
:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование гитару!")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889847226648653874/a6570bd09d1203e6.png", false) -- true значит, что указана моделька, а не ссылка
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889869108462633040/-_2021-09-21T163532.113.png") 
:SetCategory("Атмосфера")

IGS("Баян", "bayan"):SetWeapon("bayan")
--:SetPrice(45):SetDiscountedFrom(65) 
:SetPrice(150)
:SetTerm(30)
:SetDescription("")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889849874080735242/1.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889868987192705084/-_2021-09-21T163503.086.png") 
:SetCategory("Атмосфера")

IGS("Сигареты", "ciga"):SetWeapon("weapon_ciga_cheap")
:SetPrice(75)
:SetTerm(30)
:SetDescription("Вы сможете брать себе Сигарету!")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889852438608232468/2.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873618669015041/6.png") 
:SetCategory("Атмосфера")
:SetGlobal(true)

IGS("Аптечка (обл)", "apte"):SetWeapon("weapon_medkit2")
:SetPrice(90)
:SetTerm(30)
:SetDescription("Вы сможете брать себе аптечку на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Разное")
:SetGlobal(true)

IGS("Набор инструментов (обл)", "inst"):SetWeapon("weapon_simrepair2")
:SetPrice(90)
:SetTerm(30)
:SetDescription("Вы сможете брать себе набор инструментов на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Разное")
:SetGlobal(true)

IGS("Отмычка", "theif"):SetWeapon("lockpick")
:SetPrice(50)
:SetTerm(30)
:SetDescription("Вы сможете брать себе отмычку на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Разное")
:SetGlobal(true)

IGS("АК-12", "ak12"):SetWeapon("cw_ak12")
:SetPrice(150)
:SetTerm(60)
:SetDescription("Вы сможете брать себе AK-12 на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Оружие")
:SetGlobal(true)

IGS("Сайга", "saiga"):SetWeapon("cw_saiga12k_official")
:SetPrice(190)
:SetTerm(60)
:SetDescription("Вы сможете брать себе Сайгу на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Оружие")
:SetGlobal(true)

IGS("Застава", "zastava"):SetWeapon("cw_zastam76")
:SetPrice(200)
:SetTerm(60)
:SetDescription("Вы сможете брать себе винтовку Застава на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Оружие")
:SetGlobal(true)

IGS("ОЦ-33", "pernach"):SetWeapon("cw_ots")
:SetPrice(80)
:SetTerm(60)
:SetDescription("Вы сможете брать себе пистолет ОЦ-33 на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Оружие")
:SetGlobal(true)

IGS("L115", "l115"):SetWeapon("cw_l115")
:SetPrice(290)
:SetTerm(60)
:SetDescription("Вы сможете брать себе винтовку на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Оружие")
:SetGlobal(true)

IGS("MP9", "mp99"):SetWeapon("cw_mp9_official")
:SetPrice(150)
:SetTerm(60)
:SetDescription("Вы сможете брать себе винтовку на любой профе.")
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889864898337718342/6.png", false)
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889873195493105704/4.png") 
:SetCategory("Оружие")
:SetGlobal(true)


-------------------------------------

--[[
IGS("ППШ-41", "tfa_ins2_ppsh"):SetWeapon("tfa_ins2_ppsh")
:SetPrice(125)  -- 65
:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование знаменитое оружие! 7,62-мм пистолет-пулемёт образца 1941 года системы Шпагина (ППШ). Внимание: После покупки зайдите в услуги и выбирите данное оружие и поставьте галочку <<Выдавать при спавне>>")
:SetIcon("models/weapons/tfa_ins2/w_ppsh.mdl", true) -- true значит, что указана моделька, а не ссылка
:SetImage("https://i.imgur.com/70fCWQy.jpg") 
:SetGlobal(true)

IGS("Мосинка", "tfa_ins2_mosin"):SetWeapon("tfa_ins2_mosin")
:SetPrice(125)  -- 65
:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование знаменитое оружие! Русская 3-линейная (7,62-мм) винтовка Мосин-Наган образца 1891 года. Внимание: После покупки зайдите в услуги, выбирите данное оружие и поставьте галочку <<Выдавать при спавне>>")
:SetIcon("models/weapons/tfa_ins2/w_mosin.mdl", true) -- true значит, что указана моделька, а не ссылка
:SetImage("https://i.imgur.com/0ZmIWVh.jpg") 
:SetGlobal(true) ]]





IGS("Лётчик-истребитель", "profa_2")
:SetPrice(850)
--:SetPrice(500):SetDiscountedFrom(750) 

:SetHighlightColor(Color(255, 140, 17))
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889857623418081310/4.png", false) 
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889869794331996170/-_2021-09-21T163810.331.png") 
:SetStackable(true)
:SetCategory("Профессии")
:SetDescription("Даёт возможность летать на самолёте.")
:SetOnActivate(function(ply)
	ply:SetPData("sosig",22)
	ply:Kill()
	ply:Spawn()
end)

IGS("Сотрудник ЧВК «Wagner»", "profa_3")
:SetPrice(850)
--:SetPrice(500):SetDiscountedFrom(750) 

:SetHighlightColor(Color(255, 140, 17))
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889857623418081310/4.png", false) 
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889869794331996170/-_2021-09-21T163810.331.png") 
:SetStackable(true)
:SetCategory("Профессии")
:SetDescription("Даёт возможность почуствовать себя хорошо вооруженым сотрудником Российской Частной Военной Компании.")
:SetOnActivate(function(ply)
	ply:SetPData("sosig",5)
	ply:Kill()
	ply:Spawn()
end)

IGS("Боец-националист «Азов»", "profa_4")
:SetPrice(850)
--:SetPrice(500):SetDiscountedFrom(750) 

:SetHighlightColor(Color(255, 140, 17))
:SetIcon("https://media.discordapp.net/attachments/738423645184983140/889857623418081310/4.png", false) 
:SetImage("https://media.discordapp.net/attachments/738423645184983140/889869794331996170/-_2021-09-21T163810.331.png") 
:SetStackable(true)
:SetCategory("Профессии")
:SetDescription("Даёт возможность почуствовать себя хорошо вооруженым националистом.")
:SetOnActivate(function(ply)
	ply:SetPData("sosig",37)
	ply:Kill()
	ply:Spawn()
end)

