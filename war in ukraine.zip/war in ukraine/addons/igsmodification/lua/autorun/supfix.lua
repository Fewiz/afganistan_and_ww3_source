--[[
addons/igsmodification/lua/autorun/supfix.lua
--]]
timer.Simple(5, function()
hook.Remove("playerCanChangeTeam", "IGS")
end) 

