--[[
addons/low_health_effect/lua/autorun/lowhealth_sh.lua
--]]


if SERVER then
	resource.AddFile("materials/vgui/vignette_w.vmt")
	resource.AddFile("sound/lowhp/hbeat.wav")
end

AddCSLuaFile()

if CLIENT then
	-- as suggested by Kamshak, I will now start using locals in a different way so that my code is "readable"
	CreateClientConVar("lowhp_status", 1, true, true)
	
	local intensity = 0
	local hpwait, hpalpha = 0, 0
	local vig = surface.GetTextureID("vgui/vignette_w")
	
	local clr = {
		[ "$pp_colour_addr" ] = 0,
		[ "$pp_colour_addg" ] = 0,
		[ "$pp_colour_addb" ] = 0,
		[ "$pp_colour_brightness" ] = 0,
		[ "$pp_colour_contrast" ] = 1,
		[ "$pp_colour_colour" ] = 1,
		[ "$pp_colour_mulr" ] = 0,
		[ "$pp_colour_mulg" ] = 0,
		[ "$pp_colour_mulb" ] = 0
	}
	
	-- these are the settings for various parts of the script
	-- you can turn off various parts of it by changing 'true' to 'false' here
	
	local LHPS = {
		lowhpthreshold = 50, -- 25 -- when the player's health reaches this value, various low health effects will start kicking in and increasing in intensity as his health lowers
		drawVignette = true,
		drawRedFlash = true,
		playHeartbeatSound = true,
		muffleSounds = true,
		muffleSoundsOnHealth = 25  -- 15-- when the player's health reaches this value, sounds will become muffled
	}

	local function LowHP_HUDPaint()
		if GetConVarNumber("lowhp_status") <= 0 then
			return 
		end
		
		local ply = LocalPlayer()
		local hp = ply:Health()
		local x, y = ScrW(), ScrH()
		local FT = FrameTime()
		
		if LHPS.muffleSounds then
			if ply:Health() <= LHPS.muffleSoundsOnHealth then
				if not ply.lastDSP then
					ply:SetDSP(14)
					ply.lastDSP = 14
				end
			else
				if ply.lastDSP then
					ply:SetDSP(0)
					ply.lastDSP = nil
				end
			end
		end
		
		intensity = math.Approach(intensity, math.Clamp(1 - math.Clamp(hp / LHPS.lowhpthreshold, 0, 1), 0, 1), FT * 3)
		
		if intensity > 0 then
			if LHPS.drawVignette then
				surface.SetDrawColor(0, 0, 0, 200 * intensity)
				surface.SetTexture(vig)
				surface.DrawTexturedRect(0, 0, x, y)
			end
			
			clr[ "$pp_colour_colour" ] = 1 - intensity
			DrawColorModify(clr)
			
			if ply:Alive() then
				local CT = CurTime()
				
				if LHPS.playHeartbeatSound then
					if CT > hpwait then
						ply:EmitSound("lowhp/hbeat.wav", 45 * intensity, 100 + 20 * intensity)
						hpwait = CT + 0.5
					end
				end
				
				if LHPS.drawRedFlash then
					surface.SetDrawColor(255, 0, 0, (50 * intensity) * hpalpha)
					surface.DrawTexturedRect(0, 0, x, y)
					
					if CT < hpwait - 0.4 then
						hpalpha = math.Approach(hpalpha, 1, FrameTime() * 10)
					else
						hpalpha = math.Approach(hpalpha, 0.33, FrameTime() * 10)
					end
				end
			end
		end	
	end
	
	hook.Add("HUDPaint", "LowHP_HUDPaint", LowHP_HUDPaint)
end

-- LEAKED BY ANONYMOUS LEAKR ON LEAKFORUMS/LEAK.SX - Big thanks to snow for making this possible <3

