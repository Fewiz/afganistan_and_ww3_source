--[[
addons/weaponselector/lua/autorun/client/cl_hud_should_draw.lua
--]]
local function HideThings( name )
	if(name == "CHudHealth") 
	or (name == "CHudBattery") 
	/*or (name == "CHudCrosshair")*/ 
	or (name == "CHudWeaponSelection") 
	or (name == "CHudHealth") then
		return false 
	end
end
hook.Add("HUDShouldDraw", "HideThings", HideThings)

