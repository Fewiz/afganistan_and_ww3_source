
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_whitelist/lua/autorun/client/cl_ez_jw.lua ~

]]

surface.CreateFont("MST.Header", {
    font = "Trebuchet24",
    size = ScreenScale(8),
    weight = 150,
    antialias = true,
    shadow = true
})

surface.CreateFont("MST.ItemName", {
    font = "Trebuchet24",
    size = ScreenScale(6),
    weight = 150,
    antialias = true,
    shadow = false
})

local blur = Material("pp/blurscreen")

local function DrawBlur(panel, amount)
    local x, y = panel:LocalToScreen(0, 0)
    local scrW, scrH = ScrW(), ScrH()
--[[surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(blur)

    for i = 1, 3 do
        blur:SetFloat("$blur", (i / 3) * (amount or 6))
        blur:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(x * -1, y * -1, scrW, scrH)
    end]]
end

local function DrawOutline(w, h, t, col)
    draw.RoundedBox(0, 0, h - t, w, t, col)
    draw.RoundedBox(0, 0, h - h, w, t, col)
    draw.RoundedBox(0, w - t, 0, t, h, col)
    draw.RoundedBox(0, w - w, 0, t, h, col)
end

local pan_w, pan_h = ScrW() * .7, ScrW() * .5 -- ScrW() * .4, ScrW() * .4

local function OpenMenu()
    if LocalPlayer():GetUserGroup()=="user" and !table.HasValue(mst_jw.AllowedSteamID,ply:SteamID()) then return end 
    local picked_ply
    local picked_team
    local main = vgui.Create("DFrame")
    main:SetSize(0, 0)
    main:SetAlpha(0)
    main:Center()
    main:AlphaTo(255, 0.5)
    main:SizeTo(pan_w, pan_h, 1, 0, 2)
    main:MoveTo(ScrW() / 2.75 - pan_w / 2, ScrH() / 2 - pan_h / 2, 1, 0, 2) -- (ScrW() / 2 - pan_w / 2, ScrH() / 2 - pan_h / 2, 1, 0, 2)
    main:MakePopup()
    main:SetTitle('')
    main:ShowCloseButton(false)

    main.Paint = function(self, w, h)
        Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
        local cin = (math.sin(CurTime() * 6) + 1) / 2
        DrawBlur(self, 5)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100)) -- вся панель
        DrawOutline(w, h, 1, Color(0, 0, 0, 255)) -- боковые
        draw.RoundedBox(0, 0, 0, w, pan_h * .035, Color(0, 0, 0, 200)) -- вверхняя полоса
        draw.RoundedBox(0, 0, h - pan_h * .035, w, pan_h * .035, Color(0, 0, 0, 200))  -- нижняя полоса
        draw.SimpleText("Whitelist", "MST.Header", w / 2, 0, Color(255, 255, 255), 1, 0)
    end

    local Gscroll = vgui.Create("DScrollPanel", main)
    Gscroll:SetPos(2, pan_h * .035 + 2)
    Gscroll:SetSize(pan_w - 4, pan_h - pan_h * .035 - pan_h * .035 - pan_h * .035 - 6)

    Gscroll.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))  -- вся панель 2 (wtf)
    end

    Gscroll.VBar:SetWide(3)
    Gscroll:DockMargin(0, 0, 0, 0)
    local bar = Gscroll.VBar
    bar.Paint = function(this, w, h) end
    bar.btnUp.Paint = function(this, w, h) end
    bar.btnDown.Paint = function(this, w, h) end
    local listlayout = vgui.Create("DListLayout", Gscroll)
    listlayout:SetSize(Gscroll:GetWide(), Gscroll:GetTall())
    local categories = {}

    for i, data in pairs(rp.teams) do -- RPExtraTeams
        --print(i,data)
        --PrintTable(data)
        if (type(data.catagory) != "string") then
            data.catagory="Другие"
        end
        categories[data.catagory] = categories[data.catagory] or {}
        categories[data.catagory][i] = data
    end
 
    local panelOpenState = {}

    for name, jobs in pairs(categories) do
        panelOpenState[name] = true
    end

    for name, jobs in pairs(categories) do
        local category = vgui.Create("DPanel", listlayout)
        category.open = panelOpenState[name]

        if category.open then
            category:SetSize(listlayout:GetWide(), 28 + ((Gscroll:GetTall() * .069) * table.Count(jobs)))
        else
            category:SetSize(listlayout:GetWide(), 28)
        end

        function category:Paint(w, h)
            draw.RoundedBox(0, 0, 0, w, 29, Color(255, 255, 255, 5))
        end

        local fixes = vgui.Create("DButton", category)
        fixes:Dock(TOP)
        fixes:SetTall(28)
        fixes:SetText("")

        fixes.Paint = function(this, w, h)
            if (this.Depressed or this.m_bSelected) then
                draw.RoundedBox(0, 0, 0, w, h, Color(0, 255, 128, 50))
            elseif (this.Hovered) then
                draw.RoundedBox(0, 0, 0, w, h, Color(155, 155, 155, 50))
            else
                draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 150))
            end

            draw.SimpleText(name, "MST.ItemName", 30, h / 2, Color(255, 255, 255, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.RoundedBox(5, 10, 10, 10, 10, Color(255, 255, 255, 255))

            if category.open then
                draw.RoundedBox(3, 12, 12, 6, 6, Color(0, 0, 0, 255))
            end
        end

        function fixes:OnCursorEntered()
            self:SetCursor("hand")
        end

        function fixes:OnCursorExited()
            self:SetCursor("arrow")
        end

        function fixes:OnMousePressed()
            category.open = not category.open

            if category.open then
                category:SizeTo(self:GetWide(), 28 + ((Gscroll:GetTall() * .069) * table.Count(jobs)), 0.25, 0, 0.25, function(anim, panel) end)
            else
                category:SizeTo(self:GetWide(), 28, 0.25, 0, 0.25, function(anim, panel) end)
            end

            panelOpenState[name] = category.open
        end

        for k, v in pairs(jobs) do
            local job = vgui.Create("DButton", category)
            job:Dock(TOP)
            job:DockMargin(0, 0, 0, 0)
            job:SetTall(Gscroll:GetTall() * .07)
            job:SetContentAlignment(5)
            job:SetText("")
            local c = v.color

            job.Paint = function(this, w, h)
                if (this.Depressed or this.m_bSelected) then
                    draw.RoundedBox(0, 0, 0, w, h, Color(0, 255, 128, 50))
                elseif (this.Hovered) then
                    if v.max <= team.NumPlayers(k) and v.max > 0 then
                        draw.RoundedBox(0, 0, 0, w, h, Color(175, 75, 75, 80))
                    else
                        draw.RoundedBox(0, 0, 0, w, h, Color(155, 155, 155, 70))
                    end
                else
                    if v.max <= team.NumPlayers(k) and v.max > 0 then
                        draw.RoundedBox(0, 0, 0, w, h, Color(155, 55, 55, 70))
                    else
                        draw.RoundedBox(0, 0, 0, w, h, Color(c.r, c.g, c.b, 20))
                    end
                end

                draw.RoundedBox(0, 5, 5, h - 10, h - 10, Color(155, 155, 155, 70))
                draw.SimpleText(v.name, "MST.ItemName", h + 5, h / 2, Color(255, 255, 255, 200), 0, 1)
                local col2
                local cin = (math.sin(CurTime() * 6) + 1) / 2

                if picked_team == k then
                    col2 = Color(0, cin * 255, 0)
                else
                    col2 = Color(0, 0, 0, 0)
                end

                DrawOutline(w, h, 1, col2)
            end

            job.OnCursorEntered = function(this)
                surface.PlaySound("garrysmod/ui_hover.wav")
            end

            job.DoClick = function(this)
                surface.PlaySound("garrysmod/ui_click.wav")
                picked_team = k
            end

            local model = vgui.Create("DModelPanel", job)
            model:SetSize(job:GetTall() - 10, job:GetTall() - 10)
            model:SetPos(5, 5)
            model:SetFOV(45)
            model:SetCamPos(Vector(20, 15, 64))
            model:SetLookAt(Vector(0, 0, 64))

            if type(v.model) == "string" then
                model:SetModel(v.model)
            else
                model:SetModel(table.Random(v.model))
            end

            function model:LayoutEntity(Entity)
                return
            end
        end
    end

    local RpName = vgui.Create( "DTextEntry", main )
	RpName:SetPos( 2, pan_h - pan_h * .035 - pan_h * .035 - 2 )
	RpName:SetSize( pan_w - 4, pan_h * .035 )
	RpName:SetText( "" )  -- за изменение ников

    local createlot_main = vgui.Create("DFrame")

    createlot_main.Think = function(self)
        if not IsValid(self) then return end
        local x, y = main:GetPos()
        x = x + pan_w + 4
        self:SetPos(x, y)
        self:SetSize(main:GetWide() * .4, main:GetTall())
    end

    createlot_main:SetSize(pan_w * .4, pan_h)  -- кнопка "Изменить"
    createlot_main:MakePopup()
    createlot_main:SetTitle('')
    createlot_main:ShowCloseButton(false)

    createlot_main.Paint = function(self, w, h)
        DrawBlur(self, 5)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100)) -- вся панель
        DrawOutline(w, h, 1, Color(0, 0, 0, 255))  -- вся панель
        draw.RoundedBox(0, 0, 0, w, pan_h * .035, Color(0, 0, 0, 200)) -- вверх полоса
        draw.RoundedBox(0, 0, h - pan_h * .035, w, pan_h * .035, Color(0, 0, 0, 200))  -- ниж полоса
        draw.SimpleText("Выбор игрока", "MST.Header", w / 2, 0, Color(255, 255, 255), 1, 0)
    end

    local Cscroll = vgui.Create("DScrollPanel", createlot_main)
    Cscroll:SetPos(2, createlot_main:GetTall() * .035 + 2)
    Cscroll:SetSize(createlot_main:GetWide() *5, createlot_main:GetTall() - createlot_main:GetTall() * .035 - createlot_main:GetTall() * .035 - 2)
    ---------------------------------------(- 4,) -- от бока 
    Cscroll.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))  -- цвет панели игроков
    end

    Cscroll.VBar:SetWide(3)
    Cscroll:DockMargin(0, 0, 0, 0)
    local bar = Cscroll.VBar
    bar.Paint = function(this, w, h) end
    bar.btnUp.Paint = function(this, w, h) end
    bar.btnDown.Paint = function(this, w, h) end

    function Cscroll:DAddPlayer(v)
        local p = vgui.Create('DButton', Cscroll)
        p:Dock(TOP)--отступ б, отступ в, размер ш, размер в
        p:DockMargin(2, 1, 2, 1)
        p:SetTall(pan_h * .05)  -- Размер иконок
        p:SetText('')

        p.Paint = function(s, w, h)
            if (not IsValid(v)) then
                s:Remove()

                return
            end

            local col = team.GetColor(v:Team())
            draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))
            local col2
            local cin = (math.sin(CurTime() * 6) + 1) / 2

            if picked_ply == v then
                col2 = Color(0, cin * 255, 0)
            else
                col2 = Color(0, 0, 0)
            end

            DrawOutline(w, h, 1, col2)
            draw.SimpleTextOutlined(v:Name(), "MST.ItemName", h + 6, h / 2, Color(col.r, col.g, col.b), 0, 1, 1, Color(0, 0, 0))
        end

        p.OnCursorEntered = function(this)
            surface.PlaySound("garrysmod/ui_hover.wav")
        end

        p.DoClick = function()
            surface.PlaySound("garrysmod/ui_click.wav")

            if IsValid(v) then
                picked_ply = v
                RpName:SetText(v:Nick())
                picked_team = v:Team()
            end
        end

        local OwnerAvatar = vgui.Create("AvatarImage", p)
        OwnerAvatar:SetSize(p:GetTall() - 6, p:GetTall() - 6)
        OwnerAvatar:SetPos(3, 3)
        OwnerAvatar:SetPlayer(v, 64)
        local AvatarB = vgui.Create("DButton", OwnerAvatar)
        AvatarB:SetText('')
        AvatarB:Dock(FILL)
        AvatarB.Paint = function(self, w, h) end

        AvatarB.OnCursorEntered = function(this)
            surface.PlaySound("garrysmod/ui_hover.wav")
            OwnerAvatar:SetSize(p:GetTall() - 3, p:GetTall() - 3)
            OwnerAvatar:SetPos(1.5, 1.5)
        end

        AvatarB.OnCursorExited = function(this)
            surface.PlaySound("garrysmod/ui_hover.wav")
            OwnerAvatar:SetSize(p:GetTall() - 6, p:GetTall() - 6)
            OwnerAvatar:SetPos(3, 3)
        end

        AvatarB.DoClick = function(self)
            surface.PlaySound("garrysmod/ui_click.wav")
            gui.OpenURL("http://steamcommunity.com/profiles/" .. v:SteamID64())
        end
    end

    for k, v in ipairs(player.GetAll()) do 
       -- if LocalPlayer():GetPos():Distance(v:GetPos() < 1000) then
        Cscroll:DAddPlayer(v)-- end
       -- if LocalPlayer():GetPos():Distance(v:GetPos() < 1000) then print("Да"..v) end
    end

    local changejob = vgui.Create("DButton",createlot_main)
	changejob:SetText('')
	changejob:SetSize(createlot_main:GetWide(), createlot_main:GetTall()*.035)
	changejob:SetPos(0,createlot_main:GetTall() - createlot_main:GetTall()*.035)
	changejob.Paint = function(self,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(0,255,0,100))
		draw.SimpleText("Изменить", "MST.Header", w/2, h/2, Color(255, 255, 255, 255), 1, 1)
	end
	changejob.OnCursorEntered = function(this)
	    surface.PlaySound( "garrysmod/ui_hover.wav" )
	end
	changejob.DoClick = function(self)
		surface.PlaySound( "garrysmod/ui_click.wav" )
		
		if picked_ply ~= nil and picked_team ~= nil then
			net.Start("MST.ChangeTeam")
				net.WriteEntity(picked_ply)
				net.WriteFloat(picked_team)
				net.WriteString(RpName:GetText())
			net.SendToServer()
		end
	end

    local close = vgui.Create("DButton", main)
    close:SetText('')
    close:SetSize(pan_w * .07, pan_h * .035)
    close:SetPos(pan_w - pan_w * .07, 0)

    close.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
        draw.SimpleText("X", "MST.Header", w / 2, h / 2, Color(1, 255, 255, 255), 1, 1)
    end

    close.OnCursorEntered = function(this)
        surface.PlaySound("garrysmod/ui_hover.wav")
    end

    close.DoClick = function(self)
        surface.PlaySound("garrysmod/ui_click.wav")
        self:SetEnabled(false)
        main:AlphaTo(0, 0.9)

        createlot_main:AlphaTo(0, 0.9, 0, function()
            if IsValid(createlot_main) then
                createlot_main:Remove()
            end
        end)

        main:SizeTo(0, 0, 1, 0, 2, function()
            if IsValid(main) then
                main:Close()
            end
        end)

        main:MoveTo(ScrW() / 2, ScrH() / 2, 1, 0, 2, function()
            if IsValid(main) then
                main:Close()
            end
        end)
    end
end

net.Receive("MST.OpenMenu", OpenMenu)

-- hook.Add("Think","MST.CheckLP", function()
-- 	if IsValid(LocalPlayer()) then
-- 		net.Start("MST.RequestJob")
-- 		net.SendToServer()
-- 		hook.Remove("Think","MST.CheckLP")
-- 	end
-- end)

concommand.Add("wl",OpenMenu)