
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_whitelist/lua/autorun/sh_ez_jw.lua ~

]]

mst_jw = mst_jw or {}

mst_jw.command = "wl"  

mst_jw.Ranks = { 
	"root","admin+","admin","moderator","vip", "vip+", 
}
mst_jw.Job = {  
	"Инструктор", 
}

mst_jw.AllowedSteamID = { -- Who can change job and name
	"STEAM_0:0:145530561", -- STEAMID
 
	"STEAM_0:0:114373647", -- КМД ВДВ
	"STEAM_0:1:36668535", -- КМД КГБ
	"STEAM_0:1:464573945",
	
}