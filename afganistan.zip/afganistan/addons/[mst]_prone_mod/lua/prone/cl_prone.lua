
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_prone_mod/lua/prone/cl_prone.lua ~

]]

hook.Add("EntityNetworkedVarChanged", "prone.DetectProneStateChanges", function(ply, nwVarName, oldVal, newVal)
	if nwVarName == "prone.AnimationState" then
		if newVal == PRONE_GETTINGDOWN or newVal == PRONE_GETTINGUP then
			ply:AnimRestartMainSequence()
			ply:SetCycle(0)
			ply:SetPlaybackRate(1)
		elseif newVal == PRONE_NOTINPRONE then
			ply:ResetHull()
		end
	end
end)

-- Called to inform the player that they can't get up.
local lastGetUpPrintTime = 0		-- Last time a print was made.
local getUpWarningPrintDelay = 2	-- Time it takes before allowing another print.
function prone.CantGetUpWarning()
	local ct = CurTime()

	if lastGetUpPrintTime < ct then
		chat.AddText(Color(210, 10, 10), "Здесь недостаточно места, чтобы подняться.") -- There is not enough room to get up here
		lastGetUpPrintTime = ct + getUpWarningPrintDelay
	end
end

--------------------
-- prone.SetImpulse
--------------------
-- Desc:		This is the proper, predicted, way to toggle prone.
-- Arg One:		CUserCmd object, to set the impulse on.
function prone.SetImpulse(cmd)
	cmd:SetImpulse(PRONE_IMPULSE)
end

-----------------
-- prone.Request
-----------------
-- Desc:		Begins sending a prone impulse to the server.
local SendImpulse = false
function prone.Request()
	SendImpulse = true
end
concommand.Add("prone", function()
	prone.Request()
end)
net.Receive("prone.ResetAnimation", function()
	local ply = prone.ReadPlayer()
	local table = net.ReadTable()
	if IsValid(ply) then
		ply:AnimRestartMainSequence()
		ply.prone = table
	end
end)
-------------------
-- Bind key handler
-------------------
local function boolToNumString(bool)
	return bool and "1" or "0"
end
local bindkey_enabled = CreateClientConVar("prone_bindkey_enabled", boolToNumString(prone.Config.DefaultBindKey_Enabled), true, false, "Disable this to disable the prone bind key from working.")
local bindkey_key = CreateClientConVar("prone_bindkey_key", tostring(prone.Config.DefaultBindKey), true, false, "Don't directly change this convar. Use the command prone_config.")
local bindkey_doubletap = CreateClientConVar("prone_bindkey_doubletap", boolToNumString(prone.Config.DefaultBindKey_DoubleTap), true, false, "Enable to make them double tap the bind key to go prone.")
local jumptogetup = CreateClientConVar("prone_jumptogetup", "1", boolToNumString(prone.Config.DefaultJumpToGetUp), false, "If enabled you can press the jump key to get up.")
local jumptogetup_doubletap = CreateClientConVar("prone_jumptogetup_doubletap", boolToNumString(prone.Config.DefaultJumpToGetUp_DoubleTap), true, false, "If enabled you must double press jump to get up.")

local key_waspressed = false
local last_prone_request = 0
local doubletap_shouldsend = true
local doubletap_keypress_resettime = false
hook.Add("CreateMove", "prone.ReadBindKeys", function(cmd)
	local ply = LocalPlayer()
	if not IsValid(ply) then
		return
	end

	if SendImpulse then
		prone.SetImpulse(cmd)

		if cmd:TickCount() ~= 0 then
			SendImpulse = false
		end
	end

	if (system.IsLinux() or system.HasFocus()) and bindkey_enabled:GetBool() and ply:OnGround() and not vgui.GetKeyboardFocus() and not gui.IsGameUIVisible() and not gui.IsConsoleVisible() then
		if input.IsKeyDown(bindkey_key:GetInt()) then
			key_waspressed = true

			-- If doubletap is enabled they have a second to double click the bind key.
			doubletap_keypress_resettime = CurTime() + .66
		else
			if key_waspressed then
				if last_prone_request < CurTime() then
					doubletap_shouldsend = not doubletap_shouldsend

					if not bindkey_doubletap:GetBool() or doubletap_shouldsend then
						prone.Request()

						last_prone_request = CurTime() + 1.25
					end
				end

				key_waspressed = false
			end
		end

		if doubletap_keypress_resettime ~= false and doubletap_keypress_resettime < CurTime() then
			doubletap_keypress_resettime = false
			doubletap_shouldsend = true
		end
	end
end)

-- If they enable jump to get up then read that here.
local jumptogetup_presstime = 0
hook.Add("KeyPress", "Prone.JumpToGetUp", function(ply, key)
	if IsFirstTimePredicted() and ply == LocalPlayer() and ply:IsProne() and jumptogetup:GetBool() and key == IN_JUMP then
		if not jumptogetup_doubletap:GetBool() then
			prone.Request()
		else
			if jumptogetup_presstime > CurTime() then
				prone.Request()
			else
				jumptogetup_presstime = CurTime() + 1.25
			end
		end
	end
end)

-------------------
-- View Transitions
-------------------

-- Addons should use the prone.ShouldChangeCalcView and prone.ShouldChangeCalcViewModelView hooks instead of this cvar.
local enabledViewTransitions = CreateClientConVar("prone_disabletransitions", "0", true, false, "Disables the slide down and up of the get up/down animations.")

do
	local from, to, animEndTime, animLength, transitionVector
	hook.Add("CalcView", "prone.ViewTransitions", function(ply, pos)
		if ply ~= LocalPlayer() or enabledViewTransitions:GetBool() then
			return
		end

		local proneState = ply:GetProneAnimationState()

		-- Reset state and return if were not in a transition phase.
		
		if proneState ~= PRONE_GETTINGDOWN and proneState ~= PRONE_GETTINGUP then
			from = nil
			to = nil
			timeDiff = nil
			animLength = nil
			animEndTime = nil
			transitionVector = nil
			return
		end

		local result = hook.Run("prone.ShouldChangeCalcView", localply)
		if result == false then
			return
		end

		-- Get original view offset.
		local oldViewOffset = Vector(0, 0, 64)
		local plyProneStateData = prone.PlayerStateDatas[ply:SteamID()]
		if plyProneStateData then
			oldViewOffset = plyProneStateData:GetOriginalViewOffset()
			ply:SetViewOffsetDucked(plyProneStateData:GetOriginalViewOffsetDucked())
		end

		-- Set from, to, animLength, and animEndTime, at start of get down/up.
		if not from then
			animLength = ply:SequenceDuration((proneState == PRONE_GETTINGDOWN) and ply:LookupSequence("pronedown_stand") or ply:LookupSequence("proneup_stand"))-.2
			animEndTime = SysTime() + animLength

			-- Getting down
			if proneState == PRONE_GETTINGDOWN then
				from = pos
				to = pos - (oldViewOffset - prone.Config.View)+Vector(0,0,35)
			
			-- Getting up
			else
				from = pos
				to = pos + (oldViewOffset - prone.Config.View)-Vector(0,0,9)
			end
		end
		local frac = (animEndTime - SysTime())/animLength
		-- You might by wondering: "hey, why are you to and from variables flipped from what the Wiki says?"
		-- And my response will be: "Who fucking knows why this is backwards, but it is and it works!"
		transitionVector = LerpVector(frac, to, from)

		return {origin = transitionVector}
	end)
	hook.Add("CalcViewModelView", "prone.ViewTransitions", function()
		local localply = LocalPlayer()

		if enabledViewTransitions:GetBool() then
			return
		end

		local result = hook.Run("prone.ShouldChangeCalcViewModelView", localply)
		if result == false then
			return
		end

		if transitionVector then
			return transitionVector
		end
	end)
end

-------------------------------------------------
-- A derma panel for configuring your prone keys.
-------------------------------------------------
concommand.Add("prone_config", function()
	local frame = vgui.Create("DFrame")
	frame:SetSize(200, 210)
	frame:Center()
	frame:SetTitle("Режим лежа | MST") -- Prone Mod Config
	frame:MakePopup()

	local bindkey_enabled_checkbox = vgui.Create("DCheckBoxLabel", frame)
	bindkey_enabled_checkbox:SetText("Включить кастомную кнопку") -- Enable bind key
	bindkey_enabled_checkbox:SetPos(10, 30)
	bindkey_enabled_checkbox:SetValue(bindkey_enabled:GetInt())
	function bindkey_enabled_checkbox:OnChange(bool)
		RunConsoleCommand("prone_bindkey_enabled", bool and "1" or "0")
	end

	local bindkey_double_checkbox = vgui.Create("DCheckBoxLabel", frame)
	bindkey_double_checkbox:SetText("Режим двойного нажатия") -- Double tap bind key
	bindkey_double_checkbox:SetPos(10, 50)
	bindkey_double_checkbox:SetValue(bindkey_doubletap:GetInt())
	function bindkey_double_checkbox:OnChange(bool)
		RunConsoleCommand("prone_bindkey_doubletap", bool and "1" or "0")
	end

	local jump_getup = vgui.Create("DCheckBoxLabel", frame)
	jump_getup:SetText("Зажать прыжок, чтобы встать") -- Press jump to get up
	jump_getup:SetPos(10, 70)
	jump_getup:SetValue(jumptogetup:GetInt())
	function jump_getup:OnChange(bool)
		RunConsoleCommand("prone_jumptogetup", bool and "1" or "0")
	end

	local jump_getup_double = vgui.Create("DCheckBoxLabel", frame)
	jump_getup_double:SetText("Двойной прыжок, чтобы встать") -- Double tap jump to get up
	jump_getup_double:SetPos(10, 90)
	jump_getup_double:SetValue(jumptogetup_doubletap:GetInt())
	function jump_getup_double:OnChange(bool)
		RunConsoleCommand("prone_jumptogetup_doubletap", bool and "1" or "0")
	end

	local bindkey_desc = vgui.Create("DLabel", frame)
	bindkey_desc:SetText("Кастомная кнопка:") -- Prone bind key
	bindkey_desc:SizeToContents()
	bindkey_desc:SetPos(10, 110)

	local binder = vgui.Create("DBinder", frame)
	binder:SetSize(150, 50)
	binder:SetPos(25, 130)
	binder:CenterHorizontal()
	binder:SetValue(bindkey_key:GetInt())
	function binder:OnChange(num)
		RunConsoleCommand("prone_bindkey_key", num)
		self:SetText(input.GetKeyName(num))
	end

	local resetbutton = vgui.Create("DButton", frame)
	resetbutton:SetText("Сброс настроек") -- Reset settings
	resetbutton:SetPos(0, 190)
	resetbutton:SetSize(200, 20)
	function resetbutton:DoClick()
		RunConsoleCommand("prone_bindkey_enabled", "1")
		RunConsoleCommand("prone_bindkey_key", tostring(prone.Config.DefaultBindKey))
		RunConsoleCommand("prone_bindkey_doubletap", "1")
		RunConsoleCommand("prone_jumptogetup", "1")
		RunConsoleCommand("prone_jumptogetup_doubletap", "1")
		frame:Remove()
	end
end)