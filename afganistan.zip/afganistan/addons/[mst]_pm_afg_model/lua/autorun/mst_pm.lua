
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_pm_afg_model/lua/autorun/mst_pm.lua ~

]]

player_manager.AddValidModel( "Taliban_rpg", "models/player/afghanistan_rp/taliban_rpg.mdl" );
player_manager.AddValidHands( "Taliban_rpg", "models/player/afghanistan_rp/arms/alqaeda_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "Taliban_rpg", "models/player/afghanistan_rp/taliban_rpg.mdl" );
player_manager.AddValidModel( "alqaeda_commando", "models/player/afghanistan_rp/alqaeda_commando.mdl" );
player_manager.AddValidHands( "alqaeda_commando", "models/player/afghanistan_rp/arms/alqaeda_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "alqaeda_commando", "models/player/afghanistan_rp/alqaeda_commando.mdl" );
player_manager.AddValidModel( "iraqi_insurgent_pm", "models/player/afghanistan_rp/iraqi_insurgent_pm.mdl" );
player_manager.AddValidHands( "iraqi_insurgent_pm", "models/player/afghanistan_rp/arms/alqaeda_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "iraqi_insurgent_pm", "models/player/afghanistan_rp/iraqi_insurgent_pm.mdl" );
player_manager.AddValidModel( "taliban_grunt", "models/player/afghanistan_rp/taliban_grunt.mdl" );
player_manager.AddValidHands( "taliban_grunt", "models/player/afghanistan_rp/arms/alqaeda_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "taliban_grunt", "models/player/afghanistan_rp/taliban_grunt.mdl" );
player_manager.AddValidModel( "taliban_bomber", "models/player/afghanistan_rp/taliban_bomber.mdl" );
player_manager.AddValidHands( "taliban_bomber", "models/player/afghanistan_rp/arms/taliban_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "taliban_bomber", "models/player/afghanistan_rp/taliban_bomber.mdl" );
player_manager.AddValidModel( "pilot", "models/player/afghanistan_rp/pilot.mdl" );
player_manager.AddValidHands( "pilot", "models/player/afghanistan_rp/arms/pilot_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "pilot", "models/player/afghanistan_rp/pilot.mdl" );
player_manager.AddValidModel( "soldier", "models/player/afghanistan_rp/soldier.mdl" );
player_manager.AddValidHands( "soldier", "models/player/afghanistan_rp/arms/soldier_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "soldier", "models/player/afghanistan_rp/soldier.mdl" );
player_manager.AddValidModel( "soldier1", "models/player/afghanistan_rp/soldier1.mdl" );
player_manager.AddValidHands( "soldier1", "models/player/afghanistan_rp/arms/soldier1_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "soldier1", "models/player/afghanistan_rp/soldier1.mdl" );
player_manager.AddValidModel( "soldier2", "models/player/afghanistan_rp/soldier2.mdl" );
player_manager.AddValidHands( "soldier2", "models/player/afghanistan_rp/arms/soldier2_arms.mdl" , 0, "00000000" )
--list.Set( "PlayerOptionsModel", "soldier2", "models/player/afghanistan_rp/soldier2.mdl" );

player_manager.AddValidModel("OsamaEnhanced", "models/v92/kuma/characters/osama/player.mdl" )
player_manager.AddValidHands( "OsamaEnhanced", "models/v92/kuma/characters/osama/arms.mdl", 1, "00000000" )
--list.Set( "PlayerOptionsAnimations", "OsamaEnhanced", { "menu_combine" } )