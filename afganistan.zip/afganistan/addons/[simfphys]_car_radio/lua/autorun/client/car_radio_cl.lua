
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_car_radio/lua/autorun/client/car_radio_cl.lua ~

]]

 print(BRANCH)
CurrentCar = CurrentCar or false

local function CheckCurrentCar()
	local vehicle = LocalPlayer():GetVehicle()
	if vehicle:IsValid() then
		local car = vehicle:GetOwner()
		if car:IsValid() and simfphys.IsCar(car) then
			CurrentCar = car
			return
		end
	end
	CurrentCar = false
end

hook.Add("InitPostEntity", "CarRadioCheckCurrentCar", CheckCurrentCar)
if LocalPlayer():IsValid() then
	CheckCurrentCar()
end

local VolumeConVar = CreateConVar("car_radio_music_volume", 100, FCVAR_ARCHIVE, "Sets the volume of the car radio.", 0, 300)
cvars.AddChangeCallback("car_radio_music_volume",
	function(_, _, volume)
		if CurrentCar and CurrentCar.CarRadioAudioChannel then
			CurrentCar.CarRadioAudioChannel:SetVolume(volume/100)
		end 
	end, "car_radio_change_volume"
)
local FadeConVar = CreateConVar("car_radio_music_fade_time", 0.75, FCVAR_ARCHIVE, "Sets the time at which the car radio music fades in/out.", 0)

local CAR_RADIO_URL_DIRECT = 1
local CAR_RADIO_URL_YOUTUBE = 2

local ebanathistory={}

if file.Exists('car_radio_history.dat','DATA') then
	ebanathistory=util.JSONToTable(file.Read('car_radio_history.dat','DATA'))
else
	file.Write('car_radio_history.dat',util.TableToJSON({}))
end

--[[
local Favorites
local favoritesFileExists = file.Exists("car_radio_favorites.json", "DATA")
if favoritesFileExists then
	Favorites = util.JSONToTable(file.Read("car_radio_favorites.json"))
end
if not (favoritesFileExists and Favorites) then
	file.Write("car_radio_favorites.json", util.TableToJSON({}))
	Favorites = {}
end

local function AddFavorite(name, link)
	Favorites[name] = link
	file.Write("car_radio_favorites.json", util.TableToJSON(Favorites))
end

local function RemoveFavorite(name)
	Favorites[name] = nil
	file.Write("car_radio_favorites.json", util.TableToJSON(Favorites))
end
]]--

local function NotifyAndPrint(text, notifyType)
	notification.AddLegacy(string.sub(text, 1, 128), notifyType, 5)
end

local function FadeAudioVolume(audioChannel, fadeIn)
	local Time = SysTime
	local fadeTime = FadeConVar:GetFloat()
	local volume = VolumeConVar:GetInt()/100
	local fadeStartTime = SysTime()
	local fadeEndTime = fadeStartTime+fadeTime
	hook.Add("Think", "CarRadioFadeMusicVolume",
		function()
			local time = Time()
			local multiplier = fadeIn and (time-fadeStartTime)/fadeTime or (fadeEndTime-time)/fadeTime
			audioChannel:SetVolume(volume*multiplier)
			if fadeIn and multiplier >= 1 or not fadeIn and multiplier <= 0 then
				audioChannel:SetVolume(fadeIn and volume or 0)
				hook.Remove("Think", "CarRadioFadeMusicVolume")
			end
		end
	)
end

local function LoadDirectAudio(url, title, userInitiated, pause, time, niceURL)
	sound.PlayURL(url, pause and "pause mono noblock" or "mono noblock",
		function(audioChannel, errID, errName)
			if errID then
				if userInitiated then
					if errName == "BASS_ERROR_FILEOPEN" and not string.sub(url, -4, #url) == ".mp3" then
 					 	LoadDirectAudio(url..".mp3", title, userInitiated, pause, time, niceURL)
					else
 					 	NotifyAndPrint(string.format("Не могу загрузить музыку, ошибка %s: %s", errID, errName), NOTIFY_ERROR)
					end
				end
				return
			end
			if not pause then
				NotifyAndPrint("Сейчас играет: "..title, NOTIFY_GENERIC)
			end
			--CurrentAudioStream = CurrentAudioStream or false -- !
			if userInitiated then
				net.Start("car_radio_music_loaded")
					net.WriteEntity(CurrentCar)
					net.WriteString(niceURL or url)
					if niceURL then
						net.WriteBit(true)
					else
						net.WriteBit(false)
					end
				net.SendToServer()
			end
			if CurrentCar.CarRadioAudioChannel then
				CurrentCar.CarRadioAudioChannel:Stop()
			end
			CurrentCar.CarRadioAudioChannel = audioChannel
			timer.Simple(1,
				function()
					if time and audioChannel:IsValid() and not audioChannel:IsBlockStreamed() then
						audioChannel:SetTime(time)
					end
					FadeAudioVolume(audioChannel, true)
				end
			)
		end
	)
end

local function LoadYouTubeAudio(url, title, userInitiated, pause, time)
	local isShort = string.find(url, "youtu.be/", 1, true)
	http.Fetch("https://www.320youtube.com/watch?v="..(isShort and string.sub(url, -11, #url) or string.match(url, "v=(...........)")),
		function(pageSource)
			local linkStartPos = string.find(pageSource, "https://s01.ytapivmp3.com", 1, true)
			if linkStartPos then
				LoadDirectAudio(string.sub(pageSource, linkStartPos, string.find(pageSource, "\" ", linkStartPos, true)-1), title, userInitiated, pause, time, url)
			else
				LoadYouTubeAudio(url, title, userInitiated, pause, time)
			end
		end
	)
end

local function LoadMusic(url, urlType, userInitiated, pause, time)
	if CurrentCar:GetDriverSeat():GetDriver() ~= LocalPlayer() and userInitiated then
      NotifyAndPrint(string.format("Только водитель может поменять музыку!", string.sub(url, 1, 128)), NOTIFY_ERROR)
	return end
	NotifyAndPrint(string.format("Загружаю музыку с %s...", string.sub(url, 1, 128)), NOTIFY_GENERIC)
	if urlType == CAR_RADIO_URL_DIRECT then
		local slashPos = string.find(string.reverse(url), "/", 1, true)
		LoadDirectAudio(url, slashPos and string.sub(url, #url-slashPos+2) or url, userInitiated, pause, time)
	else
		http.Fetch("https://noembed.com/embed?url="..url,
			function(jsonMetadata)
				local metadata = util.JSONToTable(jsonMetadata)
				if not metadata or metadata.error then
					if userInitiated then
						NotifyAndPrint(metadata and string.format("Видео не найдено (%s)", metadata.error) or "Неправильный URL", NOTIFY_ERROR)
					end
				else
					LoadYouTubeAudio(url, metadata.title, userInitiated, pause, time)
				end
			end
		)
	end
end

concommand.Add("car_radio_load_music_direct",
	function(_, _, args)
		if CurrentCar and args[1] then
			LoadMusic(args[1], CAR_RADIO_URL_DIRECT, true)
		end
	end, nil, "Loads music for the car radio from direct audio URL."
)

concommand.Add("car_radio_load_music_youtube",
	function(_, _, args)
		if CurrentCar and args[1] then
			LoadMusic(args[1], CAR_RADIO_URL_YOUTUBE, true)
		end
	end, nil, "Loads music for the car radio from YouTube video URL."
)

net.Receive("car_radio_player_changed_vehicle",
	function()
		if net.ReadBit() == 0 then
			if not IsValid(CurrentCar) then return end
			if CurrentCar.CarRadioAudioChannel then
				FadeAudioVolume(CurrentCar.CarRadioAudioChannel)
			end
			CurrentCar = false
		else
			CurrentCar = net.ReadEntity()
			if CurrentCar:IsValid() then
				if CurrentCar.CarRadioAudioChannel then
					FadeAudioVolume(CurrentCar.CarRadioAudioChannel, true)
				else
					net.Start("car_radio_request_music_url")
						net.WriteEntity(CurrentCar)
					net.SendToServer()
				end
			else
				CurrentCar = false
			end
		end
	end
)

net.Receive("car_radio_transmit_music_url",
	function()
		local url = net.ReadString()
		local pause = net.ReadBit() ~= 0
		local isDirectURL = net.ReadBit() ~= 0
		LoadMusic(url, isDirectURL and CAR_RADIO_URL_DIRECT or CAR_RADIO_URL_YOUTUBE, false, pause, net.ReadUInt(32))
	end
)

net.Receive("car_radio_broadcast_play_state",
	function()
		local car = net.ReadEntity()
		 if car:IsValid() and car.CarRadioAudioChannel then
			if net.ReadBit() == 0 then
				car.CarRadioAudioChannel:Pause()
			else
				car.CarRadioAudioChannel:Play()
			end
		end
	end
)

net.Receive("car_radio_request_time",
	function()
		local car = net.ReadEntity()
		if car:IsValid() then
			net.Start("car_radio_transmit_time")
				net.WriteEntity(car)
				net.WriteEntity(net.ReadEntity())
				net.WriteUInt(car.CarRadioAudioChannel:GetTime(), 32)
			net.SendToServer()
		end
	end
)

local function MusicSetPlayState(boolPlay)
	if CurrentCar:GetDriverSeat():GetDriver() ~= LocalPlayer() then return end
	if CurrentCar.CarRadioAudioChannel then
		net.Start("car_radio_set_play_state")
			net.WriteEntity(CurrentCar)
			net.WriteBit(boolPlay)
			if not boolPlay then
				net.WriteUInt(CurrentCar.CarRadioAudioChannel:GetTime(), 32)
			end
		net.SendToServer()
	end
end

concommand.Add("car_radio_music_play",
	function(_, _, args)
		if CurrentCar then
			MusicSetPlayState(args[1] ~= "0")
		end
	end,
	function(_, args)
		if CurrentCar and CurrentCar.CarRadioAudioChannel then
			local state = CurrentCar.CarRadioAudioChannel:GetState()
			state = state == GMOD_CHANNEL_PLAYING and "1" or state == GMOD_CHANNEL_PAUSED and "0"
			if state then
				return {"car_radio_music_play "..state}
			end
		end
	end, "Pauses/resumes playing the car radio."
)

net.Receive("car_radio_stop_music_notify",
	function()
		local car = net.ReadEntity()
		if car:IsValid() and car.CarRadioAudioChannel then
			car.CarRadioAudioChannel:Stop()
			car.CarRadioAudioChannel = nil
		end
	end
)

local bind=KEY_M;

local long_click_time=0.5; -- 0.8

--

local v,dl,f,dr,col,mat,surface,net,CurTime=vgui,TurboDL,nil,draw,Color,Material,surface,net,CurTime
local box,text=dr.RoundedBox,dr.SimpleText
local blur,iskeydown,time,keytime,oldtime,w,h,gray = Material('pp/blurscreen'),input.IsKeyDown,CurTime,0,0,ScrW(),ScrH(),Color(0,0,0,100);

local menu=false;

local function DrawBlur(panel, amount)
	local x, y = panel:LocalToScreen(0, 0)
	surface.SetDrawColor(255, 255, 255)
	surface.SetMaterial(blur)

	for i = 1, 3 do
		blur:SetFloat("$blur", (i / 3) * (amount or 6))
		blur:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(x * -1, y * -1, w, h)
    end
end

local SizeTextB = "(Маленький)"
local SizeTextP = "(Вкл)"
local SizeTextG = "(Вкл)"
local Knopa = true
--local S = h/5 
local function car_radio_menu()
	local tw,th=w,h
	local pnl=vgui.Create('DFrame')
	pnl:SetSize(w/3,h/3) -- (w/3,h/3)
	pnl:SetPos(20,h/4)
	pnl:SetTitle''
	pnl.Paint=function(s,w,h)
		DrawBlur(s,3)
		draw.RoundedBox(0,0,0,w,h,gray)

		surface.SetDrawColor(Color(255,255,255,125))
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	pnl.btnClose.DoClick=function() menu:Hide() end
	pnl:MakePopup()
	pnl:Hide()
	tw,th=pnl:GetWide(),pnl:GetTall()

	local main_menu_panel=vgui.Create("DPanel",pnl)
	main_menu_panel:SetSize(tw,th-50)
	main_menu_panel:SetPos(0,50)
	main_menu_panel.Paint=function(s,w,h)
		draw.RoundedBox(0,0,0,w,h,gray)
	end

	-- do main menu stuff here 
    	local TextEntry = vgui.Create( "DTextEntry", main_menu_panel ) -- create the form as a child of frame
		TextEntry:SetPos( 5, 15 ) -- 30
		TextEntry:SetSize( tw*0.75, 25 )
		TextEntry:SetText( "Введите URL или ссылку на YouTube видео" )
		TextEntry.OnEnter = function( self )
		  chat.AddText( self:GetValue() ) 
		end

		local Button_progress = vgui.Create( "DButton", main_menu_panel ) 
		Button_progress:SetText( "" ) 
		Button_progress:SetPos( 5, 42  ) -- 30
		Button_progress:SetSize( tw*0.75, 5 ) -- 25
		Button_progress.Paint = function( self, w, h )    
			--DrawBlur(self, 4)
			draw.RoundedBox(0, 0, 0, w, h, Color(125,125,125,155))
			local stream = CurrentCar and CurrentCar.CarRadioAudioChannel
			--local stream = CurrentAudioStream
   		    draw.RoundedBox(0, 0, 0, (not stream or stream:GetTime() <= 0) and w or w*stream:GetTime()/stream:GetLength(), h, Color(255,0,0,155)) -- 150
   		end

	    
		local Button_on = vgui.Create( "DButton", main_menu_panel ) 
		Button_on:SetText( "" ) 
		Button_on:SetPos( tw*0.78, 10 ) -- 30
		Button_on:SetSize( tw*0.22, 45 ) -- 25
		Button_on.Paint = function( self, w, h )    
   		 self.lerp = Lerp(FrameTime()*3, self.lerp or 0, self.Hovered and 1 or 0.5) -- 0	
   		    if self.Depressed then
				Pcolor = Color(255, 255, 255, 255*self.lerp)	
			elseif self.Hovered then
				Pcolor = Color(255, 255, 255, 255*self.lerp)	
			else
				Pcolor = Color(255, 255, 255, 255*self.lerp)	
			end
	
				--DrawBlur(self, 4)
				--draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125)) -- 150

				--surface.SetDrawColor(Pcolor)
				--surface.DrawOutlinedRect(0, 0, w, h)
				--draw.SimpleText('Включить','TargetID',w*0.5,h*0.45,color_white,1,1)
			   if Knopa == false then
				mat = Material("materials/icons/hud/start.png")
			   else
			   	mat = Material("materials/icons/hud/stop.png")	
			   end
				surface.SetDrawColor(Pcolor)
				surface.SetMaterial( mat  )
				surface.DrawTexturedRect( 5, 0, 40, 40 )
		end
		Button_on.DoClick = function()
			surface.PlaySound("server/ui/click2.wav")
		  if Knopa == true then
			MusicSetPlayState(false)
			Knopa = false
 		  else 
			MusicSetPlayState(true)
			Knopa = true
		  end	

		end

		local Button_pv = vgui.Create( "DButton", main_menu_panel ) 
		Button_pv:SetText( "" ) 
		Button_pv:SetPos( tw*0.88, 10 ) -- 30
		Button_pv:SetSize( tw*0.22, 45 ) -- 25
		Button_pv.Paint = function( self, w, h )    
   		    self.lerp = Lerp(FrameTime()*3, self.lerp or 0, self.Hovered and 1 or 0.5) -- 0	
   		    if self.Depressed then
				Pcolor = Color(255, 255, 255, 255*self.lerp)	
			elseif self.Hovered then
				Pcolor = Color(255, 255, 255, 255*self.lerp)	
			else
				Pcolor = Color(255, 255, 255, 255*self.lerp)	
			end
	
	
				--DrawBlur(self, 4)
				--draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125)) -- 150

				--surface.SetDrawColor(Pcolor)
				--surface.DrawOutlinedRect(0, 0, w, h)

				--local color_red = Color(255,25,0)
				--draw.SimpleText('Остановить','TargetID',w*0.5,h*0.45,color_white,1,1) -- Сброс
				--mat = Material("materials/icons/hud/sbros.png")
				mat = Material("materials/icons/hud/repit.png")
				surface.SetDrawColor(Pcolor)
				surface.SetMaterial( mat  )
				surface.DrawTexturedRect( 5, 0, 40, 40 )

			end
		Button_pv.DoClick = function()
			surface.PlaySound("server/ui/click2.wav")
			MusicSetPlayState(false)
		end

		local Button_sb = vgui.Create( "DButton", main_menu_panel ) 
		Button_sb:SetText( "" ) 
		Button_sb:SetPos( tw*0.77, 65 )
		Button_sb:SetSize( tw*0.22, 50 )
		local testh=h 
		Button_sb.Paint = function( self, w, h )    
   		   self.lerp = Lerp(FrameTime()*3, self.lerp or 0, self.Hovered and 1 or 0.5) -- 0	
   		    if self.Depressed then
				Pcolor = Color(200*self.lerp, 200*self.lerp, 200*self.lerp, 255*self.lerp)	
			elseif self.Hovered then
				Pcolor = Color(200*self.lerp, 200*self.lerp, 200*self.lerp, 255*self.lerp)	
			else
				Pcolor = Color(200*self.lerp, 200*self.lerp, 200*self.lerp, 255*self.lerp)	
			end
	
	
				--DrawBlur(self, 4)
				--draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125)) -- 150

				--surface.SetDrawColor(Pcolor)
				--surface.DrawOutlinedRect(0, 0, w, h)
				--draw.SimpleText('П.Трек','TargetID',w*0.5,h*0.45,color_white,1,1)
				mat = Material("materials/icons/hud/razv.png")
				surface.SetDrawColor(Pcolor)
				surface.SetMaterial( mat  )

			if pnl:GetTall() == (testh/5) then
				surface.DrawTexturedRect( 10, 0, 100, 50 )	
			else
			 	surface.DrawTexturedRectRotated( 60, 23, 100, 50, 180 )	
			end	
				 
		end
		Button_sb.DoClick = function()
			surface.PlaySound("server/ui/click2.wav")
			if CurrentCar:GetDriverSeat():GetDriver() ~= LocalPlayer() then return end
			--net.Start("car_radio_stop_music")
			--	net.WriteEntity(CurrentCar)
			--net.SendToServer() --pnl:SetSize(w/3,h/5) -- (w/3,h/3)
			if pnl:GetTall() == (h/5) then
				pnl:SetSize(w/3,h/3)
			else
				pnl:SetSize(w/3,h/5)
			end

		end

		local Button_youtube = vgui.Create( "DButton", main_menu_panel )
		Button_youtube:SetText( '' ) 
		Button_youtube:SetPos( 5,60 )
		Button_youtube:SetSize( tw*0.37, 55 )
		Button_youtube.Paint = function( self, w, h )    
   		self.lerp2 = Lerp(FrameTime()*3, self.lerp2 or 0, self.Hovered and 1 or 0.5) -- 0
   		local Pcolor
			if self.Depressed then
				--surface.SetDrawColor(Color(100+255*self.lerp2, 25, 25, 255*self.lerp2))
				Pcolor = Color(100+255*self.lerp2, 25, 25, 255*self.lerp2)	
			elseif self.Hovered then
				--surface.SetDrawColor(Color(100+255*self.lerp2, 25, 25, 255*self.lerp2))
				Pcolor = Color(100+255*self.lerp2, 25, 25, 255*self.lerp2)	
			else
				--surface.SetDrawColor(Color(100+255*self.lerp2, 25, 25, 255*self.lerp2))
				Pcolor = Color(100+255*self.lerp2, 25, 25, 255*self.lerp2)	
			end
	
				DrawBlur(self, 4)
				draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125)) -- 150

				surface.SetDrawColor(Pcolor)
				surface.DrawOutlinedRect(0, 0, w, h)

				--draw.SimpleText('YouTube','TargetID',w*0.5,h*0.5,color_white,1,1)
				local color_red = Color(255,25,0)
				draw.SimpleText('You','abs_hud',75,h*0.5,color_white,1,1)
				draw.SimpleText('Tube','abs_hud',115,h*0.5,color_red,1,1)
		end
		Button_youtube.DoClick = function()
			surface.PlaySound("server/ui/click2.wav")
			LoadMusic(TextEntry:GetValue(), CAR_RADIO_URL_YOUTUBE, true)
			Knopa = true
		end

		local Button_radio = vgui.Create( "DButton", main_menu_panel ) 
		Button_radio:SetText( "" ) 
		Button_radio:SetPos( tw*0.390,60 )
		Button_radio:SetSize( tw*0.37, 55 )
		Button_radio.Paint = function( self, w, h )    
		self.lerp = Lerp(FrameTime()*3, self.lerp or 0, self.Hovered and 1 or 0.5) -- 0	
   		 if self.Depressed then
				Pcolor = Color(200, 200, 200, 255*self.lerp)	
			elseif self.Hovered then
				Pcolor = Color(200, 200, 200, 255*self.lerp)	
			else
				Pcolor = Color(200, 200, 200, 255*self.lerp)		
			end
	
				DrawBlur(self, 4)
				draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125)) -- 150

				surface.SetDrawColor(Pcolor)
				surface.DrawOutlinedRect(0, 0, w, h)

				--draw.SimpleText('YouTube','TargetID',w*0.5,h*0.5,color_white,1,1)
				local color_red = Color(255,25,0)
				draw.SimpleText('Прямая URL','abs_hud',w*0.5,h*0.5,color_white,1,1)
		end
		Button_radio.DoClick = function()
			surface.PlaySound("server/ui/click2.wav")
			LoadMusic(TextEntry:GetValue(), CAR_RADIO_URL_DIRECT, true)
		end


		for i=0,3 do
		 	local Button_radio = vgui.Create( "DButton", main_menu_panel )  
		 	Button_radio:SetText( "" ) 
		 	Button_radio:SetPos( 5+132*i,130 )
		 	Button_radio:SetSize( 127, 45 )
		 	Button_radio.Paint = function( self, w, h )    
   		 	 self.lerp = Lerp(FrameTime()*3, self.lerp or 0, self.Hovered and 1 or 0.5) -- 0	
   				if self.Depressed then
					Pcolor = Color(200, 200, 200, 255*self.lerp)	
				elseif self.Hovered then
					Pcolor = Color(200, 200, 200, 255*self.lerp)	
				else
					Pcolor = Color(200, 200, 200, 255*self.lerp)		
				end
	
				DrawBlur(self, 4)
				draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125)) -- 150

				surface.SetDrawColor(Pcolor)
				surface.DrawOutlinedRect(0, 0, w, h)

				if i == 0 then 
				  	draw.SimpleText('Пришел приказ','TargetID',w*0.5,h*0.5,color_white,1,1)		
				elseif i == 1 then  	
				  	draw.SimpleText('Здравствуй, Мама...','TargetID',w*0.5,h*0.5,color_white,1,1)	  
				elseif i == 2 then  	
				  	draw.SimpleText('Цой "Группа крови"','TargetID',w*0.5,h*0.5,color_white,1,1)				
				elseif i == 3 then  	  		
					draw.SimpleText('Цой "Кукушка"','TargetID',w*0.5,h*0.5,color_white,1,1)	  					
				end 
				--draw.SimpleText('Наше радио','abs_hud',w*0.5,h*0.5,color_white,1,1)
		 	end	
		 	-----
		 	Button_radio.DoClick = function()
					surface.PlaySound("server/ui/click2.wav")
					if i == 0 then
						LoadMusic("https://www.youtube.com/watch?v=A-FuwnPRalI", CAR_RADIO_URL_YOUTUBE, true)
					elseif i == 1 then  	
				   		LoadMusic("https://www.youtube.com/watch?v=SJGUA18sz3M", CAR_RADIO_URL_YOUTUBE, true)
				   	elseif i == 2 then  	
			 		    LoadMusic("https://www.youtube.com/watch?v=6C2ti3x9OAA", CAR_RADIO_URL_YOUTUBE, true)
					elseif i == 3 then  	  		
					 	LoadMusic("https://www.youtube.com/watch?v=Ra0ozaE-oy0", CAR_RADIO_URL_YOUTUBE, true)	
				end 
					 
			end	

		 	----

		end

		for i=0,3 do

		 	local Button_istor = vgui.Create( "DButton", main_menu_panel )  
		 	Button_istor:SetText( "" ) 
		 	Button_istor:SetPos( 5+132*i,180 )
		 	Button_istor:SetSize( 127, 45 )
		 	Button_istor.Paint = function( self, w, h )    
   		 		self.lerp = Lerp(FrameTime()*3, self.lerp or 0, self.Hovered and 1 or 0.5) -- 0	
   				if self.Depressed then
					Pcolor = Color(200, 200, 200, 255*self.lerp)	
				elseif self.Hovered then
					Pcolor = Color(200, 200, 200, 255*self.lerp)	
				else
					Pcolor = Color(200, 200, 200, 255*self.lerp)		
				end
	
				DrawBlur(self, 4)
				draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125)) -- 150

				surface.SetDrawColor(Pcolor)
				surface.DrawOutlinedRect(0, 0, w, h)

				--draw.SimpleText('YouTube','TargetID',w*0.5,h*0.5,color_white,1,1)
				local color_red = Color(255,25,0)
				draw.SimpleText(istable(ebanathistory[i]) and ebanathistory[i].name or 'Избранное','TargetID',w*0.5,h*0.5,color_white,1,1)
			end	
			Button_istor.num=i
			Button_istor.DoClick=function()
				ui.StringRequest('Избранное', 'Введите URL', '', function(url)
			        ui.StringRequest('Избранное', 'Введите название', '', function(name)
				       	Button_istor:SetText( name ) 
				       	Button_istor.DoClick=function()
				       		surface.PlaySound("server/ui/click2.wav")
				       		LoadMusic(url, (string.find(url, "youtube", 1, true) or string.find(url, "youtu.be", 1, true)) and CAR_RADIO_URL_YOUTUBE or CAR_RADIO_URL_DIRECT, true)
				       		ebanathistory[Button_istor.num]={url=url,name=name}
				       		file.Write('car_radio_history.dat',util.TableToJSON(ebanathistory))
				       end
				    end)
			    end)
			end
			Button_istor.DoRightClick=function()
				surface.PlaySound("server/ui/click2.wav")
				--Button_istor:SetText('Избранное')
				ebanathistory[Button_istor.num]=nil
				file.Write('car_radio_history.dat',util.TableToJSON(ebanathistory))
			end
		end
		

	-- btnN=vgui.Create("DButton",main_menu_panel)

	local settings_panel=vgui.Create("DPanel",pnl)
	settings_panel:SetSize(tw,th-50)
	settings_panel:SetPos(0,50)
	settings_panel.Paint=function(s,w,h)
		draw.RoundedBox(0,0,0,w,h,gray)
	end
	local slider = vgui.Create("DNumSlider",settings_panel)
	slider:SetPos(5, 30)
	slider:SetSize(tw-10, 30)
	slider:SetText("")
	slider:SetMin(0)
	slider:SetMax(300)
	slider:SetDecimals(0)
	slider:SetConVar("car_radio_music_volume")
	slider.TextArea:SetTextColor(Color(255, 255, 255))
	slider.Paint=function(s,w,h)
		--DrawBlur(self, 4)
		draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,125))
		draw.RoundedBox(0, 2, 2,w-4,h-4,Color(0,0,0,120)) -- (0,0,0,120))
		draw.SimpleText('       Громкость радио:','abs_hud',w*0.15,h*0.5,color_white,1,1)
	end
	slider.Slider.Paint=function(s,w,h)
		surface.SetDrawColor( Color(0,0,0,66) ) -- 66
		surface.DrawOutlinedRect( 0, 0, w, h )
		surface.DrawLine(5,h*0.5,w-10,h*0.5)
		surface.SetDrawColor( Color(0,0,188,66)  )
		--surface.DrawLine(5,h*0.5,dnumslider:GetValue()*4,h*0.5)
		box(0,5,h*0.5-2,slider:GetValue()*0.82,4,Color(255,0,0,222)) -- (0,0,188,66))

	end
	slider.Slider.Knob.Paint=function(s,w,h)
		w=w-4
		box(0,0,0,w,h,Color(255,0,0,222)) -- (0,0,188,66))
		box(0,0,h-2,w-2,2,col(0,0,0,35)) -- col(0,0,0,35))
		box(0,w-2,0,2,h,col(0,0,0,35))   -- col(0,0,0,35))
	end
 
	 

	settings_panel:Hide()

	-- do settings stuff here 

	-- btnN=vgui.Create("DButton",settings_panel)

	local btn1=vgui.Create('DButton',pnl)
	local btn2=vgui.Create('DButton',pnl)

	btn1:SetSize(tw/2,40)
	btn1:SetPos(0,20)
	btn1:SetText''
	btn1.Paint=function(s,w,h)
		if s:IsHovered() then
			--draw.RoundedBox(0,0,h-5,w,5,Color(33,33,33,250))
			draw.RoundedBox(0,5,h-20,w-10,5,Color(255,255,255,155))
		end

		if s.active then
			draw.RoundedBox(0,5,h-20,w-10,5,Color(255,255,255,255))
		end
		draw.SimpleText('Меню','abs_hud',w*0.45,7,color_white,1,1)
		draw.RoundedBox(0,w-3,55,3,h*0.4,Color(77,77,77,155))
	end
	btn1.active=true
	btn1.DoClick=function()
		surface.PlaySound("server/ui/click2.wav")
		main_menu_panel:Show()
		settings_panel:Hide()
		btn2.active=false
		btn1.active=true
	end	

	
	btn2:SetSize(tw/2,40)
	btn2:SetPos(tw/2,20)
	btn2:SetText''
	btn2.active=false
	btn2.Paint=function(s,w,h)
		if s:IsHovered() then
			--draw.RoundedBox(0,0,h-5,w,5,Color(33,33,33,250))
			draw.RoundedBox(0,5,h-20,w-10,5,Color(255,255,255,155))
		end

		if s.active then
			draw.RoundedBox(0,5,h-20,w-10,5,Color(255,255,255,255))
		end

		draw.RoundedBox(0,w-3,55,3,h*0.4,Color(77,77,77,155))
		draw.SimpleText('Настройки','abs_hud',w*0.45,7,color_white,1,1)
	end
	btn2.DoClick=function()
		surface.PlaySound("server/ui/click2.wav")
		main_menu_panel:Hide()
		settings_panel:Show()
		btn2.active=true
		btn1.active=false
	end	

	return pnl
end

hook.Add('InitPostEntity','car_radio_spawn_menu',function()
	menu=car_radio_menu()
	hook.Remove('InitPostEntity','car_radio_spawn_menu')
end)

hook.Add('Think','car_radio_key_hook',function()
	if not CurrentCar then return end
	if iskeydown(bind) then
		keytime=time()-oldtime;
		if keytime > long_click_time then
			if not IsValid(menu) then
				menu=car_radio_menu()
			end
			menu:Show()
		end
	else
		oldtime=time();
		if not (keytime == 0) then
			if keytime > long_click_time then
				-- open menu
				if not IsValid(menu) then
					menu=car_radio_menu()
				end
				menu:Show()

			else

				-- change track if in vehicle & menu opened
				--print('track changed')

			end
			keytime=0
		end
	end
end);