
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_donate_system/lua/autorun/l_ingameshopmod.lua ~

]]

if CLIENT or file.Exists("igs/launcher.lua","LUA") then return end

local function notif(pl,text)
	if IsValid(pl) then
		pl:ChatPrint(text)
	end
end

local function openURL(pl,url)
	if IsValid(pl) then
		pl:SendLua([[gui.OpenURL("]] .. url .. [[")]])
	end
end

hook.Add("PlayerInitialSpawn","IGSFail",function(pl)
	timer.Simple(10,function()
		timer.Create("IGSFail",1,60,function()
			notif(pl,"[IGS] Для работы автодоната нужно установить сам АВТОДОНАТ (gm-donate.ru/instructions)")
		end)

		timer.Simple(5,function()
			openURL(pl,"https://gm-donate.ru/instructions")
		end)
	end)
end)
