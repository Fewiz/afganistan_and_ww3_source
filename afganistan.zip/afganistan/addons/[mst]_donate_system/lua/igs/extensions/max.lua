
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_donate_system/lua/igs/extensions/max.lua ~

]]

 local STORE_ITEM = FindMetaTable("IGSItem")

-- Возволяет настроить максимальное количество ПОКУПОК одного предмета
-- Работает только для одного сервера, независимо от того, указан ли bGlobal
function STORE_ITEM:SetMaxPurchases(iLimit)
	return self:SetMeta("purchasesLimit", iLimit)
end

if CLIENT then return end

local function bibKey(pl,ITEM)
	return "igs:purchases:" .. pl:UniqueID() .. ":" .. ITEM:UID()
end

hook.Add("IGS.CanPlayerBuyItem", "purchasesLimit", function(pl, ITEM) -- bGlobal
	local limit = ITEM:GetMeta("purchasesLimit")
	if limit and bib.getNum(bibKey(pl, ITEM),0) >= limit then
		return false, "Этот предмет можно купить только " .. limit .. " раз(а)"
	end
end)

hook.Add("IGS.PlayerPurchasedItem", "purchasesLimit", function(pl, ITEM) -- bGlobal, iID
	local limit = ITEM:GetMeta("purchasesLimit")
	if limit then
		local key = bibKey(pl, ITEM)
		bib.setNum(key, bib.getNum(key,0) + 1)
		IGS.Notify(pl, "Вы купили " .. ITEM:Name() .. " " .. bib.getNum(key,0) .. " раз из " .. limit)
	end
end)