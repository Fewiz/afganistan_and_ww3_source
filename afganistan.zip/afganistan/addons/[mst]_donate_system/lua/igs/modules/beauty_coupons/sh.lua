
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_donate_system/lua/igs/modules/beauty_coupons/sh.lua ~

]]

function IGS.COUP.WriteAlias(a)
	net.WriteUInt(a.id,16)
	net.WriteString(a.alias)
	net.WriteString(a.code)
	net.WriteBool(a.activator)
	if a.activator then
		net.WriteString(util.SteamIDFrom64(a.activator))
	end
	net.WriteInt(a.date, 32)
end

function IGS.COUP.ReadAlias()
	return {
		id        = net.ReadUInt(16),
		alias     = net.ReadString(),
		code      = net.ReadString(),
		activator = net.ReadBool() and net.ReadString(),
		date      = net.ReadUInt(32),
	}
end
