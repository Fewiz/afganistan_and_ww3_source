
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_donate_system/lua/igs/modules/beauty_coupons/cl.lua ~

]]

function IGS.COUP.Request(cb)
	net.Ping("IGS.GetCouponsAliases")

	net.Receive("IGS.GetCouponsAliases",function()
		local d = {}
		for i = 1,net.ReadUInt(8) do
			d[i] = IGS.COUP.ReadAlias()
		end
		cb(d)
	end)
end

function IGS.COUP.Create(cb, alias, igs)
	net.Start("IGS.CreateCouponAlias")
		net.WriteString(alias)
		net.WriteDouble(igs)
	net.SendToServer()

	net.Receive("IGS.CreateCouponAlias",function()
		local ok = net.ReadBool()
		cb(ok,ok and IGS.COUP.ReadAlias())
	end)
end

function IGS.COUP.Delete(cb, id)
	net.Start("IGS.DelCouponAlias")
		net.WriteUInt(id,16)
	net.SendToServer()

	net.Receive("IGS.DelCouponAlias",function()
		local ok = net.ReadBool()
		cb(ok,ok and IGS.COUP.ReadAlias())
	end)
end
