
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_donate_system/lua/igs/modules/beauty_coupons/activity_cl.lua ~

]]

--[[-------------------------------------------------------------------------
	Набросок фрейма: https://img.qweqwe.ovh/1534882156505.png
---------------------------------------------------------------------------]]

local function addTab(activity,sidebar)
	local bg = sidebar:AddPage("Последние активации")

	function bg:InsertCoupon(c)
		c.datestr = IGS.TimestampToDate(c.date)
		c.shortcode = c.code:sub(1,10) .. "..." .. c.code:sub(-10)

		if c.activator then
			local pl = player.GetBySteamID(c.activator)
			local nick_or_sid = pl and pl:Name() or c.activator

			IGS.AddTextBlock(bg.side, nick_or_sid, c.alias .. "\n" .. c.datestr)
			return
		end

		local line = bg.table:AddLine(c.id, c.alias, c.shortcode, c.datestr)
		line:SetTooltip("Кликните для доп. действий")
		for _,v in ipairs(line.columns) do
			v:SetCursor("hand")
		end

		line.DoClick = function(s)
			local m = DermaMenu(line)
			m:AddOption("Скопировать",function() SetClipboardText(c.code) end)
			m:AddOption("Удалить",function() IGS.COUP.Delete(function(ok)
				if ok then
					line:Remove()
					-- bg.table:PerformLayout()
				else
					IGS.ShowNotify("Купон не удален. Переоткройте меню и попробуйте снова", "Ошибка")
				end
			end, c.id) end)
			m:Open()
		end

		bg.table:PerformLayout()
	end

	function bg:LoadData()
		IGS.COUP.Request(function(rows)
			if !IsValid(bg) then return end

			for _,row in ipairs(rows) do
				bg:InsertCoupon(row)
			end
		end)
	end

	-- control panel
	bg.cp = uigs.Create("Panel", function(pnl)
		pnl:Dock(BOTTOM)
		pnl:DockMargin(20,0,20,5)
		pnl:SetTall(60)

		pnl.top = uigs.Create("Panel", function(self)
			self:Dock(TOP)
			self:DockMargin(50,0,50,0)
			self:DockPadding(0,2,0,2)
			self:SetTall(30)
		end, pnl)

		pnl.bottom = uigs.Create("Panel", function(self)
			self:Dock(BOTTOM)
			self:DockMargin(50,0,50,0)
			self:SetTall(30)
		end, pnl)

		------------------------------------------------

		-- алиас
		pnl.alias = uigs.Create("DTextEntry", function(self)
			self:Dock(FILL)
			self:SetValue("beauty_coupon_code")
		end, pnl.top)

		-- сумма
		pnl.sum = uigs.Create("DTextEntry", function(self)
			self:Dock(RIGHT)
			self:DockMargin(5,0,0,0)
			self:SetWide(100)
			self:SetNumeric(true)
			self:SetValue(50)
		end, pnl.top)

		------------------------------------------------

		-- количество
		pnl.amount = uigs.Create("DNumSlider", function(self)
			self:Dock(FILL)
			self:SetText("Количество купонов:")
			self:DockMargin(5,5,5,5)
			self:SetDecimals(0)
			self:SetMinMax(1, 30)
			self:SetValue(10)

			self.Label:SetTextColor(IGS.col.TEXT_HARD)
		end, pnl.bottom)

		-- кнопка
		pnl.submit = uigs.Create("igs_button", function(self)
			self:Dock(RIGHT)
			self:SetWide(100)
			self:SetText("Создать")
			self.DoClick = function()
				local alias,sum = pnl.alias:GetValue(), pnl.sum:GetValue()
				if alias:Trim() == "" or !tonumber(sum) then
					return
				end

				for _ = 1,pnl.amount:GetValue() do
					IGS.COUP.Create(function(ok, c)
						if ok then
							bg:InsertCoupon(c) -- вставит в конец, а не в начало, но лень ебаться
						else
							IGS.ShowNotify("Купон не создан или создан с ошибкой. Перезагрузите меню и попробуйте снова", "Ошибка")
						end
					end, alias, sum)
				end
			end
			self:SetActive(true)
		end, pnl.bottom)
	end, bg)

	bg.table = uigs.Create("igs_table", function(tbl)
		tbl:Dock(FILL)
		tbl:DockMargin(5,5,5,5)
		-- tbl:SetSize(790, 565)

		tbl:SetTitle("Активные купоны")

		tbl:AddColumn("ID",50)
		tbl:AddColumn("Алиас")
		tbl:AddColumn("Купон", 200)
		tbl:AddColumn("Создание", 130)
	end, bg)

	bg:LoadData()
	activity:AddTab("Купоны",bg,"materials/icons/fa32/ticket.png") -- rub, tag, ticket
end

hook.Add("IGS.CatchActivities","beauty_coupons",function(activity,sbar)
	if LocalPlayer():IsSuperAdmin() then
		addTab(activity,sbar)
	end
end)
