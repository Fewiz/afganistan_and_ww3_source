
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_donate_system/lua/igs/settings/sh_additems.lua ~

]]

IGS.ITEMS.mst_BIG_ICONS={
    ["veh_jeep"]=		"https://i.imgur.com/Oqi6ztW.jpg",
    ["profa_1"]=		"https://cdn.discordapp.com/attachments/673101426272239629/856817629900570624/profa_1.jpg",
    ["profa_2"]=		"https://cdn.discordapp.com/attachments/673101426272239629/856817631548669982/profa_2.jpg",
    ["profa_3"]=		"https://cdn.discordapp.com/attachments/673101426272239629/856929472644775946/unknown.png",--"https://cdn.discordapp.com/attachments/673101426272239629/856817629213491200/profa_3.png",

    ["money_1000"]=		"https://mst-gmod.ru/img/money.png",    

    ["vip_probny"]=   	 "https://mst-gmod.ru/img/vip1b.png",
    ["vip_na_mesyac"]=	 "https://mst-gmod.ru/img/vip2b.png",
    ["vip_na_vsegda"]=	 "https://mst-gmod.ru/img/vip3b.png",

    ["vip_plus_na_mesyac"]=   "https://mst-gmod.ru/img/vip2b.png",
     

    ["tfa_ins2_ppsh"]=   "https://mst-gmod.ru/img/OR1S.png",
    ["tfa_ins2_mosin"]=  "https://mst-gmod.ru/img/OR2S.png",
    ["cwc_thompson"]=	   "https://mst-gmod.ru/img/OR3S.png",

    ["cw_mr96"]=  		   "https://mst-gmod.ru/img/OR4S.png",
    ["cw_deagle"]= 		   "https://mst-gmod.ru/img/OR5S.png",
    ["cw_stg44"]=		     "https://mst-gmod.ru/img/OR6S.png",
    ["cw_m620"]=         "https://mst-gmod.ru/img/OR7B2.png",
          

    ["or1_prob"]=  		   "https://mst-gmod.ru/img/OR1S.png",
    ["or2_prob"]= 		   "https://mst-gmod.ru/img/OR2S.png",
    ["or3_prob"]=		     "https://mst-gmod.ru/img/OR3S.png",

    ["or4_prob"]=  		   "https://mst-gmod.ru/img/OR4S.png",
    ["or5_prob"]= 		   "https://mst-gmod.ru/img/OR5S.png",
    ["or6_prob"]=		     "https://mst-gmod.ru/img/OR6S.png",

    ["perk_1"]= 	      "https://cdn.discordapp.com/attachments/673101426272239629/856179487871336458/unknown.png",
    ["perk_2"]= 		    "https://cdn.discordapp.com/attachments/575722389778858004/852096269832028160/SPOILER_unknown.png",
    ["perk_3"]= 	     	"https://cdn.discordapp.com/attachments/673101426272239629/856863273688104960/unknown.png",
    

     --Dukes MrsdsW123 avx_mercedes2 MrsdsW123BE MrsdsW124BE avx_technical_unarmed_BE
    ["dukes"]=						           "https://mst-gmod.ru/img/car_6.png",
    ["mrsdsw123"]=					         "https://mst-gmod.ru/img/car_1.png",
    ["avx_mercedes2"]=				       "https://mst-gmod.ru/img/car_2.png",
    ["mrsdsw123be"]=				         "https://mst-gmod.ru/img/car_3.png",
    ["mrsdsw124be"]=				         "https://mst-gmod.ru/img/car_4.png",
    ["avx_technical_unarmed_be"]=	   "https://mst-gmod.ru/img/car_5.png",
        
    ["lockpick"]= 					         "https://mst-gmod.ru/img/krow2.png",  
    ["weapon_medkit2"]= 			       "https://cdn.discordapp.com/attachments/719140874235412521/860843881947856926/unknown.png",  
    ["weapon_simrepair2"]= 			     "https://cdn.discordapp.com/attachments/719140874235412521/860844789066629130/unknown.png",  
 
    ["guitar"]=  					           "https://cdn.discordapp.com/attachments/719140874235412521/860841782748381194/unknown.png",
    ["guitar2"]= 					           "https://cdn.discordapp.com/attachments/719140874235412521/860841782748381194/unknown.png",
    ["ciga"]=						             "https://cdn.discordapp.com/attachments/719140874235412521/860842287391309824/unknown.png",


     
    ["weapon_vj_flaregun_r"]=        "https://cdn.discordapp.com/attachments/739577533707845773/925433831476068372/unknown.png",
    ["weapon_cuff_rope"]=            "https://media.discordapp.net/attachments/739577533707845773/944596828635140227/narb.png",
    ["money"]=                       "https://media.discordapp.net/attachments/739577533707845773/944661744142405702/unknown.png",
          
}
 


IGS.ITEMS.mst_INFOS={

["tfa_ins2_ppsh"]=[=[
• Урон: 26
• Урон с Magnum: 31
• Скорострельность: 1250
• Сток.Магазин: 71+1]=],

["or1_prob"]=[=[
Специально для активных игроков бесплатный приз в виде оружия на 3 дня! 
Нужно наиграть 12ч, чтобы получить данную награду.

• Урон: 26
• Урон с Magnum: 31
• Скорострельность: 1250
• Сток.Магазин: 71+1]=],
 

-- 100
["tfa_ins2_mosin"]=[=[
• Урон: 72
• Урон с Magnum: 86
• Скорострельность: 41
• Магазин: 5]=],

["or2_prob"]=[=[
Специально для активных игроков бесплатный приз в виде оружия на 3 дня! 
Нужно наиграть 12ч, чтобы получить данную награду.

• Урон: 72
• Урон с Magnum: 86
• Скорострельность: 41
• Магазин: 5]=],

["cwc_thompson"]=[=[
• Урон: 24
• Урон с Magnum: 29
• Скорострельность: 1500
• Сток.Магазин: 25]=],

["or3_prob"]=[=[
Специально для активных игроков бесплатный приз в виде оружия на 3 дня! 
Нужно наиграть 12ч, чтобы получить данную награду.

• Урон: 28
• Урон с Magnum: 34
• Скорострельность: 700
• Сток.Магазин: 25]=],


["cw_mr96"]=[=[
• Урон: 64
• Урон с Magnum: 77
• Скорострельность: 300
• Барабан: 6]=],

["or4_prob"]=[=[
Специально для активных игроков бесплатный приз в виде оружия на 3 дня! 
Нужно наиграть 12ч, чтобы получить данную награду.

• Урон: 64
• Урон с Magnum: 77
• Скорострельность: 300
• Барабан: 6]=],


["cw_deagle"]=[=[
• Урон: 70
• Урон с Magnum: 84
• Скорострельность: 240
• Магазин: 7+1]=],

["or5_prob"]=[=[
Специально для активных игроков бесплатный приз в виде оружия на 3 дня! 
Нужно наиграть 12ч, чтобы получить данную награду.

• Урон: 70
• Урон с Magnum: 84
• Скорострельность: 240
• Магазин: 7+1]=],

["cw_m620"]=[=[
• Урон: 15х9
• Урон с Пулевым: 75
• Скорострельность: 74
• Магазин: 5+1]=],

["cw_stg44"]=[=[
• Урон: 28
• Урон с Magnum: 34
• Скорострельность: 800
• Магазин: 30+1]=],

["or6_prob"]=[=[
Специально для активных игроков бесплатный приз в виде оружия на 3 дня! 
Нужно наиграть 12ч, чтобы получить данную награду.

• Урон: 28
• Урон с Magnum: 34
• Скорострельность: 800
• Магазин: 30+1]=],


["spravka"]=[=[
В продаже есть:
• Разбан Discord: 80р (в случае повтора - больше)
• Личное оружие, которое ЕСТЬ на сервере.
• Покупка доната Навсегда:
-Для транспорта: Цена на месяц x3.
-Для оружия: Цена на месяц х4.

P.S - В случае, если берете оптом (больше 800р), то множитель может быть снижен. 
ПОКУПКИ ЗВАНИЙ (Не от профы) - ЗАПРЕЩЕНА!]=],

["dukes"]=[=[
• Максималка: 203 км/ч
• Прочность: 1425
• Вместительность: 4

Для данной тачки доступно много визуального тюнинга! 
Из примера: спойлер, бампер, капот, салон, окна, выхлоп и многое другое!
Можно Узнать подробнее в нашем Discord канале, в разделе #wiki-техника 
]=],

["mrsdsw123"]=[=[
• Максималка: 160 км/ч
• Прочность: 1400
• Вместительность: 4]=],

["avx_mercedes2"]=[=[
• Максималка: 175 км/ч
• Прочность: 1450
• Вместительность: 4]=],

["mrsdsw123be"]=[=[
• Максималка: 120 км/ч
• Прочность: 3450
• Вместительность: 4]=],

["mrsdsw124be"]=[=[
• Максималка: 145 км/ч
• Прочность: 3000
• Вместительность: 4]=],

["avx_technical_unarmed_be"]=	[=[
• Максималка: 115 км/ч
• Прочность: 4250
• Вместительность: 10]=],
 
["vip_probny"]=[=[
☆ КД Чата на 25% меньше! ☆
☆ КД Арсенала на 50% меньше! ☆
☆ Кастомное отображение в TAB меню ☆
☆ Возможность использовать WhiteList! ☆
☆ За смерть снимается на 75% меньше денег! ☆ 
☆ Возможность перекрашивать доступные авто! ☆  
☆ Скидка 25% на весь Ассортимент у торговца! ☆
☆ Возможность использовать многие модификации на оружие! ☆
]=],

["vip_na_mesyac"]=[=[
☆ КД Чата на 25% меньше! ☆
☆ КД Арсенала на 50% меньше! ☆
☆ Кастомное отображение в TAB меню ☆
☆ Возможность использовать WhiteList! ☆
☆ За смерть снимается на 75% меньше денег! ☆ 
☆ Возможность перекрашивать доступные авто! ☆  
☆ Скидка 25% на весь Ассортимент у торговца! ☆
☆ Возможность использовать многие модификации на оружие! ☆
]=],


["vip_plus_na_mesyac"]=[=[
☆ КД Чата на 25% меньше! ☆
☆ КД Арсенала на 50% меньше! ☆
☆ Кастомное отображение в TAB меню ☆
☆ Возможность использовать WhiteList! ☆
☆ За смерть снимается на 75% меньше денег! ☆ 
☆ Возможность перекрашивать доступные авто! ☆  
☆ Скидка 25% на весь Ассортимент у торговца! ☆
☆ Возможность использовать ВСЕ модификации на оружие! ☆
  ↓↓↓
• Дополнительные плюшки VIP PLUS:
☆ Возможность использовать личный фонарик! ☆
☆ Получение в 2 раза больше наград от точек! ☆
☆ Возможность использовать подствольный гранатомет! ☆
]=],

 

["vip_na_vsegda"]=[=[
☆ КД Чата на 25% меньше! ☆
☆ КД Арсенала на 50% меньше! ☆
☆ Кастомное отображение в TAB меню ☆
☆ Возможность использовать WhiteList! ☆
☆ За смерть снимается на 75% меньше денег! ☆ 
☆ Возможность перекрашивать доступные авто! ☆  
☆ Скидка 25% на весь Ассортимент у торговца! ☆
☆ Возможность использовать многие модификации на оружие! ☆

  ↓↓↓

В случае нарушений - СА имеет право её снять без каких либо предупреждений! ]=],
 
------------
["profa_1"]=[=[
• Основное оружие: АКМ
• Запасное оружие: ПМ
• Рукопашное оружие: Мачете убитого им духа
• Дополнительно: РПГ-7, Наручники, Анимации
• Броня: 75% 


• Зарплата: 650$
 ↓↓↓ 


Внимание: Возможность покупки открывается после 12 часов игры!
После активации вы автоматически перейдете на выбранную сторону.
В случае, если вы уйдете с профы сами или получите снятие - её вам никто не вернет, как и средства!

На данную профессию действует частичная RP-смерть при попадании в заложники, но в случае нарушений RP состовляющей - вам имеют право дать полную RP смерть!]=],

["profa_2"]=[=[
• Основное оружие: М16А4
• Запасное оружие: ПМ
• Рукопашное оружие: Мачете
• Дополнительно: FIM-92 «Stinger»
• Дополнительно: РПГ-7, Наручники, Анимации
• Броня: 75%


• Зарплата: 650$
 ↓↓↓


Внимание: Возможность покупки открывается после 12 часов игры!
После активации вы автоматически перейдете на выбранную сторону.
В случае, если вы уйдете с профы сами или получите снятие - её вам никто не вернет, как и средства!

На данную профессию действует частичная RP-смерть при попадании в заложники, но в случае нарушений RP состовляющей - вам имеют право дать полную RP смерть!]=],


["profa_3"]=[=[
За злоупотребление данной возможностью вам может быть заблокирована она в будущем.]=],


-- • 40MM: 4 » 5 
 
["perk_1"]=[=[
• Осколочные гранаты: 2 » 3 ||| Дым/Слеп. гранаты: 1 » 2
• Минометные мина: 6 » 8 + 40MM: 3 » 4 
• Пистолетные: 21 » 42
• Автоматные: 110 » 160
• Снайперские: 21 » 32
• Пулеметные: 100 » 200
• Магнум: 14 » 21
• Дробь: 16 » 24
• РПГ: 1 » 2]=],

--  80 + 100 + 60 
["perk_2"]=[=[
• Бинты: 4 » 6
• Кр.Ост.Зажимов: 2 » 4
• Гемостоп: 3 » 5
(В расчете это: 240ед. дополнительных ХП, которые вы можете использовать для лечения своих товарищей!)
]=],


}



local STORE_ITEM = FindMetaTable("IGSItem")
function STORE_ITEM:SetGlob()
	self.Global = true
	return self
end

hook.Add("IGS.Initialized","SimfphysWorkaround",function() 
timer.Simple(10, function() hook.Remove("PlayerSpawnedVehicle","IGS")
end)
end) 

 
/***  ----------------------------------------------------------------------  ***
	Документацию по всем доступным методам можно посмотреть в файле documentation.txt
	Там написано много интересных и полезных методов, не ленитесь открыть

	Если демонстрационных итемов для настройки автодоната недостаточно
	- свяжитесь с нами и мы вам оперативно поможем: https://vk.com/im?sel=-143836547

	Не забудьте раскомментировать блок кода, чтобы настройки заработали
	Для этого нужно убрать "--" перед нужными строками.
	Если не знаете, как это сделать - напишите нам

	ДЛЯ ОПЫТНЫХ ПОЛЬЗОВАТЕЛЕЙ пример конфигурации автодоната на TRIGON.IM:
	https://gist.github.com/284608002faf5ff10525874b0225801e
***  -------------------------------------------------------------------------  ***/

прочтите_то_что_написано_выше = !!!ОБЯЗАТЕЛЬНО

/****************************************************************************
	Разрешаем покупать отмычку только донатерам (DarkRP)
	Доступ навсегда за 1 рубль
	https://img.qweqwe.ovh/1493244432112.png -- частичное объяснение
****************************************************************************/

--[[
☆ Возможность использовать ☆VIP☆ транспорт:
За СССР:

- «Уаз» 3151 и «Уаз» 3151 (без крыши) ☆
- «Запорожец»☆
- «Москвич» ☆
- «Жигули» ☆
- «Камаз» ☆
- «Раф»  ☆ 

За Остальных: 

- «Авия»  ☪
- «Пикап»    ☪
- «Гольф»       ☪
- «Фольсваген»  ☪
- «Трабант 1/2»  ☪
- «Микроавтобус»  ☪
]]
-- ☆ Возможность использовать без покупки:
 

IGS("VIP (Пробный, на 3 дня)", "vip_probny")   
--:SetPrice(190):SetDiscountedFrom(300)  
:SetPrice(0)
:SetBAdminGroup("VIP", 1)
:SetHighlightColor(Color(225,225,0))
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856841253135319050/r1.png", false)
:SetTerm(3) -- 30 1 дней
:SetCategory("Привилегия")
:SetDescription("Дается активным игрокам, которые отыграли >24ч. на нашем проекте. Целых 3 дня VIP, совершенно бесплатно, с помощью которого Вы сможете испытать все её Пользу и принять верное решение о её приобретении в будущем!") -- Вы сможете испытать все Преимущества владения VIP-кой совершенно бесплатно на целых 3 дня, просто отыграв 24 часа на сервере!
--:SetMaxGlobalPurchases(1)
:SetMaxPurchases(1)
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 24) then
		return "Для того, чтобы испытать всю мощь VIP-ки, нужно отыграть 24 часов хотя-бы! :)"
	end
end)

IGS("VIP", "vip_na_mesyac")
:SetPrice(299)
--:SetPrice(190):SetDiscountedFrom(290)   --  225
--:SetPrice(190):SetDiscountedFrom(300)  
:SetBAdminGroup("VIP", 1)
:SetHighlightColor(Color(225,225,0))
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856841269930360853/r2.png", false)
:SetTerm(30) -- 30 дней
:SetCategory("Привилегия")
:SetDescription("VIP - очень полезная и интересная вещь. Позволяет получить максимум удовльствия от игрового процесса, к примеру, давая возможность - улучшения оружия, скидку на покупку у продавца, ускоренному возраждению!")
--:SetGlobal(true)

IGS("VIP (Вечный)", "vip_na_vsegda") 
:SetPrice(899) 
--:SetPrice(690):SetDiscountedFrom(900)   -- 490 690
--:SetPrice(699):SetDiscountedFrom(900)  
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856841287336460338/r3.png", false)
:SetBAdminGroup("VIP", 2)
:SetHighlightColor(Color(255,255,0))
:SetPerma()
:SetCategory("Привилегия")
:SetDescription("VIP - очень полезная и интересная вещь. Позволяет получить максимум удовльствия от игрового процесса, к примеру, давая возможность - улучшения оружия, скидку на покупку у продавца, ускоренному возраждению!")

:SetHidden(true) -- ! 
--:SetGlobal(true)


IGS("VIP Plus", "vip_plus_na_mesyac") 
:SetPrice(499) 
--:SetPrice(690):SetDiscountedFrom(900)   -- 490 690
--:SetPrice(699):SetDiscountedFrom(900)  
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856841287336460338/r3.png", false)
:SetBAdminGroup("VIP+", 3)
:SetHighlightColor(Color(255,255,0))
:SetTerm(30)
:SetCategory("Привилегия")
:SetDescription("VIP Plus - очень полезная и интересная вещь.\n➞ Имеет ряд бонусных плюшек от обычного VIP!\nПозволяет получить максимум удовльствия от игрового процесса, к примеру, давая возможность - улучшения оружия, скидку на покупку у продавца, ускоренному возраждению!")


-------------------------------------------------------------
IGS("Перк «Запасной магазин»", "perk_1")
:SetPrice(179)  -- 129
--:SetPrice(90):SetDiscountedFrom(179)  
:SetIcon("https://mst-gmod.ru/img/perk_1b.png", false)
:SetTerm(30) -- 30 дней
:SetCategory("Перки")
:SetDescription("Данный Перк позволят вам увеличить количество переносимых боеприпасов, что явно будет не лишним во время ожесточенного боя!\nНо даже с этим перком, рекомендуем использовать транспорт со снаряжением.")
 
IGS("Перк «Увеличенная аптечка»", "perk_2")
:SetPrice(179) -- 99 
--:SetPrice(90):SetDiscountedFrom(179)  
:SetIcon("https://mst-gmod.ru/img/perk_2b.png", false)
:SetTerm(30) -- 30 дней
:SetCategory("Перки")
:SetDescription("Данный Перк увеличивает количество бинтов, расходников для аптечки, чтобы вы смогли больше выличить бойцов во время боя!")
 
IGS("Перк «Увеличенная зарплата»", "perk_3")
:SetPrice(179)
--:SetPrice(90):SetDiscountedFrom(179)  
:SetIcon("https://mst-gmod.ru/img/perk_3b.png", false)
:SetTerm(30) -- 30 дней
:SetCategory("Перки")
:SetDescription("Данный Перк добавляет к каждой Зарплате по 225$! (Это около 50% от основной ЗП), тем самым быстрее собирать сумму на покупки техники и всего в магазине!")
 


-------------------------------

IGS("Отмычка", "lockpick"):SetWeapon("lockpick")
:SetPrice(99)
:SetPrice(45):SetDiscountedFrom(99) --:SetPrice(60):SetDiscountedFrom(90)  -- 65

:SetTerm(30)
:SetDescription("Отмычка позволит взламывать любые двери. От Штабов, до машин!")
:SetIcon("https://mst-gmod.ru/img/krow2.png", false) -- true значит, что указана моделька, а не ссылка   
:SetCategory("Другое") -- RP Процесс
 
IGS("Рем-ка Обл.", "weapon_simrepair2"):SetWeapon("weapon_simrepair2")
:SetPrice(99) 
--:SetPrice(65):SetDiscountedFrom(99)

:SetTerm(30)
:SetDescription("Ремкомплект для починки наземного транспорта! Она похожа на ту, что есть у танкистов (285-ых), но имеет заряд 1.000ед, вместо 2.000ед (для баланса). P.S. Можно иметь оба Рем-комплекта, тогда суммарно будет 3.000ед починки.")
:SetIcon("https://mst-gmod.ru/img/rem2.png", false)
--:SetImage("https://i.imgur.com/rjOPkPp.jpg") 
:SetCategory("Другое") -- RP Процесс


IGS("Аптечка Обл.", "weapon_medkit2"):SetWeapon("fas2_ifak") 
:SetPrice(245) -- 99 149 199
--:SetPrice(125):SetDiscountedFrom(199)

:SetTerm(30)
:SetDescription("Аптечка. Очень важная вещь для выживания, особенно на поле боя. С ней вы сможете пополнить здоровья как себе, так и товарищу (Х2 лечение!). Я бы рекомендовал её покупать в первую очередь, чтобы повысить свои шансы на поле боя.\nИспользуйте с умом, ведь она не бесконечная и нуждается в пополнении бинтов")
:SetIcon("https://mst-gmod.ru/img/heal2.png", false) 
:SetCategory("Другое") -- RP Процесс


IGS("Флаер", "weapon_vj_flaregun_r"):SetWeapon("weapon_vj_flaregun_r")
--:SetPrice(65)
:SetPrice(45):SetDiscountedFrom(65)  -- 45
:SetHighlightColor(Color(255,125,0))
:SetTerm(30)
:SetDescription("Разрешает брать Сигнальный Пистолет через спавн меню в любое время! Играешь в клане или отряде и успел потеряться? Хочешь как-то обозначить своё местоположение? Тебе нужен сигнальный пистолет, который стреляет очень яркими флаерами, они настолько яркие что видны как с воздуха так и с земли в любое время сутоку!")
:SetIcon("https://mst-gmod.ru/img/signal.png", false)
--:SetImage("https://i.imgur.com/rjOPkPp.jpg") 
:SetCategory("Другое")  -- ("RP Процесс")
--:SetGlobal(true)


IGS("Наручники", "weapon_cuff_rope"):SetWeapon("weapon_cuff_rope") 
:SetPrice(145) 
:SetPrice(90):SetDiscountedFrom(145)

:SetTerm(30)
:SetDescription("Наручники - удобная вещь для тех, кто хочет брать в плен, либо брать на допросы или выбивать нужную информацию из человека. Не у всех есть возможность служить в спец.структурах, но приобрести себе данную вещь - может каждый!")
:SetIcon("https://mst-gmod.ru/img/narb.png", false) 
:SetCategory("Другое") -- RP Процесс
 

IGS("50.000$", "money")
:SetPrice(600) 
:SetPrice(490):SetDiscountedFrom(600)

:SetStackable(true)
:SetDescription("Выгодно и быстро получить средства, без мам, пап и кредитов! :)\nА если серьезно, то это временный слот. Скоро его не будет, так что можете попробовать успеть приобрести его!")
:SetIcon("https://mst-gmod.ru/img/money_30000.png", false) 
:SetCategory("Другое") -- RP Процесс
:SetOnActivate(function(ply)
  ply:AddMoney(50000)
end)


--[[IGS("❄ Новогодний Флаер ❄", "weapon_vj_flaregun_r"):SetWeapon("weapon_vj_flaregun_r")
:SetPrice(5):SetDiscountedFrom(65) 
:SetTerm(1)
:SetMaxPurchases(5)
:SetDescription("Разрешает брать Сигнальный Пистолет через спавн меню в любое время! Играешь в клане или отряде и успел потеряться? Хочешь как-то обозначить своё местоположение? Тебе нужен сигнальный пистолет, который стреляет очень яркими флаерами, они настолько яркие что видны как с воздуха так и с земли в любое время сутоку!")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/804763457697087568/rev.png", false)
:SetCategory("❄ Новый год ❄")  -- ("RP Процесс")
--:SetGlobal(true)
:SetHidden(true)]]
 

--------------------------------
--------------------------------------------------
IGS("Гитара (S/M)", "guitar"):SetWeapon("guitar")  
:SetPrice(99) -- 65
--:SetPrice(45):SetDiscountedFrom(99) 

:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование гитару! Содержит музыку из S.T.A.L.K.E.R и Metro2033. Разбавте грусть хорошей музыкой! Внимание: После покупки зайдите в услуги, выбирите данное оружие и поставьте галочку <<Выдавать при спавне>>")
:SetIcon("https://mst-gmod.ru/img/gitar.png", false)
:SetCategory("Другое") -- Атмосфера



IGS("Гитара (AFG)", "guitar2"):SetWeapon("guitar2")
:SetPrice(99) -- 65
--:SetPrice(45):SetDiscountedFrom(99) 

:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование гитару! Содержит музыку, специально собрунную для нашего проекта - Афганская. Разбавте грусть хорошей музыкой! Внимание: После покупки зайдите в услуги, выбирите данное оружие и поставьте галочку <<Выдавать при спавне>>")
:SetIcon("https://mst-gmod.ru/img/gitar.png", false)
:SetCategory("Другое") -- Атмосфера



IGS("Сигареты", "ciga"):SetWeapon("weapon_ciga_cheap")
:SetPrice(99) -- 65
--:SetPrice(45):SetDiscountedFrom(99) 

:SetTerm(30)
:SetDescription("Вы сможете брать себе Сигарету! Беломорканал это дешевые сигареты, от которых при долгом употреблении может возникнуть сердечный приступ. Но в случае, когда вы в Безысходности - вкурить впоследний раз. Самые массовые папиросы эпохи СССР. Приобрели популярность главным образом из-за низкой цены. Названы в честь Беломорско-Балтийского канала.\n\nПри покупке вы получаете сигарет на целый месяц!")
:SetIcon("https://mst-gmod.ru/img/siga.png", false)
:SetCategory("Другое") -- Атмосфера
:SetGlobal(true)


///////////////////////////////////////////////////

IGS("ППШ-41", "tfa_ins2_ppsh"):SetWeapon("weapon_pph41") --  cw_ppsh-41
:SetPrice(179) -- 99
--:SetPrice(90):SetDiscountedFrom(179) 

:SetTerm(30)
:SetDescription("7,62-мм пистолет-пулемёт образца 1941 года системы Шпагина (ППШ) — советский пистолет-пулемёт, разработанный в 1940 году конструктором Г. С. Шпагиным под патрон 7,62×25 мм ТТ и принятый на вооружение Красной Армии 21 декабря 1940 года. ППШ наряду с ППС-43 являлся основным пистолетом-пулемётом советских Вооружённых Сил в Великой Отечественной войне.\nВо время Афганской войны активно писпользовался Моджахедами.")
:SetIcon("https://mst-gmod.ru/img/OR1B.png", false) -- true значит, что указана моделька, а не ссылка  
--:SetGlobal(true)
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 3) then
		return "Покупка доступна для тех, кто наиграл больше 3 часов"
	end
end)

IGS("Мосинка", "tfa_ins2_mosin"):SetWeapon("cw_mosin")  
:SetPrice(179) -- 99
--:SetPrice(90):SetDiscountedFrom(179) 

:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование знаменитое оружие! Русская 3-линейная (7,62-мм) винтовка Мосин-Наган образца 1891 года.")
:SetIcon("https://mst-gmod.ru/img/OR2B.png", false) -- true значит, что указана моделька, а не ссылка
--:SetGlobal(true) 
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 3) then
		return "Покупка доступна для тех, кто наиграл больше 3 часов"
	end
end)
--  

IGS("Thompson", "cwc_thompson"):SetWeapon("cwc_thompson") -- Thompson 1928
:SetPrice(279) -- 99
--:SetPrice(179):SetDiscountedFrom(279) 

:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование знаменитое оружие - Thompson 1928! Пистолет-пулемёт Томпсона (англ. Thompson submachine gun) — американский пистолет-пулемёт, изобретённый в 1918 году Джоном Тальяферро Томпсоном.")
:SetIcon("https://mst-gmod.ru/img/OR3B.png", false) -- true значит, что указана моделька, а не ссылка
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 3) then
		return "Покупка доступна для тех, кто наиграл больше 3 часов"
	end
end)


IGS("MR73", "cw_mr96"):SetWeapon("cw_mr96") --  
:SetPrice(179) -- 99
--:SetPrice(90):SetDiscountedFrom(179) 
:SetTerm(30)
:SetHidden(true) -- !
:SetDescription("Револьвер для тех, кто умеет точно стрелять в голову. Можно менять ствол под определенные цели и стиль игры. Оружие требует рук, так что советовать можно только Опытным бойцам!")
:SetIcon("https://mst-gmod.ru/img/OR4B.png", false) -- true значит, что указана моделька, а не ссылка
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 3) then
		return "Покупка доступна для тех, кто наиграл больше 3 часов"
	end
end)

IGS("Desert Eagle", "cw_deagle"):SetWeapon("cw_deagle") -- 
:SetPrice(179) -- 99
--:SetPrice(90):SetDiscountedFrom(179) 
:SetTerm(30)
:SetDescription("Desert Eagle — самозарядный пистолет крупного калибра (до 12,7 мм). Имеет огромный урон, за счет своего калибра. Умельцы даже смогли сделать ему крепление под прицел на ваш вкус! Оружие требует рук, так что советовать можно только Опытным бойцам.")
:SetIcon("https://mst-gmod.ru/img/OR5B.png", false) -- true значит, что указана моделька, а не ссылка
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 3) then
		return "Покупка доступна для тех, кто наиграл больше 3 часов"
	end
end)

IGS("M620", "cw_m620"):SetWeapon("cw_m620") --  
:SetPrice(290) -- 99
--:SetPrice(190):SetDiscountedFrom(290) 
:SetTerm(30)
:SetDescription("Несомненно мощный дробовик, попадание которого - не обрадует никакого врага. Возможность выбора типа патронов, прицелов и глушителей - позволяет его настроить под свой тип игры. Если подвести итоги, то это Отличный ствол как и новичкам, так и опытным игрокам Афгана!")
:SetIcon("https://mst-gmod.ru/img/OR7B.png", false) -- true значит, что указана моделька, а не ссылка
:SetCanBuy(function(pl)
  local HOUR = 60 * 60 -- seconds
  if pl:GetUTimeTotalTime() < (HOUR * 3) then
    return "Покупка доступна для тех, кто наиграл больше 3 часов"
  end
end)

IGS("StG 44", "cw_stg44"):SetWeapon("cw_stg44") --  
:SetPrice(249) -- 99
--:SetPrice(179):SetDiscountedFrom(249) 
:SetTerm(30)
:SetDescription("Немецкий автомат, разработанный во время Второй мировой войны. Было выпущено около 450 тысяч единиц. Среди автоматов современного типа стал первой разработкой, производившейся массово. Имеет очень интересную баллистику стрельбы и отдачи, которую удобно контролировать. Имеет дальний прицел, но честно говоря - он вам не нужен =)")
:SetIcon("https://mst-gmod.ru/img/OR6B.png", false) -- true значит, что указана моделька, а не ссылка
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 3) then
		return "Покупка доступна для тех, кто наиграл больше 3 часов"
	end
end)

---------------------------
--[[

IGS("Наградной ППШ-41 за 12ч", "or1_prob"):SetWeapon("weapon_pph41") --  cw_ppsh-41
:SetPrice(0)
:SetTerm(3)
:SetMaxPurchases(1)
:SetDescription("7,62-мм пистолет-пулемёт образца 1941 года системы Шпагина (ППШ) — советский пистолет-пулемёт, разработанный в 1940 году конструктором Г. С. Шпагиным под патрон 7,62×25 мм ТТ и принятый на вооружение Красной Армии 21 декабря 1940 года. ППШ наряду с ППС-43 являлся основным пистолетом-пулемётом советских Вооружённых Сил в Великой Отечественной войне.\nВо время Афганской войны активно писпользовался Моджахедами.")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856839623002554398/OR1B2.png", false) 
--:SetGlobal(true)
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 12) then
		return "Покупка доступна для тех, кто наиграл больше 12 часов"
	end
end)
:SetCategory("Бесплатное")
 

IGS("Наградная Мосинка за 24ч", "or2_prob"):SetWeapon("cw_ws_mosin")
:SetPrice(0)
:SetTerm(3)
:SetMaxPurchases(1)
:SetDescription("Вы сможете брать себе в пользование знаменитое оружие! Русская 3-линейная (7,62-мм) винтовка Мосин-Наган образца 1891 года.")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856839626399678484/OR2B2.png", false) 
--:SetGlobal(true) 
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 24) then
		return "Покупка доступна для тех, кто наиграл больше 24 часов"
	end
end)
:SetCategory("Бесплатное")
 
IGS("Наградной Thompson за 48ч", "or3_prob"):SetWeapon("cwc_thompson")
:SetPrice(0)
:SetTerm(3)
:SetMaxPurchases(1)
:SetDescription("Вы сможете брать себе в пользование знаменитое оружие - Thompson 1928! Пистолет-пулемёт Томпсона (англ. Thompson submachine gun) — американский пистолет-пулемёт, изобретённый в 1918 году Джоном Тальяферро Томпсоном.")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856839621312643073/OR3B2.png", false) 
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 48) then
		return "Покупка доступна для тех, кто наиграл больше 48 часов"
	end
end)
:SetCategory("Бесплатное")


---------------------------------------------------------------

IGS("Наградной MR73 за 62ч", "or4_prob"):SetWeapon("cw_mr96")
:SetPrice(0)
:SetTerm(3)
:SetMaxPurchases(1)
:SetDescription("Револьвер для тех, кто умеет точно стрелять в голову. Можно менять ствол под ваше настроение и нужды, да и вообще - это очень интересное оружие!")
:SetIcon("https://mst-gmod.ru/img/OR4B2.png", false) 
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 62) then
		return "Покупка доступна для тех, кто наиграл больше 62 часов"
	end
end)
:SetCategory("Бесплатное")


IGS("Наградной Desert Eagle за 84ч", "or5_prob"):SetWeapon("cw_deagle")
:SetPrice(0)
:SetTerm(3)
:SetMaxPurchases(1)
:SetDescription("Desert Eagle — самозарядный пистолет крупного калибра (до 12,7 мм). Имеет огромный урон, за счет своего калибра. Умельцы даже смогли сделать ему крепление под прицел на ваш вкус!")
:SetIcon("https://mst-gmod.ru/img/OR5B2.png", false) 
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 84) then
		return "Покупка доступна для тех, кто наиграл больше 84 часов"
	end
end)
:SetCategory("Бесплатное")


IGS("Наградной StG 44 за 99ч", "or6_prob"):SetWeapon("cw_stg44")
:SetPrice(0)
:SetTerm(3)
:SetMaxPurchases(1)
:SetDescription("Немецкий автомат, разработанный во время Второй мировой войны. Было выпущено около 450 тысяч единиц. Среди автоматов современного типа стал первой разработкой, производившейся массово. Имеет очень интересную баллистику стрельбы и отдачи, которую удобно контролировать. Имеет дальний прицел, но честно говоря - он вам не нужен =)")
:SetIcon("https://mst-gmod.ru/img/OR6B2.png", false) 
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 99) then
		return "Покупка доступна для тех, кто наиграл больше 99 часов"
	end
end)
:SetCategory("Бесплатное")]]





















---------------------------------------------------------- Донат профы
local prof_ussr = [[
Ветеран, опытный и заколенный в боях. Ему не нужно объяснять как стрелять или находить врага, вооружен надежным и испытанным оружием. 
Тот, с которого новички должны брать пример - ведь он уже все испытал и знает тонкости ведения боя и обороны. 
Находится в почете у КМД/ГШ и других бойцов.

Кто знает, может это и есть Вы? 
]]
local prof_dux = [[
Дух профи - воин мятежников, благословленный самим аллахом для победы в боях с советской армией.
Обращается с оружием, как с ещё одной рукой.
А ещё умеет читать, да имеет много вооружения!

Другими словами - с ним не стоит шутить, а нужно считаться.
Опытом задавит.. 
]]
local prof_cvk = [[
Позволит снять свой ЧС структуры, без лишних проблем.
]]



IGS("Ветеран СССР", "profa_1")
:SetPrice(900) -- 500 499
--:SetPrice(490):SetDiscountedFrom(900)  -- :SetPrice(350):SetDiscountedFrom(500) 

:SetHighlightColor(Color(222, 31, 31))
:SetIcon("https://mst-gmod.ru/img/prof_ussr.png", false)   
:SetStackable(true)
:SetCategory("Профессии")
:SetDescription(prof_ussr)
:SetOnActivate(function(ply)
	ply:SetPData("sosig",5)
	ply:Kill()
	ply:Spawn()
	--setRPName(ply,ply,"108 СЖТ Ветеран Петров")
end)
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 12) then
		return "Покупка доступна для тех, кто наиграл больше 12 часов"
	end
end)



IGS("Моджахед Профи", "profa_2")
:SetPrice(900) -- 750
--:SetPrice(490):SetDiscountedFrom(900)  -- 499):SetDiscountedFrom(750

:SetHighlightColor(Color(255, 140, 17))
:SetIcon("https://mst-gmod.ru/img/prof_afg.png", false) 
:SetStackable(true)
:SetCategory("Профессии")
:SetDescription(prof_dux)
:SetOnActivate(function(ply)
	ply:SetPData("sosig",39)
	ply:Kill()
	ply:Spawn()
end)
:SetCanBuy(function(pl)
	local HOUR = 60 * 60 -- seconds
	if pl:GetUTimeTotalTime() < (HOUR * 12) then
		return "Покупка доступна для тех, кто наиграл больше 12 часов"
	end
end)



IGS("Снятие ЧС", "profa_3") -- ЧВК Профи
:SetPrice(450) -- 900
--:SetPrice(490):SetDiscountedFrom(900) 


:SetHighlightColor(Color(37, 109, 123))
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856837688598724608/prof_cvk.png", false) 
--:SetImage("https://mst-gmod.ru/img/prof_3.png")  
:SetStackable(true)
:SetCategory("Профессии")
:SetDescription(prof_cvk)
:SetOnActivate(function(ply)
	--ply:SetPData("sosig",48)
	--ply:Kill()
	--ply:Spawn()
end)
:SetCanBuy(function(pl)
	--local HOUR = 60 * 60 -- seconds
	--if pl:GetUTimeTotalTime() < (HOUR * 12) then
	--	return "Покупка доступна для тех, кто наиграл больше 12 часов"
	--end
end)











--------------------------------------------
--[[  
PL_MILLIONS = PL.Add("millions",{"$", "$", "$"})
local GROUP_MONEY = IGS.NewGroup("Игровая валюта")
	:SetIcon("https://imgur.com/lTiq7Nz") -- 

for _,t in ipairs({
	-- кол-во к рублей, цена
	{1000,100},   -- 150
	{5000,400},   -- 500
	{10000,700},  -- 750
	{25000,1500}, --  1500
    {50000,2500}, -- 2500
}) do

	local ITEM = IGS(PL_MILLIONS(t[1]),"money_" .. t[1]) -- money_10mi
		:SetPrice(t[2])
		:SetDescription("Мгновенно и без проблем пополняет баланс игровой валюты на " .. t[1] .. " $! Чем больше валюты вы покупаете - тем выгоднее цена!\nЗа валюту вы сможете покупать себе оружие, машины или выкупать из плена.")
		--:SetDarkRPMoney(t[1])
		:SetCategory("Привилегия")
		:SetOnActivate(function(pl)
			pl:AddMoney(t[1])
		end)
		:SetStackable(true)
		--:SetHidden(true) -- !

	GROUP_MONEY:AddItem(ITEM)
end

]]

-- Спонсирование аренды сервера 
--[[IGS("Помощь с сервером","dedic_rent_1d")
	:SetPrice(215)
	:SetTerm()
	:SetStackable(true)
	:SetCategory("Другое")
	:SetDescription(
		"Вы не обязаны покупать именно эту услугу, чтобы помочь с арендой, но сделав это, нам было бы намного приятнее, зная что есть не безразличные люди, думающие не только о личной выгоде\nТаким образом, ты вносишь вклад в наш проект. Свою готовность поддержать не только словом, но и рублем. "
		 
	)
	:SetOnActivate(function(pl)
		local purchased = IGS.PlayerPurchases(pl)["dedic_rent_1d"] or 0
		purchased = purchased + 1

		local money_spent = purchased * 99

		-- Через раз
		--if purchased % 2 == 1 then
			--                                   \/ NICE_MAN
			--REP.AddAction("STEAM_0:1:55598730",pl,7,"Продлил срок жизни проекта",function()
				qq.notify(pl,3,60,"Ваша репутация изменена /rep")
			--end)
		--end

		IGS.NotifyAll(pl:Name() .. " пожертвовал " .. money_spent .. " руб на продление " .. purchased .. " дней жизни проекта\nСпасибо, чувак!")
	end)
	:SetIcon("https://mst-gmod.ru/img/M1.png") -- database
	--:SetImage("http://i.imgur.com/5bwrt3m.jpg")

  IGS("Справка","spravka")
	:SetPrice(-1)
	:SetTerm()
	:SetStackable(true)
	:SetCategory(IGS_CAT_CHARITY)
	:SetDescription(
		"Данный товар не нужно покупать, это лишь справка для тех, кто хочет приобрести что-то. Товары ниже продаются только через Основателя проекта - «NFS-NIK» (Создатель, указанный в Discord)"
	)
	:SetOnActivate(function(pl)
	end)
	:SetCategory("Другое")
	:SetIcon("https://mst-gmod.ru/img/spravka.png") -- database
]]


--[[
IGS("Багги", "Baggy"):SetVehicle("sim_fphys_v8elite")
--:SetPrice(65):SetDiscountedFrom(90)
:SetNetworked(true)
:SetPrice(90)
:SetTerm(30)
:SetDescription("Разрешает использовать Багги! Маленький вес и мощный движок позволяет ему с легкостью преодалевать дюны и возвышенности!\n\nЦена вызова данной техники: 300$\n(Если у вас есть VIP, то цена ниже!)")
:SetIcon("models/vehicles/buggy_elite.mdl", true) 
--:SetImage("https://i.imgur.com/F1WBcDO.jpg")  --:SetImage("https://i.imgur.com/vX1xJwn.jpg") 
:SetCategory("Транспорт")
--:SetGlobal(true) 


IGS("Волга", "Volga"):SetVehicle("sim_fphys_pwvolga")
--:SetPrice(90):SetDiscountedFrom(145)
:SetNetworked(true)
:SetPrice(90)
:SetTerm(30)
:SetDescription("Позволяет использовать Волгу!\n\nЦена вызова данной техники: 500$\n(Если у вас есть VIP, то цена ниже!)")
:SetIcon("models/blu/volga/volga.mdl", true) 
--:SetImage("https://i.imgur.com/6tVNROA.jpg") 
:SetCategory("Транспорт")]]
 

IGS("Mercedes W123", "mrsdsw123"):SetVehicle("avx_mercedes") 
:SetPrice(129) -- 129
--:SetPrice(90):SetDiscountedFrom(129)

:SetNetworked(true)
:SetTerm(30)
:SetDescription("Cерия легковых автомобилей бизнес-класса немецкой торговой марки Mercedes-Benz. За счет своего двигателя, подвески и развесовки - имеет внушительную максимальную скорость и не плохую управляемость.\n\nЦена вызова данной техники: 700$\n(Если у вас есть VIP, то цена 525$)")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856861426374148126/car_1b.png", false) 
:SetCategory("Транспорт")




IGS("Mercedes W124", "avx_mercedes2"):SetVehicle("simfphys_mercedes_W124")
:SetPrice(149) -- 129
--:SetPrice(90):SetDiscountedFrom(149)

:SetNetworked(true)
:SetTerm(30)
:SetDescription("Cерия легковых автомобилей бизнес-класса немецкой торговой марки Mercedes-Benz. За счет своего двигателя, подвески и развесовки - имеет внушительную максимальную скорость и не плохую управляемость, но в отличии от W123 имеет Облегченный кузов и обновленный дизайн, что позволяет ей быстрее набирать скорость и лучше управляться!\n\nЦена вызова данной техники: 700$\n(Если у вас есть VIP, то цена 525$)")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856861766143049728/car_2b.png", false) 
:SetCategory("Транспорт")



IGS("Dodge Charger R/T", "dukes"):SetVehicle("sim_fphys_dukes")
:SetPrice(169) -- 175
--:SetPrice(125):SetDiscountedFrom(169)

:SetNetworked(true) 
:SetTerm(30)
:SetDescription("Самая быстрая по ускорению и максимальной скорости на нашем проекте, что позваляет как входить в управляемый занос (Дрифт), так и быстро уходить от преследования, хотя в ней скорее вы тут хищник!\n\nИмеется возможность глубокого тюнинга: капот, бампер, спойлер, выхлопная система, и многое другое!\n\nЦена вызова данной техники: 800$\n(Если у вас есть VIP, то цена 600$)")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856862026705928202/car_6b.png", false) 
:SetCategory("Транспорт")
--:SetGlobal(true) 



IGS("Premium Mercedes W123", "mrsdsw123be"):SetVehicle("avx_mercedes_Black_Edition")
:SetPrice(199) -- 199
--:SetPrice(125):SetDiscountedFrom(199)

:SetHidden(true)
:SetNetworked(true)
:SetTerm(30)
:SetDescription("Позволяет использовать премиальный Mercedes W123 с бортовым бронированием, который выдерживает заряд РПГ-7! Имеет 3.450 ед прочности.\n\nЦена вызова данной техники: 900$\n(Если у вас есть VIP, то цена 675$)")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856861838901116978/car_3b.png", false) 
:SetCategory("Транспорт")



IGS("Premium Mercedes W124", "mrsdsw124be"):SetVehicle("simfphys_mercedes_W124_BE")
:SetPrice(199) -- 199
--:SetPrice(125):SetDiscountedFrom(199) 

:SetHidden(true)
:SetNetworked(true)
:SetTerm(30)
:SetDescription("Позволяет использовать премиальный Mercedes W124 с бортовым бронированием, который выдерживает заряд РПГ-7! В отличии от своего собрата (W123 BE) имеет облегченную броню, но за счет более мощного движка и меньшего веса в разы лучше в управлении и разгоне. Имеет 3.000 ед прочности.\n\nЦена вызова данной техники: 900$\n(Если у вас есть VIP, то цена 675$!)")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856861901048381440/car_4b.png", false) 
:SetCategory("Транспорт")




IGS("Premium Пикап", "avx_technical_unarmed_be"):SetVehicle("avx_technical_unarmed_BE")
:SetPrice(249) -- 249
--:SetPrice(190):SetDiscountedFrom(249)

:SetHidden(true)
:SetNetworked(true)
:SetTerm(30)
:SetDescription("Позволяет использовать Пикап BE с бортовым бронированием, который выдерживает заряд РПГ-7! Его броня позволяет полностью обеспечить безопасность водителю и пассажиров! Имеет 4.250 ед прочности!\n\nЦена вызова данной техники: 1200$\n(Если у вас есть VIP, то цена 900$)")
:SetIcon("https://cdn.discordapp.com/attachments/673101426272239629/856861969269129256/car_5b.png", false) 
:SetCategory("Транспорт")
 













--[[
IGS("STG-44", "fn_fal"):SetWeapon("fn_fal")
--:SetPrice(90):SetDiscountedFrom(160)
:SetPrice(160)
:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование знаменитое оружие - STG-44! Внимание: После покупки зайдите в услуги, выбирите данное оружие и поставьте галочку <<Выдавать при спавне>>")
:SetIcon("models/weapons/bob/w_stg44.mdl", true) -- true значит, что указана моделька, а не ссылка
--:SetImage("https://i.imgur.com/0ZmIWVh.jpg") 
]]
 


--[[IGS("Улучшенный Бинокль", "weapon_rpw_binoculars"):SetWeapon("weapon_rpw_binoculars")
:SetPrice(45)
:SetTerm(30)
:SetDescription("Вы сможете брать себе в пользование улучшенный бинокль! Вы сможете узнать дистанцию до цели и делать более сильный зум!")
:SetIcon("models/weapons/w_binocularsbp.mdl", true) -- true значит, что указана моделька, а не ссылка
--:SetImage("https://i.imgur.com/I2n7yva.jpg") 
:SetGlobal(true)]]
 

--[[IGS("Сигара Беломорканал", "ciga_pachka_cheap"):SetWeapon("weapon_ciga_pachka_cheap")
:SetPrice(20)
:SetTerm(30)
:SetDescription("Вы сможете брать себе Сигарету! Беломорканал это дешевые сигареты, от которых при долгом употреблении может возникнуть сердечный приступ. Но в случае, когда вы в Безысходности - вкурить впоследний раз. Самые массовые папиросы эпохи СССР. Приобрели популярность главным образом из-за низкой цены. Названы в честь Беломорско-Балтийского канала.")
:SetIcon("models/mordeciga/mordes/pachkacig.mdl", true) -- true значит, что указана моделька, а не ссылка
:SetCategory("РП развлечение")
:SetGlobal(true)

IGS("Сигара Yava", "ciga_pachka"):SetWeapon("weapon_ciga_pachka")
:SetPrice(35)
:SetTerm(35)
:SetDescription("Вы сможете брать себе Сигарету! Yava это премиальные сигареты на рынке. От них вы не умрете, как от Беломорканала.")
:SetIcon("models/mordeciga/mordes/emptyboxshib.mdl", true) -- true значит, что указана моделька, а не ссылка
:SetCategory("РП развлечение")
:SetGlobal(true)
 
 
IGS("Водка", "vodka"):SetWeapon("weapon_tzar_vodka")
:SetPrice(45)
:SetTerm(35)
:SetDescription("Вы сможете брать себе Водку! Это больше для развлечения, но достаточно забавный объект. Пополняет ваше здоровье, дает возможность крикнуть знаменитую фразу, но не увлекайтесь, так-как не известно от какого количества бутылок вас может вырубить! Используйте с Умом эту замечательную Советскую Водку.")
:SetIcon("models/weapons/w_tzar_vodka.mdl", true) -- true значит, что указана моделька, а не ссылка
:SetCategory("РП развлечение")
:SetGlobal(true)]]

 

hook.Add("IGS.OnSuccessPurchase","DoItemGlobal",function(pl, ITEM, isGlobal, iID)
	if isGlobal then return end -- дальше делать нечего

	if ITEM.Global then
		-- IGS.MovePurchase(db_id, nil, fCallback)

		if IGS.C.Inv_Enabled then
			IGS.DeletePlayerInventoryItem(pl, iID, function(ok)
				if !ok then return end
				IGS.AddToInventory(pl, ITEM:UID(), true)
			end)
		else
			print("Есть инвентари выключены, то пока работать не будет")
		end
	end
end)
