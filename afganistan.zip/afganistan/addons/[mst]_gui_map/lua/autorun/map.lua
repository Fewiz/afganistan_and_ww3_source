
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_gui_map/lua/autorun/map.lua ~

]]

if not MAP then   
    MAP = {}
end

if SERVER then
	AddCSLuaFile()
	util.AddNetworkString("SendMAPSize")
	util.AddNetworkString("RequestMAPSize")

	function CalculateSize(na, size, nb, x, y, z, try)
		local res
		local End = 0

		for i = na, size, nb do
			if util.IsInWorld(Vector(x or i, y or i, z or i)) and End < try then
				res = i

				if End > 0 then
					End = 0
				end
			else
				End = End + 1

				if End >= try then
					break
				end
			end
		end
        return res
	end

	function GetMapSize()
		local nb = 45
		local try = 3
		local size = 99999999


		for k, v in pairs(ents.GetAll()) do
			if string.find(v:GetClass(), "info_player_") then
				MAP.SizeHeight = CalculateSize(v:GetPos().z, size, nb, v:GetPos().x, v:GetPos().y, nil, try)

				MAP.SizeN = CalculateSize(v:GetPos().y, size, nb, v:GetPos().x, nil, MAP.SizeHeight, try)
				MAP.SizeW = CalculateSize(v:GetPos().x, -size, -nb, nil, v:GetPos().y, MAP.SizeHeight, try)
				MAP.SizeS = CalculateSize(v:GetPos().y, -size, -nb, v:GetPos().x, nil, MAP.SizeHeight, try)
				MAP.SizeE = CalculateSize(v:GetPos().x, size, nb, nil, v:GetPos().y, MAP.SizeHeight, try)
                
                MAP.SizeHeight = math.Round(MAP.SizeHeight) + 128
				MAP.SizeN = math.Round(MAP.SizeN) - 64
				MAP.SizeW = math.Round(MAP.SizeW) + 64
				MAP.SizeS = math.Round(MAP.SizeS) + 64
				MAP.SizeE = math.Round(MAP.SizeE) - 64

				MAP.SizeX = MAP.SizeE + math.abs(MAP.SizeW)
				MAP.SizeY = MAP.SizeN + math.abs(MAP.SizeS)

				MAP.SizeX = math.abs(MAP.SizeX)
				MAP.SizeY = math.abs(MAP.SizeY)
			end
		end

		return MAP
	end

	net.Receive("RequestMAPSize", function(len, ply)
		net.Start("SendMAPSize")
		net.WriteTable(GetMapSize())
		net.Send(ply)
	end)
end

if CLIENT then

CreateClientConVar("cl_point_r", 0, true, false)
CreateClientConVar("cl_point_g", 174, true, false)
CreateClientConVar("cl_point_b", 222, true, false)

CreateClientConVar("cl_friendpoint_r", 25, true, false)
CreateClientConVar("cl_friendpoint_g", 184, true, false)
CreateClientConVar("cl_friendpoint_b", 11, true, false)

CreateClientConVar("cl_map_displayfriends", 1, true, false)

surface.CreateFont("MapFont1", {
	font = "DermaLarge",
	weight = 600,
	size = 14,
})

surface.CreateFont("MapFont2", {
	font = "Trebuchet24",
	weight = 600,
	size = 30,
})

	function RequestMAPSize()
		net.Start("RequestMAPSize")
		net.SendToServer()
	end

	net.Receive("SendMAPSize", function()
		local tbl = net.ReadTable()

		MAP = tbl

	end)
    
    if not map then
        local map
    end

    local numa = ScrH() * 0.7
	local colorr, colorg, colorb = GetConVarNumber("cl_point_r"), GetConVarNumber("cl_point_g"), GetConVarNumber("cl_point_b")	
	local fcolorr, fcolorg, fcolorb = GetConVarNumber("cl_friendpoint_r"), GetConVarNumber("cl_friendpoint_g"), GetConVarNumber("cl_friendpoint_b")
	local TeamColor = Color(255,255,255)
	local TeamSize = 0

    local function OpenMap()
    	if IsValid(map) then
    		map:Remove()
    	else
		 
		RequestMAPSize()

		map = vgui.Create("DPanel")
		map:SetSize(ScrH() * 0.7, ScrH() * 0.7)
		map:Center()

		map.Paint = function(self)
			draw.RoundedBox(3, 0, 0, self:GetWide(), self:GetTall(), Color(0, 0, 0, 200))
            
                --if file.Exists("mapimages_LH/"..game.GetMap()..".jpg", "DATA") then
                if file.Exists("mapimages_LH/"..game.GetMap()..".jpg", "DATA") then
                	print("yedssss")
                end 	
                	local MapTEXT = surface.GetTextureID( "maps/adt_recrute/carte/sikasso", "DATA") -- "lastshance_v8" mst_mapimages/rp_afghanistan_v9.jpg
            	    surface.SetDrawColor(255, 255, 255, 255)
            	    surface.SetMaterial(Material("data/mapimages_LH/"..game.GetMap()..self:GetWide().."x"..self:GetTall()..".jpg"))  --(Material("data/mapimages_LH/"..game.GetMap()..self:GetWide().."x"..self:GetTall()..".jpg"))
            	    --surface.SetTexture(MapTEXT)
            	    surface.DrawTexturedRect(0, 0, self:GetWide(), self:GetTall()) -- Обычная
            	    --surface.DrawTexturedRectRotated(0, 0, self:GetWide(), self:GetTall(),90) 
            	    if not MAP.SizeHeight or not MAP.SizeW or not MAP.SizeE or not MAP.SizeS or not MAP.SizeN then 
            	    	RequestMAPSize()
            	    	return
            	    end
                    
                    if MAP.SizeS > 0 then
                    a = LocalPlayer():GetPos().y + MAP.SizeN
                    else
                	    a = LocalPlayer():GetPos().y - MAP.SizeS
                    end
                    if MAP.SizeW > 0 then
                        b = LocalPlayer():GetPos().x + MAP.SizeE
                    else
                	    b = LocalPlayer():GetPos().x - MAP.SizeW
                    end

                    
                    draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 5, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()), 12, 4, Color(0, 0, 0, 255))
            	    draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 1, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) - 4, 4, 12, Color(0, 0, 0, 255))

            	    draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 5, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()), 11, 3, Color(colorr, colorg, colorb, 255))
            	    draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 1, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) - 4, 3, 11, Color(colorr, colorg, colorb, 255))
            	    --draw.SimpleText(string.sub(LocalPlayer():Nick(), 1, 8),  "MapFont1", math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide()) + 1, 
            	    --	self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) + 11, Color(0, 0, 0, 255), TEXT_ALIGN_CENTER)  
            	    --draw.SimpleText(string.sub(LocalPlayer():Nick(), 1, 8),  "MapFont1", math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide()), 
            	    --	self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) + 10, Color(colorr, colorg, colorb, 255), TEXT_ALIGN_CENTER)
            	    if tobool(GetConVarNumber("cl_map_displayfriends")) then
            	    	for _, pl in pairs(player.GetAll()) do
            	    		--if pl != LocalPlayer() and pl:GetFriendStatus() == "friend" then --
            	    		--if pl != LocalPlayer() and LocalPlayer():Team() == pl:Team() or  then -- 
            	    		if pl != LocalPlayer() and (LocalPlayer():GetCat() == pl:GetCat() or LocalPlayer():GetCat2() == pl:GetCat2())  then -- 

            	    			if MAP.SizeS > 0 then
                                a = pl:GetPos().y + MAP.SizeN
                                else
                	                a = pl:GetPos().y - MAP.SizeS
                                end
                                if MAP.SizeW > 0 then
                                    b = pl:GetPos().x + MAP.SizeE
                                else
                	                b = pl:GetPos().x - MAP.SizeW
                                end
 
                                 
                                --draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 5, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()), 12, 4, Color(0, 0, 0, 255))
            	                --draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 1, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) - 4, 4, 12, Color(0, 0, 0, 255))

            	                --draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 5, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()), 11, 3, Color(fcolorr, fcolorg, fcolorb, 255))
            	                --draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 1, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) - 4, 3, 11, Color(fcolorr, fcolorg, fcolorb, 255))
            	                
            	                if LocalPlayer():GetCat2() == pl:GetCat2() then 
            	                	TeamColor = Color(25, 25, 255, 255)
            	                else 
            	                	TeamColor = Color(25,200,25,255)
            	                end 

            	                 
            	                --if pl:HasWeapon( "wep_jack_job_drpradio" ) then 
								--	if pl:Voi then
								--		TeamSize = 5
								--		TeamColor = Color(255,255,255,255)
								--	end 
								--end 
								
            	                draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 5, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()), 8+TeamSize, 8+TeamSize, Color(0, 0, 0, 255))
            	                draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 5, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()), 7+TeamSize, 7+TeamSize, TeamColor)


            	                --draw.SimpleText(string.sub(pl:Nick(), 1, 8),  "MapFont1", math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide()) + 1, 
            	                	--self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) + 11, Color(0, 0, 0, 255), TEXT_ALIGN_CENTER)  
            	                --draw.SimpleText(string.sub(pl:Nick(), 1, 8),  "MapFont1", math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide()), 
            	                	--self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()) + 10, Color(fcolorr, fcolorg, fcolorb, 255), TEXT_ALIGN_CENTER)	
            	    		end
            	    	end
            	    end

            	   --[[ for _, npc in pairs(ents.GetAll()) do
            	    	print(npc)
            	    	if npc:GetClass() == "npc_vj_nmrih_walkfemalez" or npc:GetClass() == "npc_vj_nmrih_walkmalez" or
            	    	npc:GetClass() == "npc_vj_nmrih_walksoldierz" or npc:GetClass() == "npc_vj_nmrih_runfemalez" or	
            	    	npc:GetClass() == "npc_vj_nmrih_runmalez" or npc:GetClass() == "npc_vj_nmrih_runsoldierz" or	
            	    	npc:GetClass() == "npc_vj_nmrih_childz" or npc:GetClass() == "npc_wick_mutant_dog" or	
            	    	npc:GetClass() == "npc_genesis_kaban"

            	    	 then
            	    		if MAP.SizeS > 0 then
                                a = npc:GetPos().y + MAP.SizeN
                                else
                	                a = npc:GetPos().y - MAP.SizeS
                                end
                                if MAP.SizeW > 0 then
                                    b = npc:GetPos().x + MAP.SizeE
                                else
                	                b = npc:GetPos().x - MAP.SizeW
                                end

                                local numa = ScrH() * 0.7
                                draw.RoundedBox(0, math.Clamp(b/MAP.SizeX * numa, 0, self:GetWide() ) - 5, self:GetTall() - math.Clamp(a/MAP.SizeY * numa, 0, self:GetTall()), 4, 4, Color(255, 0, 0, 125))
            	    	end
            	    end	]]
                --else
            	--    RebuildMapImage(self:GetWide() , self:GetTall())
                --end


		    end

		    map.OnRemove = function(self)
			    if IsValid(tools) then
			    	tools:Remove()
			    end

			    if IsValid(buddypanel) then
			    	buddypanel:Remove()
			    end
		    end
		end
    end
    
    concommand.Add("openmap", OpenMap)

	function RebuildMapImage(w, h)
		RequestMAPSize()

		if not MAP.SizeHeight or not MAP.SizeW or not MAP.SizeE or not MAP.SizeS or not MAP.SizeN then return end
		
		if not file.IsDir("mst_mapimages", "DATA") then
			file.CreateDir("mst_mapimages")
		end
		local data = {
			angles = Angle(90, 90, 0),
			origin = Vector(0, 0, MAP.SizeHeight * 0.8),
			x = 0,
			y = 0,
			w = w,
			h = h,
			bloomtone = false,
			drawviewmodel = false,
			ortho = true,
			ortholeft = MAP.SizeW,
			orthoright = MAP.SizeE,
			orthotop = MAP.SizeS,
			orthobottom =  MAP.SizeN 
		}

		render.ClearStencil()
		render.SetStencilEnable(true)

		render.SetStencilWriteMask(255)
		render.SetStencilTestMask(255)
		render.SetStencilReferenceValue(255)
		render.SetStencilFailOperation(STENCILOPERATION_REPLACE)
		render.SetStencilZFailOperation(STENCILOPERATION_REPLACE)
		render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
		render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)

		render.SuppressEngineLighting(true)
		render.SetColorModulation(0, 1, 0)
		render.SetBlend(0.4)

		render.RenderView(data)


           local tbl = render.Capture({
			format = "jpeg",
			quality = 100,
			w = w, 
			h = h,
			x = 0,
			y = 0
		})

		render.SuppressEngineLighting(false)
		render.SetColorModulation(1, 1, 1)
		render.SetBlend(1)

		render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
		render.SetStencilEnable(false)
		local image = file.Open("mst_mapimages/"..game.GetMap()..w.."x"..h..".jpg", "wb", "DATA")
		image:Write(tbl)
		image:Close()



	end

	--concommand.Add("rebuildmap", SOSIK)

	--[[function SOSIK(w, h)	
		local files, folder = file.Find("mapimages/"..game.GetMap().."*", "DATA")
			if IsValid(map) then
			    RebuildMapImage(map:GetWide(), map:GetTall())
			else
				for _, f in pairs(files) do
					file.Delete("mapimages/"..f)
				end
			end
		return true

	end	
	SOSIK()

	hook.Add("OnPlayerChat", "RebuildImage", function(ply, text)
		if ply == LocalPlayer() and text == "rebuildmap" then
			local files, folder = file.Find("mapimages/"..game.GetMap().."*", "DATA")
			if IsValid(map) then
			    RebuildMapImage(map:GetWide(), map:GetTall())
			else
				for _, f in pairs(files) do
					file.Delete("mapimages/"..f)
				end
			end
			return true
		end

		if ply == LocalPlayer() and text == "!map" then
			OpenMap()
		end
	end)]]
end
