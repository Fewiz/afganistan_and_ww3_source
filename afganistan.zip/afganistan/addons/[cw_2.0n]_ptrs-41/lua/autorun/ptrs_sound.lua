
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_ptrs-41/lua/autorun/ptrs_sound.lua ~

]]

sound.Add({
    name = "PTRS-41.Deploy",
	channel = CHAN_ITEM,
	colume = 1.0,
	sound = "weapons/ptrs/PTRS_deploy.wav"
})

sound.Add({
    name = "PTRS-41.Clipout",
	channel = CHAN_ITEM,
	colume = 1.0,
	sound = "weapons/ptrs/PTRS_clipout.wav"
})

sound.Add({
    name = "PTRS-41.Clipin",
	channel = CHAN_ITEM,
	colume = 1.0,
	sound = "weapons/ptrs/PTRS_clipin.wav"
})

sound.Add({
    name = "PTRS-41.Bolt",
	channel = CHAN_ITEM,
	colume = 1.0,
	sound = "weapons/ptrs/PTRS_bolt.wav"
})