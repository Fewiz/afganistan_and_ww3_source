
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_ptrs-41/lua/weapons/gdcw_ptrs/shared.lua ~

]]

// Variables that are used on both client and server
SWEP.Category				= "Оружие"
SWEP.Author					= "Nikolai MacPootislavski"
SWEP.Contact				= "Nikolai MacPootislavski"
SWEP.Purpose				= "Create Destruction"
SWEP.Instructions			= "Use your index finger to shoot and your middle finger to aim."
SWEP.MuzzleAttachment			= "1" 	-- Should be "1" for CSS models or "muzzle" for hl2 models
SWEP.ShellEjectAttachment		= "2" 	-- Should be "2" for CSS models or "1" for hl2 models
SWEP.DrawCrosshair			= false	

SWEP.ViewModelFOV			= 60
SWEP.ViewModelFlip			= true
SWEP.ViewModel				= "models/weapons/v_snip_ptrhack.mdl"
SWEP.WorldModel				= "models/weapons/w_snip_ptrhack.mdl"
SWEP.Base 				= "gdcw_base_nik"
SWEP.Spawnable				= true
SWEP.AdminSpawnable			= true
SWEP.Icon				= "entities/gdcw_ptrs"

SWEP.Primary.Sound			= Sound("weapons/ptrs/ptrs-shoot.wav")
SWEP.Primary.Round			= ("ptrs_ball") --  gdcwa_14.5x114_ball
SWEP.Primary.RPM			= 25 --	75 30					// This is in Rounds Per Minute
SWEP.Primary.ClipSize			= 5						// Size of a clip
SWEP.Primary.DefaultClip		= 5
SWEP.Primary.ConeSpray			= 2.0					// Hip fire accuracy
SWEP.Primary.ConeIncrement		= .7					// Rate of innacuracy
SWEP.Primary.ConeMax			= 3.0					// Maximum Innacuracy
SWEP.Primary.ConeDecrement		= 1.1					// Rate of accuracy
SWEP.Primary.KickUp				= 1	-- 1				// Maximum up recoil (rise)
SWEP.Primary.KickDown			= 55	-- 0				// Maximum down recoil (skeet)
SWEP.Primary.KickHorizontal		= 25 -- 0.1					// Maximum up recoil (stock)
SWEP.Primary.Automatic			= false						// Automatic/Semi Auto
SWEP.Primary.Ammo			= "357" -- "ar2"

SWEP.Secondary.ClipSize			= 0						// Size of a clip
SWEP.Secondary.DefaultClip		= 0						// Default number of bullets in a clip
SWEP.Secondary.Automatic		= false						// Automatic/Semi Auto
SWEP.Secondary.Ammo			= ""
SWEP.Secondary.IronFOV			= 65						// How much you 'zoom' in. Less is more! 	

SWEP.data 				= {}						// The starting firemode
SWEP.data.ironsights			= 1

SWEP.SightsPos = Vector(3.39, 2, 1.9)
SWEP.SightsAng = Vector(1.1, -0.65, 0)
SWEP.RunSightsPos = Vector(0, 0, 0)
SWEP.RunSightsAng = Vector(-5.299, -20.017, -5)

SWEP.Offset = {
Pos = {
Up = -1.1,
Right = 1.0,
Forward = -3.0,
},
Ang = {
Up = 0,
Right = 1.5,
Forward = 0,
}
}

function SWEP:DrawWorldModel( )
local hand, offset, rotate

if not IsValid( self.Owner ) then
self:DrawModel( )
return
end

if not self.Hand then
self.Hand = self.Owner:LookupAttachment( "anim_attachment_rh" )
end

hand = self.Owner:GetAttachment( self.Hand )

if not hand then
self:DrawModel( )
return
end

offset = hand.Ang:Right( ) * self.Offset.Pos.Right + hand.Ang:Forward( ) * self.Offset.Pos.Forward + hand.Ang:Up( ) * self.Offset.Pos.Up

hand.Ang:RotateAroundAxis( hand.Ang:Right( ), self.Offset.Ang.Right )
hand.Ang:RotateAroundAxis( hand.Ang:Forward( ), self.Offset.Ang.Forward )
hand.Ang:RotateAroundAxis( hand.Ang:Up( ), self.Offset.Ang.Up )

self:SetRenderOrigin( hand.Pos + offset )
self:SetRenderAngles( hand.Ang )

self:DrawModel( )
end