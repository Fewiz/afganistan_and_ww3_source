
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/effects/gred_particle_aircraft_muzzle/init.lua ~

]]

function EFFECT:Init(data)
	local pos = data:GetOrigin()
	local ang = data:GetAngles()
	local ent = data:GetEntity()
	if gred.CVars["gred_cl_altmuzzleeffect"]:GetBool() then
		ParticleEffect("muzzleflash_sparks_variant_6",pos,ang,nil)
		ParticleEffect("muzzleflash_1p_glow",pos,ang,nil)
		ParticleEffect("muzzleflash_m590_1p_core",pos,ang,nil)
		ParticleEffect("muzzleflash_smoke_small_variant_1",pos,ang,nil)
	else
		local effectdata=EffectData()
		effectdata:SetOrigin(pos)
		effectdata:SetAngles(ang)
		effectdata:SetEntity(ent)
		effectdata:SetScale(1)
		util.Effect("MuzzleEffect", effectdata)
	end
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end