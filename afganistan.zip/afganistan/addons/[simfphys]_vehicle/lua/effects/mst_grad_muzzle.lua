
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/effects/mst_grad_muzzle.lua ~

]]

function EFFECT:Init( data )

	local vehicle = data:GetEntity()
	local Attachment = vehicle:GetAttachment( data:GetAttachment() )

	local Pos = Attachment.Pos
	local Dir = Attachment.Ang:Forward()
	local vel = vehicle:GetVelocity()

	self.emitter = ParticleEmitter( Pos, false )

	self:Muzzle( Pos, Dir, vel )
end

function EFFECT:Muzzle( pos, dir, vel )
	if not self.emitter then return end

	local particle = self.emitter:Add( "effects/ar2_altfire1b", pos )

	if particle then
		particle:SetVelocity( dir * 2500 + vel ) -- ( dir * math.Rand(50,200) + vel )
		particle:SetDieTime( 0.3 ) -- ( 0.2 )
		particle:SetStartAlpha( 255 )
		particle:SetStartSize( 300 )
		particle:SetEndSize( 0 )
		particle:SetRoll( math.Rand( -1, 1 ) )
		particle:SetColor( 255,255,255 )
		particle:SetCollide( false )
	end

	for i = 0,5 do
		local particle = self.emitter:Add( "particles/smokey", pos )

		local rCol = math.Rand(100,120)

		if particle then
			particle:SetVelocity( (-dir * i * math.Rand(800,1200)) + (VectorRand() * math.Rand(10,100)) + vel )
			particle:SetDieTime( math.Rand(1,4) ) --  math.Rand(1,4) 
			particle:SetAirResistance( math.Rand(300,600) )
			particle:SetStartAlpha( math.Rand(50,150) )
			particle:SetStartSize( math.Rand(5,20) )
			particle:SetEndSize( math.Rand(150,200) )
			particle:SetRoll( math.Rand(-1,1) )
			particle:SetColor( rCol,rCol,rCol )
			particle:SetGravity( VectorRand() * 20 + Vector(0,0,200) )
			particle:SetCollide( true )
			particle:SetBounce( 0.3 )
		end
	end

	local light = DynamicLight(self:EntIndex())
	if light then
		light.Pos = pos
		light.r = 255
		light.g = 206
		light.b = 122
		light.Brightness = 8
		light.Decay = 5100
		light.Size = 512
		light.DieTime = CurTime() + 0.1
	end
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end
