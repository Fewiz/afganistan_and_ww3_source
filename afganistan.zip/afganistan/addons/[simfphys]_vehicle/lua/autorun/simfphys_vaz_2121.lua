
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_vaz_2121.lua ~

]]

AddCSLuaFile()
 
 
local model = "models/sim_fphys_vaz_2121/vaz_2121.mdl"

local light_table = {
	ModernLights = false, -- грубо говоря, ксенон или старые фары. True - ксенон, false - старые
  
	Headlight_sprites = { -- Обычные фары
		{pos =  Vector(30.6, 90.1, 34.8)*0.9, size = 25, color = Color(220, 205, 160, 150)},
		{pos =  Vector(30.6, 90.1, 34.8)*0.9, size = 60},
		
		{pos =  Vector(-30.6, 90.1, 34.8)*0.9, size = 25, color = Color(220, 205, 160, 150)},
		{pos =  Vector(-30.6, 90.1, 34.8)*0.9, size = 60},
	},
	Headlamp_sprites = { -- дальние
		{pos =  Vector(30.6, 90.1, 34.8)*0.9, size = 75},
		
		{pos =  Vector(-30.6, 90.1, 34.8)*0.9, size = 75},
	},
	FogLight_sprites = { -- противотуманки
		{pos = Vector(26.92, 88.9, 44.85)*0.9, size = 60},
		{pos = Vector(-26.92, 88.9, 44.85)*0.9, size = 60},
	},
	Rearlight_sprites = { -- задние фары
		{pos = Vector(24, -88.1, 38)*0.9, size = 35, color = Color(255,20,0)},
		{pos = Vector(28, -88.1, 38)*0.9, size = 35, color = Color(255,20,0)},
		
		{pos = Vector(-24, -88.1, 38)*0.9, size = 35, color = Color(255,20,0)},
		{pos = Vector(-28, -88.1, 38)*0.9, size = 35, color = Color(255,20,0)},
	},
	Brakelight_sprites = { -- тормозные огни
		{pos = Vector(20.75, -88.4, 35+2.5)*0.9, size = 35, color = Color(255,20,0)},
		{pos = Vector(20.75, -88.4, 35-2.5)*0.9, size = 35, color = Color(255,20,0)},
		
		{pos = Vector(-20.75, -88.4, 35+2.5)*0.9, size = 35, color = Color(255,20,0)},
		{pos = Vector(-20.75, -88.4, 35-2.5)*0.9, size = 35, color = Color(255,20,0)},
	},
	Reverselight_sprites = { -- фары заднего хода
		--{pos = Vector(26.5, -87.2, 35.2)*0.9, size = 15, material = "sprites/light_ignorez_new", color = Color(220, 205, 160, 100)},
		{pos = Vector(24, -88.1, 35)*0.9, size = 40,   color = Color(220, 205, 160)},
		{pos = Vector(28, -88.1, 35)*0.9, size = 40, color = Color(220, 205, 160)},
		--{pos = Vector(26.23-2, -88.1, 35)*0.9, size = 40, material = "sprites/light_ignorez_new", color = Color(220, 205, 160)},
		
		--{pos = Vector(-26.5, -87.2, 35.2)*0.9, size = 15, material = "sprites/light_ignorez_new", color = Color(220, 205, 160, 100)},
		{pos = Vector(-24, -88.1, 35)*0.9, size = 40,   color = Color(220, 205, 160)},
		{pos = Vector(-28, -88.1, 35)*0.9, size = 40, color = Color(220, 205, 160)},
		--{pos = Vector(-26.23-2, -88.1, 35)*0.9, size = 40, material = "sprites/light_ignorez_new", color = Color(220, 205, 160)},
	},
	Turnsignal_sprites = { -- поворотники
		Right = { -- правый
			{pos = Vector(32, 88.8, 44.76)*0.9, size = 40, color = Color(255,120,0)},
		
			{pos = Vector(40.2, 80.46, 43.95)*0.9, size = 30, color = Color(255,120,0)},
		
			{pos = Vector(31.76, -88.05, 35)*0.9, size = 50,   color = Color(255,120,0)},
		},
		Left = { -- левый
			{pos = Vector(-32, 88.8, 44.76)*0.9, size = 40, color = Color(255,120,0)},
		
			{pos = Vector(-40.2, 80.46, 43.95)*0.9, size = 30, color = Color(255,120,0)},
		
			{pos = Vector(-31.76, -88.05, 35)*0.9, size = 50, color = Color(255,120,0)},
		},
	}
}
list.Set( "simfphys_lights", "vaz_2121", light_table) -- здесь тебе нужно изменить "test" на любое другое название, например "myfirstsimfcar"

--local dt = 0
--local sas = Lerp(dt, 0, -90) 
		
local V = {
	Name = "ВАЗ-2121 «Нива»", -- название машины в меню
	Model = model, -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭", -- категория в которой будет машина

	Members = {
		Mass = 1600, -- масса авто
  
		OnTick = function(v)
 
			if not v.hbrake then
				v.hbrake = 0
				v.gear = 0
				v.tacho = 0
				v.gas = 0
				v.brake = 0
				v.clutch = 0
			end
			
					
			--FT = FT-0.001
			--sas = Lerp(0.2, v.brake, 1)
			--print(sas)

			--v:ManipulateBoneAngles(v:LookupBone("bonnet"), Angle(-90,0,0)) --  Angle(-90,0,0))
			
			--v:ManipulateBoneAngles(v:LookupBone("boot"), Angle(-100,0,0))
			--v:ManipulateBonePosition(v:LookupBone("boot"), Vector(0,3,0))
		
			
			v.tacho = Lerp(0.1, 1-v:GetPoseParameter("tacho"), v:GetRPM()/v:GetLimitRPM())
			v:SetPoseParameter("tacho", 1-v.tacho)
			
			v.speed = v:GetVelocity():Length()/1400 --  2800
			v:SetPoseParameter("speedo", 1-v.speed)
			
			v.gas = Lerp(0.2, v.gas, v:GetThrottle())
			v.clutch = Lerp(0.2, v.clutch, v:GetClutch())
			if v:GetIsBraking() then
				v.brake = Lerp(0.2, v.brake, 1)
			else
				v.brake = Lerp(0.2, v.brake, 0)
			end
			
			---
			if v:GetHandBrakeEnabled() then
				v.hbrake = Lerp(0.1, v.hbrake, 1.1 )
			else
				v.hbrake = Lerp(0.1, v.hbrake, -0.1 )
			end
			---
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(5, "models/sim_fphys_vaz_2121/sensor_on")
			else
				v:SetSubMaterial(5, "models/sim_fphys_vaz_2121/sensor")
			end
			
			v:SetPoseParameter("handbrake", v.hbrake )
			v:SetPoseParameter("gearshift_lever", v.gear )
			v:SetPoseParameter("gas", v.gas)
			v:SetPoseParameter("brake", v.brake)
			v:SetPoseParameter("clutch", v.clutch)
			
			if StormFox or StormFox2 then
			
				if not v.oldwipers then 
					v.oldwipers = 0
					v.wipers = 0
				end
				
				if StormFox then
					if StormFox.IsRaining() and v:EngineActive() then
						v.wipers = math.sin((CurTime()-v.oldwipers)/0.5)
					else
						if v:GetPoseParameter("wipers") > 0.01 then
							v.wipers = math.sin((CurTime()-v.oldwipers)/0.5)
						else
							v.oldwipers = CurTime()
						end
					end
				elseif StormFox2 then
					if StormFox2.Weather.HasDownfall() and v:EngineActive() then
						v.wipers = math.sin((CurTime()-v.oldwipers)/0.5)
					else
						if v:GetPoseParameter("wipers") > 0.01 then
							v.wipers = math.sin((CurTime()-v.oldwipers)/0.5)
						else
							v.oldwipers = CurTime()
						end
					end
				end
				
				v:SetPoseParameter("wipers", v.wipers)
			
			end
			
		end,
		
		SpeedoMax = -1, -- какая максималка на спидометре(может работать криво)

		LightsTable = "vaz_2121", -- название light_table

		AirFriction = -300000,

		ModelInfo = {
			Color = Color(56, 75, 50)
		},
		
		FrontWheelRadius = 14.25, --радиус переднего колеса
		RearWheelRadius = 14.25, --радиус заднего колеса

		CustomMassCenter = Vector(0,0,-1), 

		SeatOffset = Vector(-12,-17,55), -- положение водительского сидения
		SeatPitch = -2,
		FirstPersonViewPos = Vector(0, -16, 4), -- Vector(0, -16, 7)

		PassengerSeats = { -- пассажирские места
			{
				pos = Vector(17,-7,22),
				ang = Angle(0,0,10) -- Vector(ширина, длина, высота),
			},
			
			{
				pos = Vector(-19,-45,25),
				ang = Angle(0,0,10) -- Vector(ширина, длина, высота),
			},
			{
				pos = Vector(0,-45,25),
				ang = Angle(0,0,10) -- Vector(ширина, длина, высота),
			},
			{
				pos = Vector(19,-45,25),
				ang = Angle(0,0,10) -- Vector(ширина, длина, высота),
			},
		},

		ExhaustPositions = { -- позиция выхлопа
        	--[[{
                pos = Vector(-87.65,25.5,8.72),
                ang = Angle(90,180,0),
        	},]]
        },
	
		CustomWheels = true,
		
		CustomWheelModel = "models/sim_fphys_vaz_2121/vaz_2121_wheel.mdl",
		
		CustomWheelPosFL = Vector(36.5, 63.1, 16)*0.9,
		CustomWheelPosFR = Vector(-36.5, 63.1, 16)*0.9,
		CustomWheelPosRL = Vector(36.5, -50.65, 16)*0.9,
		CustomWheelPosRR = Vector(-36.5, -50.65, 16)*0.9,
		
		CustomWheelAngleOffset = Angle(0,90,0),
		
		CustomSuspensionTravel = 1,
		
		CustomSteerAngle = 33, -- 45

		FrontHeight = 3.75, -- высота передней подвески
		FrontConstant = 43000, -- жёсткость подвески
		FrontDamping = 2000, -- прыгучесть подвески
		FrontRelativeDamping = 2000, -- ход подвески

		RearHeight = 5.5, -- высота задней подвески
		RearConstant = 43000, -- жёсткость подвески
		RearDamping = 2000, -- прыгучесть подвески
		RearRelativeDamping = 2000, -- ход подвески

		FastSteeringAngle = 10, -- 20 -- градус поворота на большой скорости
		SteeringFadeFastSpeed = 300, -- на какой скорости будет работать предыдущий параметр

		TurnSpeed = 2, -- 4 2 1  скорость поворота колёс/рулевого колеса
		
		MaxGrip = 40, -- 40 33 80
		Efficiency = 0.8,
		GripOffset = -12, -- -3,
		BrakePower = 30, -- сила торможения 60

		IdleRPM = 750, -- мин. кол-во оборотов
		LimitRPM = 6000, -- макс. кол-во оборотов 132 км/ч
		Revlimiter = false, -- Если true - Когда стрелка спидометра доходит до красного обозначения, она не проходит дальше, если false - это игнорируется
		PeakTorque = 60, -- крутящий момент 35 65
		PowerbandStart = 750, -- какие обороты на нейтральной передаче
		PowerbandEnd = 4500, -- ограничение по оборотам
		Turbocharged = false, -- турбо false = нет, true = да
		Supercharged = false, -- супер заряд
		Backfire = false, -- стреляющий выхлоп

		FuelFillPos = Vector(41.45, -27.6, 36)*0.9, -- положение заправки
		FuelType = FUELTYPE_PETROL, -- тип топлива
		FuelTankSize = 42, -- размер бака

		PowerBias = 0, -- привод. 1 - задний, 0 - полный, -1 - передний

		EngineSoundPreset = -1,
		--
		snd_pitch = 1,
		snd_idle = "vehicles/sim_fphys_vaz-2106/idle.wav",

		snd_low = "vehicles/sim_fphys_vaz-2106/low.wav",
		snd_low_revdown = "vehicles/sim_fphys_vaz-2106/low.wav", -- это всё звук
		snd_low_pitch = 0.9, -- 0.75,

		snd_mid = "vehicles/sim_fphys_vaz-2106/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_vaz-2106/second.wav",
		snd_mid_geardown = "vehicles/sim_fphys_vaz-2106/second.wav",
		snd_mid_pitch = 0.9, -- 0.75,

		snd_horn = "simulated_vehicles/horn_7.wav",

		--
		DifferentialGear = 0.2,
		Gears = {-0.2, 0, 0.2, 0.35, 0.55, 0.8} -- кол-во передач и "мощность"
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_vaz_2121", V )