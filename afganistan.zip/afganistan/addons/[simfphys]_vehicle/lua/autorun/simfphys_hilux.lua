
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_hilux.lua ~

]]

local light_table = {
 
	Headlight_sprites = { 
		{pos = Vector(112,26,44),material = "sprites/light_ignorez",size = 50},
		{pos = Vector(112,-26,44),material = "sprites/light_ignorez",size = 50},
	},
	Headlamp_sprites = { 
		{pos = Vector(112,26,44),material = "sprites/light_ignorez",size = 75},
		{pos = Vector(112,-26,44),material = "sprites/light_ignorez",size = 75},
	},
	
	FogLight_sprites = { -- противотуманки
		{pos = Vector(117,6.5,45), size = 60, OnBodyGroups = { [6] = {0} }},
		{pos = Vector(117,-6.5,45), size = 60, OnBodyGroups = { [6] = {0} }},
		
		{pos = Vector(-3.5,7.25,91.5), size = 60, OnBodyGroups = { [7] = {1} }}, --  
		{pos = Vector(-3.5,20,91.5), size = 60, OnBodyGroups = { [7] = {1} }}, --  
		
		{pos = Vector(-3.5,-7.25,91.5), size = 60, OnBodyGroups = { [7] = {1} }}, --  
		{pos = Vector(-3.5,-20,91.5), size = 60, OnBodyGroups = { [7] = {1} }}, --  
 
	},
	
 
	Rearlight_sprites = {
		{pos = Vector(-110,37.5,42),material = "sprites/light_ignorez",size = 45},
		{pos = Vector(-110,-37.5,42),material = "sprites/light_ignorez",size = 45},
	},
	
	Brakelight_sprites = {
	    {pos = Vector(-110,37.5,42),material = "sprites/light_ignorez",size = 45},
		{pos = Vector(-110,-37.5,42),material = "sprites/light_ignorez",size = 45},
	},
	Reverselight_sprites = {
		{pos = Vector(-110,37.25,46),material = "sprites/light_ignorez",size = 40}, 
	    {pos = Vector(-110,-37.25,46),material = "sprites/light_ignorez",size = 40}, 
	},
	

	
	
	Turnsignal_sprites = { -- поворотники
		Left = { -- левый	
			{pos = Vector(110,35,44),material = "sprites/light_ignorez",size = 45},

			{pos = Vector(44.5,21.85,58.5),size = 4,color = Color(0,255,161,255)},
		  
			{pos = Vector(-110,37,49.5),material = "sprites/light_ignorez",size = 45},	
		},
		Right = { -- правый	
			{pos = Vector(110,-35,44),material = "sprites/light_ignorez",size = 45},

			{pos = Vector(44.5,20.1,58.5),size = 4,color = Color(0,255,161,255)},			
			 
			{pos = Vector(-110,-37,49.5),material = "sprites/light_ignorez",size = 45},
		},
	}
		
		
}
list.Set( "simfphys_lights", "mst_hilux", light_table)
 

local mst_hilux = {
	Name = "Toyota",
	Model = "models/vehicles/hilux/coyota.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
    SpawnOffset = Vector(0,0,12),
	SpawnAngleOffset = 0,

    Members = {
		Mass = 3000,  -- 3750 -- 3500
		LightsTable = "mst_hilux",
		
		MaxHealth = 2250, -- 1500
  	
		IsArmored = true,
		
		EnginePos = Vector(85,0,60),  -- 0,73,50
		
		OnSpawn = function(ent)  
			ent:SetBodygroup(2,1) -- Окна   
			ent:SetBodygroup(6,1) -- Бампер -- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    

			ent:SetBodygroup(6,1) -- Бампер
			-- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    
		end,
		
		OnTick = function(v)
 
 
			if not v.tacho then
				v.tacho = 0
				v.gear = 0
			end
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
					
			--FT = FT-0.001
			--sas = Lerp(0.2, v.brake, 1)
			--print(sas)

			--v:ManipulateBoneAngles(v:LookupBone("bonnet"), Angle(-90,0,0)) --  Angle(-90,0,0))
			
			--v:ManipulateBoneAngles(v:LookupBone("boot"), Angle(-100,0,0))
			--v:ManipulateBonePosition(v:LookupBone("boot"), Vector(0,3,0))
			
			v.speed = v:GetVelocity():Length()/1520   --  2800
			v:SetPoseParameter("vehicle_speedo", v.speed)
			v:SetPoseParameter("vehicle_shifter", v.gear )
			v:SetPoseParameter("vehicle_fuel", v:GetFuel()/v:GetMaxFuel())
			
			 
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje_on")
			else
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje")
			end
		
			
		end,
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 4000,
		
		
		CustomWheels = true,
		
		CustomWheelModel = "models/vehicles/hilux/coyota_will.mdl",
		CustomWheelPosFL = Vector(83,38,25.5),
		CustomWheelPosFR = Vector(83,-38,25.5),
		CustomWheelPosRL = Vector(-60.5,38,25.5),	
		CustomWheelPosRR = Vector(-60.5,-38,25.5),
		CustomWheelAngleOffset = Angle(0,180,0),
 
		CustomMassCenter = Vector(2,0,-1), 
         
		CustomSuspensionTravel = 4,
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 35,
		
		FirstPersonViewPos = Vector(0,-11,5),
		SeatOffset = Vector(12,-20,60),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FrontWheelRadius = 18,
		RearWheelRadius = 18,
		
			PassengerSeats = {
			{
				pos = Vector(21,-20,30),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-10,20,32),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-10,-20,32),
				ang = Angle(0,-90,0)
			},
			
			
			
			
			{
				pos = Vector(-60,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-60,38,52),
				ang = Angle(0,180,-10)
			},
			
			{
				pos = Vector(-90,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-90,38,52),
				ang = Angle(0,180,-10)
			},
		
	    --[[	
		   {
				pos = Vector(45,-90,50),
				ang = Angle(0,90,0)
			},
	        {
				pos = Vector(-45,-90,50),
				ang = Angle(0,-90,0)
			},]]

			
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
		 
		},
		
		FrontHeight = 15,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 15,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 15, -- 10
		SteeringFadeFastSpeed = 535,
		
	    TurnSpeed = 3, -- 2
		
		MaxGrip = 80, -- 60
		Efficiency = 1.25,
		GripOffset = -5, --  -14 
		BrakePower = 30, -- 45
		BulletProofTires = false,
		
		IdleRPM = 450, -- 900
		LimitRPM = 4500,  -- 5500,
		PeakTorque = 110,  -- 220, 75 100
		PowerbandStart = 350,  -- 1000, 750
		PowerbandEnd = 3000, -- 4500, 3300
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-33,-35,46),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 65, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = -1,
 
		 
		ForceTransmission = 1,

		DifferentialGear = 0.25, -- 0.3
		Gears = {-0.09,0,0.1,0.2,0.3,0.37,0.45} -- Gears = {-0.09,0,0.09,0.18,0.28,0.35,0.45}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_hilux", mst_hilux )

--

local mst_hilux_sup = {
	Name = "Toyota Cнабжения",
	Model = "models/vehicles/hilux/coyota.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
    SpawnOffset = Vector(0,0,12),
	SpawnAngleOffset = 0,

    Members = {
		Mass = 3000,  -- 3750 -- 3500
		LightsTable = "mst_hilux",
		
		MaxHealth = 2250, -- 1500
  	
		IsArmored = true,
		
		EnginePos = Vector(85,0,60),  -- 0,73,50
		
		OnSpawn = function(ent)  
			ent:SetBodygroup(2,1) -- Окна   
			ent:SetBodygroup(6,1) -- Бампер -- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    

			ent:SetBodygroup(6,1) -- Бампер
			ent:SetBodygroup(8,1) 
			ent:SetBodygroup(4,1) 
			-- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    
		end,
		
		OnTick = function(v)
 
 
			if not v.tacho then
				v.tacho = 0
				v.gear = 0
			end
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
					
			--FT = FT-0.001
			--sas = Lerp(0.2, v.brake, 1)
			--print(sas)

			--v:ManipulateBoneAngles(v:LookupBone("bonnet"), Angle(-90,0,0)) --  Angle(-90,0,0))
			
			--v:ManipulateBoneAngles(v:LookupBone("boot"), Angle(-100,0,0))
			--v:ManipulateBonePosition(v:LookupBone("boot"), Vector(0,3,0))
			
			v.speed = v:GetVelocity():Length()/1520   --  2800
			v:SetPoseParameter("vehicle_speedo", v.speed)
			v:SetPoseParameter("vehicle_shifter", v.gear )
			v:SetPoseParameter("vehicle_fuel", v:GetFuel()/v:GetMaxFuel())
			
			 
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje_on")
			else
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje")
			end
		
			
		end,
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 4000,
		
		
		CustomWheels = true,
		
		CustomWheelModel = "models/vehicles/hilux/coyota_will.mdl",
		CustomWheelPosFL = Vector(83,38,25.5),
		CustomWheelPosFR = Vector(83,-38,25.5),
		CustomWheelPosRL = Vector(-60.5,38,25.5),	
		CustomWheelPosRR = Vector(-60.5,-38,25.5),
		CustomWheelAngleOffset = Angle(0,180,0),
 
		CustomMassCenter = Vector(2,0,-1), 
         
		CustomSuspensionTravel = 4,
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 35,
		
		FirstPersonViewPos = Vector(0,-11,5),
		SeatOffset = Vector(12,-20,60),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FrontWheelRadius = 18,
		RearWheelRadius = 18,
		
			PassengerSeats = {
			{
				pos = Vector(21,-20,30),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-10,20,32),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-10,-20,32),
				ang = Angle(0,-90,0)
			},
					
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
		 
		},
		
		FrontHeight = 15,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 15,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 15, -- 10
		SteeringFadeFastSpeed = 535,
		
	    TurnSpeed = 3, -- 2
		
		MaxGrip = 80, -- 60
		Efficiency = 1.25,
		GripOffset = -5, --  -14 
		BrakePower = 30, -- 45
		BulletProofTires = false,
		
		IdleRPM = 450, -- 900
		LimitRPM = 4500,  -- 5500,
		PeakTorque = 110,  -- 220, 75 100
		PowerbandStart = 350,  -- 1000, 750
		PowerbandEnd = 3000, -- 4500, 3300
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-33,-35,46),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 65, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = -1,
 
		 
		ForceTransmission = 1,

		DifferentialGear = 0.25, -- 0.3
		Gears = {-0.09,0,0.1,0.2,0.3,0.37,0.45} -- Gears = {-0.09,0,0.09,0.18,0.28,0.35,0.45}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_hilux_sup", mst_hilux_sup )

local mst_hilux_dshkm = {
	Name = "Toyota с ДШК",
	Model = "models/vehicles/hilux/coyota.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
    SpawnOffset = Vector(0,0,12),
	SpawnAngleOffset = 0,

    Members = {
		Mass = 3750, 
		LightsTable = "mst_hilux",
		
		MaxHealth = 2250, -- 1500
  	
		IsArmored = true,
		
		EnginePos = Vector(85,0,60),  -- 0,73,50
		
		OnSpawn = function(ent)  
			ent:SetBodygroup(2,1) -- Окна   
			ent:SetBodygroup(6,1) -- Бампер -- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    
			
			ent:SetBodygroup(1,1) -- Орудие. ДШК 
		end,
		
		OnTick = function(v)
 
 
			if not v.tacho then
				v.tacho = 0
				v.gear = 0
			end
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
 
			
			v.speed = v:GetVelocity():Length()/1520   --  2800
			v:SetPoseParameter("vehicle_speedo", v.speed)
			v:SetPoseParameter("vehicle_shifter", v.gear )
			v:SetPoseParameter("vehicle_fuel", v:GetFuel()/v:GetMaxFuel())
			
			 
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje_on")
			else
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje")
			end
		
			
		end,
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 4000,
		
		
		CustomWheels = true,
		
		CustomWheelModel = "models/vehicles/hilux/coyota_will.mdl",
		CustomWheelPosFL = Vector(83,38,25.5),
		CustomWheelPosFR = Vector(83,-38,25.5),
		CustomWheelPosRL = Vector(-60.5,38,25.5),	
		CustomWheelPosRR = Vector(-60.5,-38,25.5),
		CustomWheelAngleOffset = Angle(0,180,0),
 
		CustomMassCenter = Vector(2,0,-1), 
         
		CustomSuspensionTravel = 4,
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 35,
		
		FirstPersonViewPos = Vector(0,-11,5),
		SeatOffset = Vector(12,-20,60),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FrontWheelRadius = 18,
		RearWheelRadius = 18,
		
			PassengerSeats = {
			{
				pos = Vector(-90,0,33),
				ang = Angle(0,-90,0),
				anim = "walk_ar2",  -- walk_all
			},
			
			{
				pos = Vector(21,-20,30),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-10,20,32),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-10,-20,32),
				ang = Angle(0,-90,0)
			},
			
			
			
			
			{
				pos = Vector(-60,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-60,38,52),
				ang = Angle(0,180,-10)
			},
			
			{
				pos = Vector(-90,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-90,38,52),
				ang = Angle(0,180,-10)
			},
		
	    --[[	
		   {
				pos = Vector(45,-90,50),
				ang = Angle(0,90,0)
			},
	        {
				pos = Vector(-45,-90,50),
				ang = Angle(0,-90,0)
			},]]

			
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
		 
		},
		
		FrontHeight = 15,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 15,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 15, -- 10
		SteeringFadeFastSpeed = 535,
		
	    TurnSpeed = 3, -- 2
		
		MaxGrip = 80, -- 60
		Efficiency = 1.25,
		GripOffset = -5, --  -14 
		BrakePower = 30, -- 45
		BulletProofTires = false,
		
		IdleRPM = 450, -- 900
		LimitRPM = 4500,  -- 5500,
		PeakTorque = 110,  -- 220, 75 100
		PowerbandStart = 350,  -- 1000, 750
		PowerbandEnd = 3300, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-33,-35,46),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 65, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = -1,
 
		 
		ForceTransmission = 1,

		DifferentialGear = 0.25,
		Gears = {-0.09,0,0.1,0.2,0.3,0.37,0.45} -- Gears = {-0.09,0,0.09,0.18,0.28,0.35,0.45}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_hilux_dshkm", mst_hilux_dshkm )


local mst_hilux_m2b = {
	Name = "Toyota с M2 Browning",
	Model = "models/vehicles/hilux/coyota.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
    SpawnOffset = Vector(0,0,12),
	SpawnAngleOffset = 0,

    Members = {
		Mass = 3750, 
		LightsTable = "mst_hilux",
		
		MaxHealth = 2250, -- 1500
  	
		IsArmored = true,
		
		EnginePos = Vector(85,0,60),  -- 0,73,50
		
		OnSpawn = function(ent)  
			ent:SetBodygroup(2,1) -- Окна   
			ent:SetBodygroup(6,1) -- Бампер -- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    
			
			ent:SetBodygroup(1,3) -- Орудие. М2 
		end,
		
		OnTick = function(v)
 
 
			if not v.tacho then
				v.tacho = 0
				v.gear = 0
			end
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
 
			
			v.speed = v:GetVelocity():Length()/1520   --  2800
			v:SetPoseParameter("vehicle_speedo", v.speed)
			v:SetPoseParameter("vehicle_shifter", v.gear )
			v:SetPoseParameter("vehicle_fuel", v:GetFuel()/v:GetMaxFuel())
			
			 
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje_on")
			else
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje")
			end
		
			
		end,
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 4000,
		
		
		CustomWheels = true,
		
		CustomWheelModel = "models/vehicles/hilux/coyota_will.mdl",
		CustomWheelPosFL = Vector(83,38,25.5),
		CustomWheelPosFR = Vector(83,-38,25.5),
		CustomWheelPosRL = Vector(-60.5,38,25.5),	
		CustomWheelPosRR = Vector(-60.5,-38,25.5),
		CustomWheelAngleOffset = Angle(0,180,0),
 
		CustomMassCenter = Vector(2,0,-1), 
         
		CustomSuspensionTravel = 4,
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 35,
		
		FirstPersonViewPos = Vector(0,-11,5),
		SeatOffset = Vector(12,-20,60),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FrontWheelRadius = 18,
		RearWheelRadius = 18,
		
			PassengerSeats = {
			{
				pos = Vector(-90,0,33),
				ang = Angle(0,-90,0),
				anim = "walk_ar2",  -- walk_all
			},
			
			{
				pos = Vector(21,-20,30),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-10,20,32),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-10,-20,32),
				ang = Angle(0,-90,0)
			},
			
			
			
			
			{
				pos = Vector(-60,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-60,38,52),
				ang = Angle(0,180,-10)
			},
			
			{
				pos = Vector(-90,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-90,38,52),
				ang = Angle(0,180,-10)
			},
		
	    --[[	
		   {
				pos = Vector(45,-90,50),
				ang = Angle(0,90,0)
			},
	        {
				pos = Vector(-45,-90,50),
				ang = Angle(0,-90,0)
			},]]

			
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
		 
		},
		
		FrontHeight = 15,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 15,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 15, -- 10
		SteeringFadeFastSpeed = 535,
		
	    TurnSpeed = 3, -- 2
		
		MaxGrip = 80, -- 60
		Efficiency = 1.25,
		GripOffset = -5, --  -14 
		BrakePower = 30, -- 45
		BulletProofTires = false,
		
		IdleRPM = 450, -- 900
		LimitRPM = 4500,  -- 5500,
		PeakTorque = 110,  -- 220, 75 100
		PowerbandStart = 350,  -- 1000, 750
		PowerbandEnd = 3300, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-33,-35,46),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 65, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = -1,
 
		 
		ForceTransmission = 1,

		DifferentialGear = 0.25,
		Gears = {-0.09,0,0.1,0.2,0.3,0.37,0.45} -- Gears = {-0.09,0,0.09,0.18,0.28,0.35,0.45}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_hilux_m2b", mst_hilux_m2b )


local mst_hilux_ags = {
	Name = "Toyota с АГС-17",
	Model = "models/vehicles/hilux/coyota.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
    SpawnOffset = Vector(0,0,12),
	SpawnAngleOffset = 0,

    Members = {
		Mass = 3750, 
		LightsTable = "mst_hilux",
		
		MaxHealth = 2250, -- 1500
  	
		IsArmored = true,
		
		EnginePos = Vector(85,0,60),  -- 0,73,50
		
		OnSpawn = function(ent)  
			ent:SetBodygroup(2,1) -- Окна   
			ent:SetBodygroup(6,1) -- Бампер -- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    
			
			ent:SetBodygroup(1,2) -- Орудие. АГС-17 
		end,
		
		OnTick = function(v)
 
 
			if not v.tacho then
				v.tacho = 0
				v.gear = 0
			end
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
 
			
			v.speed = v:GetVelocity():Length()/1520   --  2800
			v:SetPoseParameter("vehicle_speedo", v.speed)
			v:SetPoseParameter("vehicle_shifter", v.gear )
			v:SetPoseParameter("vehicle_fuel", v:GetFuel()/v:GetMaxFuel())
			
			 
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje_on")
			else
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje")
			end
		
			
		end,
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 4000,
		
		
		CustomWheels = true,
		
		CustomWheelModel = "models/vehicles/hilux/coyota_will.mdl",
		CustomWheelPosFL = Vector(83,38,25.5),
		CustomWheelPosFR = Vector(83,-38,25.5),
		CustomWheelPosRL = Vector(-60.5,38,25.5),	
		CustomWheelPosRR = Vector(-60.5,-38,25.5),
		CustomWheelAngleOffset = Angle(0,180,0),
 
		CustomMassCenter = Vector(2,0,-1), 
         
		CustomSuspensionTravel = 4,
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 35,
		
		FirstPersonViewPos = Vector(0,-11,5),
		SeatOffset = Vector(12,-20,60),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FrontWheelRadius = 18,
		RearWheelRadius = 18,
		
			PassengerSeats = {
			{
				pos = Vector(-90,0,33),
				ang = Angle(0,-90,0),
				anim = "walk_ar2",  -- walk_all
			},
			
			{
				pos = Vector(21,-20,30),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-10,20,32),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-10,-20,32),
				ang = Angle(0,-90,0)
			},
			
			
			
			
			{
				pos = Vector(-60,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-60,38,52),
				ang = Angle(0,180,-10)
			},
			
			{
				pos = Vector(-90,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-90,38,52),
				ang = Angle(0,180,-10)
			},
		
	    --[[	
		   {
				pos = Vector(45,-90,50),
				ang = Angle(0,90,0)
			},
	        {
				pos = Vector(-45,-90,50),
				ang = Angle(0,-90,0)
			},]]

			
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
		 
		},
		
		FrontHeight = 15,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 15,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 15, -- 10
		SteeringFadeFastSpeed = 535,
		
	    TurnSpeed = 3, -- 2
		
		MaxGrip = 80, -- 60
		Efficiency = 1.25,
		GripOffset = -5, --  -14 
		BrakePower = 30, -- 45
		BulletProofTires = false,
		
		IdleRPM = 450, -- 900
		LimitRPM = 4500,  -- 5500,
		PeakTorque = 110,  -- 220, 75 100
		PowerbandStart = 350,  -- 1000, 750
		PowerbandEnd = 3300, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-33,-35,46),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 65, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = -1,
 
		 
		ForceTransmission = 1,

		DifferentialGear = 0.25,
		Gears = {-0.09,0,0.1,0.2,0.3,0.37,0.45} -- Gears = {-0.09,0,0.09,0.18,0.28,0.35,0.45}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_hilux_ags", mst_hilux_ags )



local mst_hilux_atgm = {
	Name = "Toyota с РСЗО",
	Model = "models/vehicles/hilux/coyota.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
    SpawnOffset = Vector(0,0,12),
	SpawnAngleOffset = 0,

    Members = {
		Mass = 3750, 
		LightsTable = "mst_hilux",
		
		MaxHealth = 2250, -- 1500
  	
		IsArmored = true,
		
		EnginePos = Vector(85,0,60),  -- 0,73,50
		
		OnSpawn = function(ent)  
			ent:SetBodygroup(2,1) -- Окна   
			ent:SetBodygroup(6,1) -- Бампер -- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    
			
			ent:SetBodygroup(1,4) -- Орудие. РСЗО
		end,
		
		OnTick = function(v)
 
 
			if not v.tacho then
				v.tacho = 0
				v.gear = 0
			end
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
 
			
			v.speed = v:GetVelocity():Length()/1520   --  2800
			v:SetPoseParameter("vehicle_speedo", v.speed)
			v:SetPoseParameter("vehicle_shifter", v.gear )
			v:SetPoseParameter("vehicle_fuel", v:GetFuel()/v:GetMaxFuel())
			
			 
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje_on")
			else
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje")
			end
		
			
		end,
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 4000,
		
		
		CustomWheels = true,
		
		CustomWheelModel = "models/vehicles/hilux/coyota_will.mdl",
		CustomWheelPosFL = Vector(83,38,25.5),
		CustomWheelPosFR = Vector(83,-38,25.5),
		CustomWheelPosRL = Vector(-60.5,38,25.5),	
		CustomWheelPosRR = Vector(-60.5,-38,25.5),
		CustomWheelAngleOffset = Angle(0,180,0),
 
		CustomMassCenter = Vector(2,0,-1), 
         
		CustomSuspensionTravel = 4,
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 35,
		
		FirstPersonViewPos = Vector(0,-11,5),
		SeatOffset = Vector(12,-20,60),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FrontWheelRadius = 18,
		RearWheelRadius = 18,
		
			PassengerSeats = {
 
			{
				pos = Vector(21,-20,30),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-10,20,32),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-10,-20,32),
				ang = Angle(0,-90,0)
			},
			
			
 

			
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
		 
		},
		
		FrontHeight = 15,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 15,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 15, -- 10
		SteeringFadeFastSpeed = 535,
		
	    TurnSpeed = 3, -- 2
		
		MaxGrip = 80, -- 60
		Efficiency = 1.25,
		GripOffset = -5, --  -14 
		BrakePower = 30, -- 45
		BulletProofTires = false,
		
		IdleRPM = 450, -- 900
		LimitRPM = 4500,  -- 5500,
		PeakTorque = 110,  -- 220, 75 100
		PowerbandStart = 350,  -- 1000, 750
		PowerbandEnd = 3300, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-33,-35,46),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 65, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = -1,
 
		 
		ForceTransmission = 1,

		DifferentialGear = 0.25,
		Gears = {-0.09,0,0.1,0.2,0.3,0.37,0.45} -- Gears = {-0.09,0,0.09,0.18,0.28,0.35,0.45}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_hilux_atgm", mst_hilux_atgm )


local mst_hilux_spg = {
	Name = "Toyota с СПГ-9",
	Model = "models/vehicles/hilux/coyota.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
    SpawnOffset = Vector(0,0,12),
	SpawnAngleOffset = 0,

    Members = {
		Mass = 3750, 
		LightsTable = "mst_hilux",
		
		MaxHealth = 2250, -- 1500
  	
		IsArmored = true,
		
		EnginePos = Vector(85,0,60),  -- 0,73,50
		
		OnSpawn = function(ent)  
			ent:SetBodygroup(2,1) -- Окна   
			ent:SetBodygroup(6,1) -- Бампер -- (7 - противотуманки, 8 - крыша, 4 - балка, мешающая крыше, 3 - запаска)    
			
			ent:SetBodygroup(1,5) -- Орудие. РСЗО
		end,
		
		OnTick = function(v)
 
 
			if not v.tacho then
				v.tacho = 0
				v.gear = 0
			end
			
			if v:GetGear() <= 6 then 
				v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			end
 
			
			v.speed = v:GetVelocity():Length()/1520   --  2800
			v:SetPoseParameter("vehicle_speedo", v.speed)
			v:SetPoseParameter("vehicle_shifter", v.gear )
			v:SetPoseParameter("vehicle_fuel", v:GetFuel()/v:GetMaxFuel())
			
			 
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje_on")
			else
				v:SetSubMaterial(4, "models/vehicles/hilux/hilux_pristroje")
			end
		
			
		end,
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 4000,
		
		
		CustomWheels = true,
		
		CustomWheelModel = "models/vehicles/hilux/coyota_will.mdl",
		CustomWheelPosFL = Vector(83,38,25.5),
		CustomWheelPosFR = Vector(83,-38,25.5),
		CustomWheelPosRL = Vector(-60.5,38,25.5),	
		CustomWheelPosRR = Vector(-60.5,-38,25.5),
		CustomWheelAngleOffset = Angle(0,180,0),
 
		CustomMassCenter = Vector(2,0,-1), 
         
		CustomSuspensionTravel = 4,
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 35,
		
		FirstPersonViewPos = Vector(0,-11,5),
		SeatOffset = Vector(12,-20,60),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FrontWheelRadius = 18,
		RearWheelRadius = 18,
		
			PassengerSeats = {
 
			{
				pos = Vector(21,-20,30),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-10,20,32),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-10,-20,32),
				ang = Angle(0,-90,0)
			},
			
			
			
			
			{
				pos = Vector(-60,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-60,38,52),
				ang = Angle(0,180,-10)
			},
			
			{
				pos = Vector(-90,-38,52),
				ang = Angle(0,0,-10)
			},
			
			{
				pos = Vector(-90,38,52),
				ang = Angle(0,180,-10)
			},
		
	    --[[	
		   {
				pos = Vector(45,-90,50),
				ang = Angle(0,90,0)
			},
	        {
				pos = Vector(-45,-90,50),
				ang = Angle(0,-90,0)
			},]]

			
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
			
			{
				pos = Vector(-98,19.8,27.8),
				ang = Angle(-90,0,0)
			},
		 
		},
		
		FrontHeight = 15,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 15,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 15, -- 10
		SteeringFadeFastSpeed = 535,
		
	    TurnSpeed = 3, -- 2
		
		MaxGrip = 80, -- 60
		Efficiency = 1.25,
		GripOffset = -5, --  -14 
		BrakePower = 30, -- 45
		BulletProofTires = false,
		
		IdleRPM = 450, -- 900
		LimitRPM = 4500,  -- 5500,
		PeakTorque = 110,  -- 220, 75 100
		PowerbandStart = 350,  -- 1000, 750
		PowerbandEnd = 3300, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-33,-35,46),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 65, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = -1,
 
		 
		ForceTransmission = 1,

		DifferentialGear = 0.25,
		Gears = {-0.09,0,0.1,0.2,0.3,0.37,0.45} -- Gears = {-0.09,0,0.09,0.18,0.28,0.35,0.45}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_hilux_spg", mst_hilux_spg )