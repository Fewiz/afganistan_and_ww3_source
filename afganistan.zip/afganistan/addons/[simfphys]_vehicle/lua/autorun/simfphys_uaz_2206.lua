
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_uaz_2206.lua ~

]]

AddCSLuaFile()
 
local light_table = {
  
	Headlight_sprites = { 
		{pos = Vector(105,28.5,46),material = "sprites/light_ignorez",size = 45},
		{pos = Vector(105,-28.5,46),material = "sprites/light_ignorez",size = 45},
	},
	Headlamp_sprites = { 
		{pos = Vector(105,28.5,46),material = "sprites/light_ignorez",size = 75},
		{pos = Vector(105,-28.5,46),material = "sprites/light_ignorez",size = 75},
	},
	FogLight_sprites = {
	    {pos = Vector(105,31.5,33),material = "sprites/light_ignorez",size = 30}, 
		{pos = Vector(105,-31.5,33),material = "sprites/light_ignorez",size = 30}, 
	},
	
	Rearlight_sprites = {
		Vector(-112,42,42.5), -- Vector(-73,33,28),
		Vector(-112,-41.5,42.5), -- Vector(-73,-33,28),
	},
	Brakelight_sprites = {
		{pos = Vector(-112,42,45.5),  material = "sprites/light_ignorez",size = 35}, 
		{pos = Vector(-112,-42,45.5),  material = "sprites/light_ignorez",size = 35}, 
	},
	Reverselight_sprites = {
		{pos = Vector(-112,23,49.5),material = "sprites/light_ignorez",size = 30,OnBodyGroups={[2]={0}}},
		
	},
	
        Turnsignal_sprites = { -- поворотники
		Left = { -- левый		
			    {pos = Vector(105,31.5,35), material = "sprites/light_ignorez",size = 35}, 
			    {pos = Vector(39.5,45,87),    material = "sprites/light_ignorez",size = 25}, 
				
			    {pos = Vector(-112,42,39),   material = "sprites/light_ignorez",size = 25}, 
	},
		Right = { -- правый
		 	    {pos = Vector(105,-31.5,35),      material = "sprites/light_ignorez",size = 35}, 
			    {pos = Vector(39.5,-44.5,87),     material = "sprites/light_ignorez",size = 25}, 
				
			    {pos = Vector(-112,-41.5,39),   material = "sprites/light_ignorez",size = 25}, 
 
		},
	} 
} 
list.Set( "simfphys_lights", "simfphys_uaz_2206", light_table)
-- uaz469_roofless
local V = {
	Name = "Уаз 2206", -- название машины в меню 
	Model = "models/vehicles/uaz_2206/uaz2206.mdl", -- модель машины (в вкладке дополнения и проп авто)  (сломанная: models/vehicles/uaz_2206/uaz2206_destroyed.mdl)
	Category = "☭Советский☭", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 2015,
		
		LightsTable = "simfphys_uaz_2206", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = false,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 55,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
	 
		
		EnginePos = Vector(105,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(50,-27,73),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
        PassengerSeats = {
			{
				pos = Vector(53,-28,42),
				ang = Angle(0,270,0)
			},


			--


			{
				pos = Vector(10,30,38),
				ang = Angle(0,180,0) -- Vector(ширина, длина, высота),
			},

			{
				pos = Vector(-20,30,38),
				ang = Angle(0,180,0) -- Vector(ширина, длина, высота),
			},

			{
				pos = Vector(-50,30,38),
				ang = Angle(0,180,0) -- Vector(ширина, длина, высота),
			},

			{
				pos = Vector(-80,30,38),
				ang = Angle(0,180,0) -- Vector(ширина, длина, высота),
			},
			 
			 
		},

		Attachments = {
			{  -- лево
				model = "models/props_wasteland/cafeteria_bench001a.mdl",
				material = "models/props_pipes/GutterMetal01a",
				color = Color(155,155,155,255),
				pos = Vector(-35,31,37),
				ang = Angle(0,-90,0)
			},
		},
		

		
		OnTick = function(v)
			v:SetPoseParameter("vehicle_speedo", v:GetVelocity():Length()/2600)
		end, 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,25,20),
				ang = Angle(90,165,0)
			},
		},
		 
		SpeedoMax = 70, -- какая максималка на спидометре(может работать криво)
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 10, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 3000,
		FrontRelativeDamping = 3000,

		RearHeight = 7, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 1000, -- 3000
		RearRelativeDamping = 3000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 2, -- 2
		
		MaxGrip = 30, -- 30
		Efficiency = 1,
		GripOffset = -3, --3
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 3000, -- 2600   127км/ч
		PeakTorque = 65, -- 55 45
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		 
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.45, -- 45
		--Gears = {-0.08,0,0.08,0.18,0.26,0.33} -- 4х ступ механика
		Gears = {-0.08,0,0.08,0.18,0.26,0.33,0.42}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_2206", V )

 