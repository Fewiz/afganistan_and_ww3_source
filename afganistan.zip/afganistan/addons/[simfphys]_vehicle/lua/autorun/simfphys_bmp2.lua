
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_bmp2.lua ~

]]

local function bcDamage( vehicle , position , cdamage )
	if not simfphys.DamageEnabled then return end
	
	cdamage = cdamage or false
	net.Start( "simfphys_spritedamage" )
		net.WriteEntity( vehicle )
		net.WriteVector( position ) 
		net.WriteBool( cdamage ) 
	net.Broadcast()
end

local function DestroyVehicle( ent )
	if not IsValid( ent ) then return end
	if ent.destroyed then return end
	
	ent.destroyed = true
	
	local ply = ent.EntityOwner
	local skin = ent:GetSkin()
	local Col = ent:GetColor()
	Col.r = Col.r * 0.8
	Col.g = Col.g * 0.8
	Col.b = Col.b * 0.8
	
	local bprop = ents.Create( "gmod_sent_vehicle_fphysics_gib" )
	bprop:SetModel( ent:GetModel() )			
	bprop:SetPos( ent:GetPos() )
	bprop:SetAngles( ent:GetAngles() )
	bprop:Spawn()
	bprop:Activate()
	bprop:GetPhysicsObject():SetVelocity( ent:GetVelocity() + Vector(math.random(-5,5),math.random(-5,5),math.random(150,250)) ) 
	bprop:GetPhysicsObject():SetMass( ent.Mass * 0.75 )
	bprop.DoNotDuplicate = true
	bprop.MakeSound = true
	bprop:SetColor( Col )
	bprop:SetSkin( skin )
	
	ent.Gib = bprop
	
	simfphys.SetOwner( ply , bprop )
	
	if IsValid( ply ) then
		undo.Create( "Gib" )
		undo.SetPlayer( ply )
		undo.AddEntity( bprop )
		undo.SetCustomUndoText( "Undone Gib" )
		undo.Finish( "Gib" )
		ply:AddCleanup( "Gibs", bprop )
	end
	
	if ent.CustomWheels == true and not ent.NoWheelGibs then
		for i = 1, table.Count( ent.GhostWheels ) do
			local Wheel = ent.GhostWheels[i]
			if IsValid(Wheel) then
				local prop = ents.Create( "gmod_sent_vehicle_fphysics_gib" )
				prop:SetModel( Wheel:GetModel() )			
				prop:SetPos( Wheel:LocalToWorld( Vector(0,0,0) ) )
				prop:SetAngles( Wheel:LocalToWorldAngles( Angle(0,0,0) ) )
				prop:SetOwner( bprop )
				prop:Spawn()
				prop:Activate()
				prop:GetPhysicsObject():SetVelocity( ent:GetVelocity() + Vector(math.random(-5,5),math.random(-5,5),math.random(0,25)) )
				prop:GetPhysicsObject():SetMass( 20 )
				prop.DoNotDuplicate = true
				bprop:DeleteOnRemove( prop )
				
				simfphys.SetOwner( ply , prop )
			end
		end
	end
	
	local Driver = ent:GetDriver()
	if IsValid( Driver ) then
		if ent.RemoteDriver ~= Driver then
			Driver:TakeDamage( Driver:Health() + Driver:Armor(), ent.LastAttacker or Entity(0), ent.LastInflictor or Entity(0) )
		end
	end
	
	if ent.PassengerSeats then
		for i = 1, table.Count( ent.PassengerSeats ) do
			local Passenger = ent.pSeat[i]:GetDriver()
			if IsValid( Passenger ) then
				Passenger:TakeDamage( Passenger:Health() + Passenger:Armor(), ent.LastAttacker or Entity(0), ent.LastInflictor or Entity(0) )
			end
		end
	end
	
	ent:Extinguish() 
	
	ent:OnDestroyed()
	
	ent:Remove()
end

local function DamageVehicle( ent , damage, type )
	if not simfphys.DamageEnabled then return end
	
	local MaxHealth = ent:GetMaxHealth()
	local CurHealth = ent:GetCurHealth()
	
	local NewHealth = math.max( math.Round(CurHealth - damage,0) , 0 )
	
	if NewHealth <= (MaxHealth * 0.6) then
		if NewHealth <= (MaxHealth * 0.3) then
			ent:SetOnFire( true )
			ent:SetOnSmoke( false )
		else
			ent:SetOnSmoke( true )
		end
	end
	
	if MaxHealth > 30 and NewHealth <= 31 then
		if ent:EngineActive() then
			ent:DamagedStall()
		end
	end
	
	if NewHealth <= 0 then
		if type ~= DMG_GENERIC and type ~= DMG_CRUSH or damage > 400 then
			
			DestroyVehicle( ent )
			
			return
		end
		
		if ent:EngineActive() then
			ent:DamagedStall()
		end
		
		return
	end
	
	ent:SetCurHealth( NewHealth )
end

local function TankTakeDamage( ent, dmginfo )
	ent:TakePhysicsDamage( dmginfo )

	if not ent:IsInitialized() then return end

	local Damage = dmginfo:GetDamage()
	local DamagePos = dmginfo:GetDamagePosition()
	local Type = dmginfo:GetDamageType()

	ent.LastAttacker = dmginfo:GetAttacker() 
	ent.LastInflictor = dmginfo:GetInflictor()

	bcDamage( ent , ent:WorldToLocal( DamagePos ) )

	local Mul = 1

	--if Damage < (ent.DamageThreshold or 80) then
	--		Mul = Damage / (80 or ent.DamageThreshold)
	--end
	
	if Damage < 80 then
			Mul = 0
	end

	if Mul == 0 then
		--DamageVehicle( ent , Damage*10 * Mul, Type )
	else
		DamageVehicle( ent , Damage * 10 * Mul, Type )
	end 
	
	--DamageVehicle( ent , Damage * Mul, Type )
	--DamageVehicle( ent , Damage*10 * Mul, Type )
end

	
 local light_table = {
	ModernLights = false, -- грубо говоря, ксенон или старые фары. True - ксенон, false - старые
	--L_HeadLampPos = Vector(134,-45,21), -- рассположение обычных фар (левых - L)
	--L_HeadLampAng = Angle(0,0,0), -- угол поворота фар

	--R_HeadLampPos = Vector(134,45,21), -- рассположение обычных фар (правых - R)
	--R_HeadLampAng = Angle(0,0,0), -- угол поворота фар

	Headlight_sprites = { -- Обычные фары
		{pos =  Vector(138,-60,33),size = 45},
		{pos =  Vector(138,60,33),size = 45},
	},
	Headlamp_sprites = { -- дальние
		{pos =  Vector(140,-60,33),size = 45},
		{pos =  Vector(140,60,33),size = 45},
	},
	
	
	Rearlight_sprites = { 
		{pos = Vector(-157,0,38.5),size = 18}, -- 15
		
		{pos = Vector(-151,47,40.25),size = 15},
		{pos = Vector(-151,-47,40.25),size = 15},
	},
	Brakelight_sprites = {
		{pos = Vector(-157,0,38.5),size = 55},
		
		{pos = Vector(-151,47,40.25),size = 15},
		{pos = Vector(-151,-47,40.25),size = 15},
	},
 
 
}
list.Set( "simfphys_lights", "simphys_BMP2", light_table) -- здесь тебе нужно изменить "test" на любое другое название, например "myfirstsimfcar"



local V = {
	Name = "БМП-2Д",
	Model = "models/vehicles/bmp2/bmp2.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "⛊Бронетранспорт⛊",
	SpawnOffset = Vector(0,0,60),
	SpawnAngleOffset = 90,

	Members = {
		Mass = 15000, -- 15000
		AirFriction = 0,
		LightsTable = "simphys_BMP2",
		--Inertia = Vector(14017.5,46543,47984.5),
		Inertia = Vector(20000,80000,100000),
 
		MaxHealth = 4300, --  3600, 4500
		IsArmored = true,
		NoWheelGibs = true,
		
		OnSpawn = function(ent)
			ent:SetNWBool( "simfphys_NoRacingHud", true )
			--ent.DamageThreshold = 60 -- 30 100
			--ent.OnTakeDamage = TankTakeDamage


			--ent:SetBodygroup(13,1) -- Катки
			ent:SetBodygroup(14,1) -- Башенная защита
			
			--ent:SetSkin(math.random(0,2))
		end,


			FrontWheelRadius = 30, -- 35 40
		RearWheelRadius = 30, -- 35 40

		EnginePos = Vector(37,-25,45),

		CustomWheels = true,
		CustomSuspensionTravel = 15, -- 10

		--CustomWheelModel = "models/props_c17/canisterchunk01g.mdl",
		CustomWheelModel = "models/props_vehicles/carparts_tire01a.mdl",
  
		CustomWheelPosRL = Vector(-90,-45,-10),  -- -90,-35,-10
		CustomWheelPosRR = Vector(-90,45,-10),
		CustomWheelPosML = Vector(-10,-45,-10),
		CustomWheelPosMR = Vector(-10,45,-10),
		CustomWheelPosFL = Vector(75,-45,-10),
		CustomWheelPosFR = Vector(75,45,-10),
		CustomWheelAngleOffset = Angle(0,0,90),

		CustomMassCenter = Vector(0,0,0),

		CustomSteerAngle = 90,
		FastSteeringAngle = 60,
		SteeringFadeFastSpeed = 1,
		
		TurnSpeed = 16, -- 8

		FirstPersonViewPos = Vector(-2,-40,22), --Vector(0,-43,7),  FirstPersonViewPos = Vector(-10,-30,20),
		SeatOffset = Vector(55,-34,3), -- 48
		SeatPitch = -15,
		SeatYaw = 90,

		ModelInfo = {
			WheelColor = Color(0,0,0,0),
		},

		ExhaustPositions = {
			{
				pos = Vector(18,-56,38),
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(18+12,-56,38),
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(18+24,-56,38),
				ang = Angle(0,0,0)
			},
		 
		},

		PassengerSeats = {
			{
				pos = Vector(-44,20,15),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-44,-20,15),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(22,34,-6),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-100,20,-6),
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(-125,20,-6),
				ang = Angle(0,0,0)
			},
			
			{
				pos = Vector(-100,-20,-6),
				ang = Angle(0,180,0)
			},
			{
				pos = Vector(-125,-20,-6),
				ang = Angle(0,180,0)
			},
			
			 
		},

		
		FrontHeight = 28, -- 5 
		FrontConstant = 37000,
		FrontDamping = 42800,
		FrontRelativeDamping = 5500,
		
		RearHeight = 28, -- 5
		RearConstant = 32000,
		RearDamping = 42900,
		RearRelativeDamping = 5500,

		-- 65 КМ/Ч
		MaxGrip = 9000, -- 3000 7000 9000
		Efficiency = 1,
		GripOffset = 1500, -- 500
		BrakePower = 400,
		BulletProofTires = true,

		IdleRPM = 500,
		LimitRPM = 2600, -- 65
		PeakTorque = 260, -- 610  220 260
		PowerbandStart = 600,
		PowerbandEnd = 1600,
		Turbocharged = false,
		Supercharged = false,
		DoNotStall = true,

		FuelFillPos = Vector(139.42,-3.68,38.38),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 460, -- 220
		
		PowerBias = -0.3, -- -0.3,
		
		EngineSoundPreset = 0,
				
		Sound_Idle = "vehicles/bmp2/bmp2_engine_idle.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "vehicles/bmp2/bmp2_engine_mid.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 100,
		Sound_MidFadeOutRate = 1,
		
		Sound_High = "vehicles/bmp2/bmp2_engine_high.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 1,
		Sound_HighFadeInRPMpercent = 50,
		Sound_HighFadeInRate = 0.2,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_2.wav",
		ForceTransmission = 1, -- 1
		
		DifferentialGear = 0.3,
		Gears = {-0.03,0,0.05,0.08,0.11,0.14}
	}
}
list.Set( "simfphys_vehicles", "avx_bmp2", V )


local V = {
	Name = "БМП-2",
	Model = "models/vehicles/bmp2/bmp2.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "⛊Бронетранспорт⛊",
	SpawnOffset = Vector(0,0,60),
	SpawnAngleOffset = 90,

	Members = {
		Mass = 15000, -- 15000
		AirFriction = 0,
		LightsTable = "simphys_BMP2",
		--Inertia = Vector(14017.5,46543,47984.5),
		Inertia = Vector(20000,80000,100000),
 
		MaxHealth = 4300, --  3600, 4500
		IsArmored = true,
		NoWheelGibs = true,
		
		OnSpawn = function(ent)
			ent:SetNWBool( "simfphys_NoRacingHud", true )
			--ent.DamageThreshold = 60 -- 30 100
			--ent.OnTakeDamage = TankTakeDamage 
			-- Мотор 8. Двери - 9/10. Птур - 12 
			ent:SetBodygroup(12,1) 

			--ent:SetBodygroup(13,1) -- Гулси защита
			ent:SetBodygroup(14,1) -- Башенная защита
			
			--ent:SetSkin(math.random(0,2))
		end,


		FrontWheelRadius = 30, -- 35 40
		RearWheelRadius = 30, -- 35 40

		EnginePos = Vector(37,-25,45),

		CustomWheels = true,
		CustomSuspensionTravel = 15, -- 10

		--CustomWheelModel = "models/props_c17/canisterchunk01g.mdl",
		CustomWheelModel = "models/props_vehicles/carparts_tire01a.mdl",
  
		CustomWheelPosRL = Vector(-90,-45,-10),  -- -90,-35,-10
		CustomWheelPosRR = Vector(-90,45,-10),
		CustomWheelPosML = Vector(-10,-45,-10),
		CustomWheelPosMR = Vector(-10,45,-10),
		CustomWheelPosFL = Vector(75,-45,-10),
		CustomWheelPosFR = Vector(75,45,-10),
		CustomWheelAngleOffset = Angle(0,0,90),

		CustomMassCenter = Vector(0,0,0),

		CustomSteerAngle = 90,
		FastSteeringAngle = 60,
		SteeringFadeFastSpeed = 1,
		
		TurnSpeed = 16, -- 8

		FirstPersonViewPos = Vector(-2,-40,22), --Vector(0,-43,7),  FirstPersonViewPos = Vector(-10,-30,20),
		SeatOffset = Vector(55,-34,3), -- 48
		SeatPitch = -15,
		SeatYaw = 90,

		ModelInfo = {
			WheelColor = Color(0,0,0,0),
		},

		ExhaustPositions = {
			{
				pos = Vector(18,-56,38),
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(18+12,-56,38),
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(18+24,-56,38),
				ang = Angle(0,0,0)
			},
		 
		},

		PassengerSeats = {
			{
				pos = Vector(-44,20,15),
				ang = Angle(0,-90,0)
			},
			
			{
				pos = Vector(-44,-20,15),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(22,34,-6),
				ang = Angle(0,-90,0)
			},
			
			
			
			{
				pos = Vector(-100,20,-6),
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(-125,20,-6),
				ang = Angle(0,0,0)
			},
			
			{
				pos = Vector(-100,-20,-6),
				ang = Angle(0,180,0)
			},
			{
				pos = Vector(-125,-20,-6),
				ang = Angle(0,180,0)
			},
			
			 
		},

		
		FrontHeight = 28, -- 5 
		FrontConstant = 37000,
		FrontDamping = 42800,
		FrontRelativeDamping = 5500,
		
		RearHeight = 28, -- 5
		RearConstant = 32000,
		RearDamping = 42900,
		RearRelativeDamping = 5500,

		-- 65 КМ/Ч
		MaxGrip = 9000, -- 3000 7000 9000
		Efficiency = 1,
		GripOffset = 1500, -- 500
		BrakePower = 400,
		BulletProofTires = true,

		IdleRPM = 500,
		LimitRPM = 2600, -- 65
		PeakTorque = 260, -- 610  220 260
		PowerbandStart = 600,
		PowerbandEnd = 1600,
		Turbocharged = false,
		Supercharged = false,
		DoNotStall = true,

		FuelFillPos = Vector(139.42,-3.68,38.38),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 460, -- 220
		
		PowerBias = -0.3, -- -0.3,
		
		EngineSoundPreset = 0,
				
		Sound_Idle = "vehicles/bmp2/bmp2_engine_idle.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "vehicles/bmp2/bmp2_engine_mid.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 100,
		Sound_MidFadeOutRate = 1,
		
		Sound_High = "vehicles/bmp2/bmp2_engine_high.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 1,
		Sound_HighFadeInRPMpercent = 50,
		Sound_HighFadeInRate = 0.2,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_2.wav",
		ForceTransmission = 1, -- 1
		
		DifferentialGear = 0.3,
		Gears = {-0.03,0,0.05,0.08,0.11,0.14}
	}
}
list.Set( "simfphys_vehicles", "avx_bmp2m", V )