
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_ural_4320_grad.lua ~

]]

 
local V = {

	Name = "РСЗО «Град»", -- название машины в меню 
	Model = "models/vehicles/ural_4320/ural4320_grad.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭",
	SpawnAngleOffset = 90,
	
	Members = {

		Mass = 9000,
		MaxHealth = 2875,
		
		LightsTable = "simfphys_ural4320", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 25.5,--радиус переднего колеса
		RearWheelRadius = 25.5,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 55,	--suspension travel limiter length
		
		CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/ural_4320/ural4320_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(100,-44,12),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(100,44,12),		-- position front right wheel
		
		CustomWheelPosML=  Vector(-45,-44,22),
		CustomWheelPosMR = Vector(-45,44,22),
		
		CustomWheelPosRL = Vector(-105,-44,22),	-- rear left
		CustomWheelPosRR = Vector(-105,44,22),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,270,0),
 
		
		EnginePos = Vector(155,0,45),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		
		OnTick = function(v)
			v:SetPoseParameter("vehicle_speedo", v:GetVelocity():Length()/1600) -- 2600 2100
		end, 
		
		SeatOffset = Vector(40,-18,87),
		SeatPitch = 0,
		SeatYaw = 90,
		--SeatAnim = "sit_zen",	
	   
        PassengerSeats = {
		
			{
				pos = Vector(45,-20,53),
				ang = Angle(0,270,0)
			},
			 
		},
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
 
		
		SpeedoMax = 70, -- какая максималка на спидометре(может работать криво)
		
		
		FuelFillPos = Vector(30,-44,40), 
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 175, -- 72 
	
	    StrengthenSuspension = false, -- жесткая подвеска.

		FrontHeight = 18, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 4000,
		FrontRelativeDamping = 6000,

		RearHeight = 16, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 4000,
		RearRelativeDamping = 6000,

		FastSteeringAngle = 20,
		SteeringFadeFastSpeed = 1000,

		TurnSpeed = 4,

		MaxGrip = 80, -- 60
		Efficiency = 1,
		GripOffset = -3,
		BrakePower = 30, -- сила торможения

		IdleRPM = 650, -- мин. кол-во оборотов
		LimitRPM = 2500, -- 1350 макс. кол-во оборотов  -- 90км/ч
		Revlimiter = false, -- Если true - Когда стрелка спидометра доходит до красного обозначения, она не проходит дальше, если false - это игнорируется
		PeakTorque = 250, -- 120 крутящий момент 200
		PowerbandStart = 650, -- какие обороты на нейтральной передаче
		PowerbandEnd = 800, -- 1200 ограничение по оборотам
		Turbocharged = false, -- турбо false = нет, true = да
		Supercharged = false, -- супер заряд
		Backfire = false, -- стреляющий выхлоп
		
		PowerBias = 0, --1
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/alfaromeo/alfaromeo_idle.wav",
		Sound_IdlePitch = 0.7,
		
		Sound_Mid = "simulated_vehicles/alfaromeo/alfaromeo_low.wav",
		Sound_MidPitch = 0.7,
		Sound_MidVolume = 1, -- 2 
		Sound_MidFadeOutRPMpercent = 37,		-- at wich percentage of limitrpm the sound fades out
		Sound_MidFadeOutRate = 0.56,                    --how fast it fades out   0 = instant       1 = never
		
		Sound_High = "simulated_vehicles/jeep/jeep_mid.wav",
		Sound_HighPitch = 1.0,
		Sound_HighVolume = 3.0, -- 9.0
		Sound_HighFadeInRPMpercent = 20,
		Sound_HighFadeInRate = 0.59,
		
		Sound_Throttle = "",		-- mutes the default throttle sound
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		DifferentialGear = 0.2,
		Gears = {-0.2,0,0.2,0.3,0.4,0.5,0.6} -- кол-во передач и "мощность"
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_ural4320_grad", V )