
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_arctic_ins2_civilian.lua ~

]]

local light_table = {
 
	Headlight_sprites = { 
		{pos = Vector(-108,32,38),material = "sprites/light_ignorez",size = 75},
		
		{pos = Vector(-108,-32,38),material = "sprites/light_ignorez",size = 75},
	},
	Headlamp_sprites = { 
	    {pos = Vector(-108,32,38),material = "sprites/light_ignorez",size = 75},
		
		{pos = Vector(-108,-32,38),material = "sprites/light_ignorez",size = 75},
	},
	
  	
	Rearlight_sprites = {
		{pos = Vector(108,45,38.5),material = "sprites/light_ignorez",size = 45},
	    {pos = Vector(108,-45,38.9),material = "sprites/light_ignorez",size = 45},
	},
	Brakelight_sprites = {
	    {pos = Vector(108,45,38.5),material = "sprites/light_ignorez",size = 45},
	    {pos = Vector(108,-45,38.9),material = "sprites/light_ignorez",size = 45},
	},
	Reverselight_sprites = {
	    {pos = Vector(107.5,45,44),material = "sprites/light_ignorez",size = 30},
	    {pos = Vector(107.5,-45,44),material = "sprites/light_ignorez",size = 30},
	},
	

	
	
	Turnsignal_sprites = { -- поворотники
		Left = { -- левый
			
      {pos = Vector(-106,-46,38),material = "sprites/light_ignorez",size = 45},	
	  
	  {pos = Vector(107.25,-45,48.5),material = "sprites/light_ignorez",size = 40},
		},
		Right = { -- правый	
	   {pos = Vector(-106,46,38),material = "sprites/light_ignorez",size = 45},	
		 
	  {pos = Vector(107.25,45,48.5),material = "sprites/light_ignorez",size = 40},
		},
	}
		
		
}
list.Set( "simfphys_lights", "minibus", light_table)

local V = {
	Name = "Микроавтобус",
	Model = "models/avx/minibus.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "︾Зарубежный︾",

	SpawnOffset = Vector(0,0,40),
	SpawnAngleOffset = -90,

	Members = {
		Mass = 2800,
		LightsTable = "minibus",

		MaxHealth = 2450, --1675,  -- 650,
		
		OnTick = function(ent)
			--ent:SetSubMaterial(1, "models/sim_fphys_willi302_shared/glass")  -- Улучшенное стекло		

        	--ent:SetColor(math.random(0,255),math.random(0,255),math.random(0,255))	
        	--ent:SetModel( "models/blu/mine.mdl" )
        end,
		 
		
		ModelInfo = {
			Skin=0,
			Color=Color(0,55,122)	 
		},
		
		--[[ModelInfo = {
			--Color=Color(0,55,122),
	 
		
		local ColorN = math.random(0,5)
		if ColorN == 0 then
		Color=Color(255,255,255)
		 elseif ColorN == 1 then
		Color=Color(255,25,0)
		 elseif ColorN == 2 then
		Color=Color(255,225,0)
		 elseif ColorN == 3 then
		Color=Color(150,25,0)
		 elseif ColorN == 4 then
		Color=Color(25,25,200)
		 elseif ColorN == 5 then
		Color=Color(30,30,30)
		end
		
		},]]
		
        --OnSpawn = function(ent) ent:SetSubMaterial(1, "models/sim_fphys_willi302_shared/glass") end,
		
		IsArmored = false,

		EnginePos = Vector(-115,0,40),

		CustomWheels = true,
		CustomSuspensionTravel = 4,

		CustomWheelModel = "models/avx/minibus_wheel.mdl",
		CustomWheelPosFL = Vector(-63,-38,19),
		CustomWheelPosFR = Vector(-63,38,19),
		CustomWheelPosRL = Vector(58,-38,20),
		CustomWheelPosRR = Vector(58,38,20),
		CustomWheelAngleOffset = Angle(0,180,0),
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 20, -- 25
		
 
		
		SeatOffset = Vector(50,-24,77),
		SeatPitch = 0,
		SeatYaw = -90,
		
		FrontWheelRadius = 16,
		RearWheelRadius = 16,
		
		PassengerSeats = {
			{
				pos = Vector(-55,22,45),  -- (-50,22,45),
				ang = Angle(0,90,0)
			},
			
			
			{
				pos = Vector(0,27,44),
				ang = Angle(0,90,0)
			},
				{
				pos = Vector(0,0,44),
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(0,-27,44),
				ang = Angle(0,90,0)
			},
			
			
			{
				pos = Vector(50,27,44),
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(50,0,44),
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(50,-27,44),
				ang = Angle(0,90,0)
			},
		},
		
		--[[FrontHeight = 10,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,]]
		
		FrontHeight = 10,
		FrontConstant = 35000,
		FrontDamping = 7000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 35000,
		RearDamping = 7000,
		RearRelativeDamping = 5000,
		
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 3,
		
		MaxGrip = 50,  -- 90  -- 60
		Efficiency = 1.25,
		GripOffset = -5,  -- -14 -2
		BrakePower = 25, -- 45
		BulletProofTires = false,
		
		IdleRPM = 900,
		LimitRPM = 5100,  -- 5500, 
		PeakTorque = 75,  -- 220,  -- 75 -- 60
		PowerbandStart = 750,  -- 1000,
		PowerbandEnd = 3500, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(80,55,55),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 120,
		
		PowerBias = 0,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		ForceTransmission = 1,

		DifferentialGear = 0.2,  -- 0.27,
		Gears = {-0.1,0,0.1,0.2,0.3,0.4} --{-0.09,0,0.09,0.18,0.28,0.35}
	}
}
list.Set( "simfphys_vehicles", "avx_minibus", V )

local V2 = {
	Name = "Микроавтобус AlUh",
	Model = "models/avx/minibus.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",
	
	SpawnOffset = Vector(0,0,40),
	SpawnAngleOffset = -90,

	Members = V.Members
}

list.Set( "simfphys_vehicles", "avx_minibus_vbied", V2 )




local light_table = {
 
	Headlight_sprites = { 
		{pos = Vector(31,102,32),material = "sprites/light_ignorez",size = 50},
		
		{pos = Vector(-31,102,32),material = "sprites/light_ignorez",size = 50},
	},
	Headlamp_sprites = { 
	    {pos = Vector(31,102,32),material = "sprites/light_ignorez",size = 50},
		
		{pos = Vector(-31,102,32),material = "sprites/light_ignorez",size = 50},
	},
	 
	
	Rearlight_sprites = {
		{pos = Vector(31.3,-100,35),material = "sprites/light_ignorez",size = 45},
	    {pos = Vector(-31.3,-100,35),material = "sprites/light_ignorez",size = 45},
	},
	Brakelight_sprites = {
	   -- {pos = Vector(31.3,-100,35),material = "sprites/light_ignorez",size = 45},
	   -- {pos = Vector(-31.3,-100,35),material = "sprites/light_ignorez",size = 45},
		
		{pos = Vector(25,-100,35),material = "sprites/light_ignorez",size = 45},
	    {pos = Vector(-25,-100,35),material = "sprites/light_ignorez",size = 45},
		
	},
	Reverselight_sprites = {
		{pos = Vector(19,-100,35),material = "sprites/light_ignorez",size = 40},
	    {pos = Vector(-19,-100,35),material = "sprites/light_ignorez",size = 40},
	},
	

	
	
	Turnsignal_sprites = { -- поворотники
		Left = { -- левый
			
      {pos = Vector(-38,100,32),material = "sprites/light_ignorez",size = 45},	
	  
	  {pos = Vector(-37,-100,35),material = "sprites/light_ignorez",size = 45},
		},
		Right = { -- правый	
	  {pos = Vector(38,100,32),material = "sprites/light_ignorez",size = 45},	
		 
	  {pos = Vector(37,-100,35),material = "sprites/light_ignorez",size = 45},
		},
	}
		
		
}
list.Set( "simfphys_lights", "passat", light_table)

local V = {
	Name = "Volkswagen Passat 1973",
	Model = "models/avx/passat.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "︾Зарубежный︾",
	
	SpawnOffset = Vector(0,0,40),
	SpawnAngleOffset = 0,

	Members = {
		Mass = 1150,  -- 3200
		
        LightsTable = "passat",
		
	       
		MaxHealth = 1300,  -- 400,
		
		
		ModelInfo = {
			Skin=0,
		},
		
 
		IsArmored = false,

		EnginePos = Vector(0,75,55),

		CustomWheels = true,
		CustomSuspensionTravel = 24,

		CustomWheelModel = "models/avx/passat_wheel.mdl",
		CustomWheelPosRL = Vector(-30, -56,19),
		CustomWheelPosRR = Vector(30, -56,19),
		CustomWheelPosFL = Vector(-30, 65,19),
		CustomWheelPosFR = Vector(30, 65,19),
		CustomWheelAngleOffset = Angle(0,90,0),
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 25,
		
		SeatOffset = Vector(2,-18.5,52),
		SeatPitch = 0,
		SeatYaw = 0,
		
		FrontWheelRadius = 14,
		RearWheelRadius = 14,
		
		PassengerSeats = {
			{
				pos = Vector(20,0,20), -- Vector(20,0,20), 
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(20,-40,20),
				ang = Angle(0,0,0)
			},
			{
				pos = Vector(-20,-40,20),
				ang = Angle(0,0,0)
			},
		},
		
		--[[FrontHeight = 12,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 12,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,]]
		
		FrontHeight = 10,
		FrontConstant = 25000,
		FrontDamping = 2500,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 25000,
		RearDamping = 2500,
		RearRelativeDamping = 5000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 3,
		
		MaxGrip = 15,  -- 60
		Efficiency = 1.25,
		GripOffset = -5,  -- -14 -2
		BrakePower = 15, -- 45
		BulletProofTires = false,
		
		IdleRPM = 900,
		LimitRPM = 8000,  -- 5500, -- 7500   -- 150-160 КМ/Ч
		PeakTorque = 30,  -- 220, -- 40 -- 15
		PowerbandStart = 750,  -- 1000,
		PowerbandEnd = 6600, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(45,-72,40),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 45,
		
		PowerBias = 0,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		ForceTransmission = 1,

		DifferentialGear = 0.2,
		Gears = {-0.1,0,0.1,0.2,0.3,0.4}  -- {-0.09,0,0.09,0.18,0.28,0.35}
	}
}
list.Set( "simfphys_vehicles", "avx_passat", V )

local V2 = {
	Name = "Volkswagen Passat 1973 AlUh",
	Model = "models/avx/passat.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",

	SpawnOffset = Vector(0,0,40),
	SpawnAngleOffset = 0,

	Members = V.Members
}

list.Set( "simfphys_vehicles", "avx_passat_vbied", V2 )



 


local light_table = {
 
	Headlight_sprites = { 
		{pos = Vector(-100,31,32.5),material = "sprites/light_ignorez",size = 75},
		
		{pos = Vector(-100,-31,32.5),material = "sprites/light_ignorez",size = 75},
	},
	Headlamp_sprites = { 
	    {pos = Vector(-102,23,32.5),material = "sprites/light_ignorez",size = 50},
		
		{pos = Vector(-102,-23,32.5),material = "sprites/light_ignorez",size = 50},	  
	},
	
  	
	Rearlight_sprites = {
		{pos = Vector(105,24,33),material = "sprites/light_ignorez",size = 45},
	    {pos = Vector(105,-24,33),material = "sprites/light_ignorez",size = 45},
	},
	Brakelight_sprites = {
	    {pos = Vector(105,15,33),material = "sprites/light_ignorez",size = 35},
	    {pos = Vector(105,-15,33),material = "sprites/light_ignorez",size = 35},
	},
	Reverselight_sprites = {
	    {pos = Vector(105,19,33),material = "sprites/light_ignorez",size = 35},
	    {pos = Vector(105,-19,33),material = "sprites/light_ignorez",size = 35},
	},
	

	
	
	Turnsignal_sprites = { -- поворотники
		Left = { -- левый
			
      {pos = Vector(-96,-38,31.5),material = "sprites/light_ignorez",size = 45},	
	  
	  {pos = Vector(105,-31,33),material = "sprites/light_ignorez",size = 40},  -- {pos = Vector(105,-30,33),material = "sprites/light_ignorez",size = 40},
	  {pos = Vector(102,-35,33),material = "sprites/light_ignorez",size = 40},  -- {pos = Vector(102,-35,33),material = "sprites/light_ignorez",size = 40},
		},
		Right = { -- правый	
	   {pos = Vector(-96,38,31.5),material = "sprites/light_ignorez",size = 45},	
		 
	   {pos = Vector(105,31,33),material = "sprites/light_ignorez",size = 40},
	   {pos = Vector(102,35,33),material = "sprites/light_ignorez",size = 40},
		},
	}
		
		
}
list.Set( "simfphys_lights", "mercedes", light_table)


local V = {
	Name = "Mercedes W123",
	Model = "models/avx/mercedes.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "★Премиум★", -- Транспорт

	SpawnOffset = Vector(0,0,10),
	SpawnAngleOffset = -90,
		
	Members = {
		Mass = 1720,  -- 3600  -- 3000
		LightsTable = "mercedes",

		MaxHealth = 1400,  -- 1600
		
		
			--OnTick = function(ent)
			--ent:SetSubMaterial(1, "models/silyrunningdigital/cartex/glass01")  -- Улучшенное стекло		     
           -- end,
		   
	 
		IsArmored = false,

		EnginePos = Vector(-80,0,50),

		CustomWheels = true,
		CustomSuspensionTravel = 3,

		CustomWheelModel = "models/avx/mercedes_wheel.mdl",
		CustomWheelPosFL = Vector(-73,-32,15),
		CustomWheelPosFR = Vector(-73,32,15),
		CustomWheelPosRL = Vector(58,-32,15),
		CustomWheelPosRR = Vector(58,32,15),
		CustomWheelAngleOffset = Angle(0,180,0),
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 25,
		
		SeatOffset = Vector(4,-20.5,50),
		SeatPitch = 0,
		SeatYaw = -90,
		
		FrontWheelRadius = 15,
		RearWheelRadius = 15,
		
		PassengerSeats = {
			{
				pos = Vector(-8,20,18),
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(38,18,18),  -- pos = Vector(38,20,20),
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(38,-18,18),
				ang = Angle(0,90,0)
			},
		},
		
		FrontHeight = 10,
		FrontConstant = 25000,
		FrontDamping = 2500,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 25000,
		RearDamping = 2500,
		RearRelativeDamping = 5000,
		
		--[[
	    FrontHeight = 10,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		]]
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 3,
		
		MaxGrip = 60,   -- 60 
		Efficiency = 1.25,  -- 1.25,
		GripOffset = -5,  -- -14 -2
		BrakePower = 30,
		BulletProofTires = false,
		
		IdleRPM = 900,
		LimitRPM = 7750,  -- 5500,  -- 135-200 КМ/Ч  -- 3500  --6200
		PeakTorque = 30,  -- 220,  -- 75  -- 84  -- 100  -- 40
		PowerbandStart = 750,  -- 1000,
		PowerbandEnd = 7000, -- 4500,  -- 5500
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(62,45,40),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 120,
		
		PowerBias = 1,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		ForceTransmission = 1,  -- 1

		DifferentialGear = 0.2,
		Gears =  {-0.1,0,0.1,0.2,0.3,0.4}  --{-0.09,0,0.09,0.18,0.28,0.35,0.5}
	}
}
list.Set( "simfphys_vehicles", "avx_mercedes", V )

local V2 = {
	Name = "Mercedes W123 AlUh",
	Model = "models/avx/mercedes.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☪Душманский☪",


	SpawnOffset = Vector(0,0,10),
	SpawnAngleOffset = -90,

	Members = V.Members
}

list.Set( "simfphys_vehicles", "avx_mercedes_vbied", V2 )


///////////////////////////////////////////////////////////

local V = {
	Name = "Mercedes W123 Premium",
	Model = "models/avx/mercedes.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "★Премиум★", -- Транспорт

	SpawnOffset = Vector(0,0,10),
	SpawnAngleOffset = -90,

	Members = {
		Mass = 2250,  -- 3600  -- 3000  -- 1620  -- 2250
		LightsTable = "mercedes",

		MaxHealth = 3450,  -- 1600 -- 1400
		
		IsArmored = true,

		
		
		--OnSpawn = function(ent)
			 -- ent:SetSubMaterial(1, "debug/env_cubemap_model")  -- Улучшенное стекло					  
 		--end,

 		OnSpawn = function(ent) ent:SetSubMaterial(1, "models/sim_fphys_willi302_shared/glass") end,
		   
		ModelInfo = {
			Color=Color(0,0,0),
		 },

		 

		EnginePos = Vector(-80,0,50),

		CustomWheels = true,
		CustomSuspensionTravel = 4,

		CustomWheelModel = "models/avx/mercedes_wheel.mdl",
		CustomWheelPosFL = Vector(-73,-32,14), -- 15
		CustomWheelPosFR = Vector(-73,32,14),
		CustomWheelPosRL = Vector(58,-32,13),
		CustomWheelPosRR = Vector(58,32,13),
		CustomWheelAngleOffset = Angle(0,180,0),
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 25,
		
		SeatOffset = Vector(4,-20.5,50),
		SeatPitch = 0,
		SeatYaw = -90,
		
		FrontWheelRadius = 15,
		RearWheelRadius = 15,
		
		PassengerSeats = {
			{
				pos = Vector(-8,20,18),
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(38,18,18),  -- pos = Vector(38,20,20),
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(38,-18,18),
				ang = Angle(0,90,0)
			},
		},
		
		FrontHeight = 10,
		FrontConstant = 25000,
		FrontDamping = 2500,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 25000,
		RearDamping = 2500,
		RearRelativeDamping = 5000,
		
		--[[
	    FrontHeight = 10,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		]]
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 4,
		
		MaxGrip = 60,   -- 60
		Efficiency = 1.25,  -- 1.25,
		GripOffset = -2,  -- -14 -2
		BrakePower = 45,
		BulletProofTires = true,
		
		IdleRPM = 900,
		LimitRPM = 6200,  -- 5500,  -- 135-200 КМ/Ч  -- 3500 
		PeakTorque = 65,  -- 40 -- 60
		PowerbandStart = 750,  -- 1000, 750
		PowerbandEnd = 5500, -- 4500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(62,45,40),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 150, -- 150
		
		PowerBias = 0,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		ForceTransmission = 1,  -- 1

		DifferentialGear = 0.2,
		Gears =  {-0.1,0,0.1,0.2,0.3,0.4}  --{-0.09,0,0.09,0.18,0.28,0.35,0.5}
	}
}
list.Set( "simfphys_vehicles", "avx_mercedes_Black_Edition", V )