
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_uaz_3151.lua ~

]]

AddCSLuaFile()
 
local light_table = {
 
 
	
	Headlight_sprites = { 
		{pos = Vector(88,25,35),material = "sprites/light_ignorez",size = 45},
		{pos = Vector(88,-25,35),material = "sprites/light_ignorez",size = 45},
	},
	Headlamp_sprites = { 
		{pos = Vector(88,25,35),material = "sprites/light_ignorez",size = 75},
		{pos = Vector(88,-25,35),material = "sprites/light_ignorez",size = 75},
	},
	FogLight_sprites = {
		{pos = Vector(87,28,26),material = "sprites/light_ignorez",size = 30},
		{pos = Vector(87,-28,26),material = "sprites/light_ignorez",size = 30},
		
		{pos = Vector(41,37,53),material = "sprites/light_ignorez",size = 30,OnBodyGroups={[12]={0}}}, 
	    {pos = Vector(41,-37,53),material = "sprites/light_ignorez",size = 30,OnBodyGroups={[11]={0}}}, 
	},
	
	Rearlight_sprites = {
		Vector(-73,33,28),
		Vector(-73,-33,28),
	},
	Brakelight_sprites = {
		{pos = Vector(-72.7,33,25),  material = "sprites/light_ignorez",size = 35}, 
		{pos = Vector(-72.7,-33,25),  material = "sprites/light_ignorez",size = 35}, 
	},
	--Reverselight_sprites = {
	--	Vector(-70,29,26.5),
	--	Vector(-70,-29,26.5),
	--},
	
        Turnsignal_sprites = { -- поворотники
		Left = { -- левый		
			    {pos = Vector(87,28,24),  material = "sprites/light_ignorez",size = 25}, 
			    {pos = Vector(42.5,35,42),    material = "sprites/light_ignorez",size = 25}, 
				
			    {pos = Vector(-73.3,33,31),   material = "sprites/light_ignorez",size = 25}, 
	},
		Right = { -- правый
		 	    {pos = Vector(87,-28,24),      material = "sprites/light_ignorez",size = 25}, 
			    {pos = Vector(42.5,-35,42),    material = "sprites/light_ignorez",size = 25}, 
				
			    {pos = Vector(-73.3,-33,31),   material = "sprites/light_ignorez",size = 25}, 
 
		},
	} 
} 
list.Set( "simfphys_lights", "simfphys_uaz_3151", light_table)

local V = {
	Name = "Уаз 3151", -- название машины в меню 
	Model = "models/vehicles/uaz_3151/uaz_3151c.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 1650,
		
		LightsTable = "simfphys_uaz_3151", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(65,-35,11),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(65,35,11),		-- position front right wheel
		CustomWheelPosRL = Vector(-44,-35,10),	-- rear left
		CustomWheelPosRR = Vector(-44,35,10),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
		 
		OnTick = function(ent)

			if ent:GetLightsEnabled() then
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co_on")
			else
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co")
			end


			if ent:GetGear() == 2 then
                ent:SetBodygroup( 1, 5 )
            elseif ent:GetGear() == 1 then
                ent:SetBodygroup( 1, 6 )  -- назад
				
				elseif ent:GetGear() == 3 then
                ent:SetBodygroup( 1, 0 )  -- 1 передача
				
				elseif ent:GetGear() == 4 then
                ent:SetBodygroup( 1, 1 )  -- 2 передача
				
				elseif ent:GetGear() == 5 then
                ent:SetBodygroup( 1, 2 )  -- 3 передача
				
				elseif ent:GetGear() == 6 then
                ent:SetBodygroup( 1, 3 )  -- 4 передача
				
				elseif ent:GetGear() == 7 then
                ent:SetBodygroup( 1, 4 )  -- 5 передача
            end
			
        end,
		
		EnginePos = Vector(75,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(2,-18,55),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
        PassengerSeats = {
			{
				pos = Vector(7,-18,23),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-28,22,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,0,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,-22,26),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-55,24,26),
				ang = Angle(0,180,0)
			},
		    {
				pos = Vector(-55,-24,26),
				ang = Angle(0,0,0)
			},
		},
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
		
		OnSpawn = function(ent)

           --ent:SetSkin(4) -- Зимний цвет


		   ent:SetBodygroup(11,math.random(0,1)) -- Прав. Противотуманка
           ent:SetBodygroup(12,math.random(0,1)) -- Лев.  Противотуманка
           ent:SetBodygroup(13,math.random(0,1)) -- Хз что это
           --ent:SetBodygroup(14,math.random(0,1)) -- Насадки на Фары
           ent:SetBodygroup(15,math.random(0,1)) -- Запаска

        end,


		GibModels = {
			"models/vehicles/uaz_3151/uaz_destroyed.mdl",
			"models/vehicles/uaz_3151/uaz_destroyed_hood.mdl",
		},
		
		SpeedoMax = 37, -- какая максималка на спидометре(может работать криво) 70
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 10, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 3000,
		FrontRelativeDamping = 3000,

		RearHeight = 10, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 1000, -- 3000
		RearRelativeDamping = 3000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 1.75, -- 2
		
		MaxGrip = 50, -- 30 50
		Efficiency = 1,
		GripOffset = -14,  -- -14 -2
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 2750, -- 2600 
		PeakTorque = 55, -- 55
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.45, -- 45
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_3151", V )
 
 
 
//////////////////////////////////////////////////////////////////////////////////////////////////


local V = {
	Name = "Уаз 3151 (Без Крыши)", -- название машины в меню 
	Model = "models/vehicles/uaz_3151/uaz_3151o.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 1650,
		
		LightsTable = "simfphys_uaz_3151", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(65,-35,1),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(65,35,1),		-- position front right wheel
		CustomWheelPosRL = Vector(-44,-35,0),	-- rear left
		CustomWheelPosRR = Vector(-44,35,0),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
		 
		OnTick = function(ent)

			if ent:GetLightsEnabled() then
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co_on")
			else
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co")
			end

			if ent:GetGear() == 2 then
                ent:SetBodygroup( 1, 5 )
            elseif ent:GetGear() == 1 then
                ent:SetBodygroup( 1, 6 )  -- назад
				
				elseif ent:GetGear() == 3 then
                ent:SetBodygroup( 1, 0 )  -- 1 передача
				
				elseif ent:GetGear() == 4 then
                ent:SetBodygroup( 1, 1 )  -- 2 передача
				
				elseif ent:GetGear() == 5 then
                ent:SetBodygroup( 1, 2 )  -- 3 передача
				
				elseif ent:GetGear() == 6 then
                ent:SetBodygroup( 1, 3 )  -- 4 передача
				
				elseif ent:GetGear() == 7 then
                ent:SetBodygroup( 1, 4 )  -- 5 передача
            end
			
        end,
		
		
		OnSpawn = function(ent)
		   
		  -- ent:SetSkin(4) -- Зимний цвет
   
		   ent:SetBodygroup(11,math.random(0,1)) -- Прав. Противотуманка
           ent:SetBodygroup(12,math.random(0,1)) -- Лев.  Противотуманка
           ent:SetBodygroup(13,math.random(0,1)) -- Хз что это
           --ent:SetBodygroup(14,math.random(0,1)) -- Насадки на Фары
           ent:SetBodygroup(15,math.random(0,1)) -- Запаска
		end,

		GibModels = {
			"models/vehicles/uaz_3151/uaz_destroyed.mdl",
			"models/vehicles/uaz_3151/uaz_destroyed_hood.mdl",
		},
		
		
		EnginePos = Vector(75,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(2,-18,55),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
         PassengerSeats = {
			{
				pos = Vector(7,-18,23),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-28,22,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,0,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,-22,26),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-55,24,26),
				ang = Angle(0,180,0)
			},
		    {
				pos = Vector(-55,-24,26),
				ang = Angle(0,0,0)
			},
		},
		
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,-25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			Skin=1,	
			-- SetBodygroup( 2, 2 )  -- ДШУ
		},
		
		SpeedoMax = 37, -- какая максималка на спидометре(может работать криво) 70
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 5,
		FrontConstant = 20000,
		FrontDamping = 1000,
		FrontRelativeDamping = 500,
		
		RearHeight = 3,
		RearConstant = 20000,
		RearDamping = 1000,
		RearRelativeDamping = 500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 2, -- 2
		
		MaxGrip = 60, -- 30 50
		Efficiency = 1,
		GripOffset = -7,  -- -14 -2
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 2750, -- 2600 
		PeakTorque = 55, -- 55
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		DifferentialGear = 0.45, -- 45
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_3151_bk", V )


//////////////////////////////////////////////////////////////////////////////////////////////////


local V = {
	Name = "Уаз 3151 с ДШК", -- название машины в меню 
	Model = "models/vehicles/uaz_3151/uaz_3151o.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 1650,
		
		LightsTable = "simfphys_uaz_3151", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(65,-35,1),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(65,35,1),		-- position front right wheel
		CustomWheelPosRL = Vector(-44,-35,0),	-- rear left
		CustomWheelPosRR = Vector(-44,35,0),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
		 
		OnTick = function(ent)

			if ent:GetLightsEnabled() then
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co_on")
			else
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co")
			end

			if ent:GetGear() == 2 then
                ent:SetBodygroup( 1, 5 )
            elseif ent:GetGear() == 1 then
                ent:SetBodygroup( 1, 6 )  -- назад
				
				elseif ent:GetGear() == 3 then
                ent:SetBodygroup( 1, 0 )  -- 1 передача
				
				elseif ent:GetGear() == 4 then
                ent:SetBodygroup( 1, 1 )  -- 2 передача
				
				elseif ent:GetGear() == 5 then
                ent:SetBodygroup( 1, 2 )  -- 3 передача
				
				elseif ent:GetGear() == 6 then
                ent:SetBodygroup( 1, 3 )  -- 4 передача
				
				elseif ent:GetGear() == 7 then
                ent:SetBodygroup( 1, 4 )  -- 5 передача
            end
			
        end,
		

		OnSpawn = function(ent)
           
		   --ent:SetSkin(4) -- Зимний цвет

		   ent:SetBodygroup( 3, 2 ) 
		   ent:SetBodygroup( 4, 1 )  
		      
		   ent:SetBodygroup(11,math.random(0,1)) -- Прав. Противотуманка
           ent:SetBodygroup(12,math.random(0,1)) -- Лев.  Противотуманка
           ent:SetBodygroup(13,math.random(0,1)) -- Хз что это
           --ent:SetBodygroup(14,math.random(0,1)) -- Насадки на Фары
           ent:SetBodygroup(15,math.random(0,1)) -- Запаска

        end,

        GibModels = {
			"models/vehicles/uaz_3151/uaz_destroyed.mdl",
			"models/vehicles/uaz_3151/uaz_destroyed_hood.mdl",
		},
		
		
		EnginePos = Vector(75,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(2,-18,55),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
        PassengerSeats = {
		
			{
				pos = Vector(-45,0,65),
				ang = Angle(0,270,0)
			},

 
			{
				pos = Vector(7,-18,23),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-55,24,26),
				ang = Angle(0,180,0)
			},
		    {
				pos = Vector(-55,-24,26),
				ang = Angle(0,0,0)
			},
		},
		
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,-25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			Skin=1,	
			-- SetBodygroup( 2, 2 )  -- ДШУ
		},
		
		SpeedoMax = 37, -- какая максималка на спидометре(может работать криво) 70
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 5,
		FrontConstant = 20000,
		FrontDamping = 1000,
		FrontRelativeDamping = 500,
		
		RearHeight = 3,
		RearConstant = 20000,
		RearDamping = 1000,
		RearRelativeDamping = 500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 2, -- 2
		
		MaxGrip = 60, -- 30 50
		Efficiency = 1,
		GripOffset = -7,  -- -14 -2
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 2750, -- 2600 
		PeakTorque = 55, -- 55
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.45, -- 45
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_3151_dshk", V )

---------------------------

local V = {
	Name = "Уаз 3151 с АГС", -- название машины в меню 
	Model = "models/vehicles/uaz_3151/uaz_3151o.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 1650,
		
		LightsTable = "simfphys_uaz_3151", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(65,-35,1),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(65,35,1),		-- position front right wheel
		CustomWheelPosRL = Vector(-44,-35,0),	-- rear left
		CustomWheelPosRR = Vector(-44,35,0),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
		 
		OnTick = function(ent)

			if ent:GetLightsEnabled() then
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co_on")
			else
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co")
			end

			if ent:GetGear() == 2 then
                ent:SetBodygroup( 1, 5 )
            elseif ent:GetGear() == 1 then
                ent:SetBodygroup( 1, 6 )  -- назад
				
				elseif ent:GetGear() == 3 then
                ent:SetBodygroup( 1, 0 )  -- 1 передача
				
				elseif ent:GetGear() == 4 then
                ent:SetBodygroup( 1, 1 )  -- 2 передача
				
				elseif ent:GetGear() == 5 then
                ent:SetBodygroup( 1, 2 )  -- 3 передача
				
				elseif ent:GetGear() == 6 then
                ent:SetBodygroup( 1, 3 )  -- 4 передача
				
				elseif ent:GetGear() == 7 then
                ent:SetBodygroup( 1, 4 )  -- 5 передача
            end
			
        end,
		

		OnSpawn = function(ent)
          
           --ent:SetSkin(4) -- Зимний цвет
		  
		   ent:SetBodygroup( 3, 1 )  
		   ent:SetBodygroup( 4, 1 )  
		      
		   ent:SetBodygroup(11,math.random(0,1)) -- Прав. Противотуманка
           ent:SetBodygroup(12,math.random(0,1)) -- Лев.  Противотуманка
           ent:SetBodygroup(13,math.random(0,1)) -- Хз что это
           --ent:SetBodygroup(14,math.random(0,1)) -- Насадки на Фары
           ent:SetBodygroup(15,math.random(0,1)) -- Запаска

        end,

    	GibModels = {
			"models/vehicles/uaz_3151/uaz_destroyed.mdl",
			"models/vehicles/uaz_3151/uaz_destroyed_hood.mdl",
		},    
		
		
		EnginePos = Vector(75,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(2,-18,55),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
        PassengerSeats = {
		
			{
				pos = Vector(-45,0,65),
				ang = Angle(0,270,0)
			},

 
			{
				pos = Vector(7,-18,23),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-55,24,26),
				ang = Angle(0,180,0)
			},
		    {
				pos = Vector(-55,-24,26),
				ang = Angle(0,0,0)
			},
		},
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,-25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			Skin=1,	
			-- SetBodygroup( 2, 2 )  -- ДШУ
		},
		
		SpeedoMax = 37, -- какая максималка на спидометре(может работать криво) 70
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 5,
		FrontConstant = 20000,
		FrontDamping = 1000,
		FrontRelativeDamping = 500,
		
		RearHeight = 3,
		RearConstant = 20000,
		RearDamping = 1000,
		RearRelativeDamping = 500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 2, -- 2
		
		MaxGrip = 60, -- 30 50
		Efficiency = 1,
		GripOffset = -7,  -- -14 -2
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 2750, -- 2600 
		PeakTorque = 55, -- 55
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.45, -- 45
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_3151_ags", V )

---------------------------

local V = {
	Name = "Уаз 3151 с СПГ", -- название машины в меню 
	Model = "models/vehicles/uaz_3151/uaz_3151o.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 1650,
		
		LightsTable = "simfphys_uaz_3151", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(65,-35,1),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(65,35,1),		-- position front right wheel
		CustomWheelPosRL = Vector(-44,-35,0),	-- rear left
		CustomWheelPosRR = Vector(-44,35,0),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
		 
		OnTick = function(ent)

			if ent:GetLightsEnabled() then
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co_on")
			else
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co")
			end

			if ent:GetGear() == 2 then
                ent:SetBodygroup( 1, 5 )
            elseif ent:GetGear() == 1 then
                ent:SetBodygroup( 1, 6 )  -- назад
				
				elseif ent:GetGear() == 3 then
                ent:SetBodygroup( 1, 0 )  -- 1 передача
				
				elseif ent:GetGear() == 4 then
                ent:SetBodygroup( 1, 1 )  -- 2 передача
				
				elseif ent:GetGear() == 5 then
                ent:SetBodygroup( 1, 2 )  -- 3 передача
				
				elseif ent:GetGear() == 6 then
                ent:SetBodygroup( 1, 3 )  -- 4 передача
				
				elseif ent:GetGear() == 7 then
                ent:SetBodygroup( 1, 4 )  -- 5 передача
            end
			
        end,
		

		OnSpawn = function(ent)
 
        
        --ent:SetSkin(4) -- Зимний цвет
		  
		   ent:SetBodygroup( 3, 3 )  
		   ent:SetBodygroup( 4, 1 )  
		      
		   ent:SetBodygroup(11,math.random(0,1)) -- Прав. Противотуманка
           ent:SetBodygroup(12,math.random(0,1)) -- Лев.  Противотуманка
           ent:SetBodygroup(13,math.random(0,1)) -- Хз что это
           --ent:SetBodygroup(14,math.random(0,1)) -- Насадки на Фары
           ent:SetBodygroup(15,math.random(0,1)) -- Запаска

        end,
		
        GibModels = {
			"models/vehicles/uaz_3151/uaz_destroyed.mdl",
			"models/vehicles/uaz_3151/uaz_destroyed_hood.mdl",
		},


		EnginePos = Vector(75,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(2,-18,55),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
         PassengerSeats = {
 
			{
				pos = Vector(7,-18,23),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-55,24,26),
				ang = Angle(0,180,0)
			},
		    {
				pos = Vector(-55,-24,26),
				ang = Angle(0,0,0)
			},
		},
		
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,-25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			Skin=1,	
			-- SetBodygroup( 2, 2 )  -- ДШУ
		},
		
		SpeedoMax = 37, -- какая максималка на спидометре(может работать криво) 70
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 5,
		FrontConstant = 20000,
		FrontDamping = 1000,
		FrontRelativeDamping = 500,
		
		RearHeight = 3,
		RearConstant = 20000,
		RearDamping = 1000,
		RearRelativeDamping = 500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 2, -- 2
		
		MaxGrip = 60, -- 30 50
		Efficiency = 1,
		GripOffset = -7,  -- -14 -2
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 2750, -- 2600 
		PeakTorque = 55, -- 55
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.45, -- 45
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_3151_spg", V )

 



///////////////////////////////////////////////////


local V = {
	Name = "Уаз 3151", -- название машины в меню 
	Model = "models/vehicles/uaz_3151/uaz_3151c_dux.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☪Душманский☪", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 1650,
		
		LightsTable = "simfphys_uaz_3151", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(65,-35,11),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(65,35,11),		-- position front right wheel
		CustomWheelPosRL = Vector(-44,-35,10),	-- rear left
		CustomWheelPosRR = Vector(-44,35,10),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
		 
		OnTick = function(ent)

			if ent:GetLightsEnabled() then
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co_on")
			else
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co")
			end


			if ent:GetGear() == 2 then
                ent:SetBodygroup( 1, 5 )
            elseif ent:GetGear() == 1 then
                ent:SetBodygroup( 1, 6 )  -- назад
				
				elseif ent:GetGear() == 3 then
                ent:SetBodygroup( 1, 0 )  -- 1 передача
				
				elseif ent:GetGear() == 4 then
                ent:SetBodygroup( 1, 1 )  -- 2 передача
				
				elseif ent:GetGear() == 5 then
                ent:SetBodygroup( 1, 2 )  -- 3 передача
				
				elseif ent:GetGear() == 6 then
                ent:SetBodygroup( 1, 3 )  -- 4 передача
				
				elseif ent:GetGear() == 7 then
                ent:SetBodygroup( 1, 4 )  -- 5 передача
            end
			
        end,
		
		GibModels = {
			"models/vehicles/uaz_3151/uaz_destroyed.mdl",
			"models/vehicles/uaz_3151/uaz_destroyed_hood.mdl",
			
			--"models/vehicles/uaz_3151/uaz_3151_wheel.mdl", "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",
			--"models/vehicles/uaz_3151/uaz_3151_wheel.mdl", "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",
			
		},
		
		EnginePos = Vector(75,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(2,-18,55),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
        PassengerSeats = {
			{
				pos = Vector(7,-18,23),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-28,22,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,0,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,-22,26),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-55,24,26),
				ang = Angle(0,180,0)
			},
		    {
				pos = Vector(-55,-24,26),
				ang = Angle(0,0,0)
			},
		},
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
		
		OnSpawn = function(ent)

           --ent:SetSkin(4) -- Зимний цвет


		   ent:SetBodygroup(11,math.random(0,1)) -- Прав. Противотуманка
           ent:SetBodygroup(12,math.random(0,1)) -- Лев.  Противотуманка
           ent:SetBodygroup(13,math.random(0,1)) -- Хз что это
           --ent:SetBodygroup(14,math.random(0,1)) -- Насадки на Фары
           ent:SetBodygroup(15,math.random(0,1)) -- Запаска

        end,
		
		SpeedoMax = 37, -- какая максималка на спидометре(может работать криво) 70
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 10, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 3000,
		FrontRelativeDamping = 3000,

		RearHeight = 10, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 1000, -- 3000
		RearRelativeDamping = 3000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 1.75, -- 2
		
		MaxGrip = 50, -- 30 50
		Efficiency = 1,
		GripOffset = -14,  -- -14 -2
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 2750, -- 2600 
		PeakTorque = 55, -- 55
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.45, -- 45
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_3151c_dux", V ) 

local V = {
	Name = "Уаз 3151 (Без Крыши)", -- название машины в меню 
	Model = "models/vehicles/uaz_3151/uaz_3151o_dux.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☪Душманский☪", -- категория в которой будет машина
    SpawnAngleOffset = 90,
	Members = {
		Mass = 1650,
		
		LightsTable = "simfphys_uaz_3151", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 17,--радиус переднего колеса
		RearWheelRadius = 17,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
        CustomSteerAngle = 20,	
		
		CustomWheelModel = "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(65,-35,11),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(65,35,11),		-- position front right wheel
		CustomWheelPosRL = Vector(-44,-35,10),	-- rear left
		CustomWheelPosRR = Vector(-44,35,10),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
		 
		OnTick = function(ent)

			if ent:GetLightsEnabled() then
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co_on")
			else
				ent:SetSubMaterial(2, "models/vehicles/UAZ_3151/uaz_interier_co")
			end


			if ent:GetGear() == 2 then
                ent:SetBodygroup( 1, 5 )
            elseif ent:GetGear() == 1 then
                ent:SetBodygroup( 1, 6 )  -- назад
				
				elseif ent:GetGear() == 3 then
                ent:SetBodygroup( 1, 0 )  -- 1 передача
				
				elseif ent:GetGear() == 4 then
                ent:SetBodygroup( 1, 1 )  -- 2 передача
				
				elseif ent:GetGear() == 5 then
                ent:SetBodygroup( 1, 2 )  -- 3 передача
				
				elseif ent:GetGear() == 6 then
                ent:SetBodygroup( 1, 3 )  -- 4 передача
				
				elseif ent:GetGear() == 7 then
                ent:SetBodygroup( 1, 4 )  -- 5 передача
            end
			
        end,
		
		GibModels = {
			"models/vehicles/uaz_3151/uaz_destroyed.mdl",
			"models/vehicles/uaz_3151/uaz_destroyed_hood.mdl",
			
			--"models/vehicles/uaz_3151/uaz_3151_wheel.mdl", "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",
			--"models/vehicles/uaz_3151/uaz_3151_wheel.mdl", "models/vehicles/uaz_3151/uaz_3151_wheel.mdl",
			
		},
		
		EnginePos = Vector(75,0,40),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(2,-18,55),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
        PassengerSeats = {
			{
				pos = Vector(7,-18,23),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-28,22,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,0,26),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(-28,-22,26),
				ang = Angle(0,270,0)
			},
			
			
		    {
				pos = Vector(-55,24,26),
				ang = Angle(0,180,0)
			},
		    {
				pos = Vector(-55,-24,26),
				ang = Angle(0,0,0)
			},
		},
		
	 
		
		ExhaustPositions = {
			{
				pos = Vector(-71,25,20),
				ang = Angle(90,165,0)
			},
		},
		
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
		
		OnSpawn = function(ent)

           --ent:SetSkin(4) -- Зимний цвет


		   ent:SetBodygroup(11,math.random(0,1)) -- Прав. Противотуманка
           ent:SetBodygroup(12,math.random(0,1)) -- Лев.  Противотуманка
           ent:SetBodygroup(13,math.random(0,1)) -- Хз что это
           --ent:SetBodygroup(14,math.random(0,1)) -- Насадки на Фары
           ent:SetBodygroup(15,math.random(0,1)) -- Запаска

        end,
		
		SpeedoMax = 37, -- какая максималка на спидометре(может работать криво) 70
		
		
		FuelFillPos = Vector(2,-37,26), 
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 78, -- 72
	
	    FrontHeight = 10, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 3000,
		FrontRelativeDamping = 3000,

		RearHeight = 10, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 1000, -- 3000
		RearRelativeDamping = 3000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 1.75, -- 2
		
		MaxGrip = 50, -- 30 50
		Efficiency = 1,
		GripOffset = -14,  -- -14 -2
		BrakePower = 30, -- сила торможения
		
		IdleRPM = 750,
		LimitRPM = 2750, -- 2600 
		PeakTorque = 55, -- 55
		PowerbandStart = 600,
		PowerbandEnd = 2200,
		Turbocharged = false,
		Supercharged = false,
		
		PowerBias = 0, -- -1
		
		EngineSoundPreset = -1,
		
		--[[snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.5,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.6,]]
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "vehicles/sim_fphys_uaz/low.wav",
		snd_low_pitch = 1.2,
		
		snd_mid = "vehicles/sim_fphys_uaz/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_uaz/second.wav",
		snd_mid_pitch = 1.2,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.45, -- 45
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_uaz_3151o_dux", V )
//////////////////////////////////////////////////////////////////////////////////////////////////
 