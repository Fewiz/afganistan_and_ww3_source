
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_kamaz.lua ~

]]


AddCSLuaFile()
--[[
 By
   NFS-NIK
]]
local light_table = {
 
  ModernLights = false, -- грубо говоря, ксенон или старые фары. True - ксенон, false - старые
	
	Headlight_sprites = { 
		{pos = Vector(152,36,47),size = 75},
		{pos = Vector(152,-36,47),size = 75},
	},
	Headlamp_sprites = { 
		{pos = Vector(152,36,47),material = "sprites/light_ignorez",size =  75},
		{pos = Vector(152,-36,47),material = "sprites/light_ignorez",size = 75},
	},
	FogLight_sprites = {
		{pos = Vector(161,37.4,29.5),  material = "sprites/light_ignorez",size = 30}, 
		{pos = Vector(161,-37.4,29.5),  material = "sprites/light_ignorez",size = 30}, 
		
		{pos = Vector(127,5.5,110),  material = "sprites/light_ignorez",size = 30,color=Color(255,155,0)}, 
		{pos = Vector(127,0,110),  material = "sprites/light_ignorez",size = 30,color=Color(255,155,0)}, 
		{pos = Vector(127,-5.5,110),  material = "sprites/light_ignorez",size = 30,color=Color(255,155,0)}, 
		
		{pos = Vector(135,54,104),  material = "sprites/light_ignorez",size = 60, OnBodyGroups = { [7] = {0} }},
	},
	
	Rearlight_sprites = {
    {pos = Vector(-168,33,31),  material = "sprites/light_ignorez",size = 15}, 
		{pos = Vector(-168,-33,31),  material = "sprites/light_ignorez",size = 15}, 
	},
	Brakelight_sprites = {
		{pos = Vector(-168,30,31),  material = "sprites/light_ignorez",size = 35}, 
		{pos = Vector(-168,-30,31),  material = "sprites/light_ignorez",size = 35}, 

		{pos = Vector(140.4,12,75.1),  material = "sprites/light_ignorez",size = 5, color=Color(200,25,0)}, -- Салон
	},
	--Reverselight_sprites = {
	--	Vector(-70,29,26.5),
	--	Vector(-70,-29,26.5),
	--},
	
  Turnsignal_sprites = { -- поворотники
		Left = { -- левый		
			    {pos = Vector(161,37.4,32),  material = "sprites/light_ignorez",size = 30}, 
			    {pos = Vector(149,50.5,59.5),    material = "sprites/light_ignorez",size = 30}, 

			    {pos = Vector(140.4,17.25,75.1),  material = "sprites/light_ignorez",size = 5, color=Color(25,175,0)}, -- Салон
				
			    {pos = Vector(-168,36,30.75),  material = "sprites/light_ignorez",size = 35}, 
		},
		Right = { -- правый
		 	    {pos = Vector(161,-37.4,32),  material = "sprites/light_ignorez",size = 30}, 
			    {pos = Vector(149,-50.5,59.5),    material = "sprites/light_ignorez",size = 30}, 

			    {pos = Vector(140.4,17.25,75.1),  material = "sprites/light_ignorez",size = 5, color=Color(25,175,0)}, -- Салон
				
			    {pos = Vector(-168,-36,30.75),  material = "sprites/light_ignorez",size = 35}, 
 
		},
	} 

} 
list.Set( "simfphys_lights", "simfphys_kamaz1", light_table)

local V = {
	Name = "Камаз", -- название машины в меню 
	Model = "models/vehicles/kamaz/zamak/kamaz1.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭",
	SpawnAngleOffset = 90,
	Members = {
		Mass = 7500,
		MaxHealth = 2700, 

		SpawnOffset = Vector(0,0,80),

		LightsTable = "simfphys_kamaz1", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 25,--радиус переднего колеса
		RearWheelRadius = 24.5,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
		CustomSteerAngle = 38,	 -- 20
	
		CustomWheelModel = "models/vehicles/kamaz/zamak/kamaz_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(100,-44,18),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(100,44,18),		-- position front right wheel
		
		CustomWheelPosML=  Vector(-45,-44,20),
		CustomWheelPosMR = Vector(-45,44,20),
		
		CustomWheelPosRL = Vector(-105,-44,20),	-- rear left
		CustomWheelPosRR = Vector(-105,44,20),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
 
		
		EnginePos = Vector(155,0,45),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(105,-26,84),
		SeatPitch = 0,
		SeatYaw = 90,


		PassengerSeats = {
		
			{
				pos = Vector(109,-5,53),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(109,-30,53),
				ang = Angle(0,270,0)
			},
			
            -- Левая перед 
			{
				pos = Vector(22+4,42,65),
				ang = Angle(0,180,0)
			},
			
		  {
				pos = Vector(0+2,42,65),
				ang = Angle(0,180,0)
			},
			
			{
				pos = Vector(-22,42,65),
				ang = Angle(0,180,0)
			},
			
			{
				pos = Vector(-44-2,42,65),
				ang = Angle(0,180,0)
			},
			-- Правая перед
			--------------------
			{
				pos = Vector(22+4,-42,65),
				ang = Angle(0,0,0)
			},
			
		    {
				pos = Vector(0+2,-42,65),
				ang = Angle(0,0,0)
			},
			
			{
				pos = Vector(-22,-42,65),
				ang = Angle(0,0,0)
			},
			
			{
				pos = Vector(-44-2,-42,65),
				ang = Angle(0,0,0)
			},
			-- Левая зад 
			{
				pos = Vector(-88+4,42,65),
				ang = Angle(0,180,0)
			},
			
		    {
				pos = Vector(-110+2,42,65),
				ang = Angle(0,180,0)
			},
			
			{
				pos = Vector(-132,42,65),
				ang = Angle(0,180,0)
			},
			
			{
				pos = Vector(-154-2,42,65),
				ang = Angle(0,180,0)
			},
			-- Правая зад 
			{
				pos = Vector(-88+4,-42,65),
				ang = Angle(0,0,0)
			},
			
		    {
				pos = Vector(-110+2,-42,65),
				ang = Angle(0,0,0)
			},
			
			{
				pos = Vector(-132,-42,65),
				ang = Angle(0,0,0)
			},
			
			{
				pos = Vector(-154-2,-42,65),
				ang = Angle(0,0,0)
			},
			
			
		},
		
		ExhaustPositions = {

			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},

		},
		
	 
	 
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
		
		OnSpawn = function(ent)
		--ent:SetSkin(2)
		  --ent:SetBodygroups(0,0,1) 
		  ent:SetBodygroup( 3, math.random(0,2) ) -- Задняя часть
		   
		  ent:SetBodygroup( 5, math.random(0,1) ) -- Окна
		  ent:SetBodygroup( 6, math.random(0,1) ) -- Окна
		   
		  ent:SetBodygroup( 7, math.random(0,1) ) -- Противотуманка
		   
		  ent:SetBodygroup( 9, 1 ) -- Огнетуш
		end,
		
		OnTick = function(v)
			if not v.temp then
				v.tacho = 0
				v.temp = 0
				v.realtemp = 0
				v.fuel = 0
				v.oil = 0
				v.gear = 0
				v.gas = 0
				v.brake = 0
				v.clutch = 0
			end
			
			--v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()/3.3333)/v:GetLimitRPM())
			v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()-100)/v:GetLimitRPM())
			v.speed = v:GetVelocity():Length()/900
			
			if v:EngineActive() then
				v.fuel = Lerp(0.05, v.fuel, v:GetFuel()/v:GetMaxFuel() )
				v.realtemp = Lerp(0.001, v.realtemp, 1-v:GetCurHealth()/v:GetMaxHealth()/2 )
				v.temp = Lerp(0.05, v.temp, v.realtemp)
				v.oil = Lerp(0.05, v.oil, v:GetCurHealth()/v:GetMaxHealth()/2+0.3 )
			else
				v.fuel = Lerp(0.05, v.fuel, 0 )
				v.realtemp = Lerp(0.001, v.realtemp, 0 )
				v.temp = Lerp(0.05, v.temp, 0)
				v.oil = Lerp(0.05, v.oil, 0 )
			end
			
			---
			
			v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			v.gas = Lerp(0.2, v.gas, v:GetThrottle())
			v.clutch = Lerp(0.2, v.clutch, v:GetClutch())
			if v:GetIsBraking() then
				v.brake = Lerp(0.2, v.brake, 1)
			else
				v.brake = Lerp(0.2, v.brake, 0)
			end
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_on")
			else
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_co")
			end
			
			v:SetPoseParameter("gas", v.gas)
			v:SetPoseParameter("brake", v.brake)
			v:SetPoseParameter("clutch", v.clutch)
			v:SetPoseParameter("tacho", v.tacho)
			v:SetPoseParameter("speedo", v.speed)
			v:SetPoseParameter("temp", v.temp )
			v:SetPoseParameter("oil", v.oil )
			v:SetPoseParameter("fuel", v.fuel )
			v:SetPoseParameter("shiftlever", v.gear )
			
		end,
		
		SpeedoMax = 0, -- какая максималка на спидометре(может работать криво)
		
		
		FuelFillPos = Vector(30,-44,40), 
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 175, -- 72 
	
		StrengthenSuspension = true, -- жесткая подвеска.

		FrontHeight = 18, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 4000,
		FrontRelativeDamping = 6000,

		RearHeight = 18, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 4000,
		RearRelativeDamping = 6000,

		FastSteeringAngle = 20,
		SteeringFadeFastSpeed = 1000,

		TurnSpeed = 2.5,

		MaxGrip = 120, -- 60 80
		Efficiency = 1,
		GripOffset = 2,
		BrakePower = 45, -- сила торможения

		IdleRPM = 450, -- мин. кол-во оборотов
		LimitRPM = 1500, -- 1350 макс. кол-во оборотов  -- 90км/ч. (При 1500 - 115км.ч. В реальност 5350 - до 100км.ч. 1400 - 110.  1240 - ровно 100.)
		Revlimiter = false, -- Если true - Когда стрелка спидометра доходит до красного обозначения, она не проходит дальше, если false - это игнорируется
		PeakTorque = 250, -- 120 крутящий момент 200 250
		PowerbandStart = 350, -- какие обороты на нейтральной передаче
		PowerbandEnd = 1200, -- 1200 ограничение по оборотам
		Turbocharged = false, -- турбо false = нет, true = да
		Supercharged = false, -- супер заряд
		Backfire = false, -- стреляющий выхлоп
		
		PowerBias = 0, --1
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/alfaromeo/alfaromeo_idle.wav",
		Sound_IdlePitch = 1.0, -- 0.7
		
		Sound_Mid = "simulated_vehicles/alfaromeo/alfaromeo_low.wav",
		Sound_MidPitch = 1, -- 0.7
		Sound_MidVolume = 1, -- 2 
		Sound_MidFadeOutRPMpercent = 37,		-- at wich percentage of limitrpm the sound fades out
		Sound_MidFadeOutRate = 0.56,                    --how fast it fades out   0 = instant       1 = never
		
		Sound_High = "simulated_vehicles/jeep/jeep_mid.wav",
		Sound_HighPitch = 1.0,
		Sound_HighVolume = 3.0, -- 9.0
		Sound_HighFadeInRPMpercent = 20,
		Sound_HighFadeInRate = 0.59,
		
		Sound_Throttle = "",		-- mutes the default throttle sound
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		DifferentialGear = 0.2,
		Gears = {-0.2,0,0.2,0.5,0.7,0.85,1} -- кол-во передач и "мощность"
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_kamaz", V )

--------------------------------------------------


local V = {
	Name = "Камаз технический", -- название машины в меню 
	Model = "models/vehicles/kamaz/zamak/kamaz.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭",
	SpawnAngleOffset = 90,
	Members = {
		Mass = 7500,
		MaxHealth = 2700, 

		SpawnOffset = Vector(0,0,80),

		LightsTable = "simfphys_kamaz1", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 25,--радиус переднего колеса
		RearWheelRadius = 24.5,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		BulletProofTires = true,
		CustomSteerAngle = 37, --	20 
		
		CustomWheelModel = "models/vehicles/kamaz/zamak/kamaz_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(100,-44,16),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(100,44,16 ),		-- position front right wheel
		
		CustomWheelPosML=  Vector(-45,-44,20),
		CustomWheelPosMR = Vector(-45,44,20),
		
		CustomWheelPosRL = Vector(-105,-44,20),	-- rear left
		CustomWheelPosRR = Vector(-105,44,20),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
 
		
		EnginePos = Vector(155,0,45),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(105,-26,84),
		SeatPitch = 0,
		SeatYaw = 90,
        
	   
		PassengerSeats = {
		
			{
				pos = Vector(109,-5,53),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(109,-30,53),
				ang = Angle(0,270,0)
			},
			
		},
		
	 
		
		ExhaustPositions = {

			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},

		},
		
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
		
		OnSpawn = function(ent)
		   --ent:SetBodygroups(0,0,1) 
		   ent:SetBodygroup(6,math.random(0,2)) -- Запаска
		   
		   ent:SetBodygroup(3,math.random(0,1)) -- Окна
		   ent:SetBodygroup(4,math.random(0,1)) -- Окна
		   
		   ent:SetBodygroup(5,math.random(0,1)) -- Противотуманка
		   
		   ent:SetBodygroup(7,1) -- Огнетуш
        end,
		
		OnTick = function(v)
			if not v.temp then
				v.tacho = 0
				v.temp = 0
				v.realtemp = 0
				v.fuel = 0
				v.oil = 0
				v.gear = 0
				v.gas = 0
				v.brake = 0
				v.clutch = 0
			end
			
			--v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()/3.3333)/v:GetLimitRPM())
			v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()-100)/v:GetLimitRPM())
			v.speed = v:GetVelocity():Length()/900
			
			if v:EngineActive() then
				v.fuel = Lerp(0.05, v.fuel, v:GetFuel()/v:GetMaxFuel() )
				v.realtemp = Lerp(0.001, v.realtemp, 1-v:GetCurHealth()/v:GetMaxHealth()/2 )
				v.temp = Lerp(0.05, v.temp, v.realtemp)
				v.oil = Lerp(0.05, v.oil, v:GetCurHealth()/v:GetMaxHealth()/2+0.3 )
			else
				v.fuel = Lerp(0.05, v.fuel, 0 )
				v.realtemp = Lerp(0.001, v.realtemp, 0 )
				v.temp = Lerp(0.05, v.temp, 0)
				v.oil = Lerp(0.05, v.oil, 0 )
			end
			
			---
			
			v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			v.gas = Lerp(0.2, v.gas, v:GetThrottle())
			v.clutch = Lerp(0.2, v.clutch, v:GetClutch())
			if v:GetIsBraking() then
				v.brake = Lerp(0.2, v.brake, 1)
			else
				v.brake = Lerp(0.2, v.brake, 0)
			end
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_on")
			else
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_co")
			end
			
			v:SetPoseParameter("gas", v.gas)
			v:SetPoseParameter("brake", v.brake)
			v:SetPoseParameter("clutch", v.clutch)
			v:SetPoseParameter("tacho", v.tacho)
			v:SetPoseParameter("speedo", v.speed)
			v:SetPoseParameter("temp", v.temp )
			v:SetPoseParameter("oil", v.oil )
			v:SetPoseParameter("fuel", v.fuel )
			v:SetPoseParameter("shiftlever", v.gear )
			
		end,
		
		SpeedoMax = 0, -- какая максималка на спидометре(может работать криво)
		
		FuelFillPos = Vector(30,-44,40), 
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 175, -- 72 
	
		StrengthenSuspension = true, -- жесткая подвеска.

		FrontHeight = 18, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 4000,
		FrontRelativeDamping = 6000,

		RearHeight = 18, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 4000,
		RearRelativeDamping = 6000,

		FastSteeringAngle = 20,
		SteeringFadeFastSpeed = 1000,

		TurnSpeed = 2.5,

		MaxGrip = 120, -- 60 80
		Efficiency = 1,
		GripOffset = 2,
		BrakePower = 45, -- сила торможения

		IdleRPM = 450, -- мин. кол-во оборотов
		LimitRPM = 1500, -- 1350 макс. кол-во оборотов  -- 90км/ч
		Revlimiter = false, -- Если true - Когда стрелка спидометра доходит до красного обозначения, она не проходит дальше, если false - это игнорируется
		PeakTorque = 250, -- 120 крутящий момент 200 250
		PowerbandStart = 350, -- какие обороты на нейтральной передаче
		PowerbandEnd = 1200, -- 1200 ограничение по оборотам
		Turbocharged = false, -- турбо false = нет, true = да
		Supercharged = false, -- супер заряд
		Backfire = false, -- стреляющий выхлоп
		
		PowerBias = 0, --1
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/alfaromeo/alfaromeo_idle.wav",
		Sound_IdlePitch = 1.0, -- 0.7
		
		Sound_Mid = "simulated_vehicles/alfaromeo/alfaromeo_low.wav",
		Sound_MidPitch = 1, -- 0.7
		Sound_MidVolume = 1, -- 2 
		Sound_MidFadeOutRPMpercent = 37,		-- at wich percentage of limitrpm the sound fades out
		Sound_MidFadeOutRate = 0.56,                    --how fast it fades out   0 = instant       1 = never
		
		Sound_High = "simulated_vehicles/jeep/jeep_mid.wav",
		Sound_HighPitch = 1.0,
		Sound_HighVolume = 3.0, -- 9.0
		Sound_HighFadeInRPMpercent = 20,
		Sound_HighFadeInRate = 0.59,
		
		Sound_Throttle = "",		-- mutes the default throttle sound
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		DifferentialGear = 0.2,
		Gears = {-0.2,0,0.2,0.5,0.7,0.85,1} -- кол-во передач и "мощность"
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_kamaz_kom", V )

local V = {
	Name = "Камаз бензовоз", -- название машины в меню 
	Model = "models/vehicles/kamaz/zamak/kamaz2.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭",
	SpawnAngleOffset = 90,
	Members = {
		Mass = 7500,
		MaxHealth = 512,  -- 2700

		SpawnOffset = Vector(0,0,80),

		LightsTable = "simfphys_kamaz1", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 25,--радиус переднего колеса
		RearWheelRadius = 24.5,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
		CustomSteerAngle = 38,	 -- 20
	
		CustomWheelModel = "models/vehicles/kamaz/zamak/kamaz_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(100,-44,18),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(100,44,18),		-- position front right wheel
		
		CustomWheelPosML=  Vector(-45,-44,20),
		CustomWheelPosMR = Vector(-45,44,20),
		
		CustomWheelPosRL = Vector(-105,-44,20),	-- rear left
		CustomWheelPosRR = Vector(-105,44,20),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
 
		
		EnginePos = Vector(155,0,45),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(105,-26,84),
		SeatPitch = 0,
		SeatYaw = 90,
        


 		OnDestroyed = function(ent)
			if IsValid( ent.Gib ) then
				--print(ent)
				local pos = ent:GetPos()
				--ParticleEffect( "microplane_midair_explosion", ent.Gib:GetPos(), ent.Gib:GetAngles(), nil ) -- Vector(-706,231,-150) ply:GetPos()
				local effectdata = EffectData()
				effectdata:SetStart(ent.Gib:GetPos())
				effectdata:SetOrigin(ent.Gib:GetPos())
				effectdata:SetScale(50)  -- 50
				
				--util.Effect("lfs_explosion", effectdata)  
				ParticleEffect("c4_explosion_air", ent.Gib:GetPos(),Angle(0,0,0),nil)
				--ParticleEffect("vj_medium_dust1", ent.Gib:GetPos(),Angle(0,0,0),nil)
				util.Effect( "vj_medium_explosion1", effectdata )

				util.BlastDamage(ent.Gib, ent.Gib, ent.Gib:GetPos(), 2500, 90)  

				rp.NotifyAll(1, 'Камаз бензовоз был уничтожен!')

			end 
		end,
		    
	   
    PassengerSeats = {
		
			{
				pos = Vector(109,-5,53),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(109,-30,53),
				ang = Angle(0,270,0)
			},
		 		
		},
		
	 
		
		ExhaustPositions = {

			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},

		},
		
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
		
		OnSpawn = function(ent)
           --ent:SetSkin(2)
		   --ent:SetBodygroups(0,0,1) 
		   ent:SetBodygroup( 3, math.random(0,2) ) -- Задняя часть
		   
		   ent:SetBodygroup( 5, math.random(0,1) ) -- Окна
		   ent:SetBodygroup( 6, math.random(0,1) ) -- Окна
		   
		   ent:SetBodygroup( 7, math.random(0,1) ) -- Противотуманка
		   
		   ent:SetBodygroup( 9, 1 ) -- Огнетуш
        end,
		
		OnTick = function(v)
			if not v.temp then
				v.tacho = 0
				v.temp = 0
				v.realtemp = 0
				v.fuel = 0
				v.oil = 0
				v.gear = 0
				v.gas = 0
				v.brake = 0
				v.clutch = 0
			end
			
			--v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()/3.3333)/v:GetLimitRPM())
			v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()-100)/v:GetLimitRPM())
			v.speed = v:GetVelocity():Length()/900
			
			if v:EngineActive() then
				v.fuel = Lerp(0.05, v.fuel, v:GetFuel()/v:GetMaxFuel() )
				v.realtemp = Lerp(0.001, v.realtemp, 1-v:GetCurHealth()/v:GetMaxHealth()/2 )
				v.temp = Lerp(0.05, v.temp, v.realtemp)
				v.oil = Lerp(0.05, v.oil, v:GetCurHealth()/v:GetMaxHealth()/2+0.3 )
			else
				v.fuel = Lerp(0.05, v.fuel, 0 )
				v.realtemp = Lerp(0.001, v.realtemp, 0 )
				v.temp = Lerp(0.05, v.temp, 0)
				v.oil = Lerp(0.05, v.oil, 0 )
			end
			
			---
			
			v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			v.gas = Lerp(0.2, v.gas, v:GetThrottle())
			v.clutch = Lerp(0.2, v.clutch, v:GetClutch())
			if v:GetIsBraking() then
				v.brake = Lerp(0.2, v.brake, 1)
			else
				v.brake = Lerp(0.2, v.brake, 0)
			end
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_on")
			else
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_co")
			end
			
			v:SetPoseParameter("gas", v.gas)
			v:SetPoseParameter("brake", v.brake)
			v:SetPoseParameter("clutch", v.clutch)
			v:SetPoseParameter("tacho", v.tacho)
			v:SetPoseParameter("speedo", v.speed)
			v:SetPoseParameter("temp", v.temp )
			v:SetPoseParameter("oil", v.oil )
			v:SetPoseParameter("fuel", v.fuel )
			v:SetPoseParameter("shiftlever", v.gear )
			
		end,
		
		SpeedoMax = 0, -- какая максималка на спидометре(может работать криво)
		
		
		FuelFillPos = Vector(30,-44,40), 
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 175, -- 72 
	
		StrengthenSuspension = true, -- жесткая подвеска.

		FrontHeight = 18, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 4000,
		FrontRelativeDamping = 6000,

		RearHeight = 18, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 4000,
		RearRelativeDamping = 6000,

		FastSteeringAngle = 20,
		SteeringFadeFastSpeed = 1000,

		TurnSpeed = 2.5,

		MaxGrip = 120, -- 60 80
		Efficiency = 1,
		GripOffset = 2,
		BrakePower = 45, -- сила торможения

		IdleRPM = 450, -- мин. кол-во оборотов
		LimitRPM = 1500, -- 1350 макс. кол-во оборотов  -- 90км/ч
		Revlimiter = false, -- Если true - Когда стрелка спидометра доходит до красного обозначения, она не проходит дальше, если false - это игнорируется
		PeakTorque = 250, -- 120 крутящий момент 200 250
		PowerbandStart = 350, -- какие обороты на нейтральной передаче
		PowerbandEnd = 1200, -- 1200 ограничение по оборотам
		Turbocharged = false, -- турбо false = нет, true = да
		Supercharged = false, -- супер заряд
		Backfire = false, -- стреляющий выхлоп
		
		PowerBias = 0, --1
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/alfaromeo/alfaromeo_idle.wav",
		Sound_IdlePitch = 1.0, -- 0.7
		
		Sound_Mid = "simulated_vehicles/alfaromeo/alfaromeo_low.wav",
		Sound_MidPitch = 1, -- 0.7
		Sound_MidVolume = 1, -- 2 
		Sound_MidFadeOutRPMpercent = 37,		-- at wich percentage of limitrpm the sound fades out
		Sound_MidFadeOutRate = 0.56,                    --how fast it fades out   0 = instant       1 = never
		
		Sound_High = "simulated_vehicles/jeep/jeep_mid.wav",
		Sound_HighPitch = 1.0,
		Sound_HighVolume = 3.0, -- 9.0
		Sound_HighFadeInRPMpercent = 20,
		Sound_HighFadeInRate = 0.59,
		
		Sound_Throttle = "",		-- mutes the default throttle sound
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		DifferentialGear = 0.2,
		Gears = {-0.2,0,0.2,0.5,0.7,0.85,1} -- кол-во передач и "мощность"
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_kamaz_fuel", V )

local V = {
	Name = "Камаз с боеприпасами", -- название машины в меню 
	Model = "models/vehicles/kamaz/zamak/kamaz3.mdl", -- модель машины (в вкладке дополнения и проп авто)
	Category = "☭Советский☭",
  SpawnAngleOffset = 90,
	Members = {
		Mass = 7500,
		MaxHealth = 1200,  -- 2700

		SpawnOffset = Vector(0,0,80),

		LightsTable = "simfphys_kamaz1", -- название light_table
   
		AirFriction = -30000,

		FrontWheelRadius = 25,--радиус переднего колеса
		RearWheelRadius = 24.5,--радиус заднего колеса
		
		CustomWheels = true,       	 -- You have to set this to "true" in order to define custom wheels
		CustomSuspensionTravel = 15,	--suspension travel limiter length
		
		CustomSteerAngle = 38,	 -- 20
	
		CustomWheelModel = "models/vehicles/kamaz/zamak/kamaz_wheel.mdl",	-- since we create our own wheels we have to define a model. It has to have a collission model
		--CustomWheelModel_R = "",			-- different model for rear wheels?
		CustomWheelPosFL = Vector(100,-44,18),		-- set the position of the front left wheel. 
		CustomWheelPosFR = Vector(100,44,18),		-- position front right wheel
		
		CustomWheelPosML=  Vector(-45,-44,20),
		CustomWheelPosMR = Vector(-45,44,20),
		
		CustomWheelPosRL = Vector(-105,-44,20),	-- rear left
		CustomWheelPosRR = Vector(-105,44,20),	-- rear right		NOTE: make sure the position actually matches the name. So FL is actually at the Front Left ,  FR Front Right, ...   if you do this wrong the wheels will spin in the wrong direction or the car will drive sideways/reverse
		CustomWheelAngleOffset = Angle(0,90,0),
 
		
		EnginePos = Vector(155,0,45),

		CustomMassCenter = Vector(0,0,0),		-- custom masscenter offset. The script creates a counter weight to make the masscenter exactly in the center of the wheels. However you can add an offset to this to create more body roll if you really have to...
		

		SeatOffset = Vector(105,-26,84),
		SeatPitch = 0,
		SeatYaw = 90,

		OnDestroyed = function(ent)
			if IsValid( ent.Gib ) then
				--print(ent)
				local pos = ent:GetPos()
				--ParticleEffect( "microplane_midair_explosion", ent.Gib:GetPos(), ent.Gib:GetAngles(), nil ) -- Vector(-706,231,-150) ply:GetPos()
				local effectdata = EffectData()
				effectdata:SetStart(ent.Gib:GetPos())
				effectdata:SetOrigin(ent.Gib:GetPos())
				effectdata:SetScale(50)  -- 50
				--util.Effect("lfs_explosion", effectdata)  
				ParticleEffect("c4_explosion_air", ent.Gib:GetPos(),Angle(0,0,0),nil)

				util.BlastDamage(ent.Gib, ent.Gib, ent.Gib:GetPos(), 2500, 90)  

				rp.NotifyAll(1, 'Камаз с боеприпасами был уничтожен!')

			end 
		end,
        
	   
    PassengerSeats = {
		
			{
				pos = Vector(109,-5,53),
				ang = Angle(0,270,0)
			},
			{
				pos = Vector(109,-30,53),
				ang = Angle(0,270,0)
			},
		
		},
		
	 
		
		ExhaustPositions = {

			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},
			{
				pos = Vector(10,-40,25),
				ang = Angle(75,-90,0)
			},

		},
		
		ModelInfo = {
			--Skin=1,	
			--Bodygroups = {math.random(0,1),0,math.random(0,1)},
		},
		--Bodygroups = {0,0,1},
		
		OnSpawn = function(ent)
           --ent:SetSkin(2)
		   --ent:SetBodygroups(0,0,1) 
		   ent:SetBodygroup( 3, math.random(0,2) ) -- Задняя часть
		   
		   ent:SetBodygroup( 5, math.random(0,1) ) -- Окна
		   ent:SetBodygroup( 6, math.random(0,1) ) -- Окна
		   
		   ent:SetBodygroup( 7, math.random(0,1) ) -- Противотуманка
		   
		   ent:SetBodygroup( 9, 1 ) -- Огнетуш
        end,
		
		OnTick = function(v)
			if not v.temp then
				v.tacho = 0
				v.temp = 0
				v.realtemp = 0
				v.fuel = 0
				v.oil = 0
				v.gear = 0
				v.gas = 0
				v.brake = 0
				v.clutch = 0
			end
			
			--v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()/3.3333)/v:GetLimitRPM())
			v.tacho = Lerp(0.2, v.tacho, (v:GetRPM()-100)/v:GetLimitRPM())
			v.speed = v:GetVelocity():Length()/900
			
			if v:EngineActive() then
				v.fuel = Lerp(0.05, v.fuel, v:GetFuel()/v:GetMaxFuel() )
				v.realtemp = Lerp(0.001, v.realtemp, 1-v:GetCurHealth()/v:GetMaxHealth()/2 )
				v.temp = Lerp(0.05, v.temp, v.realtemp)
				v.oil = Lerp(0.05, v.oil, v:GetCurHealth()/v:GetMaxHealth()/2+0.3 )
			else
				v.fuel = Lerp(0.05, v.fuel, 0 )
				v.realtemp = Lerp(0.001, v.realtemp, 0 )
				v.temp = Lerp(0.05, v.temp, 0)
				v.oil = Lerp(0.05, v.oil, 0 )
			end
			
			---
			
			v.gear = Lerp(0.07, v.gear, v:GetGear()-1)
			v.gas = Lerp(0.2, v.gas, v:GetThrottle())
			v.clutch = Lerp(0.2, v.clutch, v:GetClutch())
			if v:GetIsBraking() then
				v.brake = Lerp(0.2, v.brake, 1)
			else
				v.brake = Lerp(0.2, v.brake, 0)
			end
			
			if v:GetLightsEnabled() then
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_on")
			else
				v:SetSubMaterial(6, "models/vehicles/kamaz/kamaz_dash_co")
			end
			
			v:SetPoseParameter("gas", v.gas)
			v:SetPoseParameter("brake", v.brake)
			v:SetPoseParameter("clutch", v.clutch)
			v:SetPoseParameter("tacho", v.tacho)
			v:SetPoseParameter("speedo", v.speed)
			v:SetPoseParameter("temp", v.temp )
			v:SetPoseParameter("oil", v.oil )
			v:SetPoseParameter("fuel", v.fuel )
			v:SetPoseParameter("shiftlever", v.gear )
			
		end,
		
		SpeedoMax = 0, -- какая максималка на спидометре(может работать криво)
		
		
		FuelFillPos = Vector(30,-44,40), 
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 175, -- 72 
	
	  StrengthenSuspension = true, -- жесткая подвеска.

		FrontHeight = 18, -- высота передней подвески
		FrontConstant = 43000,
		FrontDamping = 4000,
		FrontRelativeDamping = 6000,

		RearHeight = 18, -- высота задней подвески
		RearConstant = 43000,
		RearDamping = 4000,
		RearRelativeDamping = 6000,

		FastSteeringAngle = 20,
		SteeringFadeFastSpeed = 1000,

		TurnSpeed = 2.5,

		MaxGrip = 120, -- 60 80
		Efficiency = 1,
		GripOffset = 2,
		BrakePower = 45, -- сила торможения

		IdleRPM = 450, -- мин. кол-во оборотов
		LimitRPM = 1500, -- 1350 макс. кол-во оборотов  -- 90км/ч
		Revlimiter = false, -- Если true - Когда стрелка спидометра доходит до красного обозначения, она не проходит дальше, если false - это игнорируется
		PeakTorque = 250, -- 120 крутящий момент 200 250
		PowerbandStart = 350, -- какие обороты на нейтральной передаче
		PowerbandEnd = 1200, -- 1200 ограничение по оборотам
		Turbocharged = false, -- турбо false = нет, true = да
		Supercharged = false, -- супер заряд
		Backfire = false, -- стреляющий выхлоп
		
		PowerBias = 0, --1
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/alfaromeo/alfaromeo_idle.wav",
		Sound_IdlePitch = 1.0, -- 0.7
		
		Sound_Mid = "simulated_vehicles/alfaromeo/alfaromeo_low.wav",
		Sound_MidPitch = 1, -- 0.7
		Sound_MidVolume = 1, -- 2 
		Sound_MidFadeOutRPMpercent = 37,		-- at wich percentage of limitrpm the sound fades out
		Sound_MidFadeOutRate = 0.56,                    --how fast it fades out   0 = instant       1 = never
		
		Sound_High = "simulated_vehicles/jeep/jeep_mid.wav",
		Sound_HighPitch = 1.0,
		Sound_HighVolume = 3.0, -- 9.0
		Sound_HighFadeInRPMpercent = 20,
		Sound_HighFadeInRate = 0.59,
		
		Sound_Throttle = "",		-- mutes the default throttle sound
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		DifferentialGear = 0.2,
		Gears = {-0.2,0,0.2,0.5,0.7,0.85,1} -- кол-во передач и "мощность"
	}
}

list.Set( "simfphys_vehicles", "sim_fphys_kamaz_ammo", V )

 