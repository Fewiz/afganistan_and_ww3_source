
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_t62b.lua ~

]]

local function bcDamage( vehicle , position , cdamage )
	if not simfphys.DamageEnabled then return end
	
	cdamage = cdamage or false
	net.Start( "simfphys_spritedamage" )
		net.WriteEntity( vehicle )
		net.WriteVector( position ) 
		net.WriteBool( cdamage ) 
	net.Broadcast()
end

local function DamageVehicle( ent , damage, type )
	if not simfphys.DamageEnabled then return end
	
	local MaxHealth = ent:GetMaxHealth()
	local CurHealth = ent:GetCurHealth()
	
	local NewHealth = math.max( math.Round(CurHealth - damage,0) , 0 )
	
	if NewHealth <= (MaxHealth * 0.6) then
		if NewHealth <= (MaxHealth * 0.3) then
			ent:SetOnFire( true )
			ent:SetOnSmoke( false )
		else
			ent:SetOnSmoke( true )
		end
	end
	
	if MaxHealth > 30 and NewHealth <= 31 then
		if ent:EngineActive() then
			ent:DamagedStall()
		end
	end
	
	if NewHealth <= 0 then
		if type ~= DMG_GENERIC and type ~= DMG_CRUSH or damage > 400 then
			
			DestroyVehicle( ent )
			
			return
		end
		
		if ent:EngineActive() then
			ent:DamagedStall()
		end
		
		return
	end
	
	ent:SetCurHealth( NewHealth )
end

local function TankTakeDamage( ent, dmginfo )
	ent:TakePhysicsDamage( dmginfo )

	if not ent:IsInitialized() then return end

	local Damage = dmginfo:GetDamage()
	local DamagePos = dmginfo:GetDamagePosition()
	local Type = dmginfo:GetDamageType()

	ent.LastAttacker = dmginfo:GetAttacker() 
	ent.LastInflictor = dmginfo:GetInflictor()

	bcDamage( ent , ent:WorldToLocal( DamagePos ) )

	local Mul = 1

	if Damage < (ent.DamageThreshold or 80) then
			Mul = Damage / (80 or ent.DamageThreshold)
	end


	--DamageVehicle( ent , Damage * Mul, Type )
	DamageVehicle( ent , Damage*10 * Mul, Type )
end







-------------------------------
local light_table = {	
ModernLights = false,

 
--L_HeadLampPos = Vector(-120,30.6,22.57),
--L_HeadLampAng = Angle(10,180,0),

	Headlight_sprites = { 
		{pos = Vector(-106,25.5,61),material = "sprites/light_ignorez",size = 50},
		
		 
	},
	Headlamp_sprites = { 
    
	
	{pos = Vector(-106,25.5,61),material = "sprites/light_ignorez",size = 30},
	
	{pos = Vector(-107,17.5,60.5),material = "sprites/light_ignorez",size = 50},
	},
	
	 
		
		
}
list.Set( "simfphys_lights", "T-62_AVX", light_table)


local V = {
	Name = "T-62 с ДШК",
	Model = "models/vehicles/t62/t62.mdl",  --"models/avx/t62.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "⛊Бронетранспорт⛊",
	SpawnOffset = Vector(0,0,60),
	SpawnAngleOffset = -90,

	Members = {
		Mass = 8000, --Mass = 12000, -- 24000
		
		LightsTable = "T-62_AVX",
		
		AirFriction = 5,
		Inertia = Vector(14000,47000,48000),

		
		IsArmored = true,

		NoWheelGibs = true,
		
		OnSpawn = function(ent)
			ent:SetNWBool( "simfphys_NoRacingHud", true )
			ent.DamageThreshold = 30
			--ent.OnTakeDamage = TankTakeDamage
			--ent.OnTakeDamage = AVX.TankTakeDamage -- Делает урон от автоматов - бесполезной херней

			ent:SetBodygroup(0,1)
			ent:SetBodygroup(1,1)
		end,

		OnDestroyed =
			function(ent)
				if IsValid( ent.Gib ) then
					local yaw = ent.sm_pp_yaw or 0
					local pitch = ent.sm_pp_pitch or 0
					ent.Gib:SetPoseParameter("cannon_aim_yaw", -yaw )
					ent.Gib:SetPoseParameter("cannon_aim_pitch", -pitch )
				end
			end,

		MaxHealth = 6200,  -- 7200  -- 4200

		IsArmored = true,

		NoWheelGibs = true,

		--FirstPersonViewPos = Vector(0,-50,15),
		FirstPersonViewPos = Vector(-25,-85,25),
		
		PassengerSeats = {
			{
				pos = Vector(-8,20,35),  -- стрелок
				ang = Angle(0,90,0)
			},
			{
				pos = Vector(28,15,50),  -- КПТ
				ang = Angle(0,90,0)
			},
			
			
			{
				pos = Vector(38,-15,35),  -- 85),
				ang = Angle(0,90,0)
			},
		},

		FrontWheelRadius = 25, -- 45
		RearWheelRadius = 25,  -- 55
		
		EnginePos = Vector(130,0.69,66),
		
		CustomWheels = true,
		CustomSuspensionTravel = 15,
		
		CustomWheelModel = "models/props_c17/canisterchunk01g.mdl",
		
		--[[CustomWheelPosRL = Vector(120,65,40),
		CustomWheelPosRR = Vector(120,-58,40),
		CustomWheelPosML = Vector(5,65,35),
		CustomWheelPosMR = Vector(5,-58,35),
		CustomWheelPosFL = Vector(-130,65,35),
		CustomWheelPosFR = Vector(-130,-58,35),]]

		CustomWheelPosRL = Vector(120,65,15),
		CustomWheelPosRR = Vector(120,-58,15),
		CustomWheelPosML = Vector(5,65,10),
		CustomWheelPosMR = Vector(5,-58,10),
		CustomWheelPosFL = Vector(-130,65,10),
		CustomWheelPosFR = Vector(-130,-58,10),
		CustomWheelAngleOffset = Angle(0,0,90),
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 60,
		
		SeatOffset = Vector(0,0,55),
		SeatPitch = 0,
		SeatYaw = -90,
		
		ModelInfo = {
			WheelColor = Color(0,0,0,0),
		},

		FrontHeight = 1,
		FrontConstant = 50000,
		FrontDamping = 30000,
		FrontRelativeDamping = 300000,

		RearHeight = 1,
		RearConstant = 50000,
		RearDamping = 20000,
		RearRelativeDamping = 20000,

		FastSteeringAngle = 20,
		SteeringFadeFastSpeed = 300,

		TurnSpeed = 6,

		MaxGrip = 800,
		Efficiency = 0.52, --  0.42,
		GripOffset = -300,
		BrakePower = 100,
		BulletProofTires = true,

		--IdleRPM = 800,
		--LimitRPM = 2500,  -- 3500,
		--PeakTorque = 550,  -- 310,  -- 350 -- 650 350
		--PowerbandStart = 600,
		--PowerbandEnd = 700,  -- 2600,
		--Turbocharged = false,
		--Supercharged = false,
		--DoNotStall = true,

		IdleRPM = 100,
		LimitRPM = 2800, -- 2500		-- Скорость по шоссе, 50км/ч  -- Скорость по пересеченке, 25км/ч
		PeakTorque = 200,
		PowerbandStart = 300,
		PowerbandEnd = 2850, -- 2700
		Turbocharged = false,
		Supercharged = false,
		DoNotStall = true,

		FuelFillPos = Vector(139.42,-3.68,38.38),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 960, -- 220
		
		PowerBias = -0.5,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/t90ms/idle.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/t90ms/low.wav",
		Sound_MidPitch = 1.5,
		Sound_MidVolume = 0.22, -- 1,
		Sound_MidFadeOutRPMpercent = 100,
		Sound_MidFadeOutRate = 1,
		
		Sound_High = "simulated_vehicles/t90ms/high.wav",
		Sound_HighPitch = 1.5,
		Sound_HighVolume = 0.12, -- 0.7,
		Sound_HighFadeInRPMpercent = 50,
		Sound_HighFadeInRate = 0.2,
		
		--Sound_Throttle = "keys",
		--Sound_ThrottlePitch = 0,
		--Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_2.wav",
		ForceTransmission = 1,
		
		DifferentialGear = 0.3,
		Gears = {-0.03,0,0.05,0.08,0.11,0.14}
	}
}
list.Set( "simfphys_vehicles", "avx_t62b", V )