
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_mercedes.lua ~

]]




local light_table = {
 
	Headlight_sprites = { 
		{pos = Vector(101,31,32.5),material = "sprites/light_ignorez",size = 75},
		
		{pos = Vector(101,-31,32.5),material = "sprites/light_ignorez",size = 75},
	},
	Headlamp_sprites = { 
	    {pos = Vector(103,23,32.5),material = "sprites/light_ignorez",size = 50},
		
		{pos = Vector(103,-23,32.5),material = "sprites/light_ignorez",size = 50},	  
	},
	
  	
	Rearlight_sprites = {
		{pos = Vector(-110,23.5,33),material = "sprites/light_ignorez",size = 45},
	    {pos = Vector(-110,-23.5,33),material = "sprites/light_ignorez",size = 45},
	},
	Brakelight_sprites = {
	    {pos = Vector(-110,17,33),material = "sprites/light_ignorez",size = 45},
	    {pos = Vector(-110,-17,33),material = "sprites/light_ignorez",size = 45},
	},
	Reverselight_sprites = {
	    {pos = Vector(-110,20,33),material = "sprites/light_ignorez",size = 35},
	    {pos = Vector(-110,-20,33),material = "sprites/light_ignorez",size = 35},
	},
	

	
	
	Turnsignal_sprites = { -- поворотники
		Left = { -- левый
	    {pos = Vector(98,39,33),material = "sprites/light_ignorez",size = 45},	
		{pos = Vector(99,39,30),material = "sprites/light_ignorez",size = 45},		
		
        {pos = Vector(-108,34,32.7),material = "sprites/light_ignorez",size = 55},
	 -- {pos = Vector(102,35,33),material = "sprites/light_ignorez",size = 40},  -- {pos = Vector(102,-35,33),material = "sprites/light_ignorez",size = 40},
		},
		Right = { -- правый	
		
		{pos = Vector(98,-39,33),material = "sprites/light_ignorez",size = 45},	
		{pos = Vector(99,-39,30),material = "sprites/light_ignorez",size = 45},		
		
	    {pos = Vector(-108,-34,32.7),material = "sprites/light_ignorez",size = 55},
 
		},
	}
		
		
}
list.Set( "simfphys_lights", "simfphys_mercedes", light_table)


local V = {
	Name = "Mercedes W124",
	Model = "models/vehicles/mercedes/civ_mercedes.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "★Премиум★", -- Транспорт

	SpawnOffset = Vector(0,0,10),
	SpawnAngleOffset = 90,

	Members = {
		Mass = 1720,  -- 3600  -- 3000
		LightsTable = "simfphys_mercedes",

		MaxHealth = 1450,  -- 1600
		
		
				
		OnDestroyed =  function(ent)
			if IsValid( ent.Gib ) then
 				ent.Gib:SetBodygroup(0,1)   
			end
		end,
		
		--OnSpawn = function(ent) ent:SetSubMaterial(1, "models/sim_fphys_willi302_shared/glass") end,
		OnSpawn = function(ent) ent:SetSubMaterial(1, "models/sim_fphys_willi302_shared/glass") end,
		
			--OnTick = function(ent)
			--ent:SetSubMaterial(1, "models/silyrunningdigital/cartex/glass01")  -- Улучшенное стекло		     
           -- end,


		IsArmored = false,

		EnginePos = Vector(80,0,50),

		CustomWheels = true,
		CustomSuspensionTravel = 3,

		CustomWheelModel = "models/vehicles/mercedes/civ_mercedes_wheel.mdl",
		CustomWheelPosFL = Vector(74,-33,17),
		CustomWheelPosFR = Vector(74,33,17),
		CustomWheelPosRL = Vector(-60,-33,15),
		CustomWheelPosRR = Vector(-60,33,15),
		CustomWheelAngleOffset = Angle(0,0,0),
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 25,
		
		SeatOffset = Vector(8,-5,2),
		SeatPitch = 0,
		SeatYaw = 0,
		
		FrontWheelRadius = 15,
		RearWheelRadius = 15,
		
		PassengerSeats = {
			{
				pos = Vector(10,-20,18),
				ang = Angle(0,-90,0)
			},
			{
				pos = Vector(-40,20,20),  -- pos = Vector(38,20,20),
				ang = Angle(0,-90,0)
			},
			{
				pos = Vector(-40,-20,20),
				ang = Angle(0,-90,0)
			},
		},
		
		FrontHeight = 10,
		FrontConstant = 25000,
		FrontDamping = 2500,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 25000,
		RearDamping = 2500,
		RearRelativeDamping = 5000,
		
		--[[
	    FrontHeight = 10,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		]]
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 3,
		
		MaxGrip = 40,  -- 60 30
		Efficiency = 1.25,  -- 1.25,
		GripOffset = -10,  -- -14 -2
		BrakePower = 30,
		BulletProofTires = false,
		
		IdleRPM = 900,
		LimitRPM = 7750,  -- 5500,  -- 135-200 КМ/Ч  -- 3500  --6200
		PeakTorque = 30,  -- 220,  -- 75  -- 84  -- 100  -- 40
		PowerbandStart = 750,  -- 1000,
		PowerbandEnd = 7000, -- 4500,  -- 5500
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-61.34,49.71,15.98),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 120,
		
		PowerBias = 0,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		ForceTransmission = 1,  -- 1

		DifferentialGear = 0.2,
		Gears =  {-0.1,0,0.1,0.2,0.3,0.4}  --{-0.09,0,0.09,0.18,0.28,0.35,0.5}
	}
}
list.Set( "simfphys_vehicles", "simfphys_mercedes_W124", V )




local V = {
	Name = "Mercedes W124 BE",
	Model = "models/vehicles/mercedes/civ_mercedes.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "★Премиум★", -- Транспорт

	SpawnOffset = Vector(0,0,10),
	SpawnAngleOffset = 90,

	Members = {
		Mass = 2220,  -- 3600  -- 3000
		LightsTable = "simfphys_mercedes",
 
		MaxHealth = 3000,  -- 1600 -- 1400
		
		IsArmored = true,

		
		ModelInfo = {
			Color=Color(0,0,0),
		},

		 
		OnDestroyed =  function(ent)
			if IsValid( ent.Gib ) then
 				ent.Gib:SetBodygroup(0,1)   
			end
		end,

		--OnSpawn = function(ent)
			--  ent:SetSubMaterial(1, "debug/env_cubemap_model")  -- Улучшенное стекло					  
 		--end,

 		OnSpawn = function(ent) ent:SetSubMaterial(1, "models/sim_fphys_willi302_shared/glass") end,
		
			--OnTick = function(ent)
			--ent:SetSubMaterial(1, "models/silyrunningdigital/cartex/glass01")  -- Улучшенное стекло		     
           -- end,

		IsArmored = false,

		EnginePos = Vector(80,0,50),

		CustomWheels = true,
		CustomSuspensionTravel = 3,

		CustomWheelModel = "models/vehicles/mercedes/civ_mercedes_wheel.mdl",
		CustomWheelPosFL = Vector(74,-33,16),
		CustomWheelPosFR = Vector(74,33,16),
		CustomWheelPosRL = Vector(-60,-33,14),
		CustomWheelPosRR = Vector(-60,33,14),
		CustomWheelAngleOffset = Angle(0,0,0),
		
		CustomMassCenter = Vector(0,0,0),
		
		CustomSteerAngle = 25,
		
		SeatOffset = Vector(8,-5,2),
		SeatPitch = 0,
		SeatYaw = 0,
		
		FrontWheelRadius = 15,
		RearWheelRadius = 15,
		
		PassengerSeats = {
			{
				pos = Vector(10,-20,18),
				ang = Angle(0,-90,0)
			},
			{
				pos = Vector(-40,20,20),  -- pos = Vector(38,20,20),
				ang = Angle(0,-90,0)
			},
			{
				pos = Vector(-40,-20,20),
				ang = Angle(0,-90,0)
			},
		},
		
		FrontHeight = 10,
		FrontConstant = 25000,
		FrontDamping = 2500,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 25000,
		RearDamping = 2500,
		RearRelativeDamping = 5000,
		
		--[[
	    FrontHeight = 10,
		FrontConstant = 50000,
		FrontDamping = 15000,
		FrontRelativeDamping = 5000,
		
		RearHeight = 10,
		RearConstant = 50000,
		RearDamping = 15000,
		RearRelativeDamping = 5000,
		]]
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 3,
		
		MaxGrip = 45,  -- 60
		Efficiency = 1.25,  -- 1.25,
		GripOffset = -10,  -- -14 -2
		BrakePower = 30,
		BulletProofTires = true,
		
		IdleRPM = 900,
		LimitRPM = 7850,  -- 5500,  -- 135-200 КМ/Ч  -- 3500  --6200
		PeakTorque = 45,  -- 220,  -- 75  -- 84  -- 100  -- 40
		PowerbandStart = 750,  -- 1000,
		PowerbandEnd = 7000, -- 4500,  -- 5500
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-61.34,49.71,15.98),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 120,
		
		PowerBias = 0,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_1.wav",
		
		ForceTransmission = 1,  -- 1

		DifferentialGear = 0.2,
		Gears =  {-0.1,0,0.1,0.2,0.3,0.4}  --{-0.09,0,0.09,0.18,0.28,0.35,0.5}
	}
}
list.Set( "simfphys_vehicles", "simfphys_mercedes_W124_BE", V )
