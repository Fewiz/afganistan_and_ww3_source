
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_btr70.lua ~

]]

local light_table = {
ModernLights = false, -- грубо говоря, ксенон или старые фары. True - ксенон, false - старые
	Headlight_sprites = { -- Обычные фары
		{pos = Vector(-58,105,76),size = 35},
		{pos = Vector(58,105,76),size = 35},
		
		{
			pos = Vector(-22.35,115,66.75),
			size = 3,
		    color = Color(255,52,0,200),
		},
		
		{
			pos = Vector(-22.95,116.25,72.1),
			size = 3,
		    color = Color(255,52,0,200),
			OnBodyGroups={[4]={1}}
		},
		
		--[[{
			pos = Vector(-22.95,116.25,72.1),
			size = 3,
		    color = Color(255,52,0,200),
			OnBodyGroups={[5]={1}}
		},]]
		
		 
		
	},
	Headlamp_sprites = { -- дальние
		{pos = Vector(-58,105,76),size = 35},
		{pos = Vector(58,105,76),size = 35},

		{pos = Vector(-55, 98,85),size = 45},
		{pos = Vector(55,  98,85),size = 45},
		
		{
			pos = Vector(-21.15,115,66.75),
			size = 3,
		    color = Color(255,52,0,200),
		},
	},
	FogLight_sprites = {
		{pos = Vector(19,93,106),size = 45},
		{pos = Vector(19,93,106),size = 125},
	},
	Rearlight_sprites = { -- задние фары
		{pos = Vector(-48,-216,82),size = 35},
		{pos = Vector(48,-216,82),size = 35},
	},
	Brakelight_sprites = { -- тормозные огни
		{pos = Vector(-48,-216,82),size = 35},
		{pos = Vector(48,-216,82),size = 35},
		
		{
			pos = Vector(-11.15,115,65.75),
			size = 3,
		    color = Color(255,52,0,200),
		},
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(-55.5,112,74.5),
		},
		Right = {
			Vector(55.5,112,74.5),
		},
	},
	
}
list.Set( "simfphys_lights", "simphys_BTR-70", light_table) -- здесь тебе нужно изменить "test" на любое другое название, например "myfirstsimfcar"


local V = {
	Name = "БТР-70",
	Model = "models/vehicles/btr70/btr70_new.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	SpawnOffset = Vector(0,0,40),
	Category = "⛊Бронетранспорт⛊",
	SpawnAngleOffset = 0,

	Members = {
		Mass = 3000, -- 3000
		MaxHealth = 4350, -- 4500
		
	--	FirstPersonViewPos = Vector(-30,0,70),
	 	OnSpawn = function(ent)
	 		ent:SetBodygroup(11,1) -- Ненужная фляга с водою
        	--ent:SetNWBool("dangerkiddy_has_gear", false)
        	--ent:SetNWInt("_direction_", 0)
        	--ent:SetNWInt("__SetBuoyancyRatio__", 1)
        	--ent:SetNWBool("_can_swim__", true)
        	--ent:SetNWBool("_isboat", true)
        	ent.fananimspeed = 0
		end,
 
		OnTick = function(v)

			if v:GetLightsEnabled() then
				v:SetSubMaterial(9, "models/vehicles/btr70_new/int1_on")
			else
				v:SetSubMaterial(9, "models/vehicles/btr70_new/int1")
			end


		-- 4/5 - Боковые двери. 6/7 - люки 
			v:SetPoseParameter("vehicle_speedo", v:GetVelocity():Length()/900) -- 1000 950
			v:SetPoseParameter("vehicle_fan", v:GetVelocity():Length()/950)
			--print(v:GetBodygroup(3))
			if v.VehicleLocked == true then 
				v:SetBodygroup(6,0) 
				--v:SetBodygroup(3,0) 
			else 
				v:SetBodygroup(6,1) 
				--v:SetBodygroup(3,1) 
			end 
			
			--v:SetBodygroup(5,1) 
			--
			v:SetPoseParameter("vehicle_fuel", v:GetFuel() / v:GetMaxFuel())

			if not v.fananimspeed then return end
			local boost = v:GetRPM() / 100
			v.fananimspeed = Lerp(0.15, v.fananimspeed, boost)
			v:SetPoseParameter("vehicle_fan", v.fananimspeed )	
		end, 

		ExhaustPositions = {

			{
				pos = Vector(-58,-218,78),
				ang = Angle(160,0,0)
			},
				
			{
				pos = Vector(58,-218,78),
				ang = Angle(160,30,0)
			},

			--

			{
				pos = Vector(-58,-218,78),
				ang = Angle(160,0,0)
			},
				
			{
				pos = Vector(58,-218,78),
				ang = Angle(160,30,0)
			},

			--

			{
				pos = Vector(-58,-218,78),
				ang = Angle(160,0,0)
			},
				
			{
				pos = Vector(58,-218,78),
				ang = Angle(160,30,0)
			},
		
			
		},

		OnDelete = function(v) v:SetPoseParameter("vehicle_speedo", v:GetVelocity():Length()/950) end,		
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 2555,		

		--ApplyDamage = function( ent, damage, type ) 
			--simfphys.TankApplyDamage(ent, damage, type)
		--end,	
	  
		FirstPersonViewPos = Vector(3,-22,10), -- Vector(0,-25,25),
		
		LightsTable = "simphys_BTR-70",
		
		IsArmored = true,
		NoWheelGibs = true,
	    FrontWheelRadius = 26+2,--радиус переднего колеса
		RearWheelRadius = 26+2,--радиус заднего колеса
		
	   	CustomWheels = false,
		CustomSuspensionTravel = 10,  
 
		CustomMassCenter = Vector(0,0,3.5),
        EnginePos = Vector(0,-130,100),
		
		CustomSteerAngle = 25, -- 25
		CustomWheelCamber = 0,
 	
		SeatOffset = Vector(75,-19,60+12),
		SeatPitch = 0,
		SeatYaw = 0,
		
		
	 
		
		PassengerSeats = {

			{
                pos = Vector(19,80,40),
                ang = Angle(0,0,0),
        	},

        	{
                pos = Vector(0,20,70),
                ang = Angle(0,0,0),
        	},
 
            ////////
			

			{
                pos = Vector(-26,40,42),
                ang = Angle(0,0,0),
        	},
			
			{
                pos = Vector(25,40,42),
                ang = Angle(0,0,0),
        	},


			

			{
				pos = Vector(-8,-26,43),
				ang = Angle(0,90,2)
			},
			{
				pos = Vector(8,-26,43),
				ang = Angle(0,-90,-2)
			},

			{
				pos = Vector(-8,-55,43),
				ang = Angle(0,90,2)
			},
			{
				pos = Vector(8,-55,43),
				ang = Angle(0,-90,-2)
			},

			{
				pos = Vector(-8,-75,43),
				ang = Angle(0,90,2)
			},
			{
				pos = Vector(8,-75,43),
				ang = Angle(0,-90,-2)
			},
			
			-- Броня
			
			{
				pos = Vector(-38,-8,89),
				ang = Angle(0,75,2)
			},	
			
			{
				pos = Vector(38,-8,89),
				ang = Angle(0,-75,2)
			},	
			
			{
				pos = Vector(-38,-30,89),
				ang = Angle(0,90,2)
			},	
			
			{
				pos = Vector(38,-30,89),
				ang = Angle(0,-90,2)
			},	
			
			{
				pos = Vector(-38,-60,89),
				ang = Angle(0,90,2)
			},	
			
			{
				pos = Vector(38,-60,89),
				ang = Angle(0,-90,2)
			},	

		},
		
		FrontHeight = 8, -- высота передней подвески
		FrontConstant = 50000,
		FrontDamping = 4000,
		FrontRelativeDamping = 4000,

		RearHeight = 8, -- высота задней подвески
		RearConstant = 50000,
		RearDamping = 4000,
		RearRelativeDamping = 4000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 1.25, -- 1

		MaxGrip = 90,  -- 140 70
		Efficiency = 1.25,
		GripOffset = -14,
		BrakePower = 20,
		BulletProofTires = true,

		IdleRPM = 228,
		LimitRPM = 1575,
		PeakTorque = 90, -- 120 75
		PowerbandStart = 750,
		PowerbandEnd = 1450,
		Turbocharged = false,
		Supercharged = false,

		FuelFillPos = Vector(55,-135,85),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 290, -- 120

		PowerBias = 0,

		EngineSoundPreset = 0,

		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav", --"simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1, -- 1,

		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,

		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,

		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,

		snd_horn = "simulated_vehicles/horn_2.wav",

		ForceTransmission = 1,

		DifferentialGear = 0.27,
		Gears = {-0.09,0,0.09,0.18,0.28,0.35}
		--DifferentialGear = 0.25,
		--Gears = {-0.09,0,0.06,0.15,0.28,0.35}
			}
		}
list.Set( "simfphys_vehicles", "simphys_BTR70", V )


 
 