
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_1500_lada.lua ~

]]

local light_table = {
 
	Headlight_sprites = { 
		{ 
			pos = Vector(-91.5,1,16.3),
			size = 13,
		},
		{
			pos = Vector(-91.5,-1,16.3),
			size = 13,
		},
		---------
		
		{
			pos = Vector(89,28,23.5),
			size = 47,
		},
		{
			pos = Vector(89,-28,23.5),
			size = 47,
		},
		{
			pos = Vector(89,28,23.5),
			size = 35,
		},
		{
			pos = Vector(89,-28,23.5),
			size = 35,
		},
		
		{
			pos = Vector(39.5,12.77,33.33),
			size = 2,
		    color = Color(0,255,161,255),
		},
		
	},
	Headlamp_sprites = { 
		{
			pos = Vector(90,19.3,23.5),
			size = 47,
		},
		{
			pos = Vector(90,-19.3,23.5),
			size = 47,
		},
		{
			pos = Vector(39.5,10.8,33.33),
			size = 2,
		    color = Color(0,161,255,255),
		},
		{
			pos = Vector(90,19.3,23.5),
			size = 35,
		},
		{
			pos = Vector(90,-19.3,23.5),
			size = 35,
		}
	},
	Rearlight_sprites = {
		{
			pos = Vector(-90.5,24,24),
			size = 40,
		},
		{
			pos = Vector(-90.5,-24.5,24),
			size = 40,
		},
		{
			pos = Vector(-90.5,24,24),
			size = 40,
		},
		{
			pos = Vector(-90.5,-24.5,24),
			size = 40,
		},		
	},
	Brakelight_sprites = {
		{
			pos = Vector(-90.5,24,24),
			size = 49,
		},
		{
			pos = Vector(-90.5,-24.5,24),
			size = 49,
		},
				{
			pos = Vector(-90.5,24,24),
			size = 49,
		},
		{
			pos = Vector(-90.5,-24.5,24),
			size = 49,
		},	
	},
	Reverselight_sprites = {
		{
			pos = Vector(-87.5,0,9),
			size = 49,
		},
	},	   
	FogLight_sprites = {
		{
			pos = Vector(-1.9,28.3,53.3),
			size = 10,
		},
		{
			pos = Vector(-1.9,-28.2,53.3),
			size = 10,
		},
    },
	Turnsignal_sprites = {
		Left = {
		    {pos = Vector(-90.5,24,20.5),size = 49},
		    --{pos = Vector(-90.5,24,21),size = 49},
		    {pos = Vector(84.5,36.1,27.5),size = 18},
		    {pos = Vector(89,30,17),size = 18},
		    {pos = Vector(39.5,12,33.12),size = 1,color = Color(0,255,161,255)},
		},	
		Right = {
		    {pos = Vector(-90.5,-24,20.5),size = 49},
		    --{pos = Vector(-90.5,-24,21),size = 49},
		   -- {pos = Vector(84.5,-36.1,27.5),size = 18},
		    {pos = Vector(84.5,-36.1,27.5),size = 18},
			{pos = Vector(89,-30,17),size = 18},
		    {pos = Vector(89,-30,17),size = 18},
		    {pos = Vector(39.5,11.53,33.12),size = 1,color = Color(0,255,161,255)},
		    --{pos = Vector(39.5,12,33.12),size = 1,color = Color(0,255,161,255)},
		},
	}
}	
list.Set( "simfphys_lights", "mst_vaz2103", light_table)

local Category = "☭Советский☭" 
local V = {
	Name = "Лада 2103 (1500s)",
	Model = "models/vehicles/vaz2103/vaz2103.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = Category,

	Members = {
		Mass = 985,

        OnTick = function(v) 
        	if v:GetLightsEnabled() then
				v:SetSubMaterial(15, "models/vehicles/vaz2106/priborka_on")
			else
				v:SetSubMaterial(15, "models/vehicles/vaz2106/priborka")
			end
			if not v.temp then
				v.gears = {0,0.8,1.7,2.6,3.8,4.8,6}
				v.gear = 0
			end 	
			if v:GetGear() <= 6 then 
				v.gear = Lerp(1, v.gear, v.gears[v:GetGear()])
			end
			v:SetPoseParameter("vehicle_shift", v.gear )
			
			v:SetPoseParameter("vehicle_fuel", v:GetFuel() / v:GetMaxFuel())	

			--v.tacho = Lerp(1, 0.1+v:GetPoseParameter("vehicle_tacho"), v:GetRPM()/8000)
			--v:SetPoseParameter("vehicle_tacho", 1-v.tacho)

		end,
		OnDelete = function(v) v:SetPoseParameter("vehicle_shift", v.gear ) v:SetPoseParameter("vehicle_fuel", v:GetFuel() / v:GetMaxFuel()) end,	
		
					
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 8000, -- 8000
		SpeedoMax = 35, -- 111,847,

		
		EnginePos = Vector(70,0,30),
		
		LightsTable = "mst_vaz2103",
		
		CustomWheels = true,
		CustomSuspensionTravel = 15,
		
		CustomWheelModel = "models/vehicles/vaz2103/VAZ2103_wheel.mdl",
		CustomWheelPosFL = Vector(67,29,9),
		CustomWheelPosFR = Vector(67,-29,9),
		CustomWheelPosRL = Vector(-46,29,9),
		CustomWheelPosRR = Vector(-46,-29,9),
		CustomWheelAngleOffset = Angle(0,0,0),

		FrontWheelRadius = 12,--радиус переднего колеса
		RearWheelRadius = 12,--радиус заднего колеса
		
		CustomMassCenter = Vector(5,0,0),
		
		CustomSteerAngle = 30,
		
		SeatOffset = Vector(2,-15,40),
		SeatPitch = 0,
		SeatYaw = 90,
		
		FirstPersonViewPos = Vector(0,-11,9), -- Vector(0,-11,9),

		    ModelInfo = {
			WheelColor = Color(145,145,145,255)
		},
		
		PassengerSeats = {
			{
				pos = Vector(7,-17,11),
				ang = Angle(0,-90,10)
			},
			{
				pos = Vector(-29,-17,10),
				ang = Angle(0,-90,10)
			},
		    {
				pos = Vector(-29,0,10),
				ang = Angle(0,-90,10)
			},
		    {
				pos = Vector(-29,17,10),
				ang = Angle(0,-90,10)
			},	
		},
		 
		ExhaustPositions = {
			{
				pos = Vector(-90,-12,6),
				ang = Angle(90,165,0)
			},
		},
		
		FrontHeight = 9,
		FrontConstant = 21000,
		FrontDamping = 870,
		FrontRelativeDamping = 870,
		
		RearHeight = 9,
		RearConstant = 21000,
		RearDamping = 870,
		RearRelativeDamping = 870,
		
		FastSteeringAngle = 7,
		SteeringFadeFastSpeed = 440,
		
		TurnSpeed = 1.75,--  1.20 1.5
		
		MaxGrip = 33, -- 33 45
		Efficiency = 0.74, -- 0.74, 
		GripOffset = -4, -- -0.40 хд, ясно почему машину заносило так криво
		BrakePower = 20,
		
		IdleRPM = 600,
		LimitRPM = 8000, -- 142 (150км/ч)
		PeakTorque = 26, -- 45 26 38
		PowerbandStart = 750,
		PowerbandEnd =  5600,
		Turbocharged = false,
		Supercharged = false,

		FuelFillPos = Vector(-64,-36,27),
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 39,
		
		PowerBias = 1, -- привод. 1 - задний, 0 - полный, -1 - передний

		EngineSoundPreset = -1,
		--
		snd_pitch = 1,
		snd_idle = "vehicles/sim_fphys_vaz-2106/idle.wav",

		snd_low = "vehicles/sim_fphys_vaz-2106/low.wav",
		snd_low_revdown = "vehicles/sim_fphys_vaz-2106/low.wav", -- это всё звук
		snd_low_pitch = 0.9, -- 0.75,

		snd_mid = "vehicles/sim_fphys_vaz-2106/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_vaz-2106/second.wav",
		snd_mid_geardown = "vehicles/sim_fphys_vaz-2106/second.wav",
		snd_mid_pitch = 0.9, -- 0.75,

		snd_horn = "simulated_vehicles/horn_7.wav",

		--
		
		DifferentialGear = 0.2,
		Gears = {-0.1,0,0.1,0.2,0.3,0.4,0.45}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_vaz_2103", V )
 

---------------------------------------------------------------------------------




local light_table = {
    ModernLights = false,
 
	Headlight_sprites = { 
		{
			pos = Vector(85,28,23.5),
			size = 47,
		},
		{
			pos = Vector(85,-28,23.5),
			size = 47,
		},
		{
			pos = Vector(85,28,23.5),
			size = 35,
		},
		{
			pos = Vector(85,-28,23.5),
			size = 35,
		},
		
		{
			pos = Vector(36,12.7,33.2),
			size = 2,
		    color = Color(0,255,161,255),
		},
		
		
		
		-- На бампере
		
		{
			pos = Vector(91.3,24.5,13.3),
			size = 18,
			color = Color(255,120,0,255),
		},
		{
			pos = Vector(91.3,-24.5,13.3),
			size = 18,
			color = Color(255,120,0,255),
		},
 
	},
	
	FogLight_sprites = {
		{
			pos = Vector(-5.5,28.3,53.3),
			size = 10,
		},
		{
			pos = Vector(-5.5,-28.2,53.3),
			size = 10,
		},
    },
	
	Headlamp_sprites = { 
		{
			pos = Vector(86,19.3,23.5),
			size = 47,
		},
		{
			pos = Vector(86,-19.3,23.5),
			size = 47,
		},
		{
			pos = Vector(36,10.7,33.2),
			size = 2,
		    color = Color(0,161,255,255),
		},
		{
			pos = Vector(86,19.3,23.5),
			size = 35,
		},
		{
			pos = Vector(86,-19.3,23.5),
			size = 35,
		}
	},
	Rearlight_sprites = {
		{pos = Vector(-95,22,20.5),size = 25},  {pos = Vector(-95,25,20.5),size = 25},                   --Vector(-95,25,20.5), Vector(-95,24,20.5), Vector(-95,23,20.5), Vector(-95,22,20.5),
		{pos = Vector(-95,-22,20.5),size = 25}, {pos = Vector(-95,-25,20.5),size = 25},    
		Vector(-88,35.5,24.5), Vector(-88,-35.5,24.5), 
	},
	Brakelight_sprites = {
		{pos = Vector(-95,18.5,22.5),size = 45},   --Vector(-95,19,22), Vector(-95,19,24), Vector(-95,18,20), Vector(-95,18,22), Vector(-95,18,24),
		{pos = Vector(-95,-18.5,22.5),size = 45},  --Vector(-95,-19,22), Vector(-95,-19,24), Vector(-95,-18,20), Vector(-95,-18,22), Vector(-95,-18,24) 
	},
	Reverselight_sprites = {
		{pos = Vector(-95,22,22.5),size = 25},  {pos = Vector(-95,25,22.5),size = 25}, 
		{pos = Vector(-95,-22,22.5),size = 25}, {pos = Vector(-95,-25,22.5),size = 25},    
	},
			Turnsignal_sprites = {
		Left = {
		    {pos = Vector(-94.5,28.8,22.5),size = 50,color = Color(205,0,0,255)},
		    --{pos = Vector(-94.5,28.8,22.1),size = 41,color = Color(205,0,0,255)},
		    {pos = Vector(91.3,28,13.3),size = 18},
			{pos = Vector(81.5,36.2,25.2),size = 18},
			
		   {pos = Vector(36,11.53,33),size = 1,color = Color(0,255,161,255)},
		   {pos = Vector(36,12,33),size = 1,color = Color(0,255,161,255)},
		   {pos = Vector(35.5,-2.1,26.6),size = 9,color = Color(255,0,0,255)},
		},	
		Right = {
		    {pos = Vector(-94.5,-28.8,22.1),size = 41,color = Color(205,0,0,255)},
		    --{pos = Vector(-94.5,-28.8,22.1),size = 41,color = Color(205,0,0,255)},
		    {pos = Vector(91.3,-28,13.3),size = 18},
			{pos = Vector(81.5,-36.2,25.2),size = 18},
			
			
		    {pos = Vector(36,11.53,33),size = 1,color = Color(0,255,161,255)},
		    {pos = Vector(36,12,33),size = 1,color = Color(0,255,161,255)},
			{pos = Vector(35.5,-2.1,26.6),size = 9,color = Color(255,0,0,255)},
		},
	}
}	
list.Set( "simfphys_lights", "mst_vaz2106", light_table)
 

local V = {
	Name = "Лада 2106 (1500s)",
	Model = "models/vehicles/VAZ2106/vaz2106.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = Category,

	Members = {
		Mass = 1040, -- 980

        OnTick = function(v) 

        	if v:GetLightsEnabled() then
				v:SetSubMaterial(13, "models/vehicles/vaz2106/priborka_on")
			else
				v:SetSubMaterial(13, "models/vehicles/vaz2106/priborka")
			end
			
			if not v.temp then
				v.gears = {0,0.8,1.7,2.6,3.8,4.8,6}
				v.gear = 0
			end 	
			if v:GetGear() <= 6 then 
				v.gear = Lerp(1, v.gear, v.gears[v:GetGear()])
			end
			v:SetPoseParameter("vehicle_shift", v.gear )
			
			v:SetPoseParameter("vehicle_fuel", v:GetFuel() / v:GetMaxFuel())	
		end,
		OnDelete = function(v) v:SetPoseParameter("vehicle_shift", v.gear ) v:SetPoseParameter("vehicle_fuel", v:GetFuel() / v:GetMaxFuel()) end,	
			
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 8000, -- 8000
		SpeedoMax = 35, -- 111,847,
		
		EnginePos = Vector(68,0,30),	
		
		LightsTable = "mst_vaz2106",
		
		CustomWheels = true,
		CustomSuspensionTravel = 15,
		
		CustomWheelModel = "models/vehicles/VAZ2106/VAZ2106_wheel.mdl",
		CustomWheelPosFL = Vector(63,33,9),
		CustomWheelPosFR = Vector(63,-33,9),
		CustomWheelPosRL = Vector(-50,33,9),
		CustomWheelPosRR = Vector(-50,-33,9),
		CustomWheelAngleOffset = Angle(0,90,0),

		FrontWheelRadius = 12,--радиус переднего колеса
		RearWheelRadius = 12,--радиус заднего колеса
		 
		CustomMassCenter = Vector(5,0,0), --  Vector(0,0,0),
		
		CustomSteerAngle = 36,
		
		SeatOffset = Vector(-1,-15,39),
		SeatPitch = 0,
		SeatYaw = 90,
  
		FirstPersonViewPos = Vector(0,-11,9),

--[[
		ModelInfo = {
			Bodygroups = {1,1,0,1,1,1,0,0},
			WheelColor = Color(145,145,145,255)
		},
]]
		
		PassengerSeats = {
			{
				pos = Vector(4,-17,11),
				ang = Angle(0,-90,10)
			},
			{
				pos = Vector(-33,-17,10),
				ang = Angle(0,-90,10)
			},
		    {
				pos = Vector(-33,0,10),
				ang = Angle(0,-90,10)
			},
		    {
				pos = Vector(-33,17,10),
				ang = Angle(0,-90,10)
			},	
		},

		ExhaustPositions = {
			{
				pos = Vector(-92,-12,5),
				ang = Angle(90,165,0)
			},
		},
		
		FrontHeight = 9,
		FrontConstant = 21000,
		FrontDamping = 870,
		FrontRelativeDamping = 870,
		
		RearHeight = 9,
		RearConstant = 21000,
		RearDamping = 870,
		RearRelativeDamping = 870,
		
		FastSteeringAngle = 7,
		SteeringFadeFastSpeed = 440,
		
		TurnSpeed = 1.75,--  1.20 1.5
		
		MaxGrip = 45, -- 33
		Efficiency = 0.74, -- 0.74, 
		GripOffset = -4, -- -0.40 хд, ясно почему машину заносило так криво
		BrakePower = 20,
		
		IdleRPM = 600,
		LimitRPM = 8000, -- 156 (150км/ч)
		PeakTorque = 26, -- 45 26 38
		PowerbandStart = 750,
		PowerbandEnd =  5600,
		Turbocharged = false,
		Supercharged = false,

		FuelFillPos = Vector(-64,-36,27),
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 39,
		
		PowerBias = 1, -- привод. 1 - задний, 0 - полный, -1 - передний

		EngineSoundPreset = -1,
		--
		snd_pitch = 1,
		snd_idle = "vehicles/sim_fphys_vaz-2106/idle.wav",

		snd_low = "vehicles/sim_fphys_vaz-2106/low.wav",
		snd_low_revdown = "vehicles/sim_fphys_vaz-2106/low.wav", -- это всё звук
		snd_low_pitch = 0.9, -- 0.75,

		snd_mid = "vehicles/sim_fphys_vaz-2106/mid.wav",
		snd_mid_gearup = "vehicles/sim_fphys_vaz-2106/second.wav",
		snd_mid_geardown = "vehicles/sim_fphys_vaz-2106/second.wav",
		snd_mid_pitch = 0.9, -- 0.75,

		snd_horn = "simulated_vehicles/horn_7.wav",

		--
		
		DifferentialGear = 0.2,
		Gears = {-0.1,0,0.1,0.2,0.3,0.4,0.45}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_vaz_2106", V )