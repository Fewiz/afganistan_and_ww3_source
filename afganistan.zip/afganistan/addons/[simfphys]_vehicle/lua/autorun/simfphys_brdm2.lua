
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_vehicle/lua/autorun/simfphys_brdm2.lua ~

]]

local light_table = {
	ModernLights = false, -- грубо говоря, ксенон или старые фары. True - ксенон, false - старые
	--[[L_HeadLampPos = Vector(134,-34,21), -- рассположение обычных фар (левых - L)
	L_HeadLampAng = Angle(0,0,0), -- угол поворота фар

	R_HeadLampPos = Vector(134,34,21), -- рассположение обычных фар (правых - R)
	R_HeadLampAng = Angle(0,0,0), -- угол поворота фар]]

	Headlight_sprites = { -- Обычные фары
		{pos =  Vector(38,114,68),size = 35},
		{pos =  Vector(-38,114,68),size = 35},

		{
			pos = Vector(-18.4,91.2,67.2),
			size = 3,
		    color = Color(255,52,0,150),
		},
		
	},
	Headlamp_sprites = { -- дальние
		{pos =  Vector(38,114,68),size = 35},
		{pos =  Vector(-38,114,68),size = 35},
		
		{pos =  Vector(30,114,69),size = 35},
		{pos =  Vector(-30,114,69),size = 35},

		{
			pos = Vector(-17,91.2,67.2),
			size = 3,
		    color = Color(255,52,0,150),
		},
	},
	FogLight_sprites = {
		{pos =  Vector(13.5,78,97.5),size = 35,OnBodyGroups={[5]={0}}},
		{pos =  Vector(13.5,78,97.5),size = 75,OnBodyGroups={[5]={0}}},
	},
	Rearlight_sprites = { -- задние фары
		{pos = Vector(41,-122,73),size = 25},
		{pos = Vector(-41,-122,73),size = 25},
	},
	Brakelight_sprites = { -- тормозные огни
		{pos = Vector(41,-122,73),size = 25},
		{pos = Vector(-41,-122,73),size = 25},
	},
	
	
	Turnsignal_sprites = {
		Left = {
			Vector(-33.5,116,64.5),
		},
		Right = {
			Vector(33.5,116,64.5),
		},
	},

 
}
list.Set( "simfphys_lights", "simphys_BRDM2", light_table)  


local V = {
	Name = "БРДМ-2",
	Model = "models/vehicles/brdm2/brdm2.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "⛊Бронетранспорт⛊",

	SpawnOffset = Vector(0,0,60),
	SpawnAngleOffset = 0,

	Members = {
		Mass = 3000,
		MaxHealth = 3500,  -- 4050  -- 3000
  
		
		OnTick = function(v)

			if v:GetLightsEnabled() then
				v:SetSubMaterial(6, "models/vehicles/brdm2/brdm2_interior_d_on")
			else
				v:SetSubMaterial(6, "models/vehicles/brdm2/brdm2_interior_d")
			end


			v:SetPoseParameter("vehicle_speedo", v:GetVelocity():Length()/1000)

			if v.VehicleLocked == true then 
				v:SetBodygroup(2,0) 
				--v:SetBodygroup(3,0) 
			else 
				v:SetBodygroup(2,1) 
				--v:SetBodygroup(3,1) 
			end 
		end, 

		ExhaustPositions = {

			{
				pos = Vector(-36,-122,73),
				ang = Angle(160,0,0)
			},
			
			
			{
				pos = Vector(36,-122,73),
				ang = Angle(160,30,0)
			},
			
			------	
			------
			
			{
				pos = Vector(-36,-122,73),
				ang = Angle(160,0,0)
			},
			
			
			{
				pos = Vector(36,-122,73),
				ang = Angle(160,30,0)
			},
			
		},

		OnDelete = function(v) v:SetPoseParameter("vehicle_speedo", v:GetVelocity():Length()/1000) end,		
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 1700,		
		
		LightsTable = "simphys_BRDM2",
		
		FirstPersonViewPos = Vector(0,-15,7), --Vector(0,-43,7), -- Vector(-30,0,70),
		
		IsArmored = true,
		NoWheelGibs = true,
	    FrontWheelRadius = 24,--радиус переднего колеса
		RearWheelRadius = 24,--радиус заднего колеса
		
	    CustomWheels = false,
		CustomSuspensionTravel = 10,
		 
		
		CustomMassCenter = Vector(0,0,5),
		EnginePos = Vector(0,-80,85),
		
		CustomSteerAngle = 25, -- 25
		CustomWheelCamber = 0,
		
		SeatOffset = Vector(58,-13,71),
		SeatPitch = 0,
		SeatYaw = -90,
		
		PassengerSeats = {
			{
                pos = Vector(13,62,37),
                ang = Angle(0,0,0),
        	},
			-- Стрелок
			{
                pos = Vector(0,-10,52),
                ang = Angle(0,0,0),
        	},
			--
			{
                pos = Vector(-13,-30,35),
                ang = Angle(0,0,0),
        	},
			{
                pos = Vector(13,-30,35),
                ang = Angle(0,0,0),
        	},
		 
		 
		},
		
		FrontHeight = 8, -- высота передней подвески
		FrontConstant = 50000,
		FrontDamping = 4000,
		FrontRelativeDamping = 4000,

		RearHeight = 8, -- высота задней подвески
		RearConstant = 50000,
		RearDamping = 4000,
		RearRelativeDamping = 4000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 1.2, -- 2
		
		MaxGrip = 70,  -- 100
		Efficiency = 1.25,
		GripOffset = -4, -- -14 0
		BrakePower = 20,
		BulletProofTires = true,
		
		IdleRPM = 200, -- 228
		LimitRPM = 1575,
		PeakTorque = 80,
		PowerbandStart = 750,
		PowerbandEnd = 1250, -- 1450
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(40,-68,75),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 280, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_2.wav",
		
		ForceTransmission = 1,
		
		DifferentialGear = 0.27,
		Gears = {-0.09,0,0.09,0.18,0.28,0.35}
	}
}
list.Set( "simfphys_vehicles", "simphys_BRDM2", V )

------------------------------------------------


local V = {
	Name = "БРДМ-2У (КМД)", -- БРДМ-2У (командирский)
	Model = "models/vehicles/brdm2/brdm2.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "⛊Бронетранспорт⛊",

	SpawnOffset = Vector(0,0,60),
	SpawnAngleOffset = 0,

	Members = {
		Mass = 2700, -- 3000
		MaxHealth = 3500,  -- 4050  -- 3000
	
		OnSpawn = function(ent)
		   ent:SetBodygroup(1,1) -- Башня
        end,
		OnTick = function(v)

			if v:GetLightsEnabled() then
				v:SetSubMaterial(6, "models/vehicles/brdm2/brdm2_interior_d_on")
			else
				v:SetSubMaterial(6, "models/vehicles/brdm2/brdm2_interior_d")
			end
			
			v:SetPoseParameter("vehicle_speedo", v:GetVelocity():Length()/1000)
		end, 

		ExhaustPositions = {

			{
				pos = Vector(-36,-122,73),
				ang = Angle(160,0,0)
			},
			
			
			{
				pos = Vector(36,-122,73),
				ang = Angle(160,30,0)
			},
			
			------	
			------
			
			{
				pos = Vector(-36,-122,73),
				ang = Angle(160,0,0)
			},
			
			
			{
				pos = Vector(36,-122,73),
				ang = Angle(160,30,0)
			},
			
		},
		
		RPMGaugePP = "vehicle_tacho",
		RPMGaugeMax = 1700,		
		
		LightsTable = "simphys_BRDM2",
		
		FirstPersonViewPos = Vector(0,-15,7),  -- Vector(-30,0,70),
		
		IsArmored = true,
		NoWheelGibs = true,
	    FrontWheelRadius = 24,--радиус переднего колеса
		RearWheelRadius = 24,--радиус заднего колеса
		
	    CustomWheels = false,
		CustomSuspensionTravel = 10,
		 
		
		CustomMassCenter = Vector(0,0,5),
		EnginePos = Vector(0,-80,85),
		
		CustomSteerAngle = 25, -- 25
		CustomWheelCamber = 0,
		
		SeatOffset = Vector(58,-13,71),
		SeatPitch = 0,
		SeatYaw = -90,
		
		PassengerSeats = {
			{
                pos = Vector(13,62,37),
                ang = Angle(0,0,0),
        	},
			-- На ящике
			--[[{
                pos = Vector(-11,23,39.5),
                ang = Angle(0,-90,0),
        	},]]
			--
			{
                pos = Vector(-13,-30,35),
                ang = Angle(0,0,0),
        	},
			{
                pos = Vector(13,-30,35),
                ang = Angle(0,0,0),
        	},
		 
		 
		},
		
		FrontHeight = 8, -- высота передней подвески
		FrontConstant = 50000,
		FrontDamping = 4000,
		FrontRelativeDamping = 4000,

		RearHeight = 8, -- высота задней подвески
		RearConstant = 50000,
		RearDamping = 4000,
		RearRelativeDamping = 4000,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 1.2, -- 2
		
		MaxGrip = 70,  -- 100
		Efficiency = 1.25,
		GripOffset = -4, -- -14 0
		BrakePower = 20,
		BulletProofTires = true,
		
		IdleRPM = 200, -- 228
		LimitRPM = 1575,
		PeakTorque = 80,
		PowerbandStart = 750,
		PowerbandEnd = 1250, -- 1450
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(40,-68,75),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 280, -- 120
		
		PowerBias = 0,
		
		EngineSoundPreset = 0,
		
		Sound_Idle = "simulated_vehicles/misc/Nanjing_loop.wav",
		Sound_IdlePitch = 1,
		
		Sound_Mid = "simulated_vehicles/misc/m50.wav",
		Sound_MidPitch = 1,
		Sound_MidVolume = 1,
		Sound_MidFadeOutRPMpercent = 58,
		Sound_MidFadeOutRate = 0.476,
		
		Sound_High = "simulated_vehicles/misc/v8high2.wav",
		Sound_HighPitch = 1,
		Sound_HighVolume = 0.75,
		Sound_HighFadeInRPMpercent = 58,
		Sound_HighFadeInRate = 0.19,
		
		Sound_Throttle = "",
		Sound_ThrottlePitch = 0,
		Sound_ThrottleVolume = 0,
		
		snd_horn = "simulated_vehicles/horn_2.wav",
		
		ForceTransmission = 1,
		
		DifferentialGear = 0.27,
		Gears = {-0.09,0,0.09,0.18,0.28,0.35}
	}
}
list.Set( "simfphys_vehicles", "simphys_BRDM2m", V )
