
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]__base/lua/entities/gmod_sent_vehicle_fphysics_gib.lua ~

]]

AddCSLuaFile()

ENT.Type            = "anim"

ENT.Spawnable       = false
ENT.AdminSpawnable  = false

if CLIENT then
	local Mat = CreateMaterial("simfphysdamage", "VertexLitGeneric", {["$basetexture"] = "models/player/player_chrome1"})
	
	function ENT:Draw()
		self:DrawModel()
		
		render.ModelMaterialOverride( Mat )
		render.SetBlend( 0.8 )
		self:DrawModel()
		
		render.ModelMaterialOverride()
		render.SetBlend(1)
	end
	net.Receive("simfphys_explosion_fx", function(length)
		local self = net.ReadEntity()
		if IsValid( self ) then
			local effectdata = EffectData()
				effectdata:SetOrigin( self:GetPos() )
			util.Effect( "simfphys_explosion", effectdata )
			util.Effect("lfs_explosion", effectdata) 
		end
	end)
end

if SERVER then
	util.AddNetworkString( "simfphys_explosion_fx" )
	
	function ENT:Initialize()
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )

		--
		self:SetCollisionGroup(COLLISION_GROUP_NONE)
		--
		
		if not IsValid( self:GetPhysicsObject() ) then
			self.RemoveTimer = 0
			
			self:Remove()
			return
		end
		
		self:GetPhysicsObject():EnableMotion(true)
		self:GetPhysicsObject():Wake()
		--self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )  -- !
		self:SetRenderMode( RENDERMODE_TRANSALPHA )

		--timer.Simple(3, function()
			--self:SetCollisionGroup( 1 ) 
		--end) 
		
		timer.Simple( 0.05, function()
			if not IsValid( self ) then return end
			if self.MakeSound == true then
				net.Start( "simfphys_explosion_fx" )
					net.WriteEntity( self )
				net.Broadcast()
				
				util.ScreenShake( self:GetPos(), 555, 555, 2, 5500 ) -- 50, 50, 1.5, 700
				--util.BlastDamage( self, Entity(0), self:GetPos(), 300,200 )
				util.BlastDamage( self, Entity(0), self:GetPos(), 300,90 )

				self.cum = true 

				local Light = ents.Create( "light_dynamic" )
				Light:SetPos( self:GetPos() + Vector( 0, 0, 10 ) )
				local Lightpos = Light:GetPos() + Vector( 0, 0, 10 )
				Light:SetPos( Lightpos )
				Light:SetKeyValue( "_light", "220 40 0 255" )
				Light:SetKeyValue( "style", 1)
				Light:SetKeyValue( "distance", 255 )
				Light:SetKeyValue( "brightness", 2 )
				Light:SetParent( self )
				Light:Spawn()
				Light:Fire( "TurnOn", "", "0" )
				
				timer.Simple( 0.7, function()
					if not IsValid( self ) then return end
					
					self.particleeffect = ents.Create( "info_particle_system" )
					self.particleeffect:SetKeyValue( "effect_name" , "fire_large_01")
					self.particleeffect:SetKeyValue( "start_active" , 1)
					self.particleeffect:SetOwner( self )
					self.particleeffect:SetPos( self:LocalToWorld( self:GetPhysicsObject():GetMassCenter() + Vector(0,0,15) ) )
					self.particleeffect:SetAngles( self:GetAngles() )
					self.particleeffect:Spawn()
					self.particleeffect:Activate()
					self.particleeffect:SetParent( self )
					
					self.FireSound = CreateSound(self, "ambient/fire/firebig.wav")
					self.FireSound:Play()
				end)
				
				timer.Simple( 30, function() -- 120
					if not IsValid( self ) then return end
					
					if IsValid( Light ) then
						Light:Remove()
					end
	 				self.cum = false 
                    --
					--local Col = self:GetColor()
					--Col.r = Col.r * 0.25
					--Col.g = Col.g * 0.25
					--Col.b = Col.b * 0.25
					--self:SetColor(Col)
					--
					
					if IsValid( self.particleeffect ) then
						self.particleeffect:Remove()
					end
					
					if self.FireSound then
						self.FireSound:Stop()
					end
				end)
			else
				self.particleeffect = ents.Create( "info_particle_system" )
				self.particleeffect:SetKeyValue( "effect_name" , "fire_small_03")
				self.particleeffect:SetKeyValue( "start_active" , 1)
				self.particleeffect:SetOwner( self )
				self.particleeffect:SetPos( self:LocalToWorld( self:GetPhysicsObject():GetMassCenter() ) )
				self.particleeffect:SetAngles( self:GetAngles() )
				self.particleeffect:Spawn()
				self.particleeffect:Activate()
				self.particleeffect:SetParent( self )
				self.particleeffect:Fire( "Stop", "", math.random(0.5,3) )
			end
			
		end)

		self.RemoveDis = GetConVar("sv_simfphys_gib_lifetime"):GetFloat()

		self.RemoveTimer = CurTime() + self.RemoveDis
	end

	function ENT:Think()	
		if self.RemoveTimer < CurTime() then
			if self.RemoveDis > 0 then
				self:Remove()
			end
		end
		
		self:NextThink( CurTime() + 0.2 )
		return true
	end

	function ENT:OnRemove()
		if self.FireSound then
			self.FireSound:Stop()
		end
	end

	function ENT:OnTakeDamage( dmginfo )
		self:TakePhysicsDamage( dmginfo )
	end

	function ENT:PhysicsCollide( data, physobj )
	end


	function ENT:Touch(entity)
		 

		if (IsValid(entity) && self.cum == true) && (entity:IsNPC() or entity:IsPlayer()) then
			entity:Ignite(math.Rand(6,12)) -- 3,5
			--entity:Damage(math.Rand(3,5))
			entity:TakeDamage( 1, 1, 1 )	
		end
	end


end