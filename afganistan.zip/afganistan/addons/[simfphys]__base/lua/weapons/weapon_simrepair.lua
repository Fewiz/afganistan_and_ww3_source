
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]__base/lua/weapons/weapon_simrepair.lua ~

]]

AddCSLuaFile()

SWEP.Category			= "Другое"
SWEP.Spawnable			= true
SWEP.AdminSpawnable		= false
SWEP.ViewModel			= "models/weapons/c_physcannon.mdl"
SWEP.WorldModel		= "models/weapons/w_physics.mdl"
SWEP.UseHands = true
SWEP.ViewModelFlip		= false
SWEP.ViewModelFOV		= 53
SWEP.Weight 			= 42
SWEP.AutoSwitchTo 		= true
SWEP.AutoSwitchFrom 	= true
SWEP.HoldType			= "physgun"

SWEP.Damage = 10

SWEP.Primary.ClipSize		= 1250 -- 1500 --  -1 
SWEP.Primary.DefaultClip	= 1250 -- 1500  --  -1
SWEP.Primary.Automatic	= true
SWEP.Primary.Ammo		= "none"

SWEP.Secondary.ClipSize	= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= true
SWEP.Secondary.Ammo		= "none"


SWEP.HealAmount = 10  
SWEP.MaxAmmo = 1250 -- 1500  


if (CLIENT) then
	SWEP.PrintName			= "Ремкомплект"
	SWEP.Purpose			= "Ремонт транспорта simfphys"
	--SWEP.Instructions		= "Почини свой транспорт!"
	SWEP.Author			= "Blu"
	SWEP.Slot			= 1
	SWEP.SlotPos			= 9
	SWEP.IconLetter			= "k"
	
	SWEP.WepSelectIcon 			= surface.GetTextureID( "weapons/s_repair" ) 
	--SWEP.DrawWeaponInfoBox 	= false
end

function SWEP:SetupDataTables()
	self:NetworkVar( "Bool",0, "Active" )
end

function SWEP:Initialize()
	self.Weapon:SetHoldType( self.HoldType )

	if ( CLIENT ) then return end
 
	timer.Create( "rem_ammo" .. self:EntIndex(), 5, 0, function()
		if self:Clip1() != nil then
			if ( self:Clip1() < self.MaxAmmo ) then self:SetClip1( math.min( self:Clip1() + 10, self.MaxAmmo ) ) end
		end 
	end )

end

function SWEP:OwnerChanged()
end

function SWEP:PrimaryAttack()
	self.Weapon:SetNextPrimaryFire( CurTime() + 0.1 )	
	local Trace = self.Owner:GetEyeTrace()
	local ent = Trace.Entity
	
	if !IsValid(ent) then return end
	local class = ent:GetClass():lower()
	
	local IsVehicle = class == "gmod_sent_vehicle_fphysics_base"
	local IsWheel = class == "gmod_sent_vehicle_fphysics_wheel"
	
	if IsVehicle then
		local Dist = (Trace.HitPos - self.Owner:GetPos()):Length()
		
		if (Dist <= 100) then
			self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
			self.Owner:SetAnimation( PLAYER_ATTACK1 )
			
			if (SERVER) then
				local MaxHealth = ent:GetMaxHealth()
				local Health = ent:GetCurHealth()
				
				if Health < MaxHealth and self:Clip1() >= 10 then -- and self:GetPrimaryAmmo() > 20
					local NewHealth = math.min(Health + 10,MaxHealth)

					local NewHeathh_v2 = math.min(Health + self.HealAmount,MaxHealth)
					
					--local ply = LocalPlayer()
					 
					-- ply:addMoney(-55)
 		
					
					if NewHealth > (MaxHealth * 0.6) then
						ent:SetOnFire( false )
						ent:SetOnSmoke( false )
					end
				
					if NewHealth > (MaxHealth * 0.3) then
						ent:SetOnFire( false )
						if NewHealth <= (MaxHealth * 0.6) then
							ent:SetOnSmoke( true )
						end
					end

					--ent:SetCurHealth( NewHealth )	

					--
					local need = self.HealAmount
					self:TakePrimaryAmmo( need )

					ent:SetCurHealth( NewHeathh_v2 )
					--
					
					local effect = ents.Create("env_spark")
						effect:SetKeyValue("targetname", "target")
						effect:SetPos( Trace.HitPos + Trace.HitNormal * 2 )
						effect:SetAngles( Trace.HitNormal:Angle() )
						effect:Spawn()
						effect:SetKeyValue("spawnflags","128")
						effect:SetKeyValue("Magnitude",1)
						effect:SetKeyValue("TrailLength",0.2)
						effect:Fire( "SparkOnce" )
						effect:Fire("kill","",0.08)
				else 
					self.Weapon:SetNextPrimaryFire( CurTime() + 0.5 )
					
					sound.Play(Sound( "hl1/fvox/beep.wav" ), self:GetPos(), 75)
					
					net.Start( "simfphys_lightsfixall" )
						net.WriteEntity( ent )
					net.Broadcast()
					
					if istable(ent.Wheels) then
						for i = 1, table.Count( ent.Wheels ) do
							local Wheel = ent.Wheels[ i ]
							if IsValid(Wheel) then
								Wheel:SetDamaged( false )
							end
						end
					end
				end
			end
		end
	elseif IsWheel then
		local Dist = (Trace.HitPos - self.Owner:GetPos()):Length()
		
		if (Dist <= 100) then
			self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
			self.Owner:SetAnimation( PLAYER_ATTACK1 )
			
			if (SERVER) then
				if ent:GetDamaged() then
					
					ent:SetDamaged( false )
					
					local effect = ents.Create("env_spark")
						effect:SetKeyValue("targetname", "target")
						effect:SetPos( Trace.HitPos + Trace.HitNormal * 2 )
						effect:SetAngles( Trace.HitNormal:Angle() )
						effect:Spawn()
						effect:SetKeyValue("spawnflags","128")
						effect:SetKeyValue("Magnitude",1)
						effect:SetKeyValue("TrailLength",0.2)
						effect:Fire( "SparkOnce" )
						effect:Fire("kill","",0.08)
				else 
					self.Weapon:SetNextPrimaryFire( CurTime() + 0.5 )
					
					sound.Play(Sound( "hl1/fvox/beep.wav" ), self:GetPos(), 75)
				end
			end
		end
	end
end

--[[function SWEP:DrawHUD()
	if (LocalPlayer():InVehicle()) then return end
	
	local screenw = ScrW()
	local screenh = ScrH()
	local Widescreen = (screenw / screenh) > (4 / 3)
	local sizex = screenw * (Widescreen and 1 or 1.32)
	local sizey = screenh
	local xpos = sizex * 0.01
	local ypos = sizey * 0.82
	
	local Trace = self.Owner:GetEyeTrace()
	local ent = Trace.Entity
	
		//////////////////
--	local gradient = surface.GetTextureID("cw2/gui/gradient")
	local x, y = ScrW(), ScrH()
	
	--self.HUDColors.white.a = 255
	--self.HUDColors.black.a = 255
	local baseX, baseY = 250, y - 0
	local baseHeight = 30

	//////////////////////////////////
	
	
	surface.SetDrawColor(0, 0, 0, 225)
	--surface.SetTexture(gradient)
	--surface.DrawTexturedRectRotated(x - 150, y - 100 - baseHeight * 0.5, 300, baseHeight, 180)
	
	--draw.RoundedBox( 0, xpos, ypos, sizex * 0.118, sizey * 0.02, Color( 0, 0, 0, 200 ) )
	
	if (!IsValid(ent)) then
		--draw.SimpleText( "Наведитесь на транспорт!", "simfphysfont", xpos + sizex * 0.059, ypos + sizey * 0.01, Color( 255, 255, 255, 255 ), 1, 1 )
		
		draw.DrawText("Наведитесь на транспорт!", 'abs_hud', x - 10, y - 113 - baseHeight * 0.5, Color( 255, 255, 255, 255 ), TEXT_ALIGN_RIGHT)
		return
	end
	
	local IsVehicle = ent:GetClass():lower() == "gmod_sent_vehicle_fphysics_base"
	
	if (IsVehicle) then
		local MaxHealth = ent:GetMaxHealth()
		local Health = ent:GetCurHealth()
		
		--draw.RoundedBox( 0, xpos, ypos, ((sizex * 0.118) / MaxHealth) * Health, sizey * 0.02, Color( (Health < MaxHealth * 0.6) and 255 or 0, (Health >= MaxHealth * 0.3) and 255 or 0, 0, 100 ) )
		
		--draw.SimpleText( Health.." / "..MaxHealth, "simfphysfont", xpos + sizex * 0.059, ypos + sizey * 0.01, Color( 255, 235, 0, 255 ), 1, 1 )
		draw.DrawText( Health.." / "..MaxHealth, 'abs_hud', x - 10, y - 111 - baseHeight * 0.5,  Color( 255, 255, 255, 255 ), TEXT_ALIGN_RIGHT)
		
	else 
		draw.SimpleText( "0 / 0", 'abs_hud', x - 10, y - 111 - baseHeight * 0.5,  Color( 255, 255, 255, 255 ), 1, 1 )
	end
end]]

function SWEP:Think()
	if not self:CanSecondaryAttack() then return end
	
	if self.Owner:GetMoveType() ~= MOVETYPE_NOCLIP then
		if self.Owner:KeyDown( IN_JUMP ) then
			self.Owner:SetVelocity( Vector(0,0,1000) * FrameTime() )
			if self.Owner:GetMoveType() ~= MOVETYPE_FLY then
				self.Owner:SetMoveType( MOVETYPE_FLY  )
			end
		else
			if self.Owner:GetMoveType() ~= MOVETYPE_WALK then
				self.Owner:SetMoveType( MOVETYPE_WALK  )
			end
		end
		if self.Owner:KeyDown( IN_USE ) then
			self.Owner:SetVelocity( self.Owner:GetAimVector() * 1200 * FrameTime() )
		end
	end
	
	if SERVER then
		self.Weapon.NextHeal = self.Weapon.NextHeal or 0
		
		if self.Weapon.NextHeal <= CurTime() then
			self.Weapon.NextHeal = CurTime() + 0.05
			
			self.Owner:SetHealth( self.Owner:Health() + math.Clamp(200 - self.Owner:Health(),-1,1) )
			self.Owner:SetArmor( self.Owner:Armor() + math.Clamp(200 - self.Owner:Armor(),-1,1) )
		end
	end
end

function SWEP:ShootBullet( damage, num_bullets, aimcone )
	self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
	
	self.Weapon.Time = self.Weapon.Time or CurTime()
	
	local bullet = {}

	bullet.Num 	= num_bullets
	bullet.Src 	= self.Owner:GetShootPos()
	bullet.Dir 	= self.Owner:GetAimVector()
	bullet.Spread 	= Vector( aimcone, aimcone, 0 )
	bullet.Tracer		= 0
	bullet.Force	= 50
	bullet.HullSize 	= 1
	bullet.Damage	= damage
	bullet.AmmoType = "Pistol"
	bullet.Callback = function(att, tr, dmginfo)
		dmginfo:SetDamageType(DMG_AIRBOAT)
		dmginfo:SetAttacker( Entity(0) )
		dmginfo:SetInflictor( Entity(0) ) 
		
		util.BlastDamage( Entity(0) , Entity(0), tr.HitPos,200,200)
		
		if SERVER then
			if self.Weapon.Time < CurTime() then
				self.Weapon.Time = CurTime() + 0.1
				
				for _, v in pairs(ents.FindInSphere( tr.HitPos, 50 )) do
					if v:IsPlayer() then
						if v:HasGodMode() then
							v:Kill()
							
							sound.Play( "vo/ravenholm/monk_mourn0"..math.random(1,7)..".wav",v:GetPos() )
						end
					end
				end
			end
		end
	end

	self.Owner:FireBullets( bullet )
end

function SWEP:CanSecondaryAttack()
	if CLIENT then return self:GetActive() end
	
	local table = self.Owner.TOOLMemory
	
	if not istable( table ) then 
		self:SetActive( false )
		
		return false
	end
	
	local Enable = isstring( table[1] ) and string.StartWith( table[1], "Fa" ) 
	if self:GetActive() ~= Enable then
		self:SetActive( Enable )
	end
	
	return Enable
end

function SWEP:SecondaryAttack()
	if self:CanSecondaryAttack() then
		for i = 1, 20 do
			self:ShootBullet( 100, 1, math.Rand(-0.05,0.05) )
		end
		
		self:SetNextSecondaryFire( CurTime() + 0.001 )
	end
end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
	return true
end

function SWEP:Holster()
	return true
end