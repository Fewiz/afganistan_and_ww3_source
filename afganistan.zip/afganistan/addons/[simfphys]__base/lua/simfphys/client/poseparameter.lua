
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]__base/lua/simfphys/client/poseparameter.lua ~

]]

local function receiveppdata( length )
	local ent = net.ReadEntity()
	
	if IsValid( ent ) then
		ent.CustomWheels = net.ReadBool()
		
		if not ent.CustomWheels then
			local wheelFL = net.ReadEntity()
			local posFL = net.ReadFloat()
			local travelFL = net.ReadFloat()
			
			local wheelFR = net.ReadEntity()
			local posFR = net.ReadFloat()
			local travelFR = net.ReadFloat()
			
			local wheelRL = net.ReadEntity()
			local posRL = net.ReadFloat()
			local travelRL = net.ReadFloat()
			
			local wheelRR = net.ReadEntity()
			local posRR = net.ReadFloat()
			local travelRR = net.ReadFloat()
			
			if not IsValid( wheelFL ) or not IsValid( wheelFR ) or not IsValid( wheelRL ) or not IsValid( wheelRR ) then return end
			
			ent.pp_data = {
				[1] = {
					name = "vehicle_wheel_fl_height",
					entity = wheelFL,
					pos = posFL,
					travel = travelFL,
					dradius = (wheelFL:BoundingRadius() * 0.28),
				},
				[2] = {
					name = "vehicle_wheel_fr_height",
					entity = wheelFR,
					pos = posFR,
					travel = travelFR,
					dradius = (wheelFR:BoundingRadius() * 0.28),
				},
				[3] = {
					name = "vehicle_wheel_rl_height",
					entity = wheelRL,
					pos = posRL,
					travel = travelRL,
					dradius = (wheelRL:BoundingRadius() * 0.28),
				},
				[4] = {
					name = "vehicle_wheel_rr_height",
					entity = wheelRR,
					pos = posRR,
					travel = travelRR,
					dradius = (wheelRR:BoundingRadius() * 0.28),
				},
			}
		end
	end
end
net.Receive("simfphys_send_ppdata", receiveppdata)