
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]__base/lua/autorun/simfphys_prewar.lua ~

]]

local Category = "Транспорт"

local light_table = {

	
	Headlight_sprites = { 
		Vector(118.8,30.5,41.8),
		Vector(118.8,-35,41.8)
	},
	Headlamp_sprites = {
		Vector(118.8,30.5,41.8),
		Vector(118.8,-35,41.8)
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(116.88,36.33,53.57),
			Vector(115.4,37.9,53.59),
			Vector(113.67,39.87,53.72),
			Vector(-100.76,20.37,18.99),
			Vector(-100.71,18.55,18.97),
			Vector(-100.71,16.69,19.1),
		},
		Right = {
			Vector(114.88,-40.33,53.57),
			Vector(113.4,-41.9,53.59),
			Vector(111.67,-43.87,53.72),
			Vector(-100.76,-22.37,18.99),
			Vector(-100.71,-20.55,18.97),
			Vector(-100.71,-18.69,19.1),
		},
	}
}
list.Set( "simfphys_lights", "avia", light_table)


local light_table = {

	
	Headlight_sprites = { 
		{pos = Vector(-36.87,87.86,47.32),material = "sprites/light_ignorez",size = 64},
		{pos = Vector(-36.87,87.86,47.32),size = 75},
		
		{pos = Vector(36.33,87.27,46.67),material = "sprites/light_ignorez",size = 64},
		{pos = Vector(36.33,87.27,46.67),size = 75}
	},
	Headlamp_sprites = { 
		{pos = Vector(-36.87,87.86,47.32),size = 110},
		{pos = Vector(36.33,87.27,46.67),size = 110}
	},
	Rearlight_sprites = {
		Vector(43.04,-194,21.05),
		Vector(43.03,-194,22.49),
		Vector(43.23,-194,23.34),
		Vector(43.14,-194,24.32),
		
		Vector(-43.04,-194,21.05),
		Vector(-43.03,-194,22.49),
		Vector(-43.23,-194,23.34),
		Vector(-43.14,-194,24.32)
	},
	Brakelight_sprites = {
		Vector(43.04,-194,21.05),
		Vector(43.03,-194,22.49),
		Vector(43.23,-194,23.34),
		Vector(43.14,-194,24.32),
		
		Vector(-43.04,-194,21.05),
		Vector(-43.03,-194,22.49),
		Vector(-43.23,-194,23.34),
		Vector(-43.14,-194,24.32)
	},
	FrontMarker_sprites = {
		Vector(55.4,-156.48,56.9),
		Vector(56.74,-70.56,55.19),
		Vector(50,73.98,57.71),
		Vector(-53.4,-156.48,56.9),
		Vector(-54,-70.56,55.19),
		Vector(-50,73.98,57.71)
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(-38.2,87.81,58.93),
			Vector(-42.96,-193.67,28.29),
		},
		Right = {
			Vector(37.8,87.41,58.52),
			Vector(43.38,-194.54,28.99),
		},
	}
}
list.Set( "simfphys_lights", "gaz", light_table)


local light_table = {

	
	Headlight_sprites = { 
		Vector(71.15,23.26,27.92),
		Vector(71.07,-23.15,27.95)
	},
	Headlamp_sprites = { 
		{pos = Vector(71.15,23.26,27.92),size = 80, color = Color( 220,205,160,50)},
		{pos = Vector(71.07,-23.15,27.95),size = 80, color = Color( 220,205,160,50)},
	},
	Rearlight_sprites = {
		Vector(-72,22,29),Vector(-72,23.5,29),Vector(-72,25,29),Vector(-72,26.5,29),Vector(-72,28,29),Vector(-72,29.5,29),Vector(-72,31,29),
		Vector(-72,-22,29),Vector(-72,-23.5,29),Vector(-72,-25,29),Vector(-72,-26.5,29),Vector(-72,-28,29),Vector(-72,-29.5,29),Vector(-72,-31,29),
	},
	Brakelight_sprites = {
		Vector(-72,22,29),Vector(-72,23.5,29),Vector(-72,25,29),Vector(-72,26.5,29),Vector(-72,28,29),Vector(-72,29.5,29),Vector(-72,31,29),
		Vector(-72,-22,29),Vector(-72,-23.5,29),Vector(-72,-25,29),Vector(-72,-26.5,29),Vector(-72,-28,29),Vector(-72,-29.5,29),Vector(-72,-31,29),
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(-72.14,29.97,31.85),
			Vector(-72.14,27.97,31.85),
			Vector(-72.14,25.97,31.85),
			Vector(72.19,24.97,20.34),
		},
		Right = {
			Vector(-72.54,-30.32,31.81),
			Vector(-72.54,-28.32,31.81),
			Vector(-72.54,-26.32,31.81),
			Vector(72.19,-24.6,20.34),
		},
	},
}
list.Set( "simfphys_lights", "golf", light_table)

local light_table = {

	Headlight_sprites = { 
		{pos = Vector(-36.74,121.35,45.43),material = "sprites/light_ignorez",size = 40},
		{pos = Vector(-36.74,121.35,45.43),size = 55},
		
		{pos = Vector(32.15,118.88,45.13),material = "sprites/light_ignorez",size = 40},
		{pos = Vector(32.15,118.88,45.13),size = 55},
	},
	Headlamp_sprites = { 
		{pos = Vector(-36.74,121.35,45.43),size = 80},
		{pos = Vector(32.15,118.88,45.13),size = 80},
	},
	Rearlight_sprites = {
		Vector(-47,-133.97,28.14),
		Vector(44.13,-134.42,27.34),
	},
	Reverselight_sprites = {
		Vector(32.33,-134.11,27.34),
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(-39.88,119.03,66.5),
		},
		Right = {
			Vector(36.11,119.71,66.5),
		},
		
		TurnBrakeLeft = {
			Vector(-47,-133.97,28.14),
		},
		
		TurnBrakeRight = {
			Vector(44.13,-134.42,27.34),
		},
	},
}
list.Set( "simfphys_lights", "liaz", light_table)

local light_table = {

	
	Headlight_sprites = { 
		{pos = Vector(75.7,28.09,31.28),material = "sprites/light_ignorez",size = 32, color = Color( 220,205,160,255)},
		{pos = Vector(75.7,28.09,31.28),size = 64, color = Color( 220,205,160,50)},
		
		{pos = Vector(75.7,-28.09,31.28),material = "sprites/light_ignorez",size = 32, color = Color( 220,205,160,255)},
		{pos = Vector(75.7,-28.09,31.28),size = 64, color = Color( 220,205,160,50)},
	},
	Headlamp_sprites = { 
		{pos = Vector(75.7,28.09,31.28),size = 80, color = Color( 220,205,160,80)},
		{pos = Vector(75.7,-28.09,31.28),size = 80, color = Color( 220,205,160,80)},
	},
	Rearlight_sprites = {
		Vector(-99.8,21.57,29.93),Vector(-99.86,23.01,29.9),Vector(-99.75,24.52,29.92),
		Vector(-99.8,-21.57,29.93),Vector(-99.86,-23.01,29.9),Vector(-99.75,-24.52,29.92),
	},
	Brakelight_sprites = {
		Vector(-99.8,21.57,29.93),Vector(-99.86,23.01,29.9),Vector(-99.75,24.52,29.92),
		Vector(-99.8,-21.57,29.93),Vector(-99.86,-23.01,29.9),Vector(-99.75,-24.52,29.92),
	},
	Reverselight_sprites = {
		Vector(-99.98,27.41,30.76),
		Vector(-99.98,-27.41,30.76)
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(80.52,25.03,20.21),
			Vector(80.47,23.03,20.25),
			Vector(-100.5,18.95,29.97),
		},
		Right = {
			Vector(80.52,-25.03,20.21),
			Vector(80.47,-23.03,20.25),
			Vector(-100.5,-18.95,29.97),
		},
	},
}
list.Set( "simfphys_lights", "moskvich", light_table)

local light_table = {

	
	Headlight_sprites = { 
		Vector(-28.77,70.69,30.73),
		Vector(29.13,70.77,30.58)
	},
	Headlamp_sprites = { 
		{pos = Vector(-28.77,70.69,30.73),size = 80, color = Color( 220,205,160,50)},
		{pos = Vector(29.13,70.77,30.58),size = 80, color = Color( 220,205,160,50)},
	},
	Rearlight_sprites = {
		Vector(30.83,-78.44,24.),Vector(30.83,-78.44,25),Vector(30.83,-78.44,26),
		Vector(-30.83,-78.50,24),Vector(-30.83,-78.50,25),Vector(-30.83,-78.50,26)
	},
	Brakelight_sprites = {
		Vector(30.83,-78.44,24.),Vector(30.83,-78.44,25),Vector(30.83,-78.44,26),
		Vector(-30.83,-78.50,24),Vector(-30.83,-78.50,25),Vector(-30.83,-78.50,26),
		
		Vector(2,-67,56.5),
		Vector(0,-67,57),
		Vector(-2,-67,56.5),
		
	},
	Reverselight_sprites = {
		Vector(30.77,-76.39,20.09),
		Vector(-31.01,-76.14,20.29),
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(-28.5,70.97,20.41),
			Vector(-30,70.97,20.41),
			Vector(-31.5,70.97,20.41),
			
			Vector(-30.63,-79,34),
			Vector(-30.63,-79.,32),
			Vector(-30.63,-79,30),
			Vector(-30.63,-79,28),
		},
		Right = {
			Vector(28.5,70.97,20.41),
			Vector(30,70.97,20.41),
			Vector(31.5,70.97,20.41),
			
			Vector(30.63,-79,34),
			Vector(30.63,-79.,32),
			Vector(30.63,-79,30),
			Vector(30.63,-79,28),
		},
	}
}
list.Set( "simfphys_lights", "trabbi", light_table)




local light_table = {

	
	Headlight_sprites = { 
		Vector(-28.77,70.69,30.73),
		Vector(29.13,70.77,30.58)
	},
	Headlamp_sprites = { 
		{pos = Vector(-28.77,70.69,30.73),size = 80, color = Color( 220,205,160,50)},
		{pos = Vector(29.13,70.77,30.58),size = 80, color = Color( 220,205,160,50)},
	},
	Rearlight_sprites = {
		Vector(30.83,-78.44,24.),Vector(30.83,-78.44,25),Vector(30.83,-78.44,26),
		Vector(-30.83,-78.50,24),Vector(-30.83,-78.50,25),Vector(-30.83,-78.50,26)
	},
	Brakelight_sprites = {
		Vector(30.83,-78.44,24.),Vector(30.83,-78.44,25),Vector(30.83,-78.44,26),
		Vector(-30.83,-78.50,24),Vector(-30.83,-78.50,25),Vector(-30.83,-78.50,26),
		
		Vector(2,-51,56.5),
		Vector(0,-51,57),
		Vector(-2,-51,56.5),
		
	},
	Reverselight_sprites = {
		Vector(30.77,-76.39,20.09),
		Vector(-31.01,-76.14,20.29),
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(-28.5,70.97,20.41),
			Vector(-30,70.97,20.41),
			Vector(-31.5,70.97,20.41),
			
			Vector(-30.63,-79,34),
			Vector(-30.63,-79.,32),
			Vector(-30.63,-79,30),
			Vector(-30.63,-79,28),
		},
		Right = {
			Vector(28.5,70.97,20.41),
			Vector(30,70.97,20.41),
			Vector(31.5,70.97,20.41),
			
			Vector(30.63,-79,34),
			Vector(30.63,-79.,32),
			Vector(30.63,-79,30),
			Vector(30.63,-79,28),
		},
	}
}
list.Set( "simfphys_lights", "trabbi2", light_table)

local light_table = {

	
	Headlight_sprites = { 
		Vector(97.41,33.55,37.05),Vector(97.45,36.17,37.08),Vector(97.61,38.86,37.14),
		Vector(97.25,-33.56,37.04),Vector(97.23,-36.19,37.03),Vector(97.13,-38.64,37.08)
	},
	Headlamp_sprites = { 
		Vector(97.45,36.17,37.08),
		Vector(97.23,-36.19,37.03)
	},
	Rearlight_sprites = {
		{pos = Vector(-117,-32.5,41),material = "sprites/light_ignorez",size = 35,color = Color( 255, 60, 0,  125)},
		{pos = Vector(-117,-32.5,41),size = 45,color = Color( 255, 0, 0,  250)},
		
		{pos = Vector(-117,32.5,41),material = "sprites/light_ignorez",size = 35,color = Color( 255, 60, 0,  125)},
		{pos = Vector(-117,32.5,41),size = 45,color = Color( 255, 0, 0,  250)},
	},
	Reverselight_sprites = {
		Vector(-117,-32.5,45),Vector(-117,-34.5,45),Vector(-117,-30.5,45),
		Vector(-117,32.5,45),Vector(-117,34.5,45),Vector(-117,30.5,45)
	},
	
	Turnsignal_sprites = {
		Left = {
			Vector(96.64,36.27,27.21),
			Vector(96.64,35,27.21),
		},
		Right = {
			Vector(96.64,-36.27,27.21),
			Vector(96.64,-35,27.21),
		},
		TurnBrakeLeft = {
			{pos = Vector(-117,32.5,41),material = "sprites/light_ignorez",size = 50},
			{pos = Vector(-117,32.5,41),size = 55},
		},
		TurnBrakeRight = {
			{pos = Vector(-117,-32.5,41),material = "sprites/light_ignorez",size = 50},
			{pos = Vector(-117,-32.5,41),size = 55},
		},
	},
}
list.Set( "simfphys_lights", "van", light_table)

local light_table = {

	
	Headlight_sprites = { 
		Vector(91.33,30.44,30.63),
		Vector(91.33,-30.44,30.63)
	},
	Headlamp_sprites = { 
		Vector(91.33,30.44,30.63),
		Vector(91.33,-30.44,30.63)
	},
	Rearlight_sprites = {
		{pos = Vector(-102.23,30,35.85),material = "sprites/light_ignorez",size = 35,color = Color( 255, 60, 0,  125)},
		{pos = Vector(-102.23,30,35.85),size = 45,color = Color( 255, 0, 0,  90)},
		
		{pos = Vector(-102.23,-30,35.85),material = "sprites/light_ignorez",size = 35,color = Color( 255, 60, 0,  125)},
		{pos = Vector(-102.23,-30,35.85),size = 45,color = Color( 255, 0, 0,  90)},
	},
	Brakelight_sprites = {
		{pos = Vector(-102.23,-30,35.85),material = "sprites/light_ignorez",size = 45,color = Color( 255, 60, 0,  125)},
		{pos = Vector(-102.23,-30,35.85),size = 50,color = Color( 255, 0, 0,  150)},
		
		{pos = Vector(-102.23,30,35.85),material = "sprites/light_ignorez",size = 45,color = Color( 255, 60, 0,  125)},
		{pos = Vector(-102.23,30,35.85),size = 50,color = Color( 255, 0, 0,  150)},
	},
	Reverselight_sprites = {
		Vector(-101.8,-29.4,30.7),Vector(-101.8,-31.09,30.7),
		Vector(-101.8,29.4,30.7),Vector(-101.8,31.09,30.7),
	},
	Turnsignal_sprites = {
		Left = {
			Vector(-102.62,31,33.24),
			Vector(-102.62,29,33.24),
			Vector(92.09,31,22.4),
			Vector(91.71,33,22.4),
		},
		Right = {
			Vector(-102.62,-31,33.24),
			Vector(-102.62,-29,33.24),
			Vector(92.09,-31,22.4),
			Vector(91.71,-33,22.4),
		},
	},
}
list.Set( "simfphys_lights", "volga", light_table)

local light_table = {

	
	Headlight_sprites = { 
		Vector(87.3,29.59,35.42),
		Vector(87.34,-31.76,35.52)
	},
	Headlamp_sprites = { 
		Vector(87.3,29.59,35.42),
		Vector(87.34,-31.76,35.52)
	},
	
	Rearlight_sprites = {
		Vector(-95.5,21,34),Vector(-95.5,21,33),Vector(-95.5,21,32),Vector(-95.5,22.25,34),Vector(-95.5,22.25,32),Vector(-95.5,23.5,34),Vector(-95.5,23.5,33),Vector(-95.5,23.5,32),
		Vector(-95.5,-23.5,34),Vector(-95.5,-23.5,33),Vector(-95.5,-23.5,32),Vector(-95.5,-24.75,34),Vector(-95.5,-24.75,32),Vector(-95.5,-26,34),Vector(-95.5,-26,33),Vector(-95.5,-26,32)
	},
	Brakelight_sprites = {
		Vector(-95.5,15.5,34.8),Vector(-95.5,15.5,33.4),Vector(-95.5,15.5,32.6),Vector(-95.5,15.5,31.2),
		Vector(-95.5,-18,34.8),Vector(-95.5,-18,33.4),Vector(-95.5,-18,32.6),Vector(-95.5,-18,31.2)
	},
	Reverselight_sprites = {
		Vector(-95.5,18.25,34.8),Vector(-95.5,18.25,33.4),Vector(-95.5,18.25,32.6),Vector(-95.5,18.25,31.2),
		Vector(-95.5,-20.75,34.8),Vector(-95.5,-20.75,33.4),Vector(-95.5,-20.75,32.6),Vector(-95.5,-20.75,31.2)
	},
	Turnsignal_sprites = {
		Left = {
			Vector(86.78,22.39,31.92),
			Vector(-95.41,26.7,33.76),
			Vector(-95.42,26.72,32.22),
		},

		Right = {
			Vector(86.78,-24.39,31.92),
			Vector(-95.41,-28.7,33.76),
			Vector(-95.42,-28.72,32.22),
		},
	},
}
list.Set( "simfphys_lights", "zaz", light_table)


local V = {
	Name = "Гольф",
	Model = "models/blu/hatchback/pw_hatchback.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "︾Зарубежный︾",
	SpawnAngleOffset = 90,

	Members = {
		Mass = 800,
		
		MaxHealth = 900,  -- 1200
 
 
		EnginePos = Vector(54.27,0,37.26),
		
		LightsTable = "golf",
		
		CustomWheels = true,
		CustomSuspensionTravel = 10,
		
		CustomWheelModel = "models/salza/hatchback/hatchback_wheel.mdl",
		CustomWheelPosFL = Vector(44.5,29,12),
		CustomWheelPosFR = Vector(44.5,-29,12),
		CustomWheelPosRL = Vector(-46,29.5,12),
		CustomWheelPosRR = Vector(-46,-29.5,12),
		CustomWheelAngleOffset = Angle(0,90,0),
		
		CustomMassCenter = Vector(0,0,2),
		
		CustomSteerAngle = 25,  -- 35
		
		SeatOffset = Vector(-8.5,-16,44),
		SeatPitch = 0,
		SeatYaw = 90,
		
		PassengerSeats = {
			{
				pos = Vector(5,-16,14),
				ang = Angle(0,-90,20)
			},
			{
				pos = Vector(-24,-16,14),
				ang = Angle(0,-90,20)
			},
			{
				pos = Vector(-24,16,14),
				ang = Angle(0,-90,20)
			}
		},
		
		FrontHeight = 6.5,
		FrontConstant = 20000,
		FrontDamping = 1000,
		FrontRelativeDamping = 500,
		
		RearHeight = 6.5,
		RearConstant = 20000,
		RearDamping = 1000,
		RearRelativeDamping = 500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 3, -- 4
		
		MaxGrip = 15, -- 23 -- 15
		Efficiency = 1, -- 1
		GripOffset = -1.7, -- -0.7,
		BrakePower = 25,
		 
		IdleRPM = 750,
		LimitRPM = 2255,
		PeakTorque = 45, -- 45
		PowerbandStart = 750,
		PowerbandEnd = 2055,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-61.59,32.11,31.83),
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 55,
		
		PowerBias = -1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/4banger/4banger_idle.wav",
		
		snd_low = "simulated_vehicles/4banger/4banger_low.wav",
		snd_low_pitch = 0.9,
		
		snd_mid = "simulated_vehicles/4banger/4banger_mid.wav",
		snd_mid_gearup = "simulated_vehicles/4banger/4banger_second.wav",
		snd_mid_pitch = 0.8,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.78,
		Gears = {-0.08,0,0.08,0.18,0.26,0.33}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwhatchback", V )


local V = {
	Name = "Микроавтобус Раф",
	Model = "models/blu/van/pw_van.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☭Советский☭",
	SpawnAngleOffset = 90,
	
	Members = {
		Mass = 2500,

		EnginePos = Vector(89.98,0,51.3),
		
		LightsTable = "van",
		
		CustomWheels = true,
		CustomSuspensionTravel = 10,
		
		CustomWheelModel = "models/salza/van/van_wheel.mdl",
		CustomWheelPosFL = Vector(45,44,20),
		CustomWheelPosFR = Vector(45,-44,20),
		CustomWheelPosRL = Vector(-72,44,20),
		CustomWheelPosRR = Vector(-72,-44,20),
		CustomWheelAngleOffset = Angle(0,-90,0),
		
		CustomMassCenter = Vector(0,0,15),
		
		CustomSteerAngle = 35,
		
		SeatOffset = Vector(36,-23,72),
		SeatPitch = 8,
		SeatYaw = 90,
		
		PassengerSeats = {
			{
				pos = Vector(45,-27,33),
				ang = Angle(0,-90,9)
			},
			{
				pos = Vector(45,0,33),
				ang = Angle(0,-90,9)
			},
			{
				pos = Vector(-38,-29,28),
				ang = Angle(0,0,0)
			},
				{
				pos = Vector(-38,32,37),
				ang = Angle(0,180,0)
			},
							{
				pos = Vector(-10,32,37),
				ang = Angle(0,180,0)
			}
		},
		
		FrontHeight = 12,
		FrontConstant = 45000,
		FrontDamping = 3500,
		FrontRelativeDamping = 3500,
		
		RearHeight = 12,
		RearConstant = 45000,
		RearDamping = 3500,
		RearRelativeDamping = 3500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 350,
		
		TurnSpeed = 3,
		
		MaxGrip = 30,
		Efficiency = 1.8,
		GripOffset = -2,
		BrakePower = 15,
		
		IdleRPM = 750,
		LimitRPM = 1600,
		PeakTorque = 65,
		PowerbandStart = 800,
		PowerbandEnd = 1500,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-93.45,46.02,42.24),
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 65,
		
		PowerBias = 1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/generic3/generic3_idle.wav",
		
		snd_low = "simulated_vehicles/generic3/generic3_low.wav",
		snd_low_revdown = "simulated_vehicles/generic3/generic3_revdown.wav",
		snd_low_pitch = 0.9,
		
		snd_mid = "simulated_vehicles/generic3/generic3_mid.wav",
		snd_mid_gearup = "simulated_vehicles/generic3/generic3_second.wav",
		snd_mid_pitch = 1,
		
		DifferentialGear = 0.52,
		Gears = {-0.1,0,0.1,0.2,0.3,0.4}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwvan", V )


local V = {
	Name = "Москвич",
	Model = "models/blu/moskvich/moskvich.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☭Советский☭",
	SpawnAngleOffset = 90,

	Members = {
		Mass = 1350,
		
		--OnTick = function(ent) print("hi") end,
		--OnSpawn = function(ent) print("i spawned") end,
		--OnDelete = function(ent) print("im removed :(") end,
		--OnDestroyed = function(ent) print("im destroyed :((((") end,
 
		EnginePos = Vector(55.76,0,44.4),
		
		LightsTable = "moskvich",
		
		CustomWheels = true,
		CustomSuspensionTravel = 10, -- 10
		
		CustomWheelModel = "models/salza/moskvich/moskvich_wheel.mdl",
		CustomWheelPosFL = Vector(52,32,12),
		CustomWheelPosFR = Vector(52,-32,12),
		CustomWheelPosRL = Vector(-55,29.5,12),
		CustomWheelPosRR = Vector(-55,-29.5,12),
		CustomWheelAngleOffset = Angle(0,0,0),
		
		CustomMassCenter = Vector(0,0,2.5),
		
		CustomSteerAngle = 25, -- 35
		
		SeatOffset = Vector(-12,-16,49),
		SeatPitch = 0,
		SeatYaw = 90,
		
		PassengerSeats = {
			{
				pos = Vector(-4,-16,17.5),
				ang = Angle(0,-90,10)
			},
			{
				pos = Vector(-40,16,19),
				ang = Angle(0,-90,10)
			},
			{
				pos = Vector(-40,-16,19),
				ang = Angle(0,-90,10)
			}
		},
		
		FrontHeight = 6.5,
		FrontConstant = 25000,
		FrontDamping = 1500,
		FrontRelativeDamping = 1500,
		
		RearHeight = 6.5,
		RearConstant = 25000,
		RearDamping = 1500,
		RearRelativeDamping = 1500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 3, -- 4
		
		MaxGrip = 25, -- 30
		Efficiency = 1,
		GripOffset = -1.5, --  -1.5,
		BrakePower = 38,
		
		IdleRPM = 750,
		LimitRPM = 1620,
		PeakTorque = 75*1.5,
		PowerbandStart = 750,
		PowerbandEnd = 1450,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-78.34,33.36,33.18),
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 65,
		
		PowerBias = 1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/generic1/generic1_idle.wav",
		
		snd_low = "simulated_vehicles/generic1/generic1_low.wav",
		snd_low_revdown = "simulated_vehicles/generic1/generic1_revdown.wav",
		snd_low_pitch = 0.8,
		
		snd_mid = "simulated_vehicles/generic1/generic1_mid.wav",
		snd_mid_gearup = "simulated_vehicles/generic1/generic1_second.wav",
		snd_mid_pitch = 1.1,
		
		snd_horn = "simulated_vehicles/horn_5.wav",
		
		DifferentialGear = 0.6,
		Gears = {-0.1,0,0.1,0.18,0.26,0.34,0.42}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwmoskvich", V )



local V = {
	Name = "Трабант",
	Model = "models/blu/trabant/trabant.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "︾Зарубежный︾",

	Members = {
		Mass = 850,
		
		EnginePos = Vector(0.6,56.38,38.7),
		
		LightsTable = "trabbi",
		
		FirstPersonViewPos =  Vector(0,-15,6),
		
		AirFriction = -8000,
		
		CustomWheels = true,
		CustomSuspensionTravel = 10,
		
		CustomWheelModel = "models/salza/trabant/trabant_wheel.mdl",
		CustomWheelPosFL = Vector(-32,50,12),
		CustomWheelPosFR = Vector(32,50,12),
		CustomWheelPosRL = Vector(-32,-41.5,12),
		CustomWheelPosRR = Vector(32,-41.5,12),
		CustomWheelAngleOffset = Angle(0,0,0),
		
		CustomMassCenter = Vector(0,0,3),
		
		CustomSteerAngle = 35,
		
		SeatOffset = Vector(-8.5,-16,46),
		SeatPitch = 0,
		SeatYaw = 0,
		
		PassengerSeats = {
			{
				pos = Vector(16,-2,13.5),
				ang = Angle(0,0,8)
			},

		},
		
		FrontHeight = 7,
		FrontConstant = 20000,
		FrontDamping = 1800,
		FrontRelativeDamping = 1800,
		
		RearHeight = 7,
		RearConstant = 20000,
		RearDamping = 1800,
		RearRelativeDamping = 1800,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		 
		TurnSpeed = 3, -- 4
		
		MaxGrip = 20, -- 30
		Efficiency = 1.1,
		GripOffset = -1,
		BrakePower = 20,
		
		IdleRPM = 750,
		LimitRPM = 1700,
		PeakTorque = 35*1.5,
		PowerbandStart = 300,
		PowerbandEnd = 1300,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(5.41,46.61,39.91),
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 65,
		
		PowerBias = -1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 0.9,
		snd_idle = "simulated_vehicles/generic5/generic5_idle.wav",
		
		snd_low = "simulated_vehicles/generic5/generic5_low.wav",
		snd_low_revdown = "simulated_vehicles/generic5/generic5_revdown.wav",
		snd_low_pitch = 0.7,
		
		snd_mid = "simulated_vehicles/generic5/generic5_mid.wav",
		snd_mid_gearup = "simulated_vehicles/generic5/generic5_gear.wav",
		snd_mid_pitch = 0.7,
		
		DifferentialGear = 0.6,
		Gears = {-0.1,0,0.1,0.2,0.28}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwtrabant", V )



local V = {
	Name = "Трабант 2",
	Model = "models/blu/trabant/trabant02.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "︾Зарубежный︾",

	Members = {
		Mass = 850,
		
		AirFriction = -8000,
		
		EnginePos = Vector(0,56.38,38.7),
		
		FirstPersonViewPos =  Vector(0,-15,6),
		
		LightsTable = "trabbi2",
		
		CustomWheels = true,
		CustomSuspensionTravel = 10,
		
		CustomWheelModel = "models/salza/trabant/trabant02_wheel.mdl",
		CustomWheelPosFL = Vector(-32,50,12),
		CustomWheelPosFR = Vector(32,50,12),
		CustomWheelPosRL = Vector(-32,-41.5,12),
		CustomWheelPosRR = Vector(32,-41.5,12),
		CustomWheelAngleOffset = Angle(0,0,0),
		
		CustomMassCenter = Vector(0,0,3),
		
		CustomSteerAngle = 35,
		
		SeatOffset = Vector(-8.5,-16,46),
		SeatPitch = 0,
		SeatYaw = 0,
		
		PassengerSeats = {
			{
				pos = Vector(16,-2,13.5),
				ang = Angle(0,0,8)
			},
			
				{
				pos = Vector(-15,-39,13.5),
				ang = Angle(0,0,8)
			},
			
				{
				pos = Vector(15,-39,13.5),
				ang = Angle(0,0,8)
			},

		},
		
		FrontHeight = 7,
		FrontConstant = 20000,
		FrontDamping = 1800,
		FrontRelativeDamping = 1800,
		
		RearHeight = 7,
		RearConstant = 20000,
		RearDamping = 1800,
		RearRelativeDamping = 1800,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 3, --4
		
		MaxGrip = 20, -- 30
		Efficiency = 1.1,
		GripOffset = -1,
		BrakePower = 20,
		
		IdleRPM = 750,
		LimitRPM = 1700,
		PeakTorque = 75,
		PowerbandStart = 300,
		PowerbandEnd = 1300,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(5.41,46.61,39.91),
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 65,
		
		PowerBias = -1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 0.9,
		snd_idle = "simulated_vehicles/generic5/generic5_idle.wav",
		
		snd_low = "simulated_vehicles/generic5/generic5_low.wav",
		snd_low_revdown = "simulated_vehicles/generic5/generic5_revdown.wav",
		snd_low_pitch = 0.7,
		
		snd_mid = "simulated_vehicles/generic5/generic5_mid.wav",
		snd_mid_gearup = "simulated_vehicles/generic5/generic5_gear.wav",
		snd_mid_pitch = 0.7,
		
		DifferentialGear = 0.6,
		Gears = {-0.1,0,0.1,0.2,0.28}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwtrabant02", V )


local V = {
	Name = "Волга",
	Model = "models/blu/volga/volga.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☭Советский☭", -- Транспорт
	SpawnAngleOffset = 90,

	Members = {
		Mass = 1350,
		
		EnginePos = Vector(65.39,0,44.84),
		
		LightsTable = "volga",
		
		CustomWheels = true,
		CustomSuspensionTravel = 10,
		
		CustomWheelModel = "models/salza/volga/volga_wheel.mdl",
		CustomWheelPosFL = Vector(64,37,13),
		CustomWheelPosFR = Vector(64,-37,13),
		CustomWheelPosRL = Vector(-55,35,13),
		CustomWheelPosRR = Vector(-55,-35,13),
		CustomWheelAngleOffset = Angle(0,-90,0),
		
		CustomMassCenter = Vector(0,0,3.5),
		
		CustomSteerAngle = 35,
		
		SeatOffset = Vector(-4,-17.5,50),
		SeatPitch = 5,
		SeatYaw = 90,
		
		PassengerSeats = {
			{
				pos = Vector(6,-17.5,18),
				ang = Angle(0,-90,12)
			},
			{
				pos = Vector(-30,-17.5,18),
				ang = Angle(0,-90,12)
			},
			{
				pos = Vector(-30,17.5,18),
				ang = Angle(0,-90,12)
			},

		},
		
		FrontHeight = 6.5,
		FrontConstant = 25000,
		FrontDamping = 1300,
		FrontRelativeDamping = 1300,
		
		RearHeight = 6.5,
		RearConstant = 25000,
		RearDamping = 1300,
		RearRelativeDamping = 1300,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 2.5, -- 3
		
		MaxGrip = 20, -- 30
		Efficiency = 1,
		GripOffset = -1.5,
		BrakePower = 38,
		
		IdleRPM = 750,
		LimitRPM = 2250,
		PeakTorque = 75,
		PowerbandStart = 750,
		PowerbandEnd = 2000,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-80.3,37.79,35.54),
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 65,
		
		PowerBias = 1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/generic2/generic2_idle.wav",
		
		snd_low = "simulated_vehicles/generic2/generic2_low.wav",
		snd_low_revdown = "simulated_vehicles/generic2/generic2_revdown.wav",
		snd_low_pitch = 1,
		
		snd_mid = "simulated_vehicles/generic2/generic2_mid.wav",
		snd_mid_gearup = "simulated_vehicles/generic2/generic2_second.wav",
		snd_mid_pitch = 1.1,
		
		snd_horn = "simulated_vehicles/horn_5.wav",
		
		DifferentialGear = 0.62,
		Gears = {-0.1,0,0.1,0.18,0.26,0.31,0.38}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwvolga", V )


local V = {
	Name = "Запорожец",
	Model = "models/blu/zaz/zaz.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "☭Советский☭",
	SpawnAngleOffset = 90,

	Members = {
		Mass = 800,

        MaxHealth = 1050,  -- 1200
 
		EnginePos = Vector(-77,0,47.96),
		
		LightsTable = "zaz",
		
		CustomWheels = true,
		CustomSuspensionTravel = 10,
		
		CustomWheelModel = "models/salza/zaz/zaz_wheel.mdl",
		CustomWheelPosFL = Vector(61,32,17),
		CustomWheelPosFR = Vector(61,-34,17),
		CustomWheelPosRL = Vector(-53,32,17),
		CustomWheelPosRR = Vector(-53,-34,17),
		CustomWheelAngleOffset = Angle(0,90,0),
		
		CustomMassCenter = Vector(0,0,3.5),
		
		CustomSteerAngle = 25,  -- 35
		
		SeatOffset = Vector(-3,-17.5,54),
		SeatPitch = 5,
		SeatYaw = 90,
 
		
		PassengerSeats = {
			{
				pos = Vector(6,-17.5,20),
				ang = Angle(0,-90,12)
			},
			{
				pos = Vector(-30,-17.5,24),
				ang = Angle(0,-90,12)
			},
			{
				pos = Vector(-30,17.5,24),
				ang = Angle(0,-90,12)
			},

		},
		
		FrontHeight = 6.5,
		FrontConstant = 25000,
		FrontDamping = 1300,
		FrontRelativeDamping = 1300,
		
		RearHeight = 6.5,
		RearConstant = 25000,
		RearDamping = 1300,
		RearRelativeDamping = 1300,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 400,
		
		TurnSpeed = 3, -- 4
		
		MaxGrip = 15, -- 30
		Efficiency = 1,
		GripOffset = -1.5,
		BrakePower = 38,
		
		IdleRPM = 750,
		LimitRPM = 2075,
		PeakTorque = 45,  -- 75
		PowerbandStart = 600,
		PowerbandEnd = 1800,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-67.9,-37.75,38.59),
		--FuelType = FUELTYPE_PETROL,
		FuelTankSize = 65,
		
		PowerBias = 1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/generic3/generic3_idle.wav",
		
		snd_low = "simulated_vehicles/generic3/generic3_low.wav",
		snd_low_revdown = "simulated_vehicles/generic3/generic3_revdown.wav",
		snd_low_pitch = 0.9,
		
		snd_mid = "simulated_vehicles/generic3/generic3_mid.wav",
		snd_mid_gearup = "simulated_vehicles/generic3/generic3_second.wav",
		snd_mid_pitch = 0.9,
		
		DifferentialGear = 0.42,
		Gears = {-0.1,0,0.1,0.17,0.24,0.3,0.37,0.41}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwzaz", V )








local V = {
	Name = "Авия",
	Model = "models/blu/avia/avia.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "︾Зарубежный︾",
	SpawnAngleOffset = 90,

	Members = {
		Mass = 2500,
		
		EnginePos = Vector(49.37,-2.41,44.13),
		
		LightsTable = "avia",
		
		CustomWheels = true,
		CustomSuspensionTravel = 10,
		
		CustomWheelModel = "models/salza/avia/avia_wheel.mdl",
		CustomWheelPosFL = Vector(78,37,17),
		CustomWheelPosFR = Vector(78,-40,17),
		CustomWheelPosRL = Vector(-55,38.5,17),
		CustomWheelPosRR = Vector(-55,-37,17),
		CustomWheelAngleOffset = Angle(0,180,0),
		
		CustomMassCenter = Vector(0,0,5),
		
		CustomSteerAngle = 35,
		
		SeatOffset = Vector(55,-20,95),
		SeatPitch = 15,
		SeatYaw = 90,
		
		PassengerSeats = {
			{
				pos = Vector(79,-21,45),
				ang = Angle(0,-90,0)
			}
		},
		
		FrontHeight = 8,
		FrontConstant = 40000,
		FrontDamping = 3500,
		FrontRelativeDamping = 3500,
		
		RearHeight = 8,
		RearConstant = 40000,
		RearDamping = 3500,
		RearRelativeDamping = 3500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 3, -- 4
		
		MaxGrip = 49,
		Efficiency = 1.1,
		GripOffset = -2,
		BrakePower = 45,	
		
		IdleRPM = 750,
		LimitRPM = 1300,
		PeakTorque = 100,
		PowerbandStart = 600,
		PowerbandEnd = 1000,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(9.79,35.14,30.77),
		--FuelType = FUELTYPE_DIESEL,
		FuelTankSize = 100,
		
		PowerBias = 1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/jeep/jeep_idle.wav",
		
		snd_low = "simulated_vehicles/jeep/jeep_low.wav",
		snd_low_revdown = "simulated_vehicles/jeep/jeep_revdown.wav",
		snd_low_pitch = 0.9,
		
		snd_mid = "simulated_vehicles/jeep/jeep_mid.wav",
		snd_mid_gearup = "simulated_vehicles/jeep/jeep_second.wav", 
		snd_mid_pitch = 1,
		
		DifferentialGear = 0.45,
		Gears = {-0.15,0,0.15,0.25,0.35,0.45,0.52}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_pwavia", V )


////////////////////////////////////////////////////////



local light_table = {

	DelayOn = 0.5,
	DelayOff = 0.25,
	BodyGroups = {
		On = {8,0},
		Off = {8,1}
	},
	
		Headlight_sprites = {
		{pos = Vector(102,27.5,-1),material = "sprites/light_ignorez",size = 20, color = Color( 220,205,160,120)},
		{pos = Vector(102,-27.5,-1),material = "sprites/light_ignorez",size = 20, color = Color( 220,205,160,120)},
		{pos = Vector(102,21,-1),material = "sprites/light_ignorez",size = 20, color = Color( 220,205,160,120)},
		{pos = Vector(102,-21,-1),material = "sprites/light_ignorez",size = 20, color = Color( 220,205,160,120)},
		
		{pos = Vector(102,27.5,-1),size = 60, color = Color( 220,205,160,50)},
		{pos = Vector(102,-27.5,-1),size = 60, color = Color( 220,205,160,50)},
		{pos = Vector(102,21,-1),size = 60, color = Color( 220,205,160,50)},
		{pos = Vector(102,-21,-1),size = 60, color = Color( 220,205,160,50)},
	},
	Headlamp_sprites = {
		{pos = Vector(102,27.5,-1),material = "sprites/light_ignorez",size = 80, color = Color( 220,205,160,70)},
		{pos = Vector(102,-27.5,-1),material = "sprites/light_ignorez",size = 80, color = Color( 220,205,160,70)},
		{pos = Vector(102,21,-1),material = "sprites/light_ignorez",size = 80, color = Color( 220,205,160,70)},
		{pos = Vector(102,-21,-1),material = "sprites/light_ignorez",size = 80, color = Color( 220,205,160,70)},
	},
	Rearlight_sprites = {
		{pos = Vector(-121,25.5,5),material = "sprites/light_ignorez",size = 45,color = Color( 255, 0, 0,  150)},
		{pos = Vector(-121,-25.5,5),material = "sprites/light_ignorez",size = 45,color = Color( 255, 0, 0,  150)},
	},
	Brakelight_sprites = {
		{pos = Vector(-121,13.5,5),material = "sprites/light_ignorez",size = 45,color = Color( 255, 0, 0,  150)},
		{pos = Vector(-121,-13.5,5),material = "sprites/light_ignorez",size = 45,color = Color( 255, 0, 0,  150)},
	},
	Reverselight_sprites = {
		{pos = Vector(-121,19.5,5),material = "sprites/light_ignorez",size = 25,color = Color( 255, 255, 255, 100)},
		{pos = Vector(-121,-19.5,5),material = "sprites/light_ignorez",size = 25,color = Color( 255, 255, 255, 100)},
	},
	
	--Turnsignal_sprites = {
	--	Left = {
	--		Vector(103.28,27,-9.54),
	--		Vector(103.28,28.5,-9.54),
	--		{pos = Vector(-121,25.5,5),material = "sprites/light_ignorez",size = 55,color = Color( 255, 0, 0,  165)},
	--	},
	--	Right = {
	--		Vector(103.28,-27,-9.54),
	--		Vector(103.28,-28.5,-9.54),
	--		{pos = Vector(-121,-25.5,5),material = "sprites/light_ignorez",size = 55,color = Color( 255, 0, 0,  165)},
	--	},
	--},
	
		Turnsignal_sprites = {
		Left = {
			Vector(103.28,27,-9.54),
			Vector(103.28,28.5,-9.54),
			{pos = Vector(-121,25.5,5),material = "sprites/light_ignorez",size = 55,color = Color( 255, 0, 0,  165)},
		},
		Right = {
			Vector(103.28,-27,-9.54),
			Vector(103.28,-28.5,-9.54),
			{pos = Vector(-121,-25.5,5),material = "sprites/light_ignorez",size = 55,color = Color( 255, 0, 0,  165)},
		},
	},
	
	
	
	SubMaterials = {
		off = {
			Base = {
				[10] = ""
			},
			Brake = {
				[10] = "models/gtav/dukes/lights/brake"
			},
			Reverse = {
				[10] = "models/gtav/dukes/lights/reverse"
			},
			Brake_Reverse = {
				[10] = "models/gtav/dukes/lights/brake_reverse"
			},
		},
		on_lowbeam = {
			Base = {
				[10] = "models/gtav/dukes/lights/lowbeam"
			},
			Brake = {
				[10] = "models/gtav/dukes/lights/lowbeam_brake"
			},
			Reverse = {
				[10] = "models/gtav/dukes/lights/lowbeam_reverse"
			},
			Brake_Reverse = {
				[10] = "models/gtav/dukes/lights/lowbeam_brake_reverse"
			},
		},
		on_highbeam = {
			Base = {
				[10] = "models/gtav/dukes/lights/highbeam"
			},
			Brake = {
				[10] = "models/gtav/dukes/lights/highbeam_brake"
			},
			Reverse = {
				[10] = "models/gtav/dukes/lights/highbeam_reverse"
			},
			Brake_Reverse = {
				[10] = "models/gtav/dukes/lights/highbeam_brake_reverse"
			},
		},
	}
}
list.Set( "simfphys_lights", "dukes", light_table)

local V = {
	Name = "Dodge Charger R/T",  -- Дукес
	Model = "models/blu/gtav/dukes/dukes.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "★Премиум★", -- Транспорт
	SpawnOffset = Vector(0,0,20),
	SpawnAngleOffset = 90,

	Members = {
		Mass = 1700,
		
		EnginePos = Vector(69,0,15),
		
		LightsTable = "dukes",
		
		
		ModelInfo = {
		Color=Color(75,75,75),
		}, 
		
		OnSpawn = function(ent)
		ent:SetSubMaterial(9, "models/XQM/Rails/gumball_1")	    -- Салон
		--ent:SetColor(math.random(0,255),math.random(0,255),math.random(0,255))  
		////
		--ent:SetBodygroup(1,math.random(0,1))
		--ent:SetBodygroup(2,math.random(0,5))
		
        end,
		
		
		
		
 
		
		-- OnTick = function(ent)
        --     ////////////////  Смена материалов //////////////////
        --     ent:SetSubMaterial(9, "models/XQM/Rails/gumball_1")	    -- Салон
        -- end,
		
		
	 
		
		CustomWheels = true,
		CustomSuspensionTravel = 14,  -- 15
		
		CustomWheelModel = "models/winningrook/gtav/dukes/dukes_wheel.mdl",
		CustomWheelPosFL = Vector(63.5,36,-13),
		CustomWheelPosFR = Vector(63.5,-36,-13),
		CustomWheelPosRL = Vector(-64,36.5,-9),
		CustomWheelPosRR = Vector(-64,-36.5,-9),
		CustomWheelAngleOffset = Angle(0,-90,0),
		
		CustomMassCenter = Vector(0,0,5),
		
		CustomSteerAngle = 32, -- 32
		
		SeatOffset = Vector(-18,-18,19),
		SeatPitch = 0,
		SeatYaw = 90,
		
		PassengerSeats = {
			{
				pos = Vector(-3,-19,-13),
				ang = Angle(0,-90,17)
			},
				{
				pos = Vector(-36,16,-13),
				ang = Angle(0,-90,17)
			},
				{
				pos = Vector(-36,-16,-13),
				ang = Angle(0,-90,17)
			}
		},
		
		ExhaustPositions = {
			{
				pos = Vector(-122.25,20.93,-7.28),
				ang = Angle(90,165,0),
				OnBodyGroups = { 
					[6] = {0},
				}
			},
			{
				pos = Vector(-122.1,-20.95,-7.42),
				ang = Angle(90,195,0),
				OnBodyGroups = { 
					[6] = {0},
				}
			},
			{
				pos = Vector(-43.43,-38.07,-12.96),
				ang = Angle(90,-125,0),
				OnBodyGroups = { 
					[6] = {1},
				}
			},
			{
				pos = Vector(-35.28,-40.72,-13.18),
				ang = Angle(90,-125,0),
				OnBodyGroups = { 
					[6] = {1},
				}
			},
			{
				pos = Vector(-43.43,38.07,-12.96),
				ang = Angle(90,125,0),
				OnBodyGroups = { 
					[6] = {1},
				}
			},
			{
				pos = Vector(-35.28,40.72,-13.18),
				ang = Angle(90,125,0),
				OnBodyGroups = { 
					[6] = {1},
				}
			}
		},
		
		FrontHeight = 8,
		FrontConstant = 29000,
		FrontDamping = 2500,
		FrontRelativeDamping = 2500,
		
		RearHeight = 9,
		RearConstant = 29000,
		RearDamping = 2500,
		RearRelativeDamping = 2500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 7,
		
		MaxGrip = 55,  -- 30 -- 25 65
		Efficiency = 1.2,
		GripOffset = -2,
		BrakePower = 30,  -- 40
		
		IdleRPM = 600,
		LimitRPM = 6850,  -- 2200   -- 203 км/ч  6650 (6850 стояло долго и хорошо)
		PeakTorque = 120,  -- 120*1.5  -- 80
		PowerbandStart = 750,
		PowerbandEnd = 6000,  -- 2000
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(-92.72,39.75,8.31),
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 80,
		
		PowerBias = 1,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 0.8,
		snd_idle = "simulated_vehicles/gta5_dukes/dukes_idle.wav",
		
		snd_low = "simulated_vehicles/gta5_dukes/dukes_low.wav",
		snd_low_revdown = "simulated_vehicles/gta5_dukes/dukes_revdown.wav",
		snd_low_pitch = 0.8,
		
		snd_mid = "simulated_vehicles/gta5_dukes/dukes_mid.wav",
		snd_mid_gearup = "simulated_vehicles/gta5_dukes/dukes_second.wav",
		snd_mid_pitch = 1,
		
		snd_horn = "simulated_vehicles/horn_3.wav",
		
		DifferentialGear = 0.3, --  0.6,
		Gears = {-0.12,0,0.12,0.21,0.32,0.42,0.5}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_dukes", V )


////////////////////////////////////////////////////



local light_table = {

	
	Headlight_sprites = { 
		Vector(-12.25,67.23,22.33),
		Vector(-3.91,67.03,22.14),
		Vector(4.63,66.33,21.96),
		Vector(13.4,66.72,22.16)
	},
	Headlamp_sprites = { 
		Vector(-12.25,67.23,22.33),
		Vector(-3.91,67.03,22.14),
		Vector(4.63,66.33,21.96),
		Vector(13.4,66.72,22.16)
	},
	Rearlight_sprites = {
		Vector(-14.8,-99.9,39.13),

		
		
		
		
		Vector(-6,-75,72.13),
		Vector(-4,-75,72.13),
		
		Vector(-1,-75,72.13),
		Vector(1,-75,72.13),
		
		Vector(6,-75,72.13),
		Vector(4,-75,72.13)
	},
	
	FogLight_sprites = { -- противотуманки
		Vector(14.3,-59.87,70.12),
		Vector(7.34,-58.62,70.32),
		Vector(-7.79,-58.55,70.09),
		Vector(-14.97,-60.01,69.99)
	},
	
	
	Brakelight_sprites = {
		Vector(-14.9,-99.9,39.1),
		Vector(-14,-99.9,39.13),
		
		Vector(-15,-99.9,41),
		Vector(-14,-99.9,41),
		
	},
}
list.Set( "simfphys_lights", "elitejeep", light_table)


local V = {
	Name = "Багги",
	Model = "models/vehicles/buggy_elite.mdl",
	Class = "gmod_sent_vehicle_fphysics_base",
	Category = "︾Зарубежный︾", -- Транспорт

	Members = {
		Mass = 1700, --
		
		LightsTable = "elitejeep",
		
		FrontWheelRadius = 18,
		RearWheelRadius = 20,
		
		SeatOffset = Vector(0,0,-3),
		SeatPitch = 0,
		SpeedoMax = 35,
		
		PassengerSeats = {
			{
			pos = Vector(16,-35,21),
			ang = Angle(0,0,9)
			}
		},
		
		Backfire = true,
		ExhaustPositions = {
			{
				pos = Vector(-15.69,-105.94,14.94),
				ang = Angle(90,-90,0)
			},
			{
				pos = Vector(16.78,-105.46,14.35),
				ang = Angle(90,-90,0)
			}
		},
		
		StrengthenSuspension = true,
		
		FrontHeight = 10,  -- 13.5,
		FrontConstant = 27000,
		FrontDamping = 2200,
		FrontRelativeDamping = 1500, 
		
		RearHeight = 10,   -- 13.5,
		RearConstant = 32000,
		RearDamping = 2200,
		RearRelativeDamping = 1500,
		
		FastSteeringAngle = 10,
		SteeringFadeFastSpeed = 535,
		
		TurnSpeed = 7,
		
		MaxGrip = 25, -- 30
		Efficiency = 1.4,
		GripOffset = 0,
		BrakePower = 40,
		
		IdleRPM = 750,
		LimitRPM = 2700,  -- 2300
		PeakTorque = 120,  -- 75*1.5,
		PowerbandStart = 750,
		PowerbandEnd = 2100,
		Turbocharged = false,
		Supercharged = false,
		
		FuelFillPos = Vector(20.92,6.95,26.83),
		FuelType = FUELTYPE_PETROL,
		FuelTankSize = 75, -- 65
		
		PowerBias = 0.6,
		
		EngineSoundPreset = -1,
		
		snd_pitch = 1,
		snd_idle = "simulated_vehicles/v8elite/v8elite_idle.wav",
		
		snd_low = "simulated_vehicles/v8elite/v8elite_low.wav",
		snd_low_revdown = "simulated_vehicles/v8elite/v8elite_revdown.wav",
		snd_low_pitch = 0.8,
		
		snd_mid = "simulated_vehicles/v8elite/v8elite_mid.wav",
		snd_mid_gearup = "simulated_vehicles/v8elite/v8elite_second.wav",
		snd_mid_pitch = 1,
		
		snd_horn = "simulated_vehicles/horn_4.wav",
		
		DifferentialGear = 0.38,
		Gears = {-0.1,0,0.1,0.18,0.25,0.31,0.40}
	}
}
list.Set( "simfphys_vehicles", "sim_fphys_v8elite", V ) --привет


////////////////////////////////////////////////////////


