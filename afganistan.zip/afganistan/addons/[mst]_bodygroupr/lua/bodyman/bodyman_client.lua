
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_bodygroupr/lua/bodyman/bodyman_client.lua ~

]]

include("bodyman/bodyman_config.lua")

if BODYMAN.French == true then
	BODYMAN.HelpText = BODYMAN.HelpText_Fr
	BODYMAN.ClosetHelpText = BODYMAN.ClosetHelpText_Fr
	BODYMAN.strings = BODYMAN.strings_fr
	BODYMAN.ClosetName = BODYMAN.ClosetName_Fr
end

surface.CreateFont("Bodygroups_Small", {
	font = "Roboto",
	size = 18,
	antialias = true,
	weight = 800
})

surface.CreateFont("Bodygroups_Medium", {
	font = "Roboto",
	size = 24,
	antialias = true,
	weight = 800
})

surface.CreateFont("Bodygroups_Large", {
	font = "Roboto",
	size = 42,
	antialias = true,
	weight = 800
})

function InverseLerp( pos, p1, p2 )

	local range = 0
	range = p2-p1

	if range == 0 then return 1 end

	return ((pos - p1)/range)

end

include("bodyman/arizard_derma.lua")

function BODYMAN:Chat( msg )
	chat.AddText(HexColor("#3498db"), "[Шкаф] ", Color(255,255,255), msg)-- bodyGroupr
end 

net.Receive("bodyman_chatprint", function()
	local msg = net.ReadString()
	BODYMAN:Chat( msg )
end)

BODYMAN.MenuIsOpen = false
BODYMAN.Menu = nil

timer.Create("IsBodyGrouprMenuStillValid", 3, 0, function()
	if BODYMAN.MenuIsOpen == true and BODYMAN.ClosetsOnly == true then
		if not BODYMAN:CloseEnoughCloset( LocalPlayer() ) then
			if IsValid(BODYMAN.Menu) then
				BODYMAN.Menu:Close()
			end
		end
	end
end)

function BODYMAN:OpenMenu()

	self.MenuIsOpen = true

	if self.ClosetsOnly == true then
		if self:CloseEnoughCloset( LocalPlayer() ) == false then
			return false
		end
	end
 

	local frame = vgui.Create("arizard_window")
	frame:SetSize( ScrW()*.95, ScrH()*.95 ) -- ScrW()*.75, ScrH()*.85 
	frame:Center()
	frame:SetPrimaryColor( Color(46,47,50) ) --  HexColor("#3498db")
	frame:SetSecondaryColor( Color(25,28,32) ) -- HexColor("#ecf0f1", 4) 
	frame:SetTitle("Шкаф") -- bodyGroupr
	frame:MakePopup()

	self.Menu = frame

	function frame:OnClose()
		BODYMAN.MenuIsOpen = false
	end

	local pmodel = vgui.Create("DModelPanel", frame)
	pmodel:SetSize( pmodel:GetParent():GetWide()*(2/3) - 8, pmodel:GetParent():GetTall() - 40 )
	pmodel:SetPos( 4, 32 )

	pmodel:SetModel( LocalPlayer():GetModel() )

	pmodel:SetLookAt( Vector(0,0,72/2) )
	pmodel:SetCamPos( Vector(64,0,72/2))
	--pmodel:SetLookAng( Angle(0,0,0) )

	pmodel.Entity:SetEyeTarget( pmodel.Entity:GetPos() + Vector(200,0,64) )

	pmodel:SetAmbientLight( Color(10,15,50) )
	pmodel:SetDirectionalLight( BOX_TOP, Color(220,190,100) )

	pmodel.rot = 110
	pmodel.fov = 20
	pmodel:SetFOV( pmodel.fov )
	pmodel.dragging = false -- left click
	pmodel.dragging2 = false -- right click
	pmodel.ux = 0
	pmodel.uy = 0
	pmodel.spinmul = 0.4
	pmodel.zoommul = 0.09

	pmodel.xmod = 0
	pmodel.ymod = 0
 

	BODYMAN.ClientModelPanel = pmodel

	pmodel.Entity:SetSkin( LocalPlayer():GetSkin() )

	-- set pmodel's bodygroups
	local curgroups = LocalPlayer():GetBodyGroups()
	--PrintTable( curgroups )

	for k,v in pairs( curgroups ) do
		local ent = pmodel.Entity
		local cur_bgid = LocalPlayer():GetBodygroup( v.id )
		ent:SetBodygroup( v.id, cur_bgid )
	end

	function pmodel.Entity:GetPlayerColor()
		return LocalPlayer():GetPlayerColor()
	end

	function pmodel:PaintOver( w, h )
		--surface.SetDrawColor( Color(255,255,255) )
		--surface.DrawOutlinedRect(0,0,w,h)
		ArizardShadowText(BODYMAN.HelpText, "Bodygroups_Medium", 0,0, Color(255,255,255,150), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1 ) -- 
	end

	function pmodel:LayoutEntity( ent )

		local newrot = self.rot
		local newfov = self:GetFOV()

		if self.dragging == true then
			newrot = self.rot + (gui.MouseX() - self.ux)*self.spinmul
			newfov = self.fov + (self.uy - gui.MouseY()) * self.zoommul
			if newfov < 20 then newfov = 20 end
			if newfov > 75 then newfov = 75 end
		end

		local newxmod, newymod = self.xmod, self.ymod

		if self.dragging2 == true then
			newxmod = self.xmod + (self.ux - gui.MouseX())*0.02
			newymod = self.ymod + (self.uy - gui.MouseY())*0.02
		end

		newxmod = math.Clamp( newxmod, -16, 16 )
		newymod = math.Clamp( newymod, -16, 16 )

		ent:SetAngles( Angle(0,0,0) )
		self:SetFOV( newfov )

		-- calculate if we should look at the face
		local height = 72/2
		-- fov between 20 and 75,
		-- height between 72/2 and 72
		local frac = InverseLerp( newfov, 75, 20 )
		height = Lerp( frac, 72/2, 64 )

		-- calculate look ang
		local norm = (self:GetCamPos() - Vector(0,0,64))
		norm:Normalize()
		local lookAng = norm:Angle()

		self:SetLookAt( Vector(0,0,height-(2*frac) ) - Vector( 0, 0, newymod*2*(1-frac) ) - lookAng:Right()*newxmod*2*(1-frac) )
		self:SetCamPos( Vector( 64*math.sin( newrot * (math.pi/180)), 64*math.cos( newrot * (math.pi/180)), height + 4*(1-frac)) - Vector( 0, 0, newymod*2*(1-frac) ) - lookAng:Right()*newxmod*2*(1-frac) )

	end

	function pmodel:OnMousePressed( k )
		self.ux = gui.MouseX()
		self.uy = gui.MouseY()
		self.dragging = (k == MOUSE_LEFT) or false 
		self.dragging2 = (k == MOUSE_RIGHT) or false 
	end

	function pmodel:OnMouseReleased( k )
		if self.dragging == true then
			self.rot = self.rot + (gui.MouseX() - self.ux)*self.spinmul
			self.fov = self.fov + (self.uy - gui.MouseY()) * self.zoommul
			self.fov = math.Clamp( self.fov, 20, 75 )
		end

		if self.dragging2 == true then
			self.xmod = self.xmod + (self.ux - gui.MouseX())*0.02
			self.ymod = self.ymod + (self.uy - gui.MouseY())*0.02

			self.xmod = math.Clamp( self.xmod, -16, 16 )
			self.ymod = math.Clamp( self.ymod, -16, 16 )
		end

		self.dragging = false 
		self.dragging2 = false
	end

	function pmodel:OnCursorExited()
		if self.dragging == true or self.dragging2 == true then
			self:OnMouseReleased()
		end
	end

	-- now for the controls
	local cpan = vgui.Create("DPanel", frame)
	cpan:SetSize( cpan:GetParent():GetWide()*(1/3)-4, cpan:GetParent():GetTall() - 44 )
	cpan:SetPos( 4+4+cpan:GetParent():GetWide()*(2/3)-8, 32)
	function cpan:Paint() end

	local cpanscroll = vgui.Create("DScrollPanel", cpan)
	cpanscroll:SetSize( cpanscroll:GetParent():GetWide(), cpanscroll:GetParent():GetTall() )
	cpanscroll:SetPos(0,0)

	-- style the scroll button:
	local sbar = cpanscroll:GetVBar()
	sbar:SetWide( 6 )
	function sbar:Paint( w, h )
	end
	function sbar.btnUp:Paint( w, h )
	end
	function sbar.btnDown:Paint( w, h )
	end
	function sbar.btnGrip:Paint( w, h )
		draw.RoundedBox((w-1)/2, 1,0,w-1,h,Color(0,0,0,200))
	end

	local cpanlist = vgui.Create("DIconLayout", cpanscroll)
	cpanlist:SetSize( cpanscroll:GetWide()-8, cpanscroll:GetTall() - 8 )
	cpanlist:SetPos( 4, 4 )
	cpanlist:SetSpaceX( 4 )
	cpanlist:SetSpaceY( 4 )

	self.cpanlist = cpanlist
	self.cpanscroll = cpanscroll

	self:RefreshAppearanceMenu( )
	
end

function BODYMAN:RefreshAppearanceMenu( )

	local cpanlist, cpanscroll = self.cpanlist, self.cpanscroll

	if ( not IsValid( cpanlist ) ) or ( not IsValid( cpanscroll ) ) then return end

	-- reload the bodygropes
	self.ClientModelPanel.Entity:SetSkin( LocalPlayer():GetSkin() )

	-- set pmodel's bodygroups
	local curgroups = LocalPlayer():GetBodyGroups()
	--PrintTable( curgroups )

	for k,v in pairs( curgroups ) do
		local ent = self.ClientModelPanel.Entity
		local cur_bgid = LocalPlayer():GetBodygroup( v.id )
		ent:SetBodygroup( v.id, cur_bgid )
	end

	self.ClientModelPanel.Entity:SetEyeTarget( self.ClientModelPanel.Entity:GetPos() + Vector(200,0,64) )

	cpanlist:Clear()

	--[[local title = cpanlist:Add( "DLabel" )
	title:SetText( BODYMAN.strings.Appearance )
	title:SetFont("Bodygroups_Large")
	title:SetTextColor( HexColor("#ffffff") )
	title:SizeToContents()
	title:SetWide( cpanscroll:GetWide() )
	title:SetExpensiveShadow(1,Color(0,0,0))]]

	local job = LocalPlayer():GetJobTable() -- local job = LocalPlayer():getJobTable()

	-- do models
	local playermodels = job.model

	if type( playermodels ) == "table" then
		--if #playermodels != 1 then 
			local modeltitle = cpanlist:Add("DLabel")
			modeltitle:SetText( BODYMAN.strings.Playermodels )
			modeltitle:SetFont("Bodygroups_Medium")
			modeltitle:SetTextColor( HexColor("#eeeeee") )
			modeltitle:SizeToContents()
			modeltitle:SetWide( cpanscroll:GetWide() )
			modeltitle:SetExpensiveShadow(1,Color(0,0,0))

			 
				for k=1,#playermodels do
					local mdl = playermodels[k]

					local btn = cpanlist:Add( "arizard_button" )
					btn:SetWide( (cpanlist:GetWide()-8)/2 - 8 )
					btn:SetTall( 28 )

					-- reduce the filepath to it's model name, without extension
					local args = string.Split( mdl, "/" )
					local mdlname = args[ #args ]
					mdlname = string.sub( mdlname, 1, -5)

					btn:SetText( mdlname )
					if #playermodels == 1 then 
						btn:SetText( "Сбросить настройки" )
					end
					if LocalPlayer():GetModel() == mdl then
						btn:SetText( "Выбранная ("..k..")" )
					else 
						btn:SetText( "Модель ("..k..")")	
					end 
					btn.mdlpath = mdl
					btn.mdlidx = k

					--btn:SetColors(HexColor("#1110b9"), HexColor("#1118db")) -- HexColor("#1110b9"), HexColor("#1118db")
					btn:SetColors( Color(46,47,50), Color(75,75,80) ) 

					function btn:DoClick()
						surface.PlaySound("server/ui/click2.wav")
						BODYMAN.ClientModelPanel:SetModel( self.mdlpath )

						net.Start("bodyman_model_change")
						net.WriteInt( self.mdlidx, 8 )
						net.SendToServer()

						BODYMAN:RefreshAppearanceMenu( )
					end
				end
		--end 	
	end

	-- do skins
	
	local skintable = {}

	if job.skins then
		skintable = job.skins
	else
		skintable = {}
		for i=0,LocalPlayer():SkinCount()-1 do
			table.insert( skintable, i )
		end
	end
	------------------------------------
	--print(LocalPlayer():SkinCount())
	if LocalPlayer():SkinCount() != 1 then 
		if skintable != {} then
			local skintitle = cpanlist:Add("DLabel")
			skintitle:SetText( BODYMAN.strings.Skins )
			skintitle:SetFont("Bodygroups_Medium")
			skintitle:SetTextColor( HexColor("#eeeeee") )
			skintitle:SizeToContents()
			skintitle:SetWide( cpanscroll:GetWide() )
			skintitle:SetExpensiveShadow(1,Color(0,0,0))

			for k,i in ipairs(skintable) do
				if BODYMAN:HasSkin( LocalPlayer(), i ) then
					local btn = cpanlist:Add( "arizard_button" )
					btn:SetSize( cpanlist:GetWide()/4 - 16, 28 )
					btn:SetText( tostring(i) )
					btn.skinNumber = i

					--btn:SetColors( Color(231,28,92), Color(75,75,80) ) --  HexColor("#2980b9"), HexColor("#3498db")
					btn:SetColors( Color(46,47,50), Color(75,75,80) ) 


					function btn:DoClick()

						btn.active = true
						
						--if btn:IsDown() or btn.active then
						--	btn:SetColors( Color(231,28,92), Color(241,30,100)  )  
						--end 

						surface.PlaySound("server/ui/click2.wav")
						--print("Attempting to switch skin", self.skinNumber)
						BODYMAN.ClientModelPanel.Entity:SetSkin( self.skinNumber )

						net.Start("skins_change")
						net.WriteInt(self.skinNumber, 8)
						net.SendToServer()
					end
				end
			end

			local spacer = cpanlist:Add("DPanel")
			spacer:SetSize(cpanlist:GetWide(), 2)
			function spacer:Paint() end
		end
	end
	-----------------------------------

	local allowedbodygroups = {}
	
	if job.bodygroups then
		allowedbodygroups = job.bodygroups 
	else
		local ply = LocalPlayer()
		for i = 2, #ply:GetBodyGroups() do
			local bg = ply:GetBodyGroups()[i]
			if bg then
				for k,v in pairs( bg ) do
					if k == "name" then
						allowedbodygroups[v] = {}
						for k2, v2 in pairs( bg["submodels"] ) do
							table.insert( allowedbodygroups[v], k2 )
						end
					end
				end	
			end
		end

		--PrintTable( allowedbodygroups )
	end

	if allowedbodygroups != {} then
		local bgtitle = cpanlist:Add("DLabel")
		bgtitle:SetText( BODYMAN.strings.Bodygroups )
		bgtitle:SetFont("Bodygroups_Medium")
		bgtitle:SetTextColor( HexColor("#eeeeee") )
		bgtitle:SizeToContents()
		bgtitle:SetWide( cpanscroll:GetWide() )
		bgtitle:SetExpensiveShadow(1,Color(0,0,0))

		for bgname, bgtable in pairs( allowedbodygroups ) do
			local bglabel = cpanlist:Add("DLabel")
			bglabel:SetFont("Bodygroups_Small")
			bglabel:SetText(string.upper(bgname))
			-- СССР
			if string.upper(bgname) == "WEBBING" then bglabel:SetText("Лямки") end
			if string.upper(bgname) == "SHIRT" then bglabel:SetText("Верх") end
			if string.upper(bgname) == "WATCH" then bglabel:SetText("Часы") end
			if string.upper(bgname) == "LEGS" then bglabel:SetText("Низ") end -- Обувь
			if string.upper(bgname) == "BACKPACK" then bglabel:SetText("Рюкзак") end
			if string.upper(bgname) == "HEADWEAR" then bglabel:SetText("Головной Убор") end
			if string.upper(bgname) == "GEAR" then bglabel:SetText("Пояс") end -- Ремень
			if string.upper(bgname) == "HEAD" then bglabel:SetText("Лицо") end

			if string.upper(bgname) == "CAMO" then bglabel:SetText("Камуфляжная сетка") end

			-- Моджахеды
			if string.upper(bgname) == "HEADGEAR" then bglabel:SetText("Маска") end
			if string.upper(bgname) == "CHESTRIG" then bglabel:SetText("Разгрузка") end

			-- ЧВК
			if string.upper(bgname) == "SKIMASK" then bglabel:SetText("Маска") end
			if string.upper(bgname) == "BOOTS" then bglabel:SetText("Берцы") end
			if string.upper(bgname) == "BELT GEAR 2" then bglabel:SetText("Разгрузка #1") end
			if string.upper(bgname) == "BELT GEAR 1" then bglabel:SetText("Разгрузка #2") end	
			if string.upper(bgname) == "BUTTPACK" then bglabel:SetText("Рюкзак (маленький)") end	
			if string.upper(bgname) == "HIP GEAR" then bglabel:SetText("Бедренная разгрузка") end	
			if string.upper(bgname) == "THROAT MIC" then bglabel:SetText("Микрофон") end	
			if string.upper(bgname) == "SLEEVES" then bglabel:SetText("Рукава") end	
			if string.upper(bgname) == "HANDS" then bglabel:SetText("Руки") end	
			if string.upper(bgname) == "VEST" then bglabel:SetText("Бронежилет") end	
			if string.upper(bgname) == "VEST2" then bglabel:SetText("Снаряжение") end	
			if string.upper(bgname) == "HELMET" then bglabel:SetText("Шлем") end	
			if string.upper(bgname) == "MASK" then bglabel:SetText("Маска") end	
			--
			if string.upper(bgname) == "TOP" then bglabel:SetText("Вверх") end
			if string.upper(bgname) == "SCARF" then bglabel:SetText("Шарф") end	

			if string.upper(bgname) == "BODYMST" then bglabel:SetText("Тело") end	

			if string.upper(bgname) == "ARMS" then bglabel:SetText("Руки") end	
			if string.upper(bgname) == "TURBAN" then bglabel:SetText("Тюрбан") end	
			if string.upper(bgname) == "BODY" then bglabel:SetText("Одежда") end	





			--
			bglabel:SetTextColor( HexColor("#dddddd") )
			bglabel:SizeToContents()
			bglabel:SetWide( cpanscroll:GetWide() )
			bglabel:SetExpensiveShadow(1,Color(0,0,0))

			for _,i in ipairs(bgtable) do

				if BODYMAN:HasBodyGroup( LocalPlayer(), bgname, i ) then

					local btn = cpanlist:Add( "arizard_button" )
					btn:SetSize( cpanlist:GetWide()/4 - 16, 28 )
					btn:SetText( tostring(i) )
					btn.bg_name = bgname
					btn.bg_num = i

					--btn:SetColors( HexColor("#2980b9"), HexColor("#3498db"))
					btn:SetColors( Color(46,47,50), Color(75,75,80) )

					function btn:DoClick()
						surface.PlaySound("server/ui/click2.wav")
						local ent = BODYMAN.ClientModelPanel.Entity
						local bgid = ent:FindBodygroupByName( self.bg_name )
						if bgid != -1 then
							ent:SetBodygroup( bgid, self.bg_num )

							net.Start("bodygroups_change")
							net.WriteTable( { bgid, self.bg_num } )
							net.SendToServer()
						end
					end

				end
			end

			local spacer = cpanlist:Add("DPanel")
			spacer:SetSize(cpanlist:GetWide(), 2)
			function spacer:Paint() end

		end

		local spacer = cpanlist:Add("DPanel")
		spacer:SetSize(cpanlist:GetWide(), 2)
		function spacer:Paint() end
	end
end

concommand.Add("shula_sosi_bibu", function()
	BODYMAN:OpenMenu()
end)

-- add to context menu
list.Set( "DesktopWindows", "BodyManEditor", {

	icon = "icon16/user_gray.png",
	title = "bodyGroupr",
	width = 100,
	height = 100,
	onewindow = true,
	init = function( icon, window )
		window:Close()		
		RunConsoleCommand("shula_sosi_bibu")
	end

	}
)

--if LocalPlayer():IsSuperAdmin() then
list.Set( "DesktopWindows", "BodyManAdmin", {

	icon = "icon16/user_gray.png",
	title = "bodyGroupr Admin Menu",
	width = 100,
	height = 100,
	onewindow = true,
	init = function( icon, window )
		window:Close()
		RunConsoleCommand("bodyman_adminmenu")
	end

	}
)
--end
 