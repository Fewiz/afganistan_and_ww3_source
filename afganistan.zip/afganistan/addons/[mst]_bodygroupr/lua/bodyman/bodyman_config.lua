
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_bodygroupr/lua/bodyman/bodyman_config.lua ~

]]


BODYMAN.HelpText = [[]] -- edit this to your liking.

--[[Выберите бодигруппы в панели справа.
Потяните горизонтально (влево или вправо) для вращения модели.
Потяните вертикально (вверх или вниз) для приближения или отдаления.
Зажмите ПКМ и потяните мышью, чтобы переместить камеру.]]

BODYMAN.HelpText_Fr = [[Sélectionnez Bodygroups dans le panneau de droite .
Faites glisser horizontalement pour faire pivoter le joueur.
Faites glisser verticalement pour zoomer.
Faites un clic droit et faites glisser pour positionner la caméra.]]

BODYMAN.ClosetViewDistance = 256 -- how far the text can be seen on the closet
BODYMAN.ClosetName = "Шкаф" -- what should the closet be called?
BODYMAN.ClosetHelpText = [[Нажмите [E] что-бы изменить форму.]]

BODYMAN.ClosetName_Fr = "Armoire"
BODYMAN.ClosetHelpText_Fr = [[Appuyez sur [ E ] pour personnaliser votre
apparence.]]

BODYMAN.ClosetsOnly = true -- set this to true if you think players MUST use a closet. They will not be able to access the interface normally. false

BODYMAN.strings = {
	Appearance = "Внешний вид",
	Playermodels = "Игровая Моделька",
	Skins = "Скин",
	Bodygroups = "Форма",
	Save = "Сохранить",
	Load = "Загрузить",
	Remove_All = "Удалить Все",
	Without_Saving = "Without Saving",
	Spawn_a = "Spawn a",
}
BODYMAN.strings_fr = {
	Appearance = "Apparence",
	Playermodels = "Joueur",
	Skins = "Peau",
	Bodygroups = "Bodygroups",
	Save = "Sauvegarder l'",
	Load = "Reapparaître",
	Remove_All = "Retirer toutes les",
	Without_Saving = "sans sauvegarder",
	Spawn_a = "Apparaître",
}

BODYMAN.French = false -- Set this to true if your server speaks french.

BODYMAN.ClosetsCanBreak = false -- set this to true if you want closets to be destroyable with guns
BODYMAN.ClosetHealth = 100 -- default HP of closets. increase this if you want to take more shots to destroy them.