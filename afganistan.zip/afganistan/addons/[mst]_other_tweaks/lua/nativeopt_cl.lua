
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_other_tweaks/lua/nativeopt_cl.lua ~

]]

hook.Remove("RenderScreenspaceEffects", "RenderColorModify")
hook.Remove("RenderScreenspaceEffects", "RenderBloom")
hook.Remove("RenderScreenspaceEffects", "RenderToyTown")
hook.Remove("RenderScreenspaceEffects", "RenderTexturize")
hook.Remove("RenderScreenspaceEffects", "RenderSunbeams")
hook.Remove("RenderScreenspaceEffects", "RenderSobel")
hook.Remove("RenderScreenspaceEffects", "RenderSharpen")
hook.Remove("RenderScreenspaceEffects", "RenderMaterialOverlay")
hook.Remove("RenderScreenspaceEffects", "RenderMotionBlur")
hook.Remove("RenderScene", "RenderStereoscopy")
hook.Remove("RenderScene", "RenderSuperDoF")
hook.Remove("GUIMousePressed", "SuperDOFMouseDown")
hook.Remove("GUIMouseReleased", "SuperDOFMouseUp")
hook.Remove("PreventScreenClicks", "SuperDOFPreventClicks")
hook.Remove("PostRender", "RenderFrameBlend")
hook.Remove("PreRender", "PreRenderFrameBlend")
hook.Remove("Think", "DOFThink")
hook.Remove("RenderScreenspaceEffects", "RenderBokeh")
hook.Remove("NeedsDepthPass", "NeedsDepthPass_Bokeh")
hook.Remove("PostDrawEffects", "RenderWidgets")

local eyepos = Vector()
local eyeangles = Angle()
local eyefov = 90
local eyevector = Vector()

hook.Add("RenderScene", "Eye", function(origin, angles, fov)
	eyepos = origin
	eyeangles = angles
	eyefov = fov
	eyevector = angles:Forward()
end)

local meta = FindMetaTable('Entity')
function meta:ShouldHide()
	local pos = self:GetPos()
	return self ~= LocalPlayer() && (eyevector:Dot(pos - eyepos) < 1.5 || pos:DistToSqr(eyepos) > 30000000)
end

function meta:NotInRange()
	local pos = self:GetPos()
	return pos:DistToSqr(eyepos) > 9000000
end

function EyePos() return eyepos end
function EyeAngles() return eyeangles end
function EyeFov() return eyefov end
function EyeVector() return eyevector end

local GM = GAMEMODE
local CalcMainActivity = GM.CalcMainActivity
local UpdateAnimation = GM.UpdateAnimation
local PrePlayerDraw = GM.PrePlayerDraw
local DoAnimationEvent = GM.DoAnimationEvent
local PlayerFootstep = GM.PlayerFootstep
--local PlayerStepSoundTime = GM.PlayerStepSoundTime
local TranslateActivity = GM.TranslateActivity

function GM:CalcMainActivity(pl, ...)
	if pl:ShouldHide() then return pl.CalcIdeal, pl.CalcSeqOverride end
	return CalcMainActivity(self, pl, ...)
end

function GM:UpdateAnimation(pl, ...)
	if pl:ShouldHide() then return end
	return UpdateAnimation(self, pl, ...)
end

function GM:PrePlayerDraw(pl, ...)
	if pl:ShouldHide() then return true end
	return PrePlayerDraw(self, pl, ...)
end

function GM:DoAnimationEvent(pl, ...)
	if pl:ShouldHide() then return pl.CalcIdeal end
	return DoAnimationEvent(self, pl, ...)
end

function GM:PlayerFootstep(pl, ...)
	if pl:NotInRange() then return true end
	PlayerFootstep(self, pl, ...)
end

--function GM:PlayerStepSoundTime(pl, ...)
--	if pl:NotInRange() then return 350 end
--	return PlayerStepSoundTime(self, pl, ...)
--end

function GM:TranslateActivity(pl, ...)
	if pl:ShouldHide() then return ACT_HL2MP_IDLE end
	return TranslateActivity(self, pl, ...)
end

--function render.SupportsHDR() return false end
--function render.SupportsPixelShaders_2_0() return false end
--function render.SupportsPixelShaders_1_4() return false end
--function render.SupportsVertexShaders_2_0() return false end
--function render.GetDXLevel() return 80 end

function render.SupportsHDR() return false end -- false
function render.SupportsPixelShaders_2_0() return false end -- false
function render.SupportsPixelShaders_1_4() return false end -- false
function render.SupportsVertexShaders_2_0() return false end -- false
function render.GetDXLevel() return 90 end -- return 80 end