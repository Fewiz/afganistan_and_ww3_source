
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_other_tweaks/lua/autorun/tweaks_init.lua ~

]]

AddCSLuaFile()
AddCSLuaFile "nativeopt_cl.lua"
AddCSLuaFile "nativeopt_sh.lua"

local function init()
	include "nativeopt_sh.lua"
	if CLIENT then
		include "nativeopt_cl.lua"
	else
		include "nativeopt_sv.lua"
	end
end

if GAMEMODE then init() else hook.Add('InitPostEntity', 'PerformanceLuaTweaks', init) end