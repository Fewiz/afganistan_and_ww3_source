
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/sh_console_time.lua ~

]]

local grey = Color(200, 200, 200)
local mst =  Color(231,28,92)
local prev
timer.Create("ClientsideTime", .5, 0, function()
	local new = os.date(" %H:%M ")
	if new ~= prev then
		--MsgC(grey, ("="):rep(30), mst, .. new .. , grey, ("="):rep(30) .. "\n")
		MsgC(grey, ("="):rep(30), mst,  new, grey, ("="):rep(30) .. "\n")
		prev = new
	end
end)

