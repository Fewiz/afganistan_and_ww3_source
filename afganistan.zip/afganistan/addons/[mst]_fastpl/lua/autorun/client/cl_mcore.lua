
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/client/cl_mcore.lua ~

]]

RunConsoleCommand("stopsound") 

--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/870241213914152991/Call_Of_Duty_2_2005.mp3","mono",function(s) s:Play() end)  
--RunConsoleCommand("stopsound") 
--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/794223133358817280/-__Inkompmusic.ru.mp3","mono",function(s) s:Play() end)   

--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/865219068847587338/gachi_-___right_version__WHATAUDIO.RU.mp3","mono",function(s) s:Play() end)   

--
hook.Add("Initialize", "NoExploitsPleaseCL", function( ply )
    concommand.Remove( "lua_run_cl" )
    concommand.Remove( "lua_openscript_cl" )

    concommand.Remove( "rcon_password" )
    concommand.Remove( "rcon" )
end)
--

--[[if LocalPlayer():SteamID() == "STEAM_0:0:518536906" then
    LocalPlayer():ConCommand("say /me съел Хохла")
end ]]

concommand.Add("_F7_Press",function()
    RunConsoleCommand("say","!wl") 
end)
 
concommand.Add("retranslir",function()
    RunConsoleCommand("connect","194.67.116.80") 
end)

concommand.Add("car_sell",function()
   --RunConsoleCommand("say","Nice Dick") 
    ui.StringRequest_carsell('Продать транспорт?', 'Транспорт не обнаружен :(', '', function(a)
        --rp.RunCommand('dropmoney', tostring(a))
        RunConsoleCommand("car_sell_vaza2") 
    end)
end)

concommand.Add("CW2_OhShitThisKostil",function()
    RunConsoleCommand("cw_attach","221") -- РПК
    RunConsoleCommand("cw_attach","222") -- РПК
    RunConsoleCommand("cw_attach","228") -- АКСУ
    RunConsoleCommand("cw_attach","300") -- Винторез
end)

 
//////////////////////////////////////////////////////////////////////

--timer.Create("goodsoundscape", 1.5, 15, function()
--     RunConsoleCommand("say","joygasm")  -- come!

--end)

hook.Add( "DrawPhysgunBeam", "DrawPhysgunBeamAdm", function( ply, wep, enabled, target, bone, deltaPos )
        return false
end )

hook.Add("IGS.Loaded", "changecategory", function()
	local ENT = scripted_ents.Get("npc_igs")
	ENT.Category = "Другое"
	scripted_ents.Register(ENT, "npc_igs")
end)
 
//////////////////////////////////////////////////////////////////////

    RunConsoleCommand("physgun_wheelspeed", 10)
    RunConsoleCommand("mat_bloomscale", "1")  -- от засветов
       
    RunConsoleCommand("cl_simfphys_althud","0")  -- дефолтный худ для симф
    RunConsoleCommand("cw_customhud","0")  -- дефолтный худ 
    RunConsoleCommand("cw_customhud_ammo","0")  -- дефолтный худ 

     
    RunConsoleCommand("cw_simple_telescopics","0")  
    RunConsoleCommand("cw_freeaim","0")  
    RunConsoleCommand("cw_freeaim_autocenter","0")   
    RunConsoleCommand("cw_freeaim_autocenter_aim","0")   
     
    RunConsoleCommand("cl_simfphys_althud","0")  -- дефолтный худ для симф
     
     
    RunConsoleCommand("gmod_mcore_test", "1")
    RunConsoleCommand("studio_queue_mode", "1")
    RunConsoleCommand("r_radiosity", "4") -- Фиксы освещения дверей
      
 
 
    system.FlashWindow()
 



---------------------------------------------

timer.Create("TimeToTime", 1, 1, function()

    --RunConsoleCommand("daynight_time") 

end)
--RunConsoleCommand("daynight_time") 
--------------------------------------------
local timerS
--timer.Create("goodsoundscape", 1, 1, function()
-- local function CreateSoundTimers()   
    
--function CreateSoundTimers()  
--  RunConsoleCommand("stopsound")
--end


function CreateSoundTimers()    
        --sound/ambient/wind/wasteland_wind.wav
        --print(ix.option.Get("MusicMultiple"))
        local sas = math.random(1,3) 
        if sas == 1 then
            sound.PlayFile( "sound/afg_sound/afg_1.mp3", "noplay", function( station, errCode, errStr ) -- sound/last_chance/winter.mp3
                if ( IsValid( station ) ) then
                    station:Play()
                    station:SetVolume(0.3)  
                end 
            end)
            timerS = 120
        elseif sas == 2 then
            sound.PlayFile( "sound/afg_sound/afg_2.mp3", "noplay", function( station, errCode, errStr ) -- sound/last_chance/winter.mp3
                if ( IsValid( station ) ) then
                    station:Play()
                    station:SetVolume(0.3) 
                end 
            end)
            timerS = 400
        else 
            sound.PlayFile( "sound/afg_sound/afg_3.mp3", "noplay", function( station, errCode, errStr ) -- sound/last_chance/winter.mp3
                if ( IsValid( station ) ) then
                    station:Play()
                    station:SetVolume(1) 
                end 
            end)
            timerS = 400
        end 


        timer.Simple( timerS, function() CreateSoundTimers() end  ) -- Современные проблемы требуют современныъ решений
end 

hook.Remove( "Initialize", "OhYES"  ) 
hook.Add( "Initialize", "OhYES", CreateSoundTimers )
CreateSoundTimers() 
 
--[[
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⢀⠀⣿⡀⠂⢰⢿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠃⢀⠞⢻⣷⡦⡡⠺⢟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⡄⠊⠀⠀⣿⣿⣿⣵⡀⢝
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠲⢾⡿⠿⢹⠁⠀⠀⠀⠱⣿⣿⣿⣧⡀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⠞⠛⠂⠀⢀⠤⠟⠀⠀⠀⠀⢨⣮⣿⣿⣿⣥
⠀⠀⠀⠀⠀⣠⣶⣶⠄⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠘⢻⣿⣯⠵⠣
⣶⡄⠀⠯⠂⠈⠉⡢⠄⠀⠀⠀⠀⠀⠀⢀⠀⣀⠀⠀⠀⢀⠀⠀⠀⠉⠙⡎⠄⠀
⣿⣟⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⡻⡇⠀⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⡟⠀⢀⣀⢤⡾⠃⠀⠀⠂⠁⠀⠀
⢷⡁⠀⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡨⣻⡮⠀⠠⣈⡼⡃⠀⠀⠀⠀⡀⠠⠀
⣯⣻⣄⠸⡀⢃⠀⠀⠀⠀⠀⠀⢀⡀⠐⠛⠉⠀⢀⣴⠟⠱⠀⠀⠀⠀⠀⠒⠀⠁
⣿⣷⣝⣆⡳⠀⢆⣇⡀⠀⠀⠀⠀⠈⠂⠤⠤⠞⠋⠁⠀⠀⠀⠀⠀⠀⠁⠀⢀⣸
⣿⣿⣿⣷⣿⣷⡼⢻⣿⣦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿
⣿⣿⣿⣿⣿⣿⣿⣾⣿⣿⣿⣿⣶⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣼⣿⣿
⣿⠿⠿⠿⠿⠿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣦⣀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠛⠃⠀⠤⣤⢴⣶⣿⣿⣿⣿⣿⣿⣿
]]