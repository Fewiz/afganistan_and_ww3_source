
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/client/cl_polet_cust.lua ~

]]

RunConsoleCommand("stopsound") 

--https://content.wgcdn.co/wot/ost/mp3/Andrey%20Kulik%20feat.%20Andrius%20Klimka%20-%20Cliff%20(Battle).mp3 -- Годнота
-- https://content.wgcdn.co/wot/ost/mp3/World%20of%20Tanks%20OST%20-%2006%20-%20%D0%A3%D0%BB%D0%B8%D1%87%D0%BD%D1%8B%D0%B9%20%D0%B1%D0%BE%D0%B9.mp3 -- Забивная, короткая
--timer.Create("NiceCum", 3, 2, function()  
	--RunConsoleCommand("say", "joygasm")
--end)
concommand.Add("RRRR",function(ply) 
	sound.PlayURL("https://content.wgcdn.co/wot/ost/mp3/Andrey%20Kulik%20feat.%20Andrius%20Klimka%20and%20Vyacheslav%20Skadorva%20-%20Mountain%20Pass%20(Battle).mp3","mono",function(s) s:Play() end)  
end) 
--sound.PlayURL("https://content.wgcdn.co/wot/ost/mp3/Andrey%20Kulik%20feat.%20Andrius%20Klimka%20-%20Cliff%20(Battle).mp3","mono",function(s) s:Play() end)  
 


local grey = Color(200, 200, 200)
local mst = Color(231,28,92)
local prev
concommand.Add("show_sas",function()

	chat.AddText(color_white, "• Не нравится музыка? >> ", mst,"stopsound", color_white, " в консоль!\n" )

end) 

--[[
chat.AddText(color_white, "=============================================" )
chat.AddText(color_white, "• Не нравится музыка? >> ", mst,"stopsound", color_white, " в консоль!" )
chat.AddText(color_white, "• Не нравится музыка? >> ", mst,"Смирись!" )
chat.AddText(color_white, "• Не нравится музыка? >> ", mst,"stopsound", color_white, " в консоль!" )
chat.AddText(color_white, "=============================================" ) 
]]

--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/932345638203555840/Perturbator_feat_Noir_Deco_-_Technoir_galamp3.com1.mp3","mono",function(s) s:Play() end)  


 
local alpha, alpha_black = 0, 0
local function build_cloak(arg)
	alpha = 512	
	alpha_black = 256
	--chat.AddText(color_white, "• Не нравится музыка? >> ", mst, mom )
	hook.Remove("HUDPaint","HUD_cloak")
	hook.Add("HUDPaint","HUD_cloak",function()
		alpha = alpha - 1
		alpha_black = alpha_black - 1
		draw.SimpleTextOutlined(arg,"KeyCaps_big",50,25,Color(alpha,alpha,alpha,alpha_black),1,1,1,Color(0,0,0,alpha_black)) 
	end) 
end
 
net.Receive( "daynight_message", function( len, ply )

	build_cloak(len)
 
end );


concommand.Add("show_cloak",function(ply, cmd, args)
	--build_cloak("12:00")
	print(args)
	build_cloak(args)
end) 
