
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/client/cl_start.lua ~

]]

--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/899710596449181706/sas.mp3","mono",function(s) s:Play() end)  
--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/870241213914152991/Call_Of_Duty_2_2005.mp3","mono",function(s) s:Play() end)  
--RunConsoleCommand("stopsound") 
--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/794223133358817280/-__Inkompmusic.ru.mp3","mono",function(s) s:Play() end)   

--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/865297950103699496/0f5d81f68fa93593.mp3","mono",function(s) s:Play() end)   


--sound.PlayURL("https://cdn.discordapp.com/attachments/948619942025109565/948688100824084510/hundred_bucks_______Gachi_Remix.mp3","mono",function(s) s:Play() end)   


local ButtonGreenColor1 = Color( 0, 255, 0, 255 )
local ButtonGreenColor2 = Color( 0, 255, 0, 128 )

local ButtonRedColor1 = Color( 255, 0, 0, 255 )
local ButtonRedColor2 = Color( 255, 0, 0, 128 )

local ButtonGenerateColor1 = Color( 255, 255, 0, 255 )
local ButtonGenerateColor2 = Color( 255, 255, 0, 128 )

_G.OpenStartMenu =function()
    local alpha = math.abs( math.cos( CurTime() * 1 ) )
    local pan_w, pan_h = ScrW() * .4, ScrW() * .4

    local frame = vgui.Create( "DFrame" )
    frame:SetSize( ScrW() * 0.9, ScrH() * 0.9 )
    frame:SetTitle( "" ) -- "Афганистан РП" 
    frame:SetIcon( "" ) -- icon16/gun.png
    frame:Center()
    frame:MakePopup()
    frame:ShowCloseButton(false)

    function frame:Paint( w, h )
        Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
        surface.SetDrawColor( 36,37,43 )
        surface.DrawRect( 0, 0, w, h )
    end
     
    local sheet = vgui.Create( "DPropertySheet", frame )
    sheet.tabScroller:SetOverlap( -8 )
    sheet:Dock( FILL )


    local ButtonBG1 = vgui.Create( "DButton", sheet ) -- СССР
    ButtonBG1:SetText( "" ) 
    ButtonBG1:SetPos( 0,0 )
    ButtonBG1:SetSize( ScrW() * 0.45, ScrH() * 0.9 )
    ButtonBG1.Paint = function( self, w, h )    
        if ButtonBG1.Hovered then
            surface.SetDrawColor( 255, 0, 0, 16 )
        else 
            surface.SetDrawColor( 0, 0, 0, 0 )
        end
        surface.DrawRect( 0, 0, w, h )
    end


    local ButtonBG2 = vgui.Create( "DButton", sheet ) -- СССР
    ButtonBG2:SetText( "" ) 
    ButtonBG2:SetPos( ScrW() * 0.45,0 )
    ButtonBG2:SetSize( ScrW() * 0.45, ScrH() * 0.9 )
    ButtonBG2.Paint = function( self, w, h )    
        if ButtonBG2.Hovered then
            surface.SetDrawColor( 255, 200, 0, 16 )
        else 
            surface.SetDrawColor( 0, 0, 0, 0 )
        end
        surface.DrawRect( 0, 0, w, h )
    end

    function sheet:Paint( w, h )
        surface.SetDrawColor( 0, 0, 0, 128 )
        surface.DrawRect( 0, 0, w, h )
        surface.SetDrawColor( 255, 255, 255, 16 )
        surface.DrawLine( 0, 0, w, 0 )
     
        
        surface.SetDrawColor( 255, 0, 0, 45 )
        surface.DrawRect( 0, 0, w*2.1, h ) -- СССР
        
        surface.SetDrawColor( 255, 200, 0, 45 )
        surface.DrawRect( ScrW() * 0.45, 0, w*2.1, h ) -- Душманы
     
        surface.SetDrawColor( 255, 255, 255, 255 )
        
        local join_ussr_list = surface.GetTextureID("gui/join_ussr_list")   
        surface.SetTexture(join_ussr_list)
    	surface.DrawTexturedRect(ScrW() * 0.045, ScrH() * 0.05, w/2.5, h/2.2)
    	
    	local join_dux_list = surface.GetTextureID("gui/join_dux_list")   
        surface.SetTexture(join_dux_list)
    	surface.DrawTexturedRect(ScrW() * 0.5, ScrH() * 0.05, w/2.4, h/2.1)
        //
        
        local join_ussr = surface.GetTextureID("gui/join_ussr")  -- cw2/gui/gradient    addons\cw_2.0_base\materials\cw2\gui
        surface.SetTexture(join_ussr)
    	surface.DrawTexturedRect(ScrW() * 0.020, ScrH() * 0.45, w/2.2, h/2.2)  -- 90  
        local join_dux = surface.GetTextureID("gui/join_dux")
        surface.SetTexture(join_dux)
    	surface.DrawTexturedRect(ScrW() * 0.47,  ScrH() * 0.45, w/2.2, h/2.2)  -- 90  
    	
    	//
     	
    end
 

    ////////////////////////////////////////////
    local SB1 = 1
    local SB2 = 1
    local Button = vgui.Create( "DButton", sheet ) -- СССР
    Button:SetText( "Стать Солдатом СССР!" ) 
    Button:SetPos( 0,0 )
    Button:SetSize( ScrW() * 0.45, 30 )
    Button.Paint = function( self, w, h )    
        if Button.Hovered or ButtonBG1.Hovered then
            if SB1 == 1 then 
                surface.PlaySound("garrysmod/ui_hover.wav")
                SB1 = 0 SB2 = 1
            end     
            surface.SetDrawColor( 255, 0, 0, 255 )
        else 
            surface.SetDrawColor( 255, 0, 0, 128 )
        end
        surface.DrawRect( 0, 0, w, h )
    end
    Button.DoClick=function()
        surface.PlaySound("garrysmod/ui_hover.wav")

         ui.StringRequest_ussr('Выберите имя вашему персонажу', 'Вы сможете поменять ник в будущем', '', function(a)
             --rp.RunCommand('dropmoney', tostring(a))
         end)

        frame:Close()
    end 

     

 


        local Button = vgui.Create( "DButton", sheet ) -- Душманы
        Button:SetText( "Стать Душманом!" ) 
        Button:SetPos( ScrW() * 0.45,0 )
        Button:SetSize( ScrW() * 0.45, 30 )
        Button.Paint = function( self, w, h )    
            --surface.SetDrawColor( 255, 200, 0, 128 )
            --surface.DrawRect( 0, 0, w, h )
            if Button.Hovered or ButtonBG2.Hovered then
                if SB2 == 1 then 
                    surface.PlaySound("garrysmod/ui_hover.wav")
                    SB1 = 1 SB2 = 0
                end     
                surface.SetDrawColor( 255, 200, 0, 255 )
            else 
                surface.SetDrawColor( 255, 200, 0, 128 )
            end
            surface.DrawRect( 0, 0, w, h )
        end

        //////////////////////////////
        Button.DoClick=function()  
            surface.PlaySound("garrysmod/ui_hover.wav")
            --OpenStartMenu_dux()

            ui.StringRequest_dux('Выберите имя вашему персонажу', 'Вы сможете поменять ник в будущем', '', function(a)
                --rp.RunCommand('dropmoney', tostring(a))
            end)

            frame:Close()
        end
 





end

 