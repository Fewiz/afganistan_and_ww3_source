
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/client/cl_polet.lua ~

]]

concommand.Add("show_pos",function()
    local pos=LocalPlayer():GetPos()
    print("Vector("..math.floor(pos.x)..","..math.floor(math.floor(pos.y))..","..math.floor(math.floor(pos.z)).."),")
    SetClipboardText("Vector("..math.floor(pos.x)..","..math.floor(math.floor(pos.y))..","..math.floor(math.floor(pos.z)).."),")
end)

concommand.Add("show_pos2",function()
    -- ply:GetEyeTrace().Entity
    local PropENT = LocalPlayer():GetEyeTrace().Entity
    local PropENTPos = PropENT:GetPos()
    if IsValid(PropENT) then
        print(PropENT:GetModel())
        print("Vector("..math.floor(PropENTPos.x)..","..math.floor(math.floor(PropENTPos.y))..","..math.floor(math.floor(PropENTPos.z)).."),")
        SetClipboardText("Vector("..math.floor(PropENTPos.x)..","..math.floor(math.floor(PropENTPos.y))..","..math.floor(math.floor(PropENTPos.z)).."),")
        print("Angle: ",PropENT:GetAngles())
    else 
        print("Невалидный объект")
    end 
    --print("Vector("..math.floor(pos.x)..","..math.floor(math.floor(pos.y))..","..math.floor(math.floor(pos.z)).."),")
    --SetClipboardText("Vector("..math.floor(pos.x)..","..math.floor(math.floor(pos.y))..","..math.floor(math.floor(pos.z)).."),")
end)


local function ShouldAlwaysSit(ply)
    return hook.Run("ShouldAlwaysSit",ply)
end

hook.Add("KeyPress","seats_use3",function(ply,key)
    if not IsFirstTimePredicted() and not game.SinglePlayer() then return end
    
    if key ~= IN_USE then return end
    
    local walk=ply:KeyDown(IN_WALK) or ShouldAlwaysSit(ply)
    if not walk then return end
    
    RunConsoleCommand("sit")
end)


_G.Pload = function()

local setting={
   rp_afghanistan_v8 ={   
  
        
        {
            kuda_smotret=Vector(-1415,-2078,620),
            kuda_letet={Vector(-3753,400,700),Vector(1430,400,700)},
            speed=6
        },
        
       --[[ {
            kuda_smotret=Vector(-6988,6759,320),
            kuda_letet={Vector(-4599,1514,905),Vector(-4599,12189,905)},
            speed=5
        },
                {
            kuda_smotret=Vector(-1415,-2078,620),
            kuda_letet={Vector(-3753,400,700),Vector(1430,400,700)},
            speed=6
        },
                     {
            kuda_smotret=Vector(12222,-12586,561),
            kuda_letet={Vector(9265,-10500,800),Vector(14565,-10500,800)},
            speed=2
        },
                             {
            kuda_smotret=Vector(-11393,-12379,504),
            kuda_letet={Vector(-9297,-14724,1000),Vector(-12999,-14713,1000)},
            speed=4
        },]]
        --[[
       {
            kuda_smotret=Vector(-12291,-12904,350),
            kuda_letet={Vector(-12288,-10777,350),Vector(Vector(-12291,-12904,350))},
            speed=0.5
        },
        ]]
 
 
       },

        rp_mst_afghanistan_v3 ={ 
                    
        {
            kuda_smotret=Vector(2612,-10128,100),
            kuda_letet={Vector(2612,-10200,100),Vector(2612,-11057,100)},
            speed=0.5
        },

        {
            kuda_smotret=Vector(-7632,-7756,550),
            kuda_letet={Vector(-7632,-7756,550),Vector(-12822,-7756,550),},
            speed=1.5
        },

         
        
        {
            kuda_smotret=Vector(965,5600,125),
            kuda_letet={Vector(965,5600,125),Vector(-965,5600,125)},
            speed=1.5
        },

        
         {
            kuda_smotret=Vector(9895,13411,64),
            kuda_letet={Vector(9895,13411,64), Vector(9895,6955,64)},
            speed=2
        },


        
    },


}
 
concommand.Add("show_preview",function()
    local map=game.GetMap()
    ply = LocalPlayer()
    local i=1
    local curanim=1
    local shas=setting[map][i].kuda_letet[curanim]
    local curpos=shas
    local sped=setting[map][i].speed
 
    curanim=curanim+1
    shas=setting[map][i].kuda_letet[curanim]
    --ply:ScreenFade(SCREENFADE.IN, Color(25,25,25, 255), 3, 0.5)  
    
    if setting[map] then
        hook.Add("HUDPaint","preview",function()
        local alpha = math.abs( math.cos( CurTime() * 1 ) )

            draw.SimpleTextOutlined("  Добро пожаловать на сервер «MST Афганистан РП!»  ","KeyCaps",ScrW()/2,92,Color(250*alpha,50,50,255),1,1,1,color_black) -- HudFont2
            draw.SimpleTextOutlined("  Добро пожаловать на сервер «MST Афганистан РП!»  ","KeyCaps",ScrW()/2,90,Color(200,200,200),1,1,1,color_black)
            draw.SimpleTextOutlined("★                                                                                                     ★","KeyCaps",ScrW()/2,92,Color(150,50,50),1,1,1,color_black)
            draw.SimpleTextOutlined("★                                                                                                     ★","KeyCaps",ScrW()/2,90,Color(255*alpha,0,0),1,1,1,color_black)
            draw.SimpleTextOutlined(" «Нажмите любую кнопку»  ","KeyCaps",ScrW()/2,127,Color(250*alpha,50,50,255),1,1,1,color_black)
            draw.SimpleTextOutlined(" «Нажмите любую кнопку»  ","KeyCaps",ScrW()/2,125,Color(100+alpha*155,100+alpha*155,100+alpha*155),1,1,1,color_black)
        end)
        hook.Add("KeyPress","preview",function()
            hook.Remove("CalcView","preview")
            hook.Remove("HUDPaint","preview")
            timer.Simple(0.1,function()
                hook.Remove("KeyPress","preview") 
                RunConsoleCommand("cw_customhud", 1)  -- возращает худ при полете)%)% 
                RunConsoleCommand("cl_drawhud", 1)
                RunConsoleCommand("stopsound")
                
                
                
--[[////// Врубаем Музыку //////
sound.PlayURL ( "http://gosha2400.beget.tech/files/gmod/poslvoynloadscr/soundtrack/soundtrack_small.ogg", "2d", function( station )
    if ( IsValid( station ) ) then
        station:SetPos( LocalPlayer():GetPos() )
        station:Play()
    else
        --LocalPlayer():ChatPrint( "Invalid URL!" )
    end
end )
////////////////////////////]]


            end)
        end) 
        hook.Add("CalcView","preview",function( ply, pos, angles, fov)
            if curpos.x<shas.x then
                curpos.x=curpos.x+sped
            else
                curpos.x=curpos.x-sped
            end
            if math.abs(shas.x-curpos.x)<sped+5 then curpos.x = shas.x end
            
            if curpos.y<shas.y then
                curpos.y=curpos.y+sped
            else
                curpos.y=curpos.y-sped
            end
            if math.abs(shas.y-curpos.y)<sped+5 then curpos.y = shas.y end
            
            if curpos.z<shas.z then
                curpos.z=curpos.z+sped
            else
                curpos.z=curpos.z-sped
            end
            if math.abs(shas.z-curpos.z)<sped+5 then curpos.z = shas.z end
            --ply:SetZoom( 100 )
            --ply:GetInfoNum( "fov_desired", 155 )
            
            if math.abs(shas.x-curpos.x)<sped+10 and math.abs(shas.y-curpos.y)<sped+10 and math.abs(shas.z-curpos.z)<sped+10 then
                curanim=curanim+1
                if #setting[map][i].kuda_letet<curanim+1 then
                    i=i+1
                    if i>#setting[map] then 
                        hook.Remove("CalcView","preview")
                        Pload()
                        RunConsoleCommand("show_preview")
                        
                        return
                    end
                    --ply:ScreenFade(SCREENFADE.IN, Color(25,25,25, 255), 1, 0.5)  

                        curanim=1
                        curpos=setting[map][i].kuda_letet[curanim]
                        curanim=curanim+1
                        ply:ScreenFade(SCREENFADE.IN, Color(25,25,25, 255), 1, 0.5)  
                        shas=setting[map][i].kuda_letet[curanim]


                end
            end
            sped=setting[map][i].speed
            return {
                origin = curpos,
                angles = (setting[map][i].kuda_smotret - curpos):Angle(),
                fov = fov,
                drawviewer = true
            }
        end)
        return
    end
end)
 
end Pload()
 
concommand.Add("stop_preview",function()
    hook.Remove("CalcView","preview") 
    hook.Remove("HUDPaint","preview")
    timer.Simple(0.5,function()
    hook.Remove("KeyPress","preview")
    end) 
end)

system.FlashWindow()
RunConsoleCommand("show_preview")
--RunConsoleCommand("cl_drawhud", 0)  -- убирает худ при полете)%)%
--RunConsoleCommand("stopsound")
 