
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/client/cl_hideconnect.lua ~

]]

-- donatehelper_cl.lua

--IGS.OLDUI=IGS.UI
--[[
IGS.UI=function()
print(1)
end
]]
 
if SERVER then return end

local oldw,oldh=ScrW,ScrH

local function ScrW()
	if oldw() > 1900 then
		return 1900
	end
	return oldw()
end

local function ScrH()
	if oldh() > 1000 then
		return 1000
	end
	return oldh()
end 

 
		surface.CreateFont( "mstdon18", {
			font = "Roboto",
			size = (ScrW()*ScrH())/56888/2,
			weight = 90000,
		} )

		surface.CreateFont( "mstdon24", {
			font = "Roboto",
			size = (ScrW()*ScrH())/42666/2,
			weight = 90000,
		} )
		surface.CreateFont( "mstdon32", {
			font = "Roboto",
			size = (ScrW()*ScrH())/32000/2,
			weight = 90000,
		} )
		surface.CreateFont( "mstdon64", {
			font = "Roboto",
			size = (ScrW()*ScrH())/32000,
			weight = 90000,
		} )
  
--_G.WebMaterials,_G.WebMaterialsCache = istable(_G.WebMaterials) and _G.WebMaterials or {},istable(_G.WebMaterialsCache) and _G.WebMaterialsCache or {}

_G.WebMaterials,_G.WebMaterialsCache={},{}
  
local Delay = 0 
local usdg={}
hook.Add( "Tick", "MST_CACHE_ICONS", function()
	if istable(IGS) and istable(IGS.ITEMS) and istable(IGS.ITEMS.STORED) and istable(IGS.ITEMS.mst_BIG_ICONS) and IsValid(LocalPlayer()) then
		hook.Remove( "Tick", "MST_CACHE_ICONS") 
		file.CreateDir("mstdontextures")
		local htmls={}
		for _,v in pairs(IGS.ITEMS.mst_BIG_ICONS) do 
			if WebMaterials[v] then continue end
			htmls[#htmls+1]=vgui.Create("DHTML")
			htmls[#htmls]:SetAlpha(0)
			htmls[#htmls]:SetSize(512,512)
			--htmls[#htmls]:OpenURL(v)
			htmls[#htmls]:SetHTML( [[<style>html { 
background: url(]]..v..[[) no-repeat;
background-size: 100% 100%; 
-webkit-background-size: 100% 100%;
-moz-background-size: 100% 100%;
-o-background-size: 100% 100%;
}</style>]] )
			htmls[#htmls].url=v
			htmls[#htmls].time=CurTime()
			WebMaterials[v]=true 
			WebMaterialsCache[v]=Material('trails/love')
		end
		for _,v in pairs(IGS.ITEMS.STORED) do 
			if (not istable(v.icon)) or v.icon.isModel or WebMaterials[v.icon.icon] then continue end
			htmls[#htmls+1]=vgui.Create("DHTML")
			htmls[#htmls]:SetAlpha(0)
			htmls[#htmls]:SetSize(512,512)
			htmls[#htmls]:SetHTML( [[<style>html { 
background: url(]]..v.icon.icon..[[) no-repeat; 
-webkit-background-size: 100% 100%;
-moz-background-size: 100% 100%;
-o-background-size: 100% 100%;
background-size: 100% 100%;
}</style>]] )
			--htmls[#htmls]:OpenURL(v.icon.icon)
			htmls[#htmls].url=v.icon.icon
			htmls[#htmls].time=CurTime()
			WebMaterials[v.icon.icon]=true 
			WebMaterialsCache[v.icon.icon]=Material('trails/love')
		end
		for _,v in pairs(IGS.ITEMS.STORED) do
			if (not istable(v.group)) or WebMaterials[v.group.icon_url] then continue end
			htmls[#htmls+1]=vgui.Create("DHTML")
			htmls[#htmls]:SetAlpha(0)
			htmls[#htmls]:SetSize(512,512)
			--htmls[#htmls]:OpenURL(v.group.icon_url)
			htmls[#htmls]:SetHTML( [[<style>html { 
background: url(]]..v.group.icon_url..[[) no-repeat; 
-webkit-background-size: 100% 100%;
-moz-background-size: 100% 100%;
-o-background-size: 100% 100%;
background-size: 100% 100%;
}</style>]] )
			htmls[#htmls].time=CurTime()
			htmls[#htmls].url=v.group.icon_url
			WebMaterials[v.group.icon_url]=true 
			WebMaterialsCache[v.group.icon_url]=Material('trails/love')
		end
		timer.Simple(30,function()
			timer.Create("MST_LOAD_ICONS",1,0,function()
				for k,v in pairs(htmls) do
					--print(k,v)
					if v and v:GetHTMLMaterial() then

						WebMaterialsCache[v.url]=v:GetHTMLMaterial()
						htmls[k]=nil
						v:Remove()
						continue
					end
					if math.abs(CurTime() - v.time) > 3 then
						htmls[#htmls]:SetHTML( [[<style>html { 
						background: url(]]..v.url..[[) no-repeat; 
						-webkit-background-size: 100% 100%;
						-moz-background-size: 100% 100%;
						-o-background-size: 100% 100%;
						background-size: 100% 100%;
						}</style>]] )
					end
				end
			end)
		end)

		--[[for _,v in pairs(IGS.ITEMS.mst_BIG_ICONS) do OLD METHOD
			if WebMaterials[v] then continue end
			Delay = Delay + 0.25
			timer.Simple( Delay, function() 
				http.Fetch(v,function(d) file.Write('mstdontextures/'..util.CRC(d)..'.'..string.GetExtensionFromFilename(v),d) 
					WebMaterials[v]=true 
					WebMaterialsCache[v]=Material('data/mstdontextures/'..util.CRC(d)..'.'..string.GetExtensionFromFilename(v), "noclamp")   
				end,function(e) print(v,e) end) 
			end )

		end
		for _,v in pairs(IGS.ITEMS.STORED) do

			if istable(v.icon) and not (v.icon.isModel) then
				if WebMaterials[v.icon.icon] then continue end
				Delay = Delay + 0.25
				timer.Simple( Delay, function() 
					http.Fetch(v.icon.icon,function(d) 
						file.Write('mstdontextures/'..util.CRC(d)..'.'..string.GetExtensionFromFilename(v.icon.icon),d) 
						WebMaterials[v.icon.icon]=true 
						WebMaterialsCache[v.icon.icon]=Material('data/mstdontextures/'..util.CRC(d)..'.'..string.GetExtensionFromFilename(v.icon.icon), "noclamp")   
					end,function(e) print(v,e) end) 
				end )
			end
		end
		for _,v in pairs(IGS.ITEMS.STORED) do

			if istable(v.group) and isstring(v.group.icon_url) then
				if WebMaterials[v.group.icon_url] then continue end
				Delay = Delay + 0.25
				timer.Simple( Delay, function() 
					http.Fetch(v.group.icon_url,function(d) 
						file.Write('mstdontextures/'..util.CRC(d)..'.'..string.GetExtensionFromFilename(v.group.icon_url),d) 
						WebMaterials[v.group.icon_url]=true 
						WebMaterialsCache[v.group.icon_url]=Material('data/mstdontextures/'..util.CRC(d)..'.'..string.GetExtensionFromFilename(v.group.icon_url), "noclamp")   
					end,function(e) print(v,e) end)
				end )
			end
		end]]

	end
end ) 

hook.Add("Tick","MST_LOAD",function()
	if IsValid(LocalPlayer()) and istable(IGS) and istable(IGS.ITEMS) and istable(IGS.ITEMS.STORED) and isfunction(IGS.UI) then
		hook.Remove("Tick","MST_LOAD")
		local myname=LocalPlayer():Name()
		local bkg7,bkg8=Color(46,47,50),Color(58,59,65)
		local alpha = math.abs( math.cos( CurTime() * 1 ) )

		local math,surface=math,surface
		local bkg1,bkg2,gradid,bkg3,color_white_50,bkg4,prim=Color(30,33,38),Color(25,28,32),surface.GetTextureID("gui/gradient_down"),Color(25,25,31),Color(255,255,255,50),Color(36,37,43),Color(231,28,92)
		local prim_alp = Color(231,28,92,255*alpha)
		local grad,color_black_50,color_black_200=surface.GetTextureID("gui/gradient"),Color(0,0,0,50),Color(0,0,0,200)
		local f=vgui.Create("DFrame")
		


		f:Hide()

		IGS.UI=function()
			if f:IsVisible() then
				f:Hide()
			else
				f:Show()
			end
		end


		surface.SetFont("mstdon32")
		monw,monh=surface.GetTextSize("RUB")
		nik=surface.GetTextSize(myname)

		if nik > 250 then
			nik=nik-250
			local mynewname=''

			for i=1,string.len(myname) do
				nik=surface.GetTextSize(mynewname..myname[i])
				if nik < 200 then
					mynewname=mynewname..myname[i]
				else
					mynewname=mynewname..'...'
					myname=mynewname
					break
				end
			end

		end

		if nik > 125 then
			nik=nik-125
		end


		f:SetSize(ScrW()*0.7+nik,ScrH()*0.95) -- ScrW()*0.6+nik,ScrH()*0.6)
		f:MakePopup()
		f:Center()
		f:SetTitle('')
		f:ShowCloseButton(false)

		--[[SPRAVKA EBANAYA

		local spravka_ebanaya=vgui.Create("DButton")
		spravka_ebanaya.txt="Справка"
		spravka_ebanaya.w,spravka_ebanaya.h=f:GetPos()
		surface.SetFont("mstdon32")
		spravka_ebanaya.tw,spravka_ebanaya.th=surface.GetTextSize(spravka_ebanaya.txt)
		spravka_ebanaya:SetPos(spravka_ebanaya.w,spravka_ebanaya.h-(spravka_ebanaya.th+20))
		spravka_ebanaya:SetSize(spravka_ebanaya.tw+20,spravka_ebanaya.th+20)
		spravka_ebanaya.DoClick=function()
			print('dolb')
		end
		spravka_ebanaya.Paint=function(s,w,h)
			s:SetVisible(f:IsVisible())
			draw.RoundedBox(0,0,0,w,h,color_black_50) 
			draw.SimpleText( s.txt, "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, bkg3,1,1 )
		end

		]]
		 
		local c1=12+f:GetTall()*0.15/12*2*2
		c1=c1*2
		f.Paint=function(s,w,h)
			Derma_DrawBackgroundBlur( s, s.m_fCreateTime )
			draw.RoundedBox(0,0,0,w,h,bkg2)
			draw.TexturedQuad
			{ 
				texture = gradid,
				color = bkg1,
				x = 0,
				y = 0, 
				w = w,
				h = h
			}
			draw.RoundedBox(0,0,0,w,s:GetTall()*0.15,bkg3) 
			draw.SimpleText( myname, "mstdon24", c1, 12, color_white, 0,0, 1, color_black )
			draw.SimpleText( LocalPlayer():GetUserGroup(), "mstdon18", c1, 36, color_white_50, 0,0, 1, color_black )
		end
		 
		local e1=vgui.Create("DButton",f)
		e1:SetPos(12,f:GetTall()*0.15/12*2)
		e1:SetSize(f:GetTall()*0.15/12*8,f:GetTall()*0.15/12*8)
		e1:SetText('')
		local e=vgui.Create("AvatarImage",f)
		e:SetPlayer(LocalPlayer(), 128)
		e:SetPos(12,f:GetTall()*0.15/12*2)
		e:SetSize(f:GetTall()*0.15/12*8,f:GetTall()*0.15/12*8)
		e:SetPaintedManually(true)
		local calcpoly=function(w,h)
		  local poly = {}

		  local x = w/2
		  local y = h/2
		  local radius = h/2

		  table.insert(poly, { x = x, y = y })

		  for i = 0, 36 do
		    local a = math.rad((i / 36) * -360)
		    table.insert(poly, { x = x + math.sin(a) * radius, y = y + math.cos(a) * radius })
		  end

		  local a = math.rad(0)
		  table.insert(poly, { x = x + math.sin(a) * radius, y = y + math.cos(a) * radius })
		  return poly
		end
		e.data=calcpoly(e:GetWide(),e:GetTall())
		e1.Paint=function(s,w,h)
		  render.ClearStencil()
		  render.SetStencilEnable(true)

		  render.SetStencilWriteMask(1)
		  render.SetStencilTestMask(1)

		  render.SetStencilFailOperation(STENCILOPERATION_REPLACE)
		  render.SetStencilPassOperation(STENCILOPERATION_ZERO)
		  render.SetStencilZFailOperation(STENCILOPERATION_ZERO)
		  render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_NEVER)
		  render.SetStencilReferenceValue(1)

		  draw.NoTexture()
		  surface.SetDrawColor(color_white)
		  surface.DrawPoly(e.data)

		  render.SetStencilFailOperation(STENCILOPERATION_ZERO)
		  render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
		  render.SetStencilZFailOperation(STENCILOPERATION_ZERO)
		  render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
		  render.SetStencilReferenceValue(1)

		  e:PaintManual()

		  render.SetStencilEnable(false)
		  render.ClearStencil()
		end

		local c=vgui.Create("DButton",f)
		c:SetSize(f:GetTall()*0.15/12*4,f:GetTall()*0.15/12*4)
		c:SetPos(f:GetWide()-f:GetTall()*0.15/12*4-24,f:GetTall()*0.15/12*4)
		c.DoClick=function()
		surface.PlaySound("server/ui/click2.wav")
			f:Hide() 
		end
		c:SetText('')
		c.Paint=function(s,w,h)
			surface.SetDrawColor(color_white)

			surface.DrawLine( 0,0,w,h )
			surface.DrawLine( w,0,0,h )

			--surface.DrawLine( w,1,0,h+1 )
			surface.DrawLine( w,-1,0,h-1 )


			--surface.DrawLine( 1,0,w+1,h )
			surface.DrawLine( 0,1,w,h+1 )

		end

		surface.SetFont( "mstdon24" )
		--surface.GetTextSize( string text )

		local b1=vgui.Create("DButton",f)
		b1:SetPos(c1+surface.GetTextSize(myname)+12,12)
		surface.SetFont( "mstdon32" )
		b1:SetSize(80+surface.GetTextSize("Главная"),f:GetTall()*0.15/12*8)
		b1:SetText''
		b1.Paint=function(s,w,h)
			
			if s:IsDown() or s.active then
				draw.RoundedBox(0,0,0,w,h,prim) 
			else
				if s.Hovered then
					draw.RoundedBox(0,0,0,w,h,bkg8) 
				else
					draw.RoundedBox(0,0,0,w,h,bkg4) 
				end
			end
			draw.SimpleText( "Главная", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, bkg3,1,1 )
			
		end


		surface.SetFont( "mstdon24" )
		local b2=vgui.Create("DButton",f)
		b2:SetPos(c1+surface.GetTextSize(myname)+b1:GetWide()+14,12)
		surface.SetFont( "mstdon32" )
		b2:SetSize(80+surface.GetTextSize("Платежи"),f:GetTall()*0.15/12*8)
		b2:SetText''
		b2.Paint=function(s,w,h)
			if s:IsDown() or s.active then
				draw.RoundedBox(0,0,0,w,h,prim) 
			else
				if s.Hovered then
					draw.RoundedBox(0,0,0,w,h,bkg8) 
				else
					draw.RoundedBox(0,0,0,w,h,bkg4) 
				end
			end
			draw.SimpleText( "Платежи", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, bkg3,1,1 )
		end
		  
		surface.SetFont( "mstdon24" )
		local b3=vgui.Create("DButton",f)
		b3:SetPos(c1+surface.GetTextSize(myname)+b1:GetWide()+16+b2:GetWide(),12)
		surface.SetFont( "mstdon32" )
		b3:SetSize(80+surface.GetTextSize("Инвентарь"),f:GetTall()*0.15/12*8)
		b3:SetText''
		b3.Paint=function(s,w,h)
			if s:IsDown() or s.active then
				draw.RoundedBox(0,0,0,w,h,prim) 
			else
				if s.Hovered then
					draw.RoundedBox(0,0,0,w,h,bkg8) 
				else
					draw.RoundedBox(0,0,0,w,h,bkg4) 
				end
			end
			draw.SimpleText( "Инвентарь", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, bkg3,1,1 )
		end
		surface.SetFont( "mstdon24" )
		local b5=vgui.Create("DButton",f)
		b5:SetPos(c1+surface.GetTextSize(myname)+b1:GetWide()+b2:GetWide()+b3:GetWide()+24,b3:GetTall()/3+8)
		b5:SetSize(monw+10,b3:GetTall()/3+10)
		b5:SetText''
		b5.Paint=function(s,w,h)
			draw.RoundedBox(0,0,0,w,h,prim)
			draw.SimpleText("RUB","mstdon32",w*0.5,h*0.5,color_white,1,1) 
		end

		  
		surface.SetFont( "mstdon24" )
		local balance = 0
		local b4=vgui.Create("DButton",f)
		b4:SetPos(c1+surface.GetTextSize(myname)+b1:GetWide()+b2:GetWide()+b3:GetWide()+b5:GetWide()+26,b3:GetTall()/3+8)
		surface.SetFont( "mstdon32" )
		b4:SetText'' 
		local balance = LocalPlayer():GetIGSVar("igs_balance") or 0
		b4:SetSize(10+surface.GetTextSize(balance),b3:GetTall()/3+10)
		b4.Paint=function(s,w,h)
			balance = LocalPlayer():GetIGSVar("igs_balance") or 0
			s:SetSize(10+surface.GetTextSize(balance),b3:GetTall()/3+10)
			draw.SimpleText(balance, "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, bkg3,1,1 )
		end

		surface.SetFont( "mstdon24" )

		b1.active=true

		local w1 = vgui.Create("Panel",f)
		w1:SetPos(0,f:GetTall()*0.15)
		w1:SetSize(f:GetWide(),f:GetTall()-(f:GetTall()*0.15))
		w1:SetText''

		local d1 = vgui.Create( "DScrollPanel", w1 )
		d1:Dock(1)

		local sbar = d1:GetVBar()
		function sbar:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnUp:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnDown:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnGrip:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, prim)
		end
		 
		local counter,cats=4,{}

		w1.Paint=function(s,w,h)
			draw.RoundedBox(0,0,0,w,40,color_black_50)
		end

		for k,v in pairs(IGS.ITEMS.STORED) do
			if not isstring(v.category) then continue end
			cats[v.category]=true
		end
		cats["Другое"]=true

		local width,height,bkg5,bkg6=5,5,Color(22,24,25),Color(22,27,28)


		 
		local w2 = vgui.Create("Panel",f)
		w2:SetPos(0,f:GetTall()*0.15)
		w2:SetSize(f:GetWide(),f:GetTall()-(f:GetTall()*0.15))
		w2:SetText''
		w2.Paint=function(s,w,h)
			if s.loading then
				draw.SimpleText( 'Загрузка...', "mstdon32", w*0.5, h*0.5, prim, 1,1, 1, color_white,1,1 )
			end
		end
		w2.lasttime=CurTime()-11

		 
		local d = vgui.Create( "DScrollPanel", w2 )
		d:Dock(1)

		local sbar = d:GetVBar()
		function sbar:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnUp:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnDown:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnGrip:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, prim)
		end

		local w3 = vgui.Create("Panel",f)
		w3:SetPos(0,f:GetTall()*0.15)
		w3:SetSize(f:GetWide(),f:GetTall()-(f:GetTall()*0.15))
		w3:SetText''
		w3.Paint=function(s,w,h)
			if s.loading then
				draw.SimpleText( 'Загрузка...', "mstdon32", w*0.5, h*0.5, prim, 1,1, 1, color_white,1,1 )
			end
		end
		 
		w3.d = vgui.Create( "DScrollPanel", w3 )
		w3.d:Dock(1)

		local sbar = w3.d:GetVBar()
		function sbar:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnUp:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnDown:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, bkg2)
		end
		function sbar.btnGrip:Paint(w, h)
			draw.RoundedBox(0, 0, 0, w, h, prim)
		end



		local w4 = vgui.Create("Panel",f)
		w4:SetPos(0,f:GetTall()*0.15)
		w4:SetSize(f:GetWide(),f:GetTall()-(f:GetTall()*0.15))
		w4:SetText''

		local function DrawRainbowText( frequency, str, font, x, y )

			surface.SetFont( font )
			surface.SetTextPos( x, y )

			for i = 1, utf8.len(str) do
				local col = HSVToColor( ( (CurTime()+i) % 360)*50, 1, 1 )
				surface.SetTextColor( col.r, col.g, col.b )	
				surface.DrawText( utf8.sub(str,i,i) )
			end

		end

		surface.SetFont("mstdon64")
		w4.w,w4.h=surface.GetTextSize("Пополнение счёта")

		w4.Paint=function(s,w,h)
			DrawRainbowText(1,"Пополнение счёта","mstdon64",w*0.5-(w4.w*0.5),20)
		end

		local values={
			"50","100","250","500","1000"
		}

		w4.inp=vgui.Create("DTextEntry",w4)

		w4.wi=0
		for i=1,#values do
			surface.SetFont("mstdon64")
			w4[i],w4.h2=surface.GetTextSize(values[i])
			w4.wi=w4.wi+w4[i]+10
		end
		w4.wi2=-5
		for i=1,#values do
			w4['b'..i]=vgui.Create("DButton",w4)
			w4['b'..i]:SetPos(w4:GetWide()*0.5-(w4.wi*0.5)+w4.wi2,w4.h*3+30)
			w4.wi2=w4.wi2+w4[i]+15
			w4['b'..i]:SetSize(w4[i]+10,w4.h2+5)
			w4['b'..i]:SetText''
			w4['b'..i].Paint=function(s,w,h)
				draw.RoundedBox(0,0,0,w,h,bkg7)
				surface.SetDrawColor(prim)
				surface.DrawOutlinedRect(0,0,w,h)
				if s.Hovered then
					draw.RoundedBox(0,0,0,w,h,prim)
				end
				draw.SimpleText(values[i],"mstdon64",w*0.5,h*0.5,color_white,1,1)
			end 
			w4['b'..i].DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
				w4.inp:SetValue(values[i])
			end
		end

		w4.inp:SetSize(w4.wi2,w4.h+5)
		w4.inp:SetPos(w4:GetWide()*0.5-w4.inp:GetWide()*0.5+5,w4.h*2+5)
		w4.inp:SetNumeric(true)
		w4.inp.OnLoseFocus = function( self )

			if isnumber(tonumber(self:GetValue())) and (tonumber(self:GetValue()) < 10) then
		    	self:SetValue( tonumber(10) )
			end
		end
		w4.inp.Paint=function(s,w,h)
			draw.RoundedBox(0,0,0,w,h,bkg7)
			surface.SetDrawColor(prim)
			surface.DrawOutlinedRect(0,0,w,h)
			if s:IsEditing() then
				draw.SimpleText(s:GetText()..'|',"mstdon64",2.5,2.5,color_white)
			else
				draw.SimpleText(s:GetText(),"mstdon64",2.5,2.5,color_white)
			end
		end

		w4.b=vgui.Create("DButton",w4)
		w4.b.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			net.Start("MSTDONATE")
			net.SendToServer()
		end
		net.Receive("MSTDONATE",function()
			gui.OpenURL(net.ReadString()..w4.inp:GetValue())
		end)
		w4.b:SetSize(w4.inp:GetWide(),w4.inp:GetTall())
		w4.b:SetPos(w4:GetWide()*0.5-w4.inp:GetWide()*0.5+5,w4.h*2+w4.inp:GetTall()+(w4.h*2)+5)
		w4.b:SetText('')
		w4.b.Paint=function(s,w,h)
			draw.RoundedBox(0,0,0,w,h,bkg7)
			if s.Hovered then
				draw.RoundedBox(0,0,0,w,h,bkg8)
			end
			draw.SimpleText( "Пополнить баланс", "mstdon64", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
		end

		local w5 = vgui.Create("Panel",f)
		w5:SetPos(0,f:GetTall()*0.15)
		w5:SetSize(f:GetWide(),f:GetTall()-(f:GetTall()*0.15))
		w5:SetText''

		local w6 = vgui.Create("Panel",f)
		w6:SetPos(0,f:GetTall()*0.15)
		w6:SetSize(f:GetWide(),f:GetTall()-(f:GetTall()*0.15))
		w6:SetText''

		w5.pnl=vgui.Create("Panel",w5)
		w5.pnl:SetPos(w5:GetWide()*0.02,w5:GetWide()*0.02)
		w5.pnl:SetSize(w5:GetWide()*0.96,w5:GetTall()-w5:GetWide()*0.04)
		w5.pnl:SetText''

		w5.back=vgui.Create("DButton",w5.pnl)
		surface.SetFont("mstdon32")
		w5.back.w,w5.back.h=surface.GetTextSize("Вернуться назад")
		w5.back:SetSize(w5.back.w+30,w5.back.h+20)
		w5.back:SetText''
		w5.back.Paint=function(s,w,h)
			draw.RoundedBox(0,0,0,w,h,color_black_200)
			draw.SimpleText( " < Вернуться назад ", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
		end
		w5.back.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			b1.active=true 
			b2.active=false
			b3.active=false
			w1:Show()
			w2:Hide()
			w3:Hide()
			w4:Hide()
			w5:Hide()
		w6:Hide()
		end 

		w5.d=vgui.Create("RichText",w5.pnl)
		w5.d:SetPos(w5.pnl:GetWide()*0.5+3,w5.pnl:GetTall()*0.7+monh+4)
		w5.d:SetSize(w5.pnl:GetWide()*0.5-3,w5.pnl:GetTall()*0.3-monh)
		w5.d:SetFontInternal("mstdon24")
		function w5.d:PerformLayout()

			self:SetFontInternal("mstdon24")

		end

		surface.SetFont("mstdon64")
		local sh1,sw1=surface.GetTextSize("A")

		w5.dd=vgui.Create("RichText",w5.pnl)
		w5.dd:SetPos(w5.pnl:GetWide()*0.5+10, 15+sw1)
		w5.dd:SetSize(w5.pnl:GetWide()*0.5-3-8,w5.pnl:GetTall()*0.7-(monh*2)-20)
		w5.dd:SetFontInternal("mstdon32")
		function w5.dd:PerformLayout()

			self:SetFontInternal("mstdon32")

		end
		w5.dd:SetVerticalScrollbarEnabled(true)

		w5.buy=vgui.Create("DButton",w5.pnl)
		w5.buy:SetZPos( 32767 )
		surface.SetFont("mstdon32")
		w5.buy.w,w5.buy.h=surface.GetTextSize("Приобрести")
		w5.buy:SetPos(w5.pnl:GetWide()*0.5+10,w5.pnl:GetTall()*0.7-(w5.buy.h+30))
		w5.buy:SetSize(w5.buy.w+30,w5.buy.h+20)
		w5.buy:SetText''
		w5.buy.Paint=function(s,w,h)
			draw.RoundedBox(0,0,0,w,h,bkg7)
			if s.Hovered then
				draw.RoundedBox(0,0,0,w,h,bkg8)
			end
			if w5.buy.loading then
				draw.SimpleText( "Загрузка...", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
			else
				draw.SimpleText( "Приобрести", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
			end
		end


		w5.buy.loading=false
		w5.buy.DoClick=function()
			surface.PlaySound("ambient/office/coinslot1.wav")
			if balance < w5.buy.item.price then
				local txt,tmp="Ошибка! Для покупки нужно ещё "..tostring(w5.buy.item.price-balance).." RUB.",vgui.Create("DFrame")
				surface.SetFont("mstdon64")
				tmp.w,tmp.h=surface.GetTextSize(txt)
				tmp:SetSize(tmp.w+40,tmp.h+140)
				tmp:Center()
				tmp:MakePopup()
				tmp:ShowCloseButton(false)
				tmp.Paint=function(s,w,h)
					draw.RoundedBox(0,0,0,w,h,bkg3)
					draw.SimpleText(txt,"mstdon64",w*0.5,h*0.33,color_white,1,1)
					surface.SetDrawColor(prim)
					surface.DrawOutlinedRect( 0,0,w,h )
				end
				tmp:SetTitle''
				tmp.b=vgui.Create("DButton",tmp)
				tmp.b.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
					w4.inp:SetValue(tostring(w5.buy.item.price-balance))
					b1.active=false 
					b2.active=false
					b3.active=false
					w1:Hide()
					w2:Hide()
					w3:Hide()
					w4:Show()
					w5:Hide()
					w6:Hide()
					tmp:Close() 
				end
				tmp.b:SetSize(tmp:GetWide(),60)
				tmp.b:SetPos(0,tmp:GetTall()-70)
				tmp.b:SetText('')
				tmp.b.Paint=function(s,w,h)
					draw.RoundedBox(0,20,0,w-40,h,bkg7)
					if s.Hovered then
						draw.RoundedBox(0,20,0,w-40,h,bkg8)
					end
					draw.SimpleText( "Пополнить баланс", "mstdon64", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
				end
				tmp.c=vgui.Create("DButton",tmp)
				tmp.c:SetSize(tmp:GetTall()*0.15/12*4,tmp:GetTall()*0.15/12*4)
				tmp.c:SetPos(tmp:GetWide()-tmp:GetTall()*0.15/12*4-24,tmp:GetTall()*0.15/12*4)
				tmp.c.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
					tmp:Close() 
				end
				tmp.c:SetText('')
				tmp.c.Paint=function(s,w,h)
					surface.SetDrawColor(color_white)

					surface.DrawLine( 0,0,w,h )
					surface.DrawLine( w,0,0,h )

					surface.DrawLine( w,-1,0,h-1 )

					surface.DrawLine( 0,1,w,h+1 )

				end
			else
				IGS.Purchase(w5.buy.item.uid,function(a)
						if a then
							local txt,tmp=a,vgui.Create("DFrame")
							surface.SetFont("mstdon64")
							tmp.w,tmp.h=surface.GetTextSize(txt)
							tmp:SetSize(tmp.w+40,tmp.h+140)
							tmp:Center()
							tmp:MakePopup()
							tmp:ShowCloseButton(false)
							tmp.Paint=function(s,w,h)
								draw.RoundedBox(0,0,0,w,h,bkg3)
								draw.SimpleText(txt,"mstdon64",w*0.5,h*0.33,color_white,1,1)
								surface.SetDrawColor(prim)
								surface.DrawOutlinedRect( 0,0,w,h )
							end
							tmp:SetTitle''
							tmp.b=vgui.Create("DButton",tmp)
							tmp.b.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")

								tmp:Close() 
							end
							tmp.b:SetSize(tmp:GetWide(),60)
							tmp.b:SetPos(0,tmp:GetTall()-70)
							tmp.b:SetText('')
							tmp.b.Paint=function(s,w,h)
								draw.RoundedBox(0,20,0,w-40,h,bkg7)
								if s.Hovered then
									draw.RoundedBox(0,20,0,w-40,h,bkg8)
								end
								draw.SimpleText( "Понятно", "mstdon64", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
							end
							tmp.c=vgui.Create("DButton",tmp)
							tmp.c:SetSize(tmp:GetTall()*0.15/12*4,tmp:GetTall()*0.15/12*4)
							tmp.c:SetPos(tmp:GetWide()-tmp:GetTall()*0.15/12*4-24,tmp:GetTall()*0.15/12*4)
							tmp.c.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
								tmp:Close() 
							end
							tmp.c:SetText('')
							tmp.c.Paint=function(s,w,h)
								surface.SetDrawColor(color_white)

								surface.DrawLine( 0,0,w,h )
								surface.DrawLine( w,0,0,h )

								surface.DrawLine( w,-1,0,h-1 )

								surface.DrawLine( 0,1,w,h+1 )

							end
						else
							b1.active=false 
							b2.active=false
							b3.active=true
							w1:Hide()
							w2:Hide()
							w3:Show()
							w4:Hide()
							w5:Hide()
							w6:Hide()
							updinvent()
						end 
					end)
			end
		end

		
		--[[
		local html=vgui.Create("HTML")
		html:SetSize(800,800)
		html:Center()
		html:OpenURL("https://mst-gmod.ru/bog.png")
		html:OpenURL("https://mst-gmod.ru/bog.png")
		html:OpenURL("https://mst-gmod.ru/bog.png")
		html:Hide()
		local alive=LocalPlayer():Alive()
		local played=1
		hook.Add("Think","eptvoymatkaktakmojnoblyatprosrat",function()
			if not (LocalPlayer():Alive() == alive) then
				alive=LocalPlayer():Alive()
				if not alive then
				
					sound.PlayURL( "https://mst-gmod.ru/donatesound.mp3", "mono", function(s) s:SetPlaybackRate((10-played)*0.1) s:Play() played=played+1 
						html:Show()
						timer.Simple(5+(played*1.1),function()
							html:Hide()
						end)
						util.ScreenShake(LocalPlayer():GetPos(), 2500, 2500, 6, 2500) end)

				end
			end
		end)]] -- РАЗКОМЕНТЬ ЭТО ДЛЯ ОПТИМИЗАЦИИ

		local function resort(isg,g)
			counter=4
			height=5

			if isg then
				d1:Clear()
				local yourp=0
				
				w1.back:Show()

				--[[d1.back=vgui.Create("DButton",d1)
				surface.SetFont("mstdon32")
				d1.back.w,d1.back.h=surface.GetTextSize("Вернуться назад")
				d1.back:SetSize(d1.back.w+30,d1.back.h+20)
				d1.back:SetPos(0,d1.back.h+5)
				d1.back:SetText''
				d1.back.Paint=function(s,w,h)
					draw.RoundedBox(0,0,0,w,h,color_black_200)
					draw.SimpleText( " < Вернуться назад ", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
				end
				d1.back.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
					b1.active=true 
					b2.active=false
					b3.active=false
					w1:Show()
					w2:Hide()
					w3:Hide()
					w4:Hide()
					w5:Hide()
					w6:Hide()
					d1.back:Close()
				end ]]
				for k,v in pairs(g.items.STORED) do
					if v.isnull then continue end
					if (not istable(v.group)) and not ( type(v.group) == "nil") then continue end
					if (not isstring(v.category)) and (not v.hidden) then v.category="Другое" end
					if not cats[v.category] then continue end
					if counter == 4 then
						local p = vgui.Create("Panel",d1)
						yourp=p
						p:SetPos(0,height)
						p:SetSize(w1:GetWide(),(w1:GetWide()-30)/3 )
						counter=1 
						height=height+(w1:GetWide()-30)/3+10
					end 
					
					local row=vgui.Create("DButton",yourp)
					row:SetPos((w1:GetWide()-30)/3*(counter-1)+10,45)
					row:SetSize((w1:GetWide()-30)/3-5,(w1:GetWide()-30)/3)
					row:SetText''
					row.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
						local newtbl=v.item
						rawset(newtbl,'icon',{isModel=false,icon=g.icon_url})
						--rawset(newtbl,'group',nil)
						openitem(newtbl)
					end
					local icon=""
					if isstring(g.icon_url) and string.StartWith(g.icon_url,"http") and WebMaterials[g.icon_url] then
						icon=g.icon_url
					end
					if (istable(v.item.icon) and not v.item.icon.isModel) and WebMaterials[v.item.icon.icon]  then
						icon=v.item.icon.icon
					end
					row.Paint=function(s,w,h)
						draw.RoundedBox(0,0,0,w,h*0.6,bkg5)
						draw.RoundedBox(0,0,h*0.6,w,h*0.4,bkg6) 

						if icon=="" then
							draw.SimpleText( "Нет иконки", "mstdon24", w*0.5, h*0.3, prim, 1,1, 1, color_white,1,1 )
						else
							surface.SetDrawColor( 255, 255, 255, 255 )
							surface.SetMaterial( WebMaterialsCache[icon] )
							surface.DrawTexturedRect( 0, 0, w, h*0.6 )
						end

						draw.SimpleText( v.name, "mstdon32", 5, h*0.66, color_white, 0,1, 1, color_white,1,1 )
						local ww=surface.GetTextSize(v.item.price)
						--draw.RoundedBox(0,ww+3,h*0.66+28,www+5,hh-4,prim) 
						if v.item.discounted_from then
							surface.SetFont("mstdon24")
							local wwww,hhhh=surface.GetTextSize(v.item.discounted_from)
							draw.SimpleText( v.item.discounted_from, "mstdon24", 5, h*0.66+20, color_white, 0,1, 1, color_white,1,1 )
							surface.SetDrawColor(prim_alp)
							for i=1,2 do
								surface.DrawLine(5,h*0.66+19+i,wwww+5,h*0.66+14+i)
							end

						end
						if tostring(v.item.price)=="0" then
							--ww=surface.GetTextSize("Бесплатно")
							draw.SimpleText( "Бесплатно", "mstdon32", 5, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
						else
							draw.SimpleText( v.item.price, "mstdon32", 5, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
							draw.RoundedBox(0,16+ww,h*0.66+36-(monh*0.5),monw+12,monh,prim) 
							draw.SimpleText( 'RUB', "mstdon32", 22+ww, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
						end
						
						
						
					end
					counter=counter+1
				end
				return
			end
			--PrintTable(IGS.ITEMS.STORED)
			d1:Clear()
			local yourp=0
			local usedg={}

			for k,v in pairs(IGS.ITEMS.STORED) do
				if v.isnull then continue end
				if (not istable(v.group)) and not ( type(v.group) == "nil") then continue end
				if (not isstring(v.category)) and (not v.hidden) then v.category="Другое" end
				if v.hidden then continue end
				if not cats[v.category] then continue end
				if counter == 4 then
					local p = vgui.Create("Panel",d1)
					yourp=p
					p:SetPos(0,height)
					p:SetSize(w1:GetWide(),(w1:GetWide()-30)/3 )
					counter=1 
					height=height+(w1:GetWide()-30)/3+10
				end 
				if istable(v.group) and usedg[v.group.name] then
					continue
				end

				if (type(v.group) == 'function') then
					continue
				end
				--[[print('00000000000000000000000000000000000000000000000')
				print(v,type(v.group),v.name)
				PrintTable(v)]]
				if (istable(v.group) and not usedg[v.group.name]) then 
					local row=vgui.Create("DButton",yourp)
					row:SetPos((w1:GetWide()-30)/3*(counter-1)+10,45)
					row:SetSize((w1:GetWide()-30)/3-5,(w1:GetWide()-30)/3)
					row:SetText''
					row.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
						openitem(v.group,true)
					end
					usedg[v.group.name]=true
					row.Paint=function(s,w,h)
						draw.RoundedBox(0,0,0,w,h*0.6,bkg5)
						draw.RoundedBox(0,0,h*0.6,w,h*0.4,bkg6) 
						if (not isstring(v.group.icon_url)) or (not string.StartWith(v.group.icon_url,"http")) then
							draw.SimpleText( "Нет иконки", "mstdon24", w*0.5, h*0.3, prim, 1,1, 1, color_white,1,1 )
						else
							if WebMaterials[v.group.icon_url] then
								surface.SetDrawColor( 255, 255, 255, 255 )
								surface.SetMaterial( WebMaterialsCache[v.group.icon_url] )
								surface.DrawTexturedRect( 0, 0, w, h*0.6 )
							end
						end

						draw.SimpleText( v.group.name, "mstdon32", 5, h*0.66, color_white, 0,1, 1, color_white,1,1 )
						local min,max=nil,nil
						for k11,v11 in pairs(v.group.items.STORED) do
							if not isnumber(min) then
								min=v11.item.price
							end
							if not isnumber(max) then
								max=v11.item.price
							end
							if v11.item.price < min then
								min = v11.item.price
							end
							if v11.item.price > max then
								max = v11.item.price
							end
						end
						local ww=surface.GetTextSize(min..' - '..max)

						draw.SimpleText( min..' - '..max, "mstdon32", 5, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
						draw.RoundedBox(0,16+ww,h*0.66+36-(monh*0.5),monw+12,monh,prim) 
						draw.SimpleText( 'RUB', "mstdon32", 22+ww, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
						
					end
					counter=counter+1
					continue 
				end
				local row=vgui.Create("DButton",yourp)
				row:SetPos((w1:GetWide()-30)/3*(counter-1)+10,45)
				row:SetSize((w1:GetWide()-30)/3-5,(w1:GetWide()-30)/3)
				row:SetText''
				row.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
					openitem(v)
				end
				row.Paint=function(s,w,h)
					draw.RoundedBox(0,0,0,w,h*0.6,bkg5)
					draw.RoundedBox(0,0,h*0.6,w,h*0.4,bkg6) 
					if (not istable(v.icon)) or (not string.StartWith(v.icon.icon,"http")) then
						draw.SimpleText( "Нет иконки", "mstdon24", w*0.5, h*0.3, prim, 1,1, 1, color_white,1,1 )
					else
						if WebMaterials[v.icon.icon] then
							surface.SetDrawColor( 255, 255, 255, 255 )
							surface.SetMaterial( WebMaterialsCache[v.icon.icon] )
							surface.DrawTexturedRect( 0, 0, w, h*0.6 )
						end
					end

					draw.SimpleText( v.name, "mstdon32", 5, h*0.66, color_white, 0,1, 1, color_white,1,1 )
					local ww=surface.GetTextSize(v.price)
					--draw.RoundedBox(0,ww+3,h*0.66+28,www+5,hh-4,prim) 
					if v.discounted_from then
						surface.SetFont("mstdon24")
						local wwww,hhhh=surface.GetTextSize(v.discounted_from)
						draw.SimpleText( v.discounted_from, "mstdon24", 5, h*0.66+20, color_white, 0,1, 1, color_white,1,1 )
						surface.SetDrawColor(prim)
						for i=1,2 do
							surface.DrawLine(5,h*0.66+19+i,wwww+5,h*0.66+14+i)
						end

					end

					if tostring(v.price)=="0" then
						--draw.SimpleText( "Бесплатно", "mstdon32", w-w5.buy.w-50, h*0.7-(w5.buy.h+30), color_white, 2,0, 1, color_white,1,1 )
						ww=surface.GetTextSize("Бесплатно")
						draw.SimpleText(  "Бесплатно", "mstdon32", 5, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
					else
						draw.SimpleText( v.price, "mstdon32", 5, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
						draw.RoundedBox(0,16+ww,h*0.66+36-(monh*0.5),monw+12,monh,prim) 
						draw.SimpleText( 'RUB', "mstdon32", 22+ww, h*0.66+36, color_white, 0,1, 1, color_white,1,1 )
					end

					
				end
				counter=counter+1
			end

		end 

		function openitem(item,isg)

			if isg then
				resort(true,item)
				return
			end

			b1.active=true 
			b2.active=false
			b3.active=false
			w1:Hide()
			w2:Hide()
			w3:Hide()
			w4:Hide()
			w5:Show()
			w6:Hide()
			
			w5.d:Clear()
			w5.d:SetText('')

			w5.dd:Clear()
			w5.dd:SetText('')

			

			local infos=string.Explode("\n",item.description)
				for i=1,#infos do
					w5.dd:InsertColorChange(255, 255, 255, 255)
					w5.dd:AppendText(infos[i]..'\n')
				end

			if isstring(IGS.ITEMS.mst_INFOS[item.uid]) then


				

				local infos=string.Explode("\n",IGS.ITEMS.mst_INFOS[item.uid])
				for i=1,#infos do
					w5.d:InsertColorChange(255, 255, 255, 255)
					w5.d:AppendText(infos[i]..'\n')
				end
			end

			if IsValid(w5.term) then
				w5.term:Remove()
			end

			if isnumber(tonumber(item.termin)) then
				if tonumber(item.termin) > -1 then
					w5.term=vgui.Create("Panel",w5.pnl)
					if tonumber(item.termin) < 30 then
						w5.term.txt='на '..item.termin..' день'
					else
						w5.term.txt='на '..math.floor(tonumber(item.termin)/30)..' месяц'
					end
					if tonumber(item.termin)==0 then
						w5.term.txt='навсегда'
					end
					surface.SetFont("mstdon24")
					w5.term.w,w5.term.h=surface.GetTextSize(w5.term.txt)
					w5.term:SetPos(w5.pnl:GetWide()*0.5+50+w5.buy.w,w5.pnl:GetTall()*0.7-(w5.term.h+30))
					w5.term:SetSize(w5.term.w+30,w5.term.h+20)
					w5.term.Paint=function(s,w,h)
						draw.SimpleText( s.txt, "mstdon24", w*0.45, h*0.5, color_white, 1,1, 1, color_white,1,1 )
					end
				end
			end
			 
			w5.pnl.Paint=function(s,w,h)
				draw.RoundedBox(0,w*0.5,0,w*0.5,h,bkg3)
				draw.RoundedBox(0,w*0.5,h*0.7,w*0.5,h*0.3,color_black_50)
				if not isstring(IGS.ITEMS.mst_BIG_ICONS[item.uid]) then
					draw.SimpleText( "Нет иконки", "mstdon24", w*0.25, h*0.5, prim, 1,1, 1, color_white,1,1 )
				else
					if WebMaterials[IGS.ITEMS.mst_BIG_ICONS[item.uid]] then
						surface.SetDrawColor( 255, 255, 255, 255 )
						surface.SetMaterial( WebMaterialsCache[IGS.ITEMS.mst_BIG_ICONS[item.uid]] )
						surface.DrawTexturedRect( 0, 0, w*0.5, h )
					end
				end
				draw.SimpleText( item.name, "mstdon64", w*0.5+10, 5, color_white, 0,0, 1, color_white,1,1 )
				surface.SetFont("mstdon64")
				s.w,s.h=surface.GetTextSize(item.name)

				

				--hbuy

				if item.discounted_from then
					surface.SetFont("mstdon24")
					local wwww,hhhh=surface.GetTextSize(item.discounted_from)
					draw.SimpleText( item.discounted_from, "mstdon24", w-w5.buy.w-50-wwww, h*0.7-(w5.buy.h+30)-hhhh, color_white, 0,0, 1, color_white,1,1 )
					surface.SetDrawColor(prim)
					for i=1,2 do
						surface.DrawLine(w-w5.buy.w-50-wwww,h*0.7-(w5.buy.h+30)-(hhhh*0.5),w-w5.buy.w-50,h*0.7-(w5.buy.h+30)-(hhhh*0.5))
					end

				end

				if tostring(item.price)=="0" then
					--ww=surface.GetTextSize("Бесплатно")
					draw.SimpleText( "Бесплатно", "mstdon32", w-w5.buy.w-50, h*0.7-(w5.buy.h+30), color_white, 2,0, 1, color_white,1,1 )
				else
					draw.RoundedBox(0,w-w5.buy.w-45,h*0.7-(w5.buy.h+30),monw+12,monh,prim) 
					draw.SimpleText( 'RUB', "mstdon32", w-w5.buy.w-40, h*0.7-(w5.buy.h+30), color_white, 0,0, 1, color_white,1,1 )

					draw.SimpleText( item.price, "mstdon32", w-w5.buy.w-50, h*0.7-(w5.buy.h+30), color_white, 2,0, 1, color_white,1,1 )
				end

				draw.SimpleText( "Информация:", "mstdon32", w*0.5+5,h*0.7, color_white, 0,0, 1, color_white,1,1 )
					
			end

			w5.buy.item=item
		end

		

		for k,v in SortedPairs(cats) do
			local row = vgui.Create("DButton",w1)
			surface.SetFont("mstdon24")
			local size=surface.GetTextSize(k)
			row.k=k
			row:SetPos(width,5)
			row:SetSize(size+10,30)
			row:SetText''
			width=width+size+15
			row.Paint=function(s,w,h)
				if cats[s.k] then
					draw.RoundedBox(15,0,0,w,h,prim)
				else
					draw.RoundedBox(15,0,0,w,h,color_black_50)
				end
				draw.SimpleText( s.k, "mstdon24", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
			end
			row.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
				cats[row.k]=!cats[row.k]
				width,height=5,5
				counter=4
				resort()
			end
		end

		w1.back=vgui.Create("DButton",w1)
		surface.SetFont("mstdon32")
		w1.back.w,w1.back.h=surface.GetTextSize("Вернуться назад")
		w1.back:SetSize(w1.back.w+30,w1.back.h+20)
		w1.back:SetPos(w1:GetWide()-(w1.back.w+45),5)
		w1.back:SetText''
		w1.back.Paint=function(s,w,h)
			draw.RoundedBox(0,0,0,w,h,color_black_200)
			draw.SimpleText( " < Вернуться назад ", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
		end 
		w1.back.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			b1.active=true 
			b2.active=false
			b3.active=false
			w1:Show()
			w2:Hide()
			w3:Hide()
			w4:Hide()
			w5:Hide()
			w6:Hide()
			w1.back:Hide()
			resort()
		end 

		w1.back:Hide()

		resort()

		w2:Hide()
		w3:Hide()
		w4:Hide()
		w5:Hide()
		w6:Hide()

		b1.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			b1.active=true 
			b2.active=false
			b3.active=false
			w1:Show()
			w2:Hide()
			w3:Hide()
			w4:Hide()
			w5:Hide()
		w6:Hide()
		end

		b2.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			b1.active=false 
			b2.active=true
			b3.active=false
			w1:Hide()
			w2:Show()
			w3:Hide()
			w4:Hide()
			w5:Hide()
		w6:Hide()

			if CurTime() - w2.lasttime > 10 then
				w2.lasttime=CurTime()
				w2.loading=true
				d:Clear()
			 
				IGS.GetMyTransactions(function(a) 
					w2.loading=false
					
					for k,v in pairs(a) do
						local db = d:Add( "DButton" )
						if string.StartWith(v.note,"P: ") then
							local rname=string.Replace(v.note,"P: ","")
							for k1,v1 in pairs(IGS.ITEMS.STORED) do
								if v1.uid == rname then
									rname=v1.name
								end
							end
							db.txt='Покупка '..rname..' за '..v.sum..' RUB. Дата: '..os.date( "%H:%M - %d/%m/%Y" , v.date )
						else
							db.txt='Пополнение на '..v.sum..' RUB. Дата: '..os.date( "%H:%M - %d/%m/%Y" , v.date )
						end
						db:SetText('')
						db:Dock( TOP )
						db:DockMargin( 0, 0, 0, 5 )
						db.Paint = function( s,w,h )
							draw.RoundedBox(0,0,0,w,h,bkg1)
							draw.TexturedQuad
							{ 
								texture = grad,
								color = prim,
								x = 0,
								y = 0, 
								w = w*0.3,
								h = h
							}
							draw.SimpleText( s.txt, "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
						end
					end
				end)
			end


		 
		end

		function updinvent(cl)
			w3.d:Clear()
			w3.loading=true
			IGS.GetInventory(function(a) 
				local counter=0
				w3.loading=false
				--PrintTable(a)
				for k,v in pairs(a) do
					local db = vgui.Create("Panel",w3.d)
					db:SetPos(0,counter*95)
					db:SetSize(w3.d:GetWide()-15,90)
					db.Paint=function(s,w,h)
						draw.RoundedBox(0,0,0,w,h,bkg6)
						draw.RoundedBox(0,0,0,h,h,bkg5)
						if istable(v.item.icon) and (not v.item.icon.isModel) and WebMaterials[v.item.icon.icon] then
							surface.SetDrawColor( 255, 255, 255, 255 )
							surface.SetMaterial( WebMaterialsCache[v.item.icon.icon] )
							surface.DrawTexturedRect( 0, 0, h, h )
						else
							draw.SimpleText("Нет иконки","mstdon18",h*0.5,h*0.5,prim,1,1)
						end
						draw.SimpleText(v.item.name,"mstdon32",h+5,5,color_white)
						draw.SimpleText(v.item.description,"mstdon32",h+5,5+monh,color_white_50)
					end
					counter=counter+1
					surface.SetFont("mstdon32")
					db.w=surface.GetTextSize("Активировать")
					db.b1=vgui.Create("DButton",db)
					db.b1:SetPos(db:GetTall()+5,monh*2+10)
					db.b1:SetSize(db.w+5,monh+5)
					db.b1:SetText''
					db.b1.Paint=function(s,w,h)
						draw.RoundedBox(0,0,0,w,h,bkg7)
						if s.Hovered then
							draw.RoundedBox(0,0,0,w,h,bkg8)
						end
						if db.loading then
							draw.SimpleText( "Загрузка...", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
						else
							draw.SimpleText( "Активировать", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
						end
					end
					db.b1.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
						if db.loading then return end
						db.loading=true
						IGS.ProcessActivate(v.id,function(a,b)
							db.loading=false
							print('[+]',a,b)
							updinvent()
						end)
					end

					surface.SetFont("mstdon32")
					db.w3=surface.GetTextSize("Выбросить")
					db.b2=vgui.Create("DButton",db)
					db.b2:SetPos(db:GetTall()+25+db.w,monh*2+10)
					db.b2:SetSize(db.w3+5,monh+5)
					db.b2:SetText''
					db.b2.Paint=function(s,w,h)
						draw.RoundedBox(0,0,0,w,h,bkg7)
						if s.Hovered then
							draw.RoundedBox(0,0,0,w,h,bkg8)
						end
						if db.loading then
							draw.SimpleText( "Загрузка", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
						else
							draw.SimpleText( "Выбросить", "mstdon32", w*0.5, h*0.5, color_white, 1,1, 1, color_white,1,1 )
						end
					end
					db.b2.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
						if db.loading then return end
						db.loading=true
						IGS.DropItem(v.id,function(a,b)
							db.loading=false
							print('[++]',a,b)
							updinvent()
						end)
					end
				end
			end)
		end 

		b3.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			updinvent()
			b1.active=false 
			b2.active=false
			b3.active=true
			w1:Hide()
			w2:Hide()
			w3:Show()
			w4:Hide()
			w5:Hide()
		w6:Hide()
		end

		b4.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			b1.active=false 
			b2.active=false
			b3.active=false
			w1:Hide()
			w2:Hide()
			w3:Hide()
			w4:Show()
			w5:Hide()
		w6:Hide()
		end

		b5.DoClick=function()
	surface.PlaySound("server/ui/click2.wav")
			b1.active=false 
			b2.active=false
			b3.active=false
			w1:Hide()
			w2:Hide()
			w3:Hide()
			w4:Show()
			w5:Hide()
		w6:Hide()
		end

		--PrintTable(IGS.ITEMS.STORED)

		--[[

		IGS.GetMyTransactions(function(a) 
			PrintTable(a)
		end) ]]

	end
end)