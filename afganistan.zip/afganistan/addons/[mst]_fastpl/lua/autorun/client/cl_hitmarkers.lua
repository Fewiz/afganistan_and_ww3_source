
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/client/cl_hitmarkers.lua ~

]]

RunConsoleCommand("stopsound") 

--https://content.wgcdn.co/wot/ost/mp3/Andrey%20Kulik%20feat.%20Andrius%20Klimka%20-%20Cliff%20(Battle).mp3 -- Годнота
-- https://content.wgcdn.co/wot/ost/mp3/World%20of%20Tanks%20OST%20-%2006%20-%20%D0%A3%D0%BB%D0%B8%D1%87%D0%BD%D1%8B%D0%B9%20%D0%B1%D0%BE%D0%B9.mp3 -- Забивная, короткая
--timer.Create("NiceCum", 3, 2, function()  
	--RunConsoleCommand("say", "joygasm")
--end)
concommand.Add("RRRR",function(ply) 
	sound.PlayURL("https://content.wgcdn.co/wot/ost/mp3/Andrey%20Kulik%20feat.%20Andrius%20Klimka%20and%20Vyacheslav%20Skadorva%20-%20Mountain%20Pass%20(Battle).mp3","mono",function(s) s:Play() end)  
end) 
--sound.PlayURL("https://content.wgcdn.co/wot/ost/mp3/Andrey%20Kulik%20feat.%20Andrius%20Klimka%20-%20Cliff%20(Battle).mp3","mono",function(s) s:Play() end)  
--sound.PlayURL("https://cdn.discordapp.com/attachments/673101426272239629/865215632098197544/-___MP3Ball.ru.mp3","mono",function(s) s:Play() end)  

--sound.PlayFile( "sound/mst_vehicle/night.mp3", "noplay", function( station, errCode, errStr ) -- sound/last_chance/winter.mp3
--		if ( IsValid( station ) ) then
--		    station:Play()
--		    station:SetVolume(0.75)  
--		end 
--end)

concommand.Add("RRRR2",function(ply) 
	sound.PlayFile( "vj_gib/bones_snapping1.wav", "noplay", function( station, errCode, errStr ) -- sound/last_chance/winter.mp3
 		if ( IsValid( station ) ) then
 		    station:Play()
 		    station:SetVolume(1)  
 		end 
 	end)
end) 
gameevent.Listen("player_hurt")

surface.CreateFont("RayDamage", {font = "Calibri", size = 24, weight = 900}) -- win vista+

local shouldHitmarker = false

local stopMarkingTime = CurTime()

local newhp

local color_damage = Color(255, 85, 85)


--[[
hook.Add("HUDPaint", "HitMarkers", function()

	if shouldHitmarker then

		draw.SimpleTextOutlined(newhp, "RayDamage", ScrW() * .5, ScrH() * .6, color_damage, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)

		if newhp == 0 then

			local cin = (math.sin(CurTime()) + 1) / 2

			surface.SetDrawColor(Color(cin * 255, 0, 255 - (cin * 255), math.abs(math.sin(RealTime() * math.pi * 0.3)) * 30))

			surface.DrawRect(0, 0, ScrW(), ScrH())

		end

	end

	

	if CurTime() >= stopMarkingTime then

		shouldHitmarker = false

	end

end)
]]

hook.Add("player_hurt", "HitMarkers", function(data)

	local attacker = Player(data.attacker)

	local hp = data.health



	if (IsValid(attacker) and attacker:Alive() and attacker == LocalPlayer()) then

		newhp = hp

        

		if hp == 0 then

			surface.PlaySound("server/ui/critical.mp3")

			LocalPlayer():ScreenFade(SCREENFADE.IN, Color(231,28,92, 40), 1, 0) -- Color(10, 100, 200, 40), 0.5, 0)  !  10, 100, 200, 40)

		elseif hp >= 0 then

			surface.PlaySound("server/ui/hitmarker.wav")

		end



		shouldHitmarker = true

		stopMarkingTime = CurTime() + 0.2

	end

end)

-----------------------------------------
if SERVER then
	util.AddNetworkString( "HitMarker" )

	hook.Add( "EntityTakeDamage", "HitMarker", function( ent, dmg )
		if not IsValid( ent ) or not ( ent:IsPlayer() or ent:IsNPC() ) then return end

		local attacker = dmg:GetAttacker()
		if not IsValid( attacker ) or not attacker:IsPlayer() then return end

		local health = 0

		if IsValid( ent ) then
			health = ent:Health()

			if ent:IsPlayer() then
				health = health + ent:Armor()
			end
		end

		local damage = dmg:GetDamage()

		net.Start( "HitMarker" )
			net.WriteFloat( math.min( damage / health, 1 ) )
			net.WriteVector( dmg:GetDamagePosition() )
		net.Send( attacker )
	end )
else
	local Enabled = CreateConVar( "cl_hitmarkers", 1, FCVAR_ARCHIVE )
	local InWorld = CreateConVar( "cl_hitmarkers_3d", 0, FCVAR_ARCHIVE )		
	local NormalSound = CreateConVar( "cl_hitmarkers_sound", "buttons/blip1.wav", FCVAR_ARCHIVE )
	local NormalColor = CreateConVar( "cl_hitmarkers_color", "255 255 255", FCVAR_ARCHIVE )
	local LethalFade = CreateConVar( "cl_hitmarkers_lethal_fade", 1, FCVAR_ARCHIVE )
	local LethalSound = CreateConVar( "cl_hitmarkers_lethal_sound", "buttons/bell1.wav", FCVAR_ARCHIVE )
	local LethalColor = CreateConVar( "cl_hitmarkers_lethal_color", "255 50 50", FCVAR_ARCHIVE )

	local function GetConVarColor( convar )
		local exploded = string.Explode( " ", convar:GetString() )

		local r = tonumber( exploded[ 1 ] ) or 255
		local g = tonumber( exploded[ 2 ] ) or 255
		local b = tonumber( exploded[ 3 ] ) or 255
		local a = tonumber( exploded[ 4 ] ) or 255

		return Color( r, g, b, a )
	end

	local function scale( n )
		return n * ( ScrH() / 720 )
	end

	local function DrawHitMarker( hm )
		local mul = hm.mul
		local damage_percent = hm.damage_percent

		if mul <= 0 then return end

		local normal_col = GetConVarColor( NormalColor )
		local lethal_col = GetConVarColor( LethalColor )

		local col = Color( 255, 255, 255, 255 * ( math.min( mul * 2, 1 ) ) )

		if LethalFade:GetBool() then
			col.r = Lerp( damage_percent, normal_col.r, lethal_col.r )
			col.g = Lerp( damage_percent, normal_col.g, lethal_col.g )
			col.b = Lerp( damage_percent, normal_col.b, lethal_col.b )
		else
			col.r = damage_percent < 1 and normal_col.r or lethal_col.r 
			col.g = damage_percent < 1 and normal_col.g or lethal_col.g 
			col.b = damage_percent < 1 and normal_col.b or lethal_col.b 
		end

		surface.SetDrawColor( col )

		local len = scale( 2 + ( 2 + damage_percent * 5 ) * mul )
		local dist = scale( 5 + ( 1 - mul ) * ( 20 + damage_percent * 5 ) )

		local x, y

		if InWorld:GetBool() then
			local screen_pos = hm.pos:ToScreen()

			x = screen_pos.x
			y = screen_pos.y
		else
			x = ScrW() / 2
			y = ScrH() / 2
		end

		surface.DrawLine( x + dist, y + dist, x + dist + len, y + dist + len )
		surface.DrawLine( x - dist, y + dist, x - dist - len, y + dist + len )
		surface.DrawLine( x + dist, y - dist, x + dist + len, y - dist - len )
		surface.DrawLine( x - dist, y - dist, x - dist - len, y - dist - len )

		hm.mul = Lerp( FrameTime() * 2, mul, 0 )
	end

	local HitMarkers = {}

	concommand.Add( "showhitmarkers", function() PrintTable( HitMarkers ) end )

	net.Receive( "HitMarker", function()
		if not Enabled:GetBool() then return end

		local damage_percent = net.ReadFloat()
		local pos = net.ReadVector()
		local mul = 1

		if not InWorld:GetBool() then
			table.Empty( HitMarkers )
		end

		table.insert( HitMarkers, {
			damage_percent = damage_percent,		
			pos = pos,
			mul = mul,
		} )

		local normal_sound = NormalSound:GetString()
		local lethal_sound = LethalSound:GetString()
		local sound = damage_percent < 1 and normal_sound or lethal_sound

		surface.PlaySound( sound )
	end )

	hook.Add( "HUDPaint", "DrawHitMarker", function()
		local i = 1

		while i <= #HitMarkers do
			local hm = HitMarkers[ i ]

			DrawHitMarker( hm )

			if hm.mul < 0.001 then
				table.remove( HitMarkers, i )
			else
				i = i + 1
			end
		end
	end )
end



