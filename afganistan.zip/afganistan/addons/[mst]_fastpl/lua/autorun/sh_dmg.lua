
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_fastpl/lua/autorun/sh_dmg.lua ~

]]


-------------------

if SERVER then
	util.AddNetworkString( 'HitInfo' )

	hook.Add( 'EntityTakeDamage', 'DMInfo', function( ent, dmginfo )
		if not dmginfo:GetAttacker():IsPlayer() or dmginfo:GetDamage() <= 0 or not dmginfo:GetDamage() or ent:Health() <= 0 or ent == dmginfo:GetAttacker() then return end 
 
		net.Start( 'HitInfo' )
			net.WriteUInt( dmginfo:GetDamage(), 8 )
		net.Send( dmginfo:GetAttacker() )
	end )
else
	local Alpha = 0
	local Alpha2 = 0
	local Dmg = 0
	local hide = 0
 
	net.Receive( 'HitInfo', function( len, ply ) 
		if Alpha2 > 40 then
			Dmg = Dmg + net.ReadUInt( 8 )	
		else
			Dmg = net.ReadUInt( 8 )	
		end

		Alpha = 255
		Alpha2 = 255
		hide = 0
 
		LocalPlayer():EmitSound( 'server/ui/hitmarker.wav', 500, 100, 1 )

		timer.Simple( 2, function() hide = 1 end )
	end )
 
	local texture = Material( 'data/cherep.png' )

	hook.Add( 'HUDPaint', 'DMInfo', function()
		if not Dmg then return end
 														-- ScrW() / 2, ScrH() / 1.85, 	  -- 152, 25, 29, 
		draw.SimpleTextOutlined( tostring( Dmg ), 'KeyCaps_mini', ScrW() / 1.92, ScrH() / 2.13, Color( 231,28,92,  Alpha2 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, Alpha ) )
		--draw.SimpleTextOutlined( tostring( Dmg_metal ), 'CW_HUD20', ScrW() / 2.1, ScrH() / 2.13, Color( 25,35,192,  Alpha2_metal ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, Alpha ) )
 			
		local screen = Vector( ScrW() / 2, ScrH() / 2 )

		local sz = 13


		if hide then
			Alpha = Alpha - 5
			Alpha2 = Alpha2 - 2
		end
	end )
end








-----------------------------------------------------------------
local indicatorRadius
if CLIENT then 
	indicatorRadius = ScrH() * 0.135 -- how big is the invisible ring that the indicators rotate around?
end 
local indicators = {} -- store all info about damage indicators here

net.Receive("DamageIndicator", function(len)
	local origin = net.ReadVector()
	local amount = net.ReadUInt(16)

	table.insert(indicators, {
		origin = origin,
		startTime = CurTime(),
		lifeTime = 1.45,
		magnitude = math.Clamp((amount / LocalPlayer():GetMaxHealth()) * indicatorRadius, indicatorRadius / 5, indicatorRadius)
	})
end)

do
	local function outBack(t, b, c, d, s)
		if not s then
			s = 1.70158
		end

		t = t / d - 1

		return c * (t * t * ((s + 1) * t + s) + 1) + b
	end

	local gradient = Material("vgui/gradient-u")
	local animTime = 0.25

	hook.Add("HUDPaint", "DamageIndicators.HUDPaint", function()
		 
	end)
end
