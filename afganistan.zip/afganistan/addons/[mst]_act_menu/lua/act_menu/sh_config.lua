
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_act_menu/lua/act_menu/sh_config.lua ~

]]

DC_ActConfig = {
	[1] = {
		name = "Сесть в транспорт",
		class = {},
		command = function(ply, vehicle)
			if vehicle.wac_seatswitcher then
				for _, v in pairs(vehicle.seats) do
					if not IsValid(v:GetPassenger(0)) and not ply:InVehicle() then
						ply:EnterVehicle(v)
						return
					end
				end				

				return
			end 

			if vehicle.SetPassenger then
				vehicle:SetPassenger( ply )

				return
			end

			ply:EnterVehicle( vehicle )
		end,
		clientComand = function(ply, vehicle)
			return not vehicle:GetNWBool("carKeysVehicleLocked")
		end,
		material = Material("materials/mst_hud/seat.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 1.5,
		id = 1,
	},

	[2] = {
		name = "Закрыть транспорт",
		class = {},
		command = function(ply, vehicle)
				local owner = vehicle:GetNWEntity("carKeysVehicleOwner")
				if (owner != NULL) and (owner:UniqueID() == ply:UniqueID()) then
					vehicle:EmitSound("npc/metropolice/gear" .. math.floor(math.Rand(1, 7)) .. ".wav")
					vehicle:SetNWBool("carKeysVehicleLocked", true)
					vehicle.VehicleLocked = true

					if not (vehicle:WaterLevel() >= 1) then
						timer.Simple(0.5, function()
							if (vehicle:IsValid()) then
								vehicle:EmitSound("carkeys/lock.wav")
							end
						end)
					end
					rp.Notify(ply,NOTIFY_ERROR, 'Автомобиль закрыт')
				else                                       
					rp.Notify(ply, NOTIFY_ERROR, 'Вы не можете закрыть данный транспорт, он не ваш!') 
					vehicle:EmitSound("doors/handle_pushbar_locked1.wav")
				end
		end,
		clientComand = function(ply, vehicle)
			return not vehicle:GetNWBool("carKeysVehicleLocked")
		end,
		material = Material("materials/mst_hud/lock.png"),
		sound = Sound("mst_vehicle/door_lock.mp3"),
		time = 0.5,
		id = 2,
	},

	[3] = {
		name = "Открыть транспорт",
		class = {},
		command = function(ply, vehicle)

			local owner = vehicle:GetNWEntity("carKeysVehicleOwner")
			if (owner != NULL) and (owner:UniqueID() == ply:UniqueID()) then
				if (vehicle:GetNWBool("carKeysVehicleAlarm")) then
					vehicle:SetNWBool("carKeysVehicleAlarm", false)
					vehicle:StopSound("carKeysAlarmSound")

					timer.Remove("carKeysLoopAlarm" .. ent:EntIndex())
					timer.Remove("carKeysAlarmLights" .. ent:EntIndex()) 
					--rp.Notify(ply, 'Сирена выключена') 
				end
				vehicle:EmitSound("npc/metropolice/gear" .. math.floor(math.Rand(1, 7)) .. ".wav")
				vehicle:SetNWBool("carKeysVehicleLocked", false)
				vehicle.VehicleLocked = false  
				rp.Notify(ply, 'Автомобиль открыт')
			else
				rp.Notify(ply, NOTIFY_ERROR, 'Вы не можете открыть данный транспорт, он не ваш!') 
				vehicle:EmitSound("doors/handle_pushbar_locked1.wav")
			end

		end,
		clientComand = function(ply, vehicle)
			return vehicle:GetNWBool("carKeysVehicleLocked")
		end,
		material = Material("materials/mst_hud/unlock.png"),
		sound = Sound("mst_vehicle/door_lock.mp3"),
		time = 0.5,
		id = 3,
	},

	----------
	[4] = {
		name = "Открыть капот",
		class = {"sim_fphys_vaz_2121", "avx_bmp2","avx_bmp2m", "simphys_BTR70", "sim_fphys_uaz_3151","sim_fphys_uaz_3151_bk","sim_fphys_uaz_3151_ags","sim_fphys_uaz_3151_dshk","sim_fphys_uaz_3151_spg",     "sim_fphys_zil130_covered","sim_fphys_zil130","sim_fphys_zil130_musor",   "sim_fphys_vaz_2103","sim_fphys_vaz_2106"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл капот"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 

		 	(vehicle:GetModel() == "models/sim_fphys_vaz_2121/vaz_2121.mdl" and vehicle:GetManipulateBoneAngles( vehicle:LookupBone("bonnet")) == Angle(0.000, 0.000, 0.000)) 	or  

		 	(vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151o.mdl" and  0 == vehicle:GetBodygroup(2))  or 
		 	(vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151c.mdl" and  0 == vehicle:GetBodygroup(3))	or 

			(vehicle:GetModel() == "models/vehicles/btr70/btr70_new.mdl" and  0 == vehicle:GetBodygroup(8)) 	or 
			
		 	(vehicle:GetModel() == "models/vehicles/vaz2103/vaz2103.mdl" and  0 == vehicle:GetBodygroup(10))	or 
		 	(vehicle:GetModel() == "models/vehicles/vaz2106/vaz2106.mdl" and  0 == vehicle:GetBodygroup(5)) 	or 
			
			(vehicle:GetModel() == "models/vehicles/bmp2/bmp2.mdl" and  0 == vehicle:GetBodygroup(8))			or   

		 	((vehicle:GetModel() == "models/vehicles/zil130/zil130_musor.mdl" or vehicle:GetModel() == "models/vehicles/zil130/zil130.mdl" or vehicle:GetModel() == "models/vehicles/zil130/zil130_covered.mdl") and  0 == vehicle:GetBodygroup(1))	
		end,
		material = Material("materials/mst_hud/bonnet.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.25,
		id = 4,
	},	
	
	[5] = {
		name = "Закрыть капот",
		class = {"sim_fphys_vaz_2121", "avx_bmp2","avx_bmp2m", "simphys_BTR70","sim_fphys_uaz_3151","sim_fphys_uaz_3151_bk","sim_fphys_uaz_3151_ags","sim_fphys_uaz_3151_dshk","sim_fphys_uaz_3151_spg",     "sim_fphys_zil130_covered","sim_fphys_zil130","sim_fphys_zil130_musor",   "sim_fphys_vaz_2103","sim_fphys_vaz_2106"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл капот"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 

		 	(vehicle:GetModel() == "models/sim_fphys_vaz_2121/vaz_2121.mdl" and vehicle:GetManipulateBoneAngles( vehicle:LookupBone("bonnet")) == Angle(-90.000, 0.000, 0.000)) 	or  

		 	(vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151o.mdl" and  1 == vehicle:GetBodygroup(2))  or 
		 	(vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151c.mdl" and  1 == vehicle:GetBodygroup(3))	or 
			
			(vehicle:GetModel() == "models/vehicles/btr70/btr70_new.mdl" and  1 == vehicle:GetBodygroup(8)) 	or 
			
		 	(vehicle:GetModel() == "models/vehicles/vaz2103/vaz2103.mdl" and  1 == vehicle:GetBodygroup(10))	or 
		 	(vehicle:GetModel() == "models/vehicles/vaz2106/vaz2106.mdl" and  1 == vehicle:GetBodygroup(5))		or 
			
			(vehicle:GetModel() == "models/vehicles/bmp2/bmp2.mdl" and  1 == vehicle:GetBodygroup(8))			or   

		 	((vehicle:GetModel() == "models/vehicles/zil130/zil130_musor.mdl" or vehicle:GetModel() == "models/vehicles/zil130/zil130.mdl" or vehicle:GetModel() == "models/vehicles/zil130/zil130_covered.mdl") and  1 == vehicle:GetBodygroup(1))	 
		end,
		material = Material("materials/mst_hud/bonnet_2.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.25,
		id = 5,
	},	

	[31] = {
		name = "Открыть багажник",
		class = {"sim_fphys_vaz_2121", "sim_fphys_vaz_2103","sim_fphys_vaz_2106"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл багажник"') 
			--print(vehicle:GetManipulateBoneAngles( vehicle:LookupBone("boot")))
			--print(vehicle:GetManipulateBoneAngles( vehicle:LookupBone("boot")) == Angle(-100.000, 0.000, 0.000)) 
		end,
		clientComand = function(ply, vehicle)
		 	return (vehicle:GetModel() == "models/sim_fphys_vaz_2121/vaz_2121.mdl" and vehicle:GetManipulateBoneAngles( vehicle:LookupBone("boot")) == Angle(0.000, 0.000, 0.000)) 	or  
		 	(vehicle:GetModel() == "models/vehicles/vaz2103/vaz2103.mdl" and  0 == vehicle:GetBodygroup(9))	or 
		 	(vehicle:GetModel() == "models/vehicles/vaz2106/vaz2106.mdl" and  0 == vehicle:GetBodygroup(6))	 
		end,
		material = Material("materials/mst_hud/trunk_open.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.25,
		id = 31,
	},	
	
	[32] = {
		name = "Закрыть багажник",
		class = {"sim_fphys_vaz_2121", "sim_fphys_vaz_2103","sim_fphys_vaz_2106"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл багажник"') 
		end,
		clientComand = function(ply, vehicle)
		 	return (vehicle:GetModel() == "models/sim_fphys_vaz_2121/vaz_2121.mdl" and vehicle:GetManipulateBoneAngles( vehicle:LookupBone("boot")) == Angle(-100.000, 0.000, 0.000)) or  
		 	(vehicle:GetModel() == "models/vehicles/vaz2103/vaz2103.mdl" and  1 == vehicle:GetBodygroup(9))	or 
		 	(vehicle:GetModel() == "models/vehicles/vaz2106/vaz2106.mdl" and  1 == vehicle:GetBodygroup(6))	 
		end,
		material = Material("materials/mst_hud/trunk_close.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.25,
		id = 32,
	},	
	--
	[6] = {
		name = "Снять запаску",
		class = {"sim_fphys_hilux", "sim_fphys_hilux_sup","sim_fphys_hilux_m2b","sim_fphys_hilux_ags","sim_fphys_hilux_dshkm","sim_fphys_hilux_atgm","sim_fphys_hilux_spg",		"simphys_BTR70","sim_fphys_uaz_3151","sim_fphys_uaz_3151_bk","sim_fphys_uaz_3151_ags","sim_fphys_uaz_3151_dshk","sim_fphys_uaz_3151_spg",   "sim_fphys_ural4320", "sim_fphys_ural4320_grad",    "sim_fphys_kamaz","sim_fphys_kamaz_kom", "sim_fphys_hmmwv_a","sim_fphys_hmmwv_a2","sim_fphys_hmmwv","sim_fphys_hmmwv2"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me взял запаску"') 
		end,
		clientComand = function(ply, vehicle)
		 	return (vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151o.mdl" and  0 == vehicle:GetBodygroup(15)) or   
		 		   (vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151c.mdl" and  0 == vehicle:GetBodygroup(15)) or
		 		   (vehicle:GetModel() == "models/vehicles/ural_4320/ural4320.mdl" and  0 == vehicle:GetBodygroup(5)) or 
		 		   (vehicle:GetModel() == "models/vehicles/ural_4320/ural4320_grad.mdl" and  0 == vehicle:GetBodygroup(2)) or
					
				   (vehicle:GetModel() == "models/vehicles/btr70/btr70_new.mdl" and  0 == vehicle:GetBodygroup(10)) or 
					
		 		   (vehicle:GetModel() == "models/vehicles/kamaz/zamak/kamaz1.mdl" and  0 == vehicle:GetBodygroup(7)) or 
		 		   (vehicle:GetModel() == "models/vehicles/kamaz/zamak/kamaz.mdl" and   0 == vehicle:GetBodygroup(5)) or 

		 		   (vehicle:GetModel() == "models/vehicles/hilux/coyota.mdl" and   0 == vehicle:GetBodygroup(3)) or 

		 		   (vehicle:GetModel() == "models/vehicles/hmmwv/hmmwv.mdl" and   1 == vehicle:GetBodygroup(16)) 
		end,
		material = Material("materials/mst_hud/wheel.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 1.5,
		id = 6,
	},	
	
	[7] = {
		name = "Вернуть запаску",
		class = {"sim_fphys_hilux", "sim_fphys_hilux_sup","sim_fphys_hilux_m2b","sim_fphys_hilux_ags","sim_fphys_hilux_dshkm","sim_fphys_hilux_atgm","sim_fphys_hilux_spg",		"simphys_BTR70","sim_fphys_uaz_3151","sim_fphys_uaz_3151_bk","sim_fphys_uaz_3151_ags","sim_fphys_uaz_3151_dshk","sim_fphys_uaz_3151_spg",   "sim_fphys_ural4320", "sim_fphys_ural4320_grad",   "sim_fphys_kamaz","sim_fphys_kamaz_kom", "sim_fphys_hmmwv_a","sim_fphys_hmmwv_a2","sim_fphys_hmmwv","sim_fphys_hmmwv2"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me вернул запаску"') 
		end,
		clientComand = function(ply, vehicle)
		 	return (vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151o.mdl" and  1 == vehicle:GetBodygroup(15)) or   
		 		   (vehicle:GetModel() == "models/vehicles/uaz_3151/uaz_3151c.mdl" and  1 == vehicle:GetBodygroup(15)) or
		 		   (vehicle:GetModel() == "models/vehicles/ural_4320/ural4320.mdl" and  1 == vehicle:GetBodygroup(5)) or 
		 		   (vehicle:GetModel() == "models/vehicles/ural_4320/ural4320_grad.mdl" and  1 == vehicle:GetBodygroup(2)) or 
				   
				   (vehicle:GetModel() == "models/vehicles/btr70/btr70_new.mdl" and  1 == vehicle:GetBodygroup(10)) or 

		 		   (vehicle:GetModel() == "models/vehicles/kamaz/zamak/kamaz1.mdl" and  1 == vehicle:GetBodygroup(7)) or 
		 		   (vehicle:GetModel() == "models/vehicles/kamaz/zamak/kamaz.mdl"  and  1 == vehicle:GetBodygroup(5)) or 

		 		   (vehicle:GetModel() == "models/vehicles/hilux/coyota.mdl" and   2 == vehicle:GetBodygroup(3)) or 

		 		   (vehicle:GetModel() == "models/vehicles/hmmwv/hmmwv.mdl" and   0 == vehicle:GetBodygroup(16))   
		end,
		material = Material("materials/mst_hud/wheel.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 1.5,
		id = 7,
	},
	--
	[8] = {
		name = "Установить брезент",
		class = {"sim_fphys_kamaz"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поменял брезент Камазу на #1"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(2)
		end,
		material = Material("materials/mst_hud/tent_1.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 8,
	},	
	[9] = {
		name = "Установить каркас брезента",
		class = {"sim_fphys_kamaz"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поменял брезент Камазу на #2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(2)
		end,
		material = Material("materials/mst_hud/tent_2.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 9,
	},	

	[10] = {
		name = "Снять брезент",
		class = {"sim_fphys_kamaz"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поменял брезент Камазу на #3"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 2 != vehicle:GetBodygroup(2) 
		end,
		material = Material("materials/mst_hud/tent_3.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 10,
	},	
	--
	[11] = {
		name = "Установить брезент",
		class = {"sim_fphys_ural4320"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поменял брезент Уралу на #2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(1) 
		end,
		material = Material("materials/mst_hud/ural_1.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 11,
	},	
	[12] = {
		name = "Снять брезент",
		class = {"sim_fphys_ural4320"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поменял брезент Уралу на #1"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(1) 
		end,
		material = Material("materials/mst_hud/ural_2.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 12,
	},	
 	--
 	[13] = {
		name = "Открыть боковую дверь",
		class = {"sim_fphys_uaz_2206"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл боковую дверь Уаза"') 
		end,
		clientComand = function(ply, vehicle)
		 	return  1 != vehicle:GetBodygroup(1) 
		end,
		material = Material("materials/mst_hud/uaz_door_1.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 13,
	},	
	[14] = {
		name = "Закрыть боковую дверь",
		class = {"sim_fphys_uaz_2206"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл боковую дверь Уаза"') 
		end,
		clientComand = function(ply, vehicle)
		 	return  0 != vehicle:GetBodygroup(1) 
		end,
		material = Material("materials/mst_hud/uaz_door_2.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 14,
	},	

	[15] = {
		name = "Открыть багажник",
		class = {"sim_fphys_uaz_2206"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл багажник Уаза"') 
		end,
		clientComand = function(ply, vehicle)
		 	return  1 != vehicle:GetBodygroup(2) 
		end,
		material = Material("materials/mst_hud/uaz_door_3.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 15,
	},	
	[16] = {
		name = "Закрыть багажник",
		class = {"sim_fphys_uaz_2206"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл багажник Уаза"') 
		end,
		clientComand = function(ply, vehicle)
		 	return  0 != vehicle:GetBodygroup(2) 
		end,
		material = Material("materials/mst_hud/uaz_door_4.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 16,
	},	
	
	--
	
	[17] = {
		name = "Опустить волноотражательный щит",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me выдвинул бампер БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return  1 != vehicle:GetBodygroup(7) 
		end,
		material = Material("materials/mst_hud/brdm_1.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 17,
	},	
	[18] = {
		name = "Убрать волноотражательный щит",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me задвинул бампер БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return  0 != vehicle:GetBodygroup(7) 
		end,
		material = Material("materials/mst_hud/brdm_2.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 18,
	},	
	
	[19] = {
		name = "Снять волноотражательный щит",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me снял бампер БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	--return  2 != vehicle:GetBodygroup(7) 
			return false
		end,
		material = Material("materials/mst_hud/brdm_0.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 19,
	},	
	--
	[20] = {
		name = "Опустить колеса",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поднял колеса БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(6) 
		end,
		material = Material("materials/mst_hud/brdm_3.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 18,
	},	
	
	[21] = {
		name = "Убрать колеса",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me опустил колеса БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(6) 
		end,
		material = Material("materials/mst_hud/brdm_4.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 19,
	},	
	--
	[22] = {
		name = "Открыть обзорные люки",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл обзорные люки БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(4) 
		end,
		material = Material("materials/mst_hud/brdm_6.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 22,
	},	
	
	[23] = {
		name = "Закрыть обзорные люки",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл обзорные люки БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(4) 
		end,
		material = Material("materials/mst_hud/brdm_7.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 23,
	},	
	--
	[24] = {
		name = "Убрать фонарь",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me убрал противотуманку у БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(5) 
		end,
		material = Material("materials/mst_hud/foglamp_2.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 1.5,
		id = 24,
	},	
	
	[25] = {
		name = "Поставить фонарь",
		class = {"simphys_BRDM2","simphys_BRDM2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил противотуманку у БРДМ-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(5) 
		end,
		material = Material("materials/mst_hud/foglamp_1.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 1.5,
		id = 25,
	},	
	--
	[26] = {
		name = "Улучшить броню (500$)",
		class = {"sim_fphys_hmmwv_a","sim_fphys_hmmwv_a2","sim_fphys_hmmwv","sim_fphys_hmmwv2"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил усиленную броню на Хаммви"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(19) and ply:GetMoney() > 500 
		end,
		material = Material("materials/mst_hud/armor.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 26,
	},	
	--
	[27] = {
		name = "Установить кенгурятник (150$)",
		class = {"sim_fphys_hmmwv_a","sim_fphys_hmmwv_a2","sim_fphys_hmmwv","sim_fphys_hmmwv2"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил усиленный кенгурятник на Хаммви"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(10) and ply:GetMoney() > 150 
		end,
		material = Material("materials/mst_hud/armor.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 27,
	},	
	--
	[28] = {
		name = "Установить ящик с патр. (300$)",
		class = {"sim_fphys_hmmwv_a","sim_fphys_hmmwv_a2","sim_fphys_hmmwv","sim_fphys_hmmwv2"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me установил ящик с патронами"') 
		end,
		clientComand = function(ply, vehicle)
		  	return 1 != vehicle:GetBodygroup(9) and ply:GetMoney() > 300 
		end,
		material = Material("materials/mst_hud/ammo.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 28,
	},	
 	--
 	[29] = {
		name = "Взять патроны (50$)",
		class = {"sim_fphys_hmmwv_a","sim_fphys_hmmwv_a2","sim_fphys_hmmwv","sim_fphys_hmmwv2"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me взял патроны из транспорта"') 
		end,
		clientComand = function(ply, vehicle)
		  	return 0 != vehicle:GetBodygroup(9) 
		end,
		material = Material("materials/mst_hud/ammo.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 29,
	},	

	[30] = {
		name = "Взять патроны",
		class = {"sim_fphys_hilux_sup", "sim_fphys_kamaz","sim_fphys_kamaz_kom","sim_fphys_ural4320"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me взял патроны из транспорта"') 
		end,
		clientComand = function(ply, vehicle)
		  
		end,
		material = Material("materials/mst_hud/ammo.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 30,
	},	
 
	--
	[33] = {
		name = "Открыть двери",
		class = {"simphys_BTR70"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл двери БТР-а"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 
		 	(vehicle:GetModel() == "models/vehicles/btr70/btr70_new.mdl" and  0 == vehicle:GetBodygroup(4))  
		end,
		material = Material("materials/mst_hud/btr_door_open.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.25,
		id = 33,
	},	
	
	[34] = {
		name = "Закрыть двери",
		class = {"simphys_BTR70"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл двери БТР-а"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 
		 	(vehicle:GetModel() == "models/vehicles/btr70/btr70_new.mdl" and  1 == vehicle:GetBodygroup(4))  
		end,
		material = Material("materials/mst_hud/btr_door_close.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.25,
		id = 34,
	},	
	--

	--
	[35] = {
		name = "Открыть обзорные люки",
		class = {"simphys_BTR70"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл обзорные люки люки БТР-70"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(9) 
		end,
		material = Material("materials/mst_hud/btr_open.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 35,
	},	
	
	[36] = {
		name = "Закрыть обзорные люки",
		class = {"simphys_BTR70"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл обзорные люки БТР-70"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(9) 
		end,
		material = Material("materials/mst_hud/btr_close.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 36,
	},	
	--
	[37] = {
		name = "Установить брезент",
		class = {"sim_fphys_uaz_3151"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me установил брезент"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(2)
		end,
		material = Material("materials/mst_hud/uaz_tent_1.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 37,
	},	
	[38] = {
		name = "Снять брезент",
		class = {"sim_fphys_uaz_3151"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me снял брезент"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(2)
		end,
		material = Material("materials/mst_hud/uaz_tent_2.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 38,
	},	
	--
	[39] = {
		name = "Убрать противотуманки",
		class = {"sim_fphys_uaz_3151","sim_fphys_uaz_3151_bk","sim_fphys_uaz_3151_ags","sim_fphys_uaz_3151_dshk","sim_fphys_uaz_3151_spg", },
		command = function(ply, vehicle)
			ply:ConCommand('say "/me убрал противотуманки"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(11) 
		end,
		material = Material("materials/mst_hud/foglamp_2.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 1.5,
		id = 39,
	},	
	
	[40] = {
		name = "Поставить противотуманки",
		class = {"sim_fphys_uaz_3151","sim_fphys_uaz_3151_bk","sim_fphys_uaz_3151_ags","sim_fphys_uaz_3151_dshk","sim_fphys_uaz_3151_spg", },
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил противотуманки"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(11) 
		end,
		material = Material("materials/mst_hud/foglamp_1.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 1.5,
		id = 40,
	},	
	--
	[41] = {
		name = "Открыть двери",
		class = {"avx_bmp2","avx_bmp2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me открыл двери БМП-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(9) 
		end,
		material = Material("materials/mst_hud/bmp_open.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 41,
	},	
	
	[42] = {
		name = "Закрыть двери",
		class = {"avx_bmp2","avx_bmp2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me закрыл двери БМП-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(9) 
		end,
		material = Material("materials/mst_hud/bmp_close.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 42,
	},	
	--
	[43] = {
		name = "Поставить Бревно",
		class = {"avx_bmp2","avx_bmp2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me установил бревно на БМП-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(11) 
		end,
		material = Material("materials/mst_hud/bmp_br1.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 43,
	},	
	
	[44] = {
		name = "Снять бревно",
		class = {"avx_bmp2","avx_bmp2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me снял бревно с БМП-2"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(11) 
		end,
		material = Material("materials/mst_hud/bmp_br2.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 44,
	},	
	--


	--
	[45] = {
		name = "Улучшить башенную броню (600$)",
		class = {"avx_bmp2","avx_bmp2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил усиленную броню башни на БМП"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(14) and ply:GetMoney() > 600 
		end,
		material = Material("materials/mst_hud/armor.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 45,
	},	
	--
	[46] = {
		name = "Улучшить бортовую броню (900$)",
		class = {"avx_bmp2","avx_bmp2m"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил усиленную броню бортов на БМП"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(13) and ply:GetMoney() > 900
		end,
		material = Material("materials/mst_hud/armor.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 46,
	},	
	--


	--
	[47] = {
		name = "Убрать противотуманки",
		class = {"sim_fphys_hilux", "sim_fphys_hilux_sup","sim_fphys_hilux_m2b","sim_fphys_hilux_ags","sim_fphys_hilux_dshkm","sim_fphys_hilux_atgm","sim_fphys_hilux_spg"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me убрал противотуманки"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(7) 
		end,
		material = Material("materials/mst_hud/foglamp_2.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 47,
	},	
	
	[48] = {
		name = "Поставить противотуманки",
		class = {"sim_fphys_hilux", "sim_fphys_hilux_sup","sim_fphys_hilux_m2b","sim_fphys_hilux_ags","sim_fphys_hilux_dshkm","sim_fphys_hilux_atgm","sim_fphys_hilux_spg"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил противотуманки"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 1 != vehicle:GetBodygroup(7) 
		end,
		material = Material("materials/mst_hud/foglamp_1.png"),
		sound = Sound("mst_vehicle/bunnet_close.mp3"),
		time = 1.5,
		id = 48,
	},	
	--
 
	--
	[49] = {
		name = "Установить кенгурятник (300$)",
		class = {"sim_fphys_hilux", "sim_fphys_hilux_sup","sim_fphys_hilux_m2b","sim_fphys_hilux_ags","sim_fphys_hilux_dshkm","sim_fphys_hilux_atgm","sim_fphys_hilux_spg"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил защитный кенгурятник"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(6) and ply:GetMoney() > 300 
		end,
		material = Material("materials/mst_hud/armor.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 49,
	},	
	--
	[50] = {
		name = "Установить защиту стекл (150$)",
		class = {"sim_fphys_hilux", "sim_fphys_hilux_sup","sim_fphys_hilux_m2b","sim_fphys_hilux_ags","sim_fphys_hilux_dshkm","sim_fphys_hilux_atgm","sim_fphys_hilux_spg"},
		command = function(ply, vehicle)
			ply:ConCommand('say "/me поставил защиту на стекла"') 
		end,
		clientComand = function(ply, vehicle)
		 	return 0 != vehicle:GetBodygroup(2) and ply:GetMoney() > 150
		end,
		material = Material("materials/mst_hud/armor.png"),
		sound = Sound("server/ui/click2.wav"),
		time = 2,
		id = 50,
	},	
	--

	
}