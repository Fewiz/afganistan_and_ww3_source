
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/sh_swep_config.lua ~

]]

-- ["разрешения"] = "40-ые","",""
VendorNPC = istable(VendorNPC) and VendorNPC or {}
VendorNPC.config = {  
 
["Оружие / Предметы"] = {
       
      --[[{
         name = "Дубинка",
         swep = "stun_baton",
         model = "models/weapons/c_stunstick.mdl",
         price = 90,
      },]]
      {
         name = "Дубликат ключей",
         swep = "carkeys",
         model = "models/sentry/pgkey.mdl",
         price = 60,
      },
 
      {
         name = "Бинокль",
         swep = "weapon_rpw_binoculars_explorer",
         model = "models/weapons/w_binocularsbp.mdl",
         price = 160,
      },

      {
         name = "Бинокль+",
         swep = "weapon_rpw_binoculars",
         model = "models/weapons/w_binoculars_uk.mdl",
         price = 300,
      },

     --[[{
         name = "Флаер",
         swep = "weapon_vj_flaregun_r",
         model = "models/vj_weapons/w_flaregun.mdl",
         price = 460,
      }, 

      {
         name = "Отмычка",
         swep = "lockpick",
         model = "models/weapons/w_crowbar.mdl",
         price = 460,
      },]]
 
      {
         name = "Мачете",
         swep = "cw_ws_pamachete",
         model = "models/weapons/melee/w_ws_pamachete.mdl",
         price = 460,
      },


      {
         name  = "Фотоаппарат",
         swep  = "gmod_camera",
         model = "models/MaxOfS2D/camera.mdl",
         price = 600,
      },

      {
         name = "Сигареты",
         swep = "weapon_ciga_cheap",
         model = "models/mordeciga/mordes/oldcigshib.mdl",
         price = 700,
      },

      {
         name = "АК-74",
         swep = "cw_ak74",
         model = "models/weapons/w_rif_ak47.mdl",
         price = 800,
      },


      {
         name  = "Улучшенная Камера",
         swep  = "gmod_cinematic_camera",
         model = "models/weapons/w_camera.mdl",
         price = 1060,
      },

      {
         name = "КС-23",
         swep = "cw_ks23",
         model = "models/weapons/world/shotguns/ks23.mdl",
         price = 1360,
      },

      {
         name = "АКМ",
         swep = "cw_akm",
         model = "models/weapons/w_rif_ak47.mdl",
         price = 1380,
      },
 
      {
         name = "Парашют",
         swep = "arrest_baton",
         model = "models/jessev92/codmw2/parachute_ground_skins.mdl",
         price = 1200,
      },

      {
         name =  "Ремкомплект (Обл)",
         swep =  "weapon_simrepair2",
         model = "models/props_c17/tools_wrench01a.mdl",
         price = 1260,
      },
 
      {
         name = "Аптечка",
         swep = "fas2_ifak",
         model = "models/weapons/w_ifak.mdl",
         price = 1260,
      },

      {
         name = "СВТ-40",
         swep = "cw_svt40",
         model = "models/weapons/w_dber_svt40.mdl",
         price = 1400,
      },

      {
         name = "СКС",
         swep = "cw_simsks",
         model = "models/weapons/w_dber_svt40.mdl", --"models/weapons/tfa_ins2/w_sks.mdl",
         price = 1460,
      },
 
      {
         name = "АС «Вал»",
         swep = "cw_vss",
         model = "models/cw2/rifles/w_vss.mdl",
         price = 1600,
      },

      {
         name = "ПКМ",
         swep = "cw_pkm",
         model ="models/weapons/w_mach_m249para.mdl",
         price = 1600,
      },

      {
         name = "СВД",
         swep = "bo_aron_dragunov",
         model = "models/weapons/v_svd_prop.mdl",
         price = 1700,
      },


      --- Донат оружие

      {
         name = "ППШ ★",
         swep = "weapon_pph41",
         model = "models/weapons/w_nik_ppsh1.mdl",
         price = 1800,
      },

      {
         name = "Мосинка ★",
         swep = "cw_mosin",
         model = "models/khrcw2/w_khri_mosinm91.mdl",
         price = 1800,
      },

      {
         name = "Thompson ★ ",
         swep = "cwc_thompson",
         model = "models/weapons/cwc_thompson/cwc_thompson_w.mdl",
         price = 3400,
      },

      {
         name = "MR73 ★ ",
         swep = "cw_mr96",
         model = "models/weapons/w_357.mdl",
         price = 2200,
      },

      {
         name = "Desert Eagle ★",
         swep = "cw_deagle",
         model = "models/weapons/w_pist_deagle.mdl",
         price = 2400,
      },

      {
         name = "STG-44 ★",
         swep = "cw_stg44",
         model = "models/weapons/bob/w_stg44.mdl",
         price = 3600,
      },

      {
         name = "M620 ★ ",
         swep = "cw_m620",
         model = "models/khrcw2/w_khri_stevenm62.mdl",
         price = 3800,
      },


   },  

   ["Взрывное"] = {
      {
         name = "Дымовая",
         swep = "cw_smoke_grenade",
         model = "models/weapons/w_eq_smokegrenade.mdl",
         price = 400,
      },
     	{
	      name = "Слеповая",
		   swep = "cw_flash_grenade",
		   model = "models/weapons/w_eq_flashbang.mdl",
		   price = 500,
	   },
      --[[{
         name = "Мина",
         swep = "weapon_simmines",
         model = "models/blu/mine.mdl",
         price = 560, -- 760
      },]]

      --[[{
         name = "Газовая Граната",
         swep = "weapon_ttt_shortgasgrenade",
         model = "models/weapons/w_eq_smokegrenade.mdl",
         price = 900, -- 2000
      },]]

      {
         name = "РПГ-7",
         swep = "ins2_atow_rpg7",
         model = "models/khrcw2/w_ins2rpg7.mdl",
         price = 1200, -- 1900
      },
      {
         name = "Миномет",
         swep = "cw_kk_ofrp_lgi",
         model = "models/bsoldiers/cw_kk_weapons/w_lgi.mdl",
         price = 1300, -- 2000
      },
 
      {
         name = "РПГ-26",
         swep = "bo_aron_m72_law",
         model = "models/my_black_ops_weapons/m72_law/w_aron_m72law.mdl",
         price = 1700, -- 2200
      },

     --[[ {
         name = "Гранатомет",
         swep = "cw_m79",
         model = "models/weapons/r_rif_m79.mdl",
         price = 2100, -- 2800
      },]]
 
   },   






}


local assault = {
      --cmaxspeed="140",
      --cmaxpl="4",
      --cmaxpl="4",
   {
      sname = "sim_fphys_uaz_3151",
      model = "models/vehicles/uaz_3151/uaz_3151c.mdl",
      cname = "Уаз",
      price = 1300,

      speed = "127",
      health = "1237",
      mplayer = "7",  

      col = false,
      skin = true, 
   },

   {
      sname = "sim_fphys_uaz_3151_bk",
      model = "models/vehicles/uaz_3151/uaz_3151o.mdl",
      cname = "Уаз (Без Крыши)",
      price = 1300,

      speed = "127", -- 127
      health = "1237",
      mplayer = "7",

      col = false,
      skin = true, 
   },

   {
      sname = "sim_fphys_vaz_2106",
      model = "models/vehicles/vaz2106/vaz2106.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "ВАЗ-2106 (1500s)",
      price = 1400,

      speed = "150",
      health = "1260",
      mplayer = "5",
      
      col = true,
      skin = true, 
   },  


   {
      sname = "sim_fphys_vaz_2121",
      model = "models/sim_fphys_vaz_2121/vaz_2121.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "ВАЗ-2121 «Нива»",
      price = 1500,

      speed = "132",
      health = "1400",
      mplayer = "5",
      
      col = true,
      skin = false,  
   }, 


   {
      sname = "sim_fphys_uaz_2206",
      model = "models/vehicles/uaz_2206/uaz2206.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "Уаз 2206 (Буханка)",
      price = 1600,

      speed = "125",
      health = "1503",
      mplayer = "6",    

      col = false,
      skin = true,  
   }, 

 
   {
      sname = "sim_fphys_zil130_covered",
      model = "models/vehicles/zil130/zil130_covered.mdl",
      cname = "Зил-130",
      price = 1660,  

      speed = "90",
      health = "2225",
      mplayer = "10",

      col = false,
      skin = false,  
   }, 

   {
      donate = "Volga",
      cname = "Волга КГБ",
      sname = "sim_fphys_pwvolga",
      model = "models/blu/volga/volga.mdl",
      price = 1700,  

      speed = "175",
      health = "1337",
      mplayer = "4",

      col = false,
      skin = true,  
   },

   {
      sname = "sim_fphys_ural4320",
      model = "models/vehicles/ural_4320/ural4320.mdl",
      cname = "Урал-4320",
      price = 1800, -- 1250

      speed = "85",
      health = "2875",
      mplayer = "14",

      col = false,
      skin = true,  
   },

   {
      sname = "sim_fphys_kamaz_kom",
      model = "models/vehicles/kamaz/zamak/kamaz.mdl",
      cname = "Камаз (Командирский)",
      price = 1600, -- 1250 900

      speed = "90",
      health = "2900",
      mplayer = "3",

      col = true,
      skin = true,  
   }, 
  
   {
      sname = "sim_fphys_kamaz",
      model = "models/vehicles/kamaz/zamak/kamaz1.mdl",
      cname = "Камаз",
      price = 2000, -- 1250

      speed = "90",
      health = "2700", -- 2000
      mplayer = "19",

      col = true,
      skin = true,  
   }, 

   -------------

   {
      sname = "simphys_BRDM2m",
      model = "models/vehicles/brdm2/brdm2.mdl",
      cname = "БРДМ-2У (Командирский)",
      price = 2800,  

      speed = "100",
      health = "3200",
      mplayer = "4",  

      col = false,
      skin = true,  
   },

  --[[ {
      sname = "simphys_BTR70",
      model = "models/vehicles/btr70/btr70.mdl",
      cname = "БТР-70",
      price = 5200, 
      speed = "80",
      health = "4500",
      mplayer = "10",
      
   },]]

     --------------------------

   --[[{
      donate = "Baggy",
      cname = "Багги",
      sname = "sim_fphys_v8elite",
      model = "models/vehicles/buggy_elite.mdl",
      price = 300,  
      speed = "90",
      health = "1425",
      mplayer = "2",
   }, ]]
   

   {
      donate = "mrsdsw123",
      cname = "Mercedes W123",
      sname = "avx_mercedes",
      model = "models/avx/mercedes.mdl",
      price = 700,  

      speed = "160",
      health = "1400",
      mplayer = "4",

      col = true,
      skin = false,  
   }, 

   {
      donate = "avx_mercedes2",
      cname = "Mercedes W124",
      sname = "simfphys_mercedes_W124",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 700,  

      speed = "175",
      health = "1450",
      mplayer = "4",

      col = true,
      skin = false,  
   }, 

   {
      donate = "dukes",
      cname = "Dodge Charger R/T",
      sname = "sim_fphys_dukes",
      model = "models/blu/gtav/dukes/dukes.mdl",
      price = 800,  

      speed = "203",
      health = "1425",
      mplayer = "4",
      
      col = true,
      skin = false,  
   },



   --[[{
      donate = "mrsdsw123be",
      cname = "Premium Mercedes W123",
      sname = "avx_mercedes_Black_Edition",
      model = "models/avx/mercedes.mdl",
      price = 900,  
      speed = "120",
      health = "3450",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "mrsdsw124be",
      cname = "Premium Mercedes W124",
      sname = "simfphys_mercedes_W124_BE",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 900,  
      speed = "145",
      health = "3000",
      mplayer = "4",
      col = true,
   }, 

   {
      donate ="avx_technical_unarmed_be",
      cname = "Premium Пикап",
      sname = "avx_technical_unarmed_BE",
      model = "models/avx/technical_unarmed.mdl",
      price = 1200,  
      speed = "115",
      health = "4250",
      mplayer = "10",
      col = true,
   }, ]]

   
 
   
}

return assault