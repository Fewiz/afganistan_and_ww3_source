
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/sh_swep_config_3.lua ~

]]

-- ["разрешения"] = "40-ые","",""
VendorNPC3 = istable(VendorNPC3) and VendorNPC3 or {}
VendorNPC3.config = {  
 
["Оружие / Предметы"] = {
       
      {
         name = "Дубинка",
         swep = "stun_baton",
         model = "models/weapons/c_stunstick.mdl",
         price = 90,
      }, 
  
      

	},  

	["Взрывное"] = {
	   {
         name = "Граната",
         swep = "cw_frag_grenade",
         model = "models/weapons/w_eq_fraggrenade.mdl",
         price = 300,
      },
 
      {
         name = "Дымовая",
         swep = "cw_smoke_grenade",
         model = "models/weapons/w_eq_smokegrenade.mdl",
         price = 400,
      },
      {
         name = "Слеповая",
         swep = "cw_flash_grenade",
         model = "models/weapons/w_eq_flashbang.mdl",
         price = 500,
      },
      {
         name = "Мина",
         swep = "weapon_simmines",
         model = "models/blu/mine.mdl",
         price = 560, -- 760
      },
      
      {
         name = "Газовая Граната",
         swep = "weapon_ttt_shortgasgrenade",
         model = "models/weapons/w_eq_smokegrenade.mdl",
         price = 800, -- 2000
      },
 
      {
         name = "Миномет",
         swep = "cw_kk_ofrp_lgi",
         model = "models/bsoldiers/cw_kk_weapons/w_lgi.mdl",
         price = 1600,
      },
      {
         name = "C4",
         swep = "z_bomb_rewrite",
         model = "models/weapons/w_c4_planted.mdl",
         price = 1700, -- 2200 3800
      },
 
      {
         name = "FIM-92 «Стингер»",
         swep = "weapon_fim_92_stinger",
         model = "models/jessev92/weapons/hl2/stinger_w.mdl",
         price = 1800, -- 5100  2800
      },
 

	},   






}


local assault = {
      --cmaxspeed="140",
      --cmaxpl="4",
      --cmaxpl="4",
 

   {
      sname = "sim_fphys_hmmwv_a",
      model = "models/vehicles/hmmwv/hmmwv.mdl",
      cname = "HMMWV-A (Без Вооружения)",
      price = 2100, -- 2300
      speed = "95",
      health = "3750 (До 4250)",
      mplayer = "4",
      angle = Angle(0,0,0),
   },

   {
      sname = "sim_fphys_hmmwv_a2",
      model = "models/vehicles/hmmwv/hmmwv.mdl",
      cname = "HMMWV-A2 (Без Вооружения)",
      price = 2300, -- 2700
      speed = "85",
      health = "3400 (До 3900)",
      mplayer = "8",
      angle = Angle(0,0,0),
   },


   {
      sname = "sim_fphys_hmmwv",
      model = "models/vehicles/hmmwv/hmmwv.mdl",
      cname = "HMMWV-E",
      price = 2700, -- 3300
      speed = "95",
      health = "3750 (До 4250)",
      mplayer = "5",
      angle = Angle(0,0,0),
   },

   {
      sname = "sim_fphys_hmmwv2",
      model = "models/vehicles/hmmwv/hmmwv.mdl",
      cname = "HMMWV-E2",
      price = 3000, -- 3800
      speed = "85",
      health = "3400 (До 3900)",
      mplayer = "9",
      angle = Angle(0,0,0),
   },




   --------------------------

  --[[ {
      donate = "Volga",
      cname = "Волга",
      sname = "sim_fphys_pwvolga",
      model = "models/blu/volga/volga.mdl",
      price = 500,  
      speed = "90",
      health = "1337",
      mplayer = "4",
   }, ]]

   

   {
      donate = "mrsdsw123",
      cname = "Mercedes W123",
      sname = "avx_mercedes",
      model = "models/avx/mercedes.mdl",
      price = 700,  
      speed = "160",
      health = "1400",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "avx_mercedes2",
      cname = "Mercedes W124",
      sname = "simfphys_mercedes_W124",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 700,  
      speed = "175",
      health = "1450",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "dukes",
      cname = "Dodge Charger R/T",
      sname = "sim_fphys_dukes",
      model = "models/blu/gtav/dukes/dukes.mdl",
      price = 800,  
      speed = "203",
      health = "1425",
      mplayer = "4",
      col = true,
   },



   {
      donate = "mrsdsw123be",
      cname = "Premium Mercedes W123",
      sname = "avx_mercedes_Black_Edition",
      model = "models/avx/mercedes.mdl",
      price = 900,  
      speed = "120",
      health = "3450",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "mrsdsw124be",
      cname = "Premium Mercedes W124",
      sname = "simfphys_mercedes_W124_BE",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 900,  
      speed = "145",
      health = "3000",
      mplayer = "4",
      col = true,
   }, 

   {
      donate ="avx_technical_unarmed_be",
      cname = "Premium Пикап",
      sname = "avx_technical_unarmed_BE",
      model = "models/avx/technical_unarmed.mdl",
      price = 1200,  
      speed = "115",
      health = "4250",
      mplayer = "10",
      col = true,
   }, 

   

   
 
   
  

}

return assault