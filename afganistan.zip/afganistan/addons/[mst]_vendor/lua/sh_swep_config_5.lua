
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/sh_swep_config_5.lua ~

]]

-- ["разрешения"] = "40-ые","",""
VendorNPC5 = istable(VendorNPC5) and VendorNPC5 or {}
VendorNPC5.config = {  
  
  
}


local assault = {
      --cmaxspeed="140",
      --cmaxpl="4",
      --cmaxpl="4",
   {
      sname = "sim_fphys_zil130",
      model = "models/vehicles/zil130/zil130.mdl",
      cname = "Зил-130",
      price = 800,  
      speed = "90",
      health = "2225",
      mplayer = "2",
      SpawnAngle = "90",
      angle = Angle(0,0,0),
   },

   {
      sname = "sim_fphys_zil130_covered",
      model = "models/vehicles/zil130/zil130_covered.mdl",
      cname = "Зил-130 (Брезентовый)",
      price = 1100,  
      speed = "90",
      health = "2225",
      mplayer = "10",
      SpawnAngle = "90",
      angle = Angle(0,0,0)
   },  
 

   --[[{
      sname = "sim_fphys_kamaz_kom",
      model = "models/vehicles/kamaz/zamak/kamaz.mdl",
      cname = "Камаз (Командирский)",
      price = 800, -- 1250 900
      speed = "90",
      health = "2000",
      mplayer = "3",
      skin = "1",
      SpawnAngle = "90",
      angle = Angle(0,0,0),
   }, ]]

   {
      sname = "sim_fphys_ural4320",
      model = "models/vehicles/ural_4320/ural4320.mdl",
      cname = "Урал-4320",
      price = 1100, -- 1250
      speed = "85",
      health = "2875",
      mplayer = "14",
      skin = "1",
      SpawnAngle = "90",
      angle = Angle(0,0,0)
   },

   {
      sname = "sim_fphys_kamaz",
      model = "models/vehicles/kamaz/zamak/kamaz1.mdl",
      cname = "Камаз",
      price = 1200, -- 1250
      speed = "90",
      health = "2000",
      mplayer = "19",
      skin = "1",
      SpawnAngle = "90",
      angle = Angle(0,0,0),
   }, 
 

   {
      sname = "sim_fphys_uaz_3151_dshk",
      model = "models/vehicles/uaz_3151/uaz_3151o.mdl",
      cname = "УАЗ с ДШК",
      price = 1300,  -- 1400
      speed = "170",
      health = "1337",
      mplayer = "5",
      angle = Angle(0,0,0),
      body = {1,1,1,1}
   },


   {
      sname = "sim_fphys_uaz_3151_spg",
      model = "models/vehicles/uaz_3151/uaz_3151o.mdl",
      cname = "УАЗ с СПГ",
      price = 1500,  
      speed = "170",
      health = "1337",
      mplayer = "5",
      angle = Angle(0,0,0),
   },


   {
      sname = "sim_fphys_uaz_3151_ags",
      model = "models/vehicles/uaz_3151/uaz_3151o.mdl",
      cname = "УАЗ с АГС",
      price = 2100, -- 1700
      speed = "170",
      health = "1337",
      mplayer = "5",
      angle = Angle(0,0,0),
   },
 
   -------------
   {
      sname = "simphys_BRDM2m",
      model = "models/vehicles/brdm2/brdm2.mdl",
      cname = "БРДМ-2У (Командирский)",
      price = 1400,  -- 2400
      speed = "100",
      health = "3200",
      mplayer = "4",
      angle = Angle(0,0,0),
   },

   {
      sname = "simphys_BRDM2",
      model = "models/vehicles/brdm2/brdm2.mdl",
      cname = "БРДМ-2",
      price = 1800,  -- 2400
      speed = "100",
      health = "3200", -- 4050
      mplayer = "5",
      angle = Angle(0,0,0),
   },

   {
      sname = "simphys_BTR70",
      model = "models/vehicles/btr70/btr70_new.mdl",
      cname = "БТР-70",
      price = 2400,  -- 2700
      speed = "80",
      health = "4500",
      mplayer = "11+6", -- 10
      angle = Angle(0,0,0),
   },

   --[[ 
   {
      sname = "simphys_tunguska_armed",
      model = "models/tunguska_armed.mdl",
      cname = "Тунгуска",
      price = 2400, 
      speed = "45",
      health = "4200",
      mplayer = "4",
      angle = Angle(0,0,0),
   },]]

   {
      sname = "avx_bmp2m",
      model = "models/vehicles/bmp2/bmp2.mdl",
      cname = "БМП-2",
      price = 3200,  -- 4200 3200
      speed = "65",
      health = "4300-5200",
      mplayer = "8",
      angle = Angle(0,0,0),
   },

   {
      sname = "avx_bmp2",
      model = "models/vehicles/bmp2/bmp2.mdl",
      cname = "БМП-2Д", -- БМП-2Д
      price = 3800,  -- 4200 3200 4000
      speed = "65",
      health = "4300-5200", -- 4500
      mplayer = "8",
      angle = Angle(0,0,0),
   },

   {
      sname = "sim_fphys_ural4320_grad",
      model = "models/vehicles/ural_4320/ural4320_grad.mdl",
      cname = "РСЗО «Град»",  
      price = 4000,  -- 4200 3200 4000
      speed = "85",
      health = "2875", -- 4500
      mplayer = "2",
      angle = Angle(0,0,0),
   },

   {
      sname = "sim_fphys_anti_air",
      model = "models/crysis/type912/antiair.mdl",
      cname = "2С6 «Тунгуска»", -- БМП-2Д
      price = 3600,  -- 4200 3200 4000
      speed = "50",
      health = "3000",
      mplayer = "4",
      angle = Angle(0,0,0),
   },


   {
      sname = "avx_t62",
      model = "models/vehicles/t62/t62.mdl",
      cname = "T-62",
      price = 4400,  -- 4200 3500
      speed = "50",
      health = "6200",
      mplayer = "4",
      angle = Angle(0,0,0),
   },

   {
      sname = "avx_t62b",
      model = "models/vehicles/t62/t62.mdl",
      cname = "T-62 с ДШК", --  T-62 (ПКМ)
      price = 4800,  -- 4200
      speed = "50",
      health = "6200",
      mplayer = "4",
      angle = Angle(0,0,0),
   },




   --------------------------

 --------------------------

 --[[
   {
      donate = "Baggy",
      cname = "Багги",
      sname = "sim_fphys_v8elite",
      model = "models/vehicles/buggy_elite.mdl",
      price = 300,  
      speed = "90",
      health = "1425",
      mplayer = "2",
   }, 

   {
      donate = "Volga",
      cname = "Волга",
      sname = "sim_fphys_pwvolga",
      model = "models/blu/volga/volga.mdl",
      price = 500,  
      speed = "90",
      health = "1337",
      mplayer = "4",
   }, 

   {
      donate = "Dukes",
      cname = "Dodge Charger R/T",
      sname = "sim_fphys_dukes",
      model = "models/blu/gtav/dukes/dukes.mdl",
      price = 500,  
      speed = "203",
      health = "1425",
      mplayer = "4",
   },


   {
      donate = "MrsdsW123",
      cname = "Mercedes W123",
      sname = "avx_mercedes",
      model = "models/avx/mercedes.mdl",
      price = 500,  
      speed = "160",
      health = "1400",
      mplayer = "4",
   }, 

   {
      donate = "avx_mercedes2",
      cname = "Mercedes W124",
      sname = "simfphys_mercedes_W124",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 500,  
      speed = "175",
      health = "1450",
      mplayer = "4",
   }, 


   {
      donate = "MrsdsW123BE",
      cname = "Mercedes W123 Premium",
      sname = "avx_mercedes",
      model = "models/avx/mercedes.mdl",
      price = 760,  
      speed = "120",
      health = "3450",
      mplayer = "4",
   }, 

   {
      donate = "MrsdsW124BE",
      cname = "Mercedes W124 Premium",
      sname = "simfphys_mercedes_W124",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 760,  
      speed = "145",
      health = "3000",
      mplayer = "4",
   }, 

   {
      donate ="avx_technical_unarmed_BE",
      cname = "Пикап Premium",
      sname = "avx_technical_unarmed_BE",
      model = "models/avx/technical_unarmed.mdl",
      price = 900,  
      speed = "115",
      health = "4250",
      mplayer = "10",
   },   ]]
  
  



}
 

return assault
