
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/sh_swep_config_7.lua ~

]]

-- ["разрешения"] = "40-ые","",""
VendorNPC7 = istable(VendorNPC7) and VendorNPC7 or {}
VendorNPC7.config = {  
 

}


local assault = {
      --cmaxspeed="140",
      --cmaxpl="4",
      --cmaxpl="4",


      
    {
      sname = "sim_fphys_pwzaz",
      model = "models/blu/zaz/zaz.mdl",
      cname = "Запорожец",
      price = 800,
      speed = "116",
      health = "1050",
      mplayer = "4",
      angle = Angle(0,0,0)
   },


   {
      sname = "sim_fphys_pwavia",
      model = "models/blu/avia/avia.mdl",
      cname = "Авия (rAk)",
      price = 900,
      speed = "110",
      health = "1625",
      mplayer = "2",
      angle = Angle(0,0,0)
   },

   
   {
      sname = "sim_fphys_vaz_2103",
      model = "models/vehicles/vaz2103/vaz2103.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "Ваз 2103 (1500s)",
      price = 1300,
      speed = "142",
      health = "1246",
      mplayer = "5",
      angle = Angle(0,0,0),
      col = true,
   },  


   {
      sname = "sim_fphys_vaz_2106",
      model = "models/vehicles/vaz2106/vaz2106.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "Ваз 2106 (1500s)",
      price = 1460,
      speed = "150",
      health = "1260",
      mplayer = "5",
      angle = Angle(0,0,0),
      col = true,
   },  


   {
      sname = "sim_fphys_zil130",
      model = "models/vehicles/zil130/zil130.mdl",
      cname = "Зил-130",
      price = 1000,  
      speed = "90",
      health = "2225",
      mplayer = "2",
      SpawnAngle = "90",
      angle = Angle(0,0,0)
   }, 
 
   {
      sname = "sim_fphys_pwmoskvich",
      model = "models/blu/moskvich/moskvich.mdl",
      cname = "Москвич",
      price = 1200,
      speed = "140",
      health = "1337",
      mplayer = "4",
      angle = Angle(0,0,0)
   },

  
   {
      sname = "sim_fphys_pwvan",
      model = "models/blu/van/pw_van.mdl",
      cname = "Микроавтобус (Ван)",
      price = 1300,
      speed = "118",
      health = "1625",
      mplayer = "6",
      angle = Angle(0,0,0),
   },
 
    {
      sname = "sim_fphys_uaz_2206",
      model = "models/vehicles/uaz_2206/uaz2206.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "Уаз 2206 (Буханка)",
      price = 1300,
      speed = "125",
      health = "1503",
      mplayer = "6",
      angle = Angle(0,0,0)
   },
 

    
   {
      sname = "sim_fphys_zil130_covered",
      model = "models/vehicles/zil130/zil130_covered.mdl",
      cname = "Зил-130 (Брезентовый)",
      price = 1400,  
      speed = "90",
      health = "2225",
      mplayer = "10",
      SpawnAngle = "90",
      angle = Angle(0,0,0)
   }, 
 

   {
      donate = "Volga",
      cname = "Волга",
      sname = "sim_fphys_pwvolga",
      model = "models/blu/volga/volga.mdl",
      price = 1500,  
      speed = "175",
      health = "1337",
      mplayer = "4",
   },
 
  --[[ {
      sname = "simphys_BTR70",
      model = "models/vehicles/btr70/btr70.mdl",
      cname = "БТР-70",
      price = 5200, 
      speed = "80",
      health = "4500",
      mplayer = "10",
      angle = Angle(0,0,0)
   },]]

     --------------------------

   --[[{
      donate = "Baggy",
      cname = "Багги",
      sname = "sim_fphys_v8elite",
      model = "models/vehicles/buggy_elite.mdl",
      price = 300,  
      speed = "90",
      health = "1425",
      mplayer = "2",
   }, ]]
  
   {
      donate = "mrsdsw123",
      cname = "Mercedes W123",
      sname = "avx_mercedes",
      model = "models/avx/mercedes.mdl",
      price = 700,  
      speed = "160",
      health = "1400",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "avx_mercedes2",
      cname = "Mercedes W124",
      sname = "simfphys_mercedes_W124",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 700,  
      speed = "175",
      health = "1450",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "dukes",
      cname = "Dodge Charger R/T",
      sname = "sim_fphys_dukes",
      model = "models/blu/gtav/dukes/dukes.mdl",
      price = 800,  
      speed = "203",
      health = "1425",
      mplayer = "4",
      col = true,
   },



   {
      donate = "mrsdsw123be",
      cname = "Premium Mercedes W123",
      sname = "avx_mercedes_Black_Edition",
      model = "models/avx/mercedes.mdl",
      price = 900,  
      speed = "120",
      health = "3450",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "mrsdsw124be",
      cname = "Premium Mercedes W124",
      sname = "simfphys_mercedes_W124_BE",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 900,  
      speed = "145",
      health = "3000",
      mplayer = "4",
      col = true,
   }, 

   {
      donate ="avx_technical_unarmed_be",
      cname = "Premium Пикап",
      sname = "avx_technical_unarmed_BE",
      model = "models/avx/technical_unarmed.mdl",
      price = 1200,  
      speed = "115",
      health = "4250",
      mplayer = "10",
      col = true,
   }, 

}



return assault