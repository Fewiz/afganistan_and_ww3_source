
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/autorun/client/cl_vendor_4.lua ~

]]

--
local assault = include("sh_swep_config_4.lua")
VendorNPC4 = istable(VendorNPC4) and VendorNPC4 or {}
net.Receive("VendorSystem4",function()
	local pmoney = LocalPlayer():GetMoney()
	local ply = LocalPlayer()

	local activtab = -1
	local activ = ""


	local frame = vgui.Create( "DFrame" )
	frame:SetSize( ScrW() * 0.9, ScrH() * 0.9 )
	frame:SetTitle( "У вас: "..pmoney .. " $"  )   
	frame:Center()
	frame:MakePopup()
	frame.Paint = function( self, w, h )  
		Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
		surface.SetDrawColor( 30,33,38, 255 ) -- 54,57,63, 255 )
		surface.DrawRect( 0, 0, w, h )
	end
	surface.PlaySound("server/ui/click2.wav")

	local DScrollPanel = vgui.Create( "DScrollPanel", frame )
	--DScrollPanel:Dock( FILL )
	DScrollPanel:SetPos(0,60)
	DScrollPanel:SetSize(frame:GetWide()*0.49,frame:GetTall()-60)
 
	local DScrollPanel2 = vgui.Create( "DScrollPanel", frame )
	DScrollPanel2:SetPos(frame:GetWide()*0.50,60)
	DScrollPanel2:SetSize(frame:GetWide()*0.49,frame:GetTall()-60)

	local framemodel = DScrollPanel2:Add( "DFrame" )
	framemodel:SetSize(frame:GetWide()*0.49,frame:GetTall()*0.85)
	framemodel:SetTitle( " " )
	framemodel.Paint = function( self, w, h )  
		surface.SetDrawColor( 28,29,32, 255 ) -- 54-5,57-5,63-5
		surface.DrawRect( 0, 0, w, h )
	end
	framemodel.DoClick=function() end framemodel:ShowCloseButton(false)  
	framemodel:SetDraggable(false)
 
					-- Правая часть 
    local Dmodel = framemodel:Add( "DModelPanel" )	
    Dmodel:SetModel( "models/Mechanics/gears2/vert_36t1.mdl" )		
    Dmodel:SetColor(Color(0,0,0,0))		
    Dmodel:Dock( TOP )		
    Dmodel:SetHeight( ScrH() * 0.8 ) 
    Dmodel.DoClick=function() end

    local ok=Dmodel:Add("DScrollPanel")
    ok:Dock( FILL )

    local ok1 = vgui.Create( "DLabel", ok )
	ok1:SetText( "" )
	ok1:SetFont( "CW_HUD24" )
	ok1:Dock( TOP )

	local ok2 = vgui.Create( "DLabel", ok )
	ok2:SetText( "" )
	ok2:SetFont( "CW_HUD24" )
	ok2:Dock( TOP )

	local ok3 = vgui.Create( "DLabel", ok )
	ok3:SetText( "" )
	ok3:SetFont( "CW_HUD24" )
	ok3:Dock( TOP )


	local ok4 = vgui.Create( "DLabel", ok )
	ok4:SetText( "" )
	ok4:SetFont( "CW_HUD24" )
	ok4:Dock( TOP )

	local ok5 = vgui.Create( "DLabel", ok )
	ok5:SetText( "" )
	ok5:SetFont( "CW_HUD24" )
	ok5:Dock( TOP )


	local mn, mx = Dmodel.Entity:GetRenderBounds()
	local size = 0
	size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
	size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
	size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )
	Dmodel:SetFOV( 35 )  -- 45
	Dmodel:SetCamPos( Vector( size, size, size ) )
	Dmodel:SetLookAt( ( mn + mx ) * 0.05 )
	  

	local DButtonBuy = DScrollPanel2:Add( "DButton" )
	--DButtonBuy:SetText( v2.name .. " " .. tostring(v2.price).. " $")
	DButtonBuy:SetPos(0,frame:GetTall()*0.84) -- *0.87
	DButtonBuy:SetSize(frame:GetWide()*0.49,30)
	DButtonBuy:SetFontInternal("CW_HUD24")
	DButtonBuy:SetText("Купить")
	DButtonBuy.Paint = function( self, w, h )  
		surface.SetDrawColor( 125, 125, 125, 128 )
		surface.DrawRect( 0, 0, w, h )
	end

	--local startPos = false
	local CarSlot = 1
	local spawn_b = DScrollPanel2:Add( "DButton" )
	spawn_b:SetText( "ВПП №"..CarSlot)
	spawn_b:SetFont( "CW_HUD24" )
	--spawn_b:Dock( t )
	spawn_b:SetPos(0,frame:GetTall()*0.88)
	spawn_b:SetSize(frame:GetWide()*0.49,30)
	spawn_b.Paint = function( self, w, h )  
		surface.SetDrawColor( 125, 255, 125, 128 )
		surface.DrawRect( 0, 0, w, h )
	end


	spawn_b.DoClick = function()
		surface.PlaySound("buttons/lightswitch2.wav")
		--if (startPos == false) then startPos = true CarSlot = 4 else startPos = false CarSlot = 3 end
		if CarSlot != 2 then CarSlot=CarSlot+1 else CarSlot = 1 end 

		spawn_b:SetText( "ВПП №"..CarSlot)		

		spawn_b.Paint = function( self, w, h )  
			surface.SetDrawColor( 125, 255, 125, 128 )
			surface.DrawRect( 0, 0, w, h )
		end 
	end	


	local c = 0
	local discount = false
	if ply:IsVIP() or ply:IsAdmin() or ply:IsRoot() then 
		discount = true  
	end 
 
	local TitleButton = vgui.Create( "DButton", frame )  
	TitleButton:SetText( "Воздушная Техника" ) 
	TitleButton:SetPos( frame:GetWide()/(table.Count(VendorNPC4.config)+1)*c,25 )     
	TitleButton:SetSize( frame:GetWide() , 30 ) 
	TitleButton:SetFontInternal("CW_HUD24")
	TitleButton.Paint = function( self, w, h )  	
		surface.SetDrawColor( 48, 49, 52, 256 ) --  155, 155, 155, 128
		TitleButton:SetColor(Color(145,145,145))
		surface.DrawRect( 1, 0, w-1, h )
	end

	TitleButton.DoClick=function()
		activtab = c1
		--surface.PlaySound("server/ui/click2.wav")
		DScrollPanel:Clear()

		for k2,v2 in pairs(assault) do 

			local DButton = DScrollPanel:Add( "DButton" )
			if discount then 
				DButton:SetText( v2.cname .. " " .. tostring(v2.price*0.75).. " $") -- .. " $ (Вместо "..tostring(v2.price).. " $)"
			else 
				DButton:SetText( v2.cname .. " " .. tostring(v2.price).. " $")
			end
		
			DButton:Dock( TOP )
			DButton:SetSize(0,30)
			DButton:DockMargin( 0, 0, 0, 5 )
			DButton:SetFontInternal("CW_HUD24")
			DButton.Paint = function( self, w, h )  
			if v2.cname == activ then
				    surface.SetDrawColor(  75, 78, 84, 256 )
				    DButton:SetColor(Color(255,255,255))
				else
				    surface.SetDrawColor(  48, 49, 52, 256 )
				    DButton:SetColor(Color(145,145,145))
				end
				surface.DrawRect( 1, 0, w-1, h )
			end

			DButton.DoClick=function()
				activ = v2.cname
				ok1:SetText('Ракет: '..v2.speed)
				ok2:SetText('ИК ловушки: '..v2.r1)  --('Боекомплект: '..v2.health)
				ok3:SetText('Боекомплект: '..v2.health)--('Вместительность: '..v2.mplayer)

				ok4:SetText('Вместительность: '..v2.mplayer)--('ИК ловушки: '..v2.r1)
				ok5:SetText('Самонаводящихся ракет: '..v2.r2)

				surface.PlaySound("server/ui/click2.wav")
					--if not IsValid(v2.model) then return end
					Dmodel:SetModel( v2.model )	
					Dmodel:SetColor(Color(255,255,255,255))		

							  local mn, mx = Dmodel.Entity:GetRenderBounds()
		  local size = 0
		  size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
		  size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
		  size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )
		  Dmodel:SetFOV( 45 )  -- 45
		  Dmodel:SetCamPos( Vector( size, size, size ) )
		  Dmodel:SetLookAt( ( mn + mx ) * 0.05 )

				--	net.Start("VendorSystem3")
				--	net.WriteString(v2.swep)
				--	net.SendToServer()	
					--print(pmoney)
					if pmoney > v2.price then 
						if discount then 
							DButtonBuy:SetText( "Купить " .. v2.cname .. " за " .. tostring(v2.price*0.75).. " $, вместо " .. tostring(v2.price).. "$?")
						else
							DButtonBuy:SetText( "Купить " .. v2.cname .. " за " .. tostring(v2.price).. " $? (VIP цена: " .. tostring(v2.price*0.75).. " $)")
						end 
						DButtonBuy.Paint = function( self, w, h )  
							surface.SetDrawColor( 125, 255, 125, 128 )
							surface.DrawRect( 0, 0, w, h )
						end
					else 

						if discount then 
							DButtonBuy:SetText( v2.cname .. " - " .. tostring(v2.price*0.75).. " $" )
						else
							DButtonBuy:SetText( v2.cname .. " - " .. tostring(v2.price).. " $" )
						end 
						--DButtonBuy:SetText( v2.cname .. " - " .. tostring(v2.price).. " $" )
						DButtonBuy.Paint = function( self, w, h )  
							surface.SetDrawColor( 255, 125, 125, 128 )
							surface.DrawRect( 0, 0, w, h )
						end	
					end 

					DButtonBuy.DoClick = function()
						surface.PlaySound("buttons/lightswitch2.wav")
						frame:Close()
						net.Start("VendorSystem4")
						net.WriteString(v2.WACname)
						net.WriteString(CarSlot)
						net.SendToServer()
				  	end	
			end
		end
	end


end)

