
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/autorun/client/cl_vendor_2.lua ~

]]

--
local assault = include("sh_swep_config_2.lua")
VendorNPC2 = istable(VendorNPC2) and VendorNPC2 or {}
net.Receive("VendorSystem2",function()
	local pmoney = LocalPlayer():GetMoney()
 
	local frame = vgui.Create( "DFrame" )
	frame:SetSize( ScrW() * 0.9, ScrH() * 0.9 )
	frame:SetTitle( "У вас: "..pmoney .. "$ | Обратите внимание, что оружие и транспорт - одноразовый, до смерти или перезахода."  )   
	frame:Center()
	frame:MakePopup()
	frame.Paint = function( self, w, h )  
		Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
		surface.SetDrawColor( 30,33,38, 255 ) -- 54,57,63, 255 )
		surface.DrawRect( 0, 0, w, h )
	end
	surface.PlaySound("server/ui/click2.wav")

	local DScrollPanel = vgui.Create( "DScrollPanel", frame )
	--DScrollPanel:Dock( FILL )
	DScrollPanel:SetPos(0,60)
	DScrollPanel:SetSize(frame:GetWide()*0.49,frame:GetTall()-60)
 
	local DScrollPanel2 = vgui.Create( "DScrollPanel", frame )
	DScrollPanel2:SetPos(frame:GetWide()*0.50,60)
	DScrollPanel2:SetSize(frame:GetWide()*0.49,frame:GetTall()-60)

	local framemodel = DScrollPanel2:Add( "DFrame" )
	framemodel:SetSize(frame:GetWide()*0.49,frame:GetTall()*0.85)
	framemodel:SetTitle( " " )
	framemodel.Paint = function( self, w, h )  
		surface.SetDrawColor( 25,25,31, 255 ) -- 54-5,57-5,63-5
		surface.DrawRect( 0, 0, w, h )
	end
	framemodel.DoClick=function() end framemodel:ShowCloseButton(false)  
	framemodel:SetDraggable(false)
 
					-- Правая часть 
    local Dmodel = framemodel:Add( "DModelPanel" )	
    Dmodel:SetModel( "models/Mechanics/gears2/vert_36t1.mdl" )		
    Dmodel:SetColor(Color(0,0,0,0))		
    Dmodel:Dock( TOP )		
    Dmodel:SetHeight( ScrH() * 0.8 ) 
    Dmodel.DoClick=function() end

    local ok=Dmodel:Add("DScrollPanel")
    ok:Dock( FILL )

    --
    local CarSkin = 1

 	local SkinDButton = vgui.Create( "DButton", ok )
 	SkinDButton:SetText("") 
 	SkinDButton:Dock( TOP )
 	SkinDButton.Paint = function( self, w, h )   
	end
	--

    local ok1 = vgui.Create( "DLabel", ok )
	ok1:SetText( "" )
	ok1:SetFont( "CW_HUD24" )
	ok1:Dock( TOP )

	local ok2 = vgui.Create( "DLabel", ok )
	ok2:SetText( "" )
	ok2:SetFont( "CW_HUD24" )
	ok2:Dock( TOP )

	local ok3 = vgui.Create( "DLabel", ok )
	ok3:SetText( "" )
	ok3:SetFont( "CW_HUD24" )
	ok3:Dock( TOP )

	local mn, mx = Dmodel.Entity:GetRenderBounds()
	local size = 0
	size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
	size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
	size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )
	Dmodel:SetFOV( 35 )  -- 45
	Dmodel:SetCamPos( Vector( size, size, size ) )
	Dmodel:SetLookAt( ( mn + mx ) * 0.05 )
	  

	local DButtonBuy = DScrollPanel2:Add( "DButton" )
	--DButtonBuy:SetText( v2.name .. " " .. tostring(v2.price).. " $")
	DButtonBuy:SetPos(0,frame:GetTall()*0.87)
	DButtonBuy:SetSize(frame:GetWide()*0.49,30)
	DButtonBuy:SetFontInternal("CW_HUD24")
	DButtonBuy:SetText("Купить")
	DButtonBuy.Paint = function( self, w, h )  
		surface.SetDrawColor( 125, 125, 125, 128 ) -- 125, 125, 125, 128
		surface.DrawRect( 0, 0, w, h )
	end

	local c = 0
	local discount = false
	if ply:IsVIP() or ply:IsAdmin() or ply:IsRoot() then 
		discount = true  
		pmoney  = LocalPlayer():GetMoney() * 1.25
	end 

	local activtab = -1
	local activ = ""

	for k,v in pairs(VendorNPC2.config) do
		local c1 = c
		local TitleButton = vgui.Create( "DButton", frame )  
		TitleButton:SetText( k ) 
		TitleButton:SetPos( frame:GetWide()/(table.Count(VendorNPC2.config)+1)*c,25 )     
		TitleButton:SetSize( frame:GetWide()/(table.Count(VendorNPC2.config)+1), 30 ) 
		TitleButton:SetFontInternal("CW_HUD24")
		TitleButton:SetColor(Color(125,125,125))
		TitleButton.Paint = function( self, w, h )  

			if activtab == c1 then 
				surface.SetDrawColor(231,28,92)
				TitleButton:SetColor(Color(255,255,255))
			else 	
			    surface.SetDrawColor( 36,37,43, 256 ) --  155, 155, 155, 128
			    TitleButton:SetColor(Color(145,145,145))
			end   
			 surface.DrawRect( 1, 0, w-1, h )
		end
		--if TitleButton.ActiveButton == self then
			--TitleButton.Paint = function( self, w, h )  
			--    surface.SetDrawColor( 75, 255, 75, 128 )
			--    surface.DrawRect( 1, 0, w-1, h )
			--end
		--end

		TitleButton.DoClick = function()
			activtab = c1
			--print(c1)
			surface.PlaySound("server/ui/click2.wav") -- "server/ui/click2.wav"
			DScrollPanel:Clear()
			for k2,v2 in pairs(VendorNPC2.config[k]) do 

				-- // -- // -- // -- // -- // -- //
				local DButton = DScrollPanel:Add( "DButton" )
				if discount then 
					DButton:SetText( v2.name .. " " .. tostring(v2.price*0.75).. "$") -- .. " $ (Вместо "..tostring(v2.price).. " $)"
				else 
					DButton:SetText( v2.name .. " " .. tostring(v2.price).. "$")
				end
				DButton:Dock( TOP )
				DButton:SetSize(0,30)
				DButton:DockMargin( 0, 0, 0, 5 )
			    DButton:SetFontInternal("CW_HUD24")
			    DButton:SetColor(Color(225,225,225))
				DButton.Paint = function( self, w, h )  
				    if v2.swep == activ then
				    	surface.SetDrawColor(231,28,92)
				    	DButton:SetColor(Color(255,255,255))
				    else
				    	surface.SetDrawColor( 36,37,43, 256 ) 
				        DButton:SetColor(Color(145,145,145))
				    end

				    surface.DrawRect( 1, 0, w-1, h )
				end
				-- // -- // -- // -- // -- // -- //


				DButton.DoClick = function()

					activ = v2.swep
						--DButton.Paint = function( self, w, h )  
					   	 --	surface.SetDrawColor(  48, 255, 52, 256 )
					    --	surface.DrawRect( 1, 0, w-1, h )
						--end

					surface.PlaySound("server/ui/click2.wav")
					--if not IsValid(v2.model) then return end
					Dmodel:SetModel( v2.model )	
					Dmodel:SetColor(Color(255,255,255,255))		

					local wep=weapons.Get(v2.swep)
					ok1:SetText('Урон: '..tostring(wep.Damage))
					if istable(wep.Primary) and isnumber(wep.Primary.ClipSize) then
						ok2:SetText('Магазин: '..tostring(wep.Primary.ClipSize ))
					else
						ok2:SetText('')
					end
					if isnumber(wep.FireDelay) then
						--ok3:SetText('Выстрелов в минуту: '..tostring(math.floor(60/wep.FireDelay)))
					else
						ok3:SetText('')
					end
					---------------
					if pmoney > v2.price then 
						if discount then 
							DButtonBuy:SetText( "Купить " .. v2.name .. " за " .. tostring(v2.price*0.75).. "$? (цена без VIP: " .. tostring(v2.price).. "$)")
						else
							DButtonBuy:SetText( "Купить " .. v2.name .. " за " .. tostring(v2.price).. "$? (цена с VIP: " .. tostring(v2.price*0.75).. "$)")
						end 
						DButtonBuy.Paint = function( self, w, h )  

							if DButtonBuy.Hovered then
								surface.SetDrawColor( 125, 255, 125, 200 )
							else 
								surface.SetDrawColor( 125, 255, 125, 128 )
							end

							surface.DrawRect( 0, 0, w, h )
						end
					else 

						if discount then 
							DButtonBuy:SetText( v2.name .. " - " .. tostring(v2.price*0.75).. "$" )
						else
							DButtonBuy:SetText( v2.name .. " - " .. tostring(v2.price).. "$" )
						end 
						--DButtonBuy:SetText( v2.cname .. " - " .. tostring(v2.price).. " $" )
						DButtonBuy.Paint = function( self, w, h )  
							surface.SetDrawColor( 255, 125, 125, 128 )
							surface.DrawRect( 0, 0, w, h )
						end	
					end 
					---------------
					DButtonBuy.DoClick = function()
						surface.PlaySound("buttons/lightswitch2.wav")
						frame:Close()
						net.Start("VendorSystem2")
						net.WriteString(v2.swep)
						net.SendToServer()
				  	end	



				end	


			end
		end
	    c = c+1 
	end

	local TitleButton = vgui.Create( "DButton", frame )  
	TitleButton:SetText( "Транспорт" ) 
	TitleButton:SetPos( frame:GetWide()/(table.Count(VendorNPC2.config)+1)*c,25 )     
	TitleButton:SetSize( frame:GetWide()/(table.Count(VendorNPC2.config)+1), 30 ) 
	TitleButton:SetFontInternal("CW_HUD24")
	TitleButton.Paint = function( self, w, h )  
	if activtab == c1 then 
			surface.SetDrawColor( 231,28,92, 256 )
			TitleButton:SetColor(Color(255,255,255))
		else 	
			surface.SetDrawColor( 36,37,43, 256 ) --  155, 155, 155, 128
			TitleButton:SetColor(Color(145,145,145))
		end   
		surface.DrawRect( 1, 0, w-1, h )
	end



	--
	local CarColor = Color(255,255,255) --({ ['r'] = 1,['b'] = 255,['g'] = 255,['a'] = 255})
	--Dmodel:SetColor(CarColor)

	local Mixer = vgui.Create("DColorMixer", frame)		
	Mixer:SetPalette(false)  -- Кубики для примера
	Mixer:SetPos( ScrW() * 0.74, ScrH() * 0.065 )  	
	Mixer:SetSize( ScrW() * 0.15, ScrH() * 0.15  ) -- Добавил
	Mixer:DockMargin( 0, 0, 0, 5 )
	Mixer:SetAlphaBar(false) 		
	--Mixer:SetLabel(false) 	
	Mixer:SetWangs(false) -- Таблица с точным значением цвета	 	
	Mixer:SetColor(color_white)  -- color_white

	local zapretcolor = vgui.Create( "DLabel", Mixer )
	zapretcolor:SetText( "Покраска для VIP!" )
	zapretcolor:DockMargin( 0, 0, 0, 5 )
	zapretcolor:SetPos( ScrW() * 0.74, ScrH() * 0.065 ) 		
	zapretcolor:SetFont( "CW_HUD24" )
	zapretcolor:Dock( TOP )

	Mixer:Hide()
	zapretcolor:Hide()

	function Mixer:ValueChanged(col)
		Dmodel:SetColor(col)
		CarColor = col
		--PrintTable(col)
	end


	local shopitems = IGS.GetItems()
	local cool_price

	TitleButton.DoClick=function()
		activtab = c1
		surface.PlaySound("server/ui/click2.wav")
		DScrollPanel:Clear()

		for k2,v2 in pairs(assault) do 

			if discount then 
				cool_price = tostring(v2.price*0.75)
			else
				cool_price = tostring(v2.price)
			end 
 

			local DButton = DScrollPanel:Add( "DButton" )
			DButton:SetText( v2.cname .. " " .. cool_price .. "$") -- .. " $ (Вместо "..tostring(v2.price).. " $)"

			for k, v in ipairs(shopitems) do
				if (v['vehicle'] ~= nil)  then -- and IsValid(v2.donate)
					if (v2.donate and v['vehicle'] == v2.sname and !ply:HasPurchase(v['uid'])) then -- v['vehicle'] == v2.sname and !ply:HasPurchase(v['uid'])
						DButton:SetText( "☆ ".. v2.cname .. " " .. v['price'].."₽")
					elseif (v2.donate and v['vehicle'] == v2.sname and ply:HasPurchase(v['uid'])) then
						DButton:SetText( "★ ".. v2.cname .. " " .. cool_price .. "$")		
					end 
				end
			end 		


			DButton:Dock( TOP )
			DButton:SetSize(0,35) -- 30
			DButton:DockMargin( 0, 0, 0, 5 )
			DButton:SetFontInternal("CW_HUD24")
			DButton.Paint = function( self, w, h )  
			  	if v2.cname == activ then
				    surface.SetDrawColor(  231,28,92, 256 )
				    DButton:SetColor(Color(255,255,255))

				else
				    surface.SetDrawColor(  36,37,43, 256 )
				    DButton:SetColor(Color(145,145,145))

				    if discount then 
						DButton:SetText(v2.cname .. " " .. tostring(v2.price*0.75).. "$")
					else
						DButton:SetText(v2.cname .. " " .. tostring(v2.price).. "$")
					end 
				end

				--
				for k, v in ipairs(shopitems) do
					if (v['vehicle'] ~= nil)  then -- and IsValid(v2.donate)
						if (v2.donate and v['vehicle'] == v2.sname and !ply:HasPurchase(v['uid'])) then -- v['vehicle'] == v2.sname and !ply:HasPurchase(v['uid'])
							DButton:SetText( "☆ ".. v2.cname .. " " .. v['price'].."₽")
						elseif (v2.donate and v['vehicle'] == v2.sname and ply:HasPurchase(v['uid'])) then
							if discount then 
								DButton:SetText( "★ ".. v2.cname .. " " .. tostring(v2.price*0.75).. "$")
							else
								DButton:SetText( "★ ".. v2.cname .. " " .. tostring(v2.price).. "$")
							end 
						end 
					end
				end 	
				--

				surface.DrawRect( 1, 0, w-1, h )
			end

		DButton.DoClick=function()
			activ = v2.cname
			ok1:SetText('Максимальная Скорость: '..v2.speed)
			ok2:SetText('Целостность: '..v2.health)
			ok3:SetText('Вместительность человек: '..v2.mplayer)
			surface.PlaySound("server/ui/click2.wav")
			Dmodel:SetModel( v2.model )	
			Dmodel:SetColor(Color(255,255,255,255))	

		  local mn, mx = Dmodel.Entity:GetRenderBounds()
		  local size = 0
		  size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
		  size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
		  size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )
		  Dmodel:SetFOV( 45 )  -- 45
		  Dmodel:SetCamPos( Vector( size, size, size ) )
		  Dmodel:SetLookAt( ( mn + mx ) * 0.05 )

		  Dmodel.Entity:SetSkin(1) 
		--discount = false
		if v2.col == true then 
		  	Mixer:Show()
		  	if col != nil then
		  		CarColor = col
		  	else 
		  		CarColor = Color(255,255,255)
		  	end 	
		  	if discount then zapretcolor:Hide() else zapretcolor:Show() end
		  	--zapretcolor:Show()
		else
			Mixer:Hide() zapretcolor:Hide()
			CarColor = Color(255,255,255)
		end

		if v2.customBG != nil then
			--print(v2.customBG)
			--Dmodel.Entity:SetBodygroup(1, 5) -- v2.customBG
		end 
 
		--print( v2.model:SkinCount())
		--print( Dmodel.Entity:SkinCount())
 	

		------------------------------------------------
		SkinDButton:SetText("Скин: "..Dmodel.Entity:GetSkin().." из "..Dmodel.Entity:SkinCount()) 
		SkinDButton:SetSize(0,20)
		SkinDButton:DockMargin( 0, 0, 0, 0 )
		SkinDButton:SetFontInternal("CW_HUD24")
		SkinDButton.Paint = function( self, w, h )   
			if Dmodel.Entity:SkinCount() != 1 then
				surface.SetDrawColor(  75, 78, 84, 256 )
				SkinDButton:SetColor(Color(225,225,225))
			else
				surface.SetDrawColor(  0, 0, 0, 0 )
				SkinDButton:SetColor(Color(25,25,25))
			end 
		end
 		SkinDButton.DoClick=function()
 			if Dmodel.Entity:GetSkin() < Dmodel.Entity:SkinCount() then
 				Dmodel.Entity:SetSkin(Dmodel.Entity:GetSkin()+1) 
 			else
 				Dmodel.Entity:SetSkin(1) 
 			end 
 			CarSkin = Dmodel.Entity:GetSkin()  
 			surface.PlaySound("server/ui/click4.wav")
 			SkinDButton:SetText("Скин: "..Dmodel.Entity:GetSkin().." из "..Dmodel.Entity:SkinCount()) 
 		end 	
		------------------------------------------------
		
 
					if pmoney > v2.price then 
						if discount then 
							DButtonBuy:SetText( "Купить " .. v2.cname .. " за " .. tostring(v2.price*0.75).. " $, вместо " .. tostring(v2.price).. "$?")
						else
							DButtonBuy:SetText( "Купить " .. v2.cname .. " за " .. tostring(v2.price).. " $? (VIP цена: " .. tostring(v2.price*0.75).. " $)")
						end 
						DButtonBuy.Paint = function( self, w, h )  
							surface.SetDrawColor( 125, 255, 125, 128 )
							surface.DrawRect( 0, 0, w, h )
						end

						if discount then 
							cool_price = tostring(v2.price*0.75)
						else
							cool_price = tostring(v2.price)
						end 

						for k, v in ipairs(shopitems) do
							if (v['vehicle'] ~= nil)  then -- and IsValid(v2.donate)
								if (v2.donate and v['vehicle'] == v2.sname and !ply:HasPurchase(v['uid'])) then -- v['vehicle'] == v2.sname and !ply:HasPurchase(v['uid'])
									DButtonBuy:SetText( "Купить ☆Премиум☆ Транспорт за "..v['price'].."rub?")
								elseif (v2.donate and v['vehicle'] == v2.sname and ply:HasPurchase(v['uid'])) then
									DButtonBuy:SetText( "Заспавнить за "..cool_price .. "$ " ..v2.cname.."?")		
							 	end 

							end
						end	
						
					else 

						if discount then 
							DButtonBuy:SetText( v2.cname .. " - " .. tostring(v2.price*0.75).. " $" )
						else
							DButtonBuy:SetText( v2.cname .. " - " .. tostring(v2.price).. " $" )
						end 
						--DButtonBuy:SetText( v2.cname .. " - " .. tostring(v2.price).. " $" )
						DButtonBuy.Paint = function( self, w, h )  
							surface.SetDrawColor( 255, 125, 125, 128 )
							surface.DrawRect( 0, 0, w, h )
						end	
					end 
					local shopitems = IGS.GetItems()
					local Status = true 
					DButtonBuy.DoClick = function()

						--ply:ChatPrint( "DEBUG 2" )  
						for k, v in ipairs(shopitems) do
							if (v['vehicle'] ~= nil)  then
								--if not v2.donate then return end  -- Проверка валидности донат тачки
								if (v2.donate and v['vehicle'] == v2.sname and !ply:HasPurchase(v['uid'])) then  
									IGS.UI(LocalPlayer())
									frame:Close()
									Status = false 
							 	end 

							end
						end	
						if Status then 
							surface.PlaySound("buttons/lightswitch2.wav")
							frame:Close()
							net.Start("VendorSystem2")
							net.WriteString(v2.sname)
							if CarColor != 0 then 
								net.WriteColor(CarColor)
							end 	
							net.WriteString(CarSkin)
							net.SendToServer()
				  		end 

				  end	
			end
		end
	end


end)

