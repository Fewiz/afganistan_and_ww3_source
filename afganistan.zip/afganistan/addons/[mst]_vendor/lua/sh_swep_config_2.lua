
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/sh_swep_config_2.lua ~

]]

-- ["разрешения"] = "40-ые","",""
VendorNPC2 = istable(VendorNPC2) and VendorNPC2 or {}
VendorNPC2.config = {  
 
 
["Оружие / Предметы"] = {
       
      --[[{
         name = "Дубинка",
         swep = "stun_baton",
         model = "models/weapons/c_stunstick.mdl",
         price = 90,
      },]]
  
          {
         name = "Нож",
         swep = "cw_extrema_ratio_official",
         model = "models/weapons/w_knife_ct.mdl",
         price = 60,
      },

      {
         name = "Дубликат ключей",
         swep = "carkeys",
         model = "models/sentry/pgkey.mdl",
         price = 80,
      },
 
      {
         name = "Бинокль",
         swep = "weapon_rpw_binoculars_explorer",
         model = "models/weapons/w_binocularsbp.mdl",
         price = 160,
      },

      {
         name = "Бинокль+",
         swep = "weapon_rpw_binoculars",
         model = "models/weapons/w_binoculars_uk.mdl",
         price = 300,
      },

      {
         name = "Флаер",
         swep = "weapon_vj_flaregun_r",
         model = "models/vj_weapons/w_flaregun.mdl",
         price = 460,
      },

      {
         name = "Мачете",
         swep = "cw_ws_pamachete",
         model = "models/weapons/melee/w_ws_pamachete.mdl",
         price = 400,
      },

	   {
	      name = "ПМ",
		   swep = "cw_makarov",
		   model = "models/khrcw2/pistols/w_makarov.mdl",
		   price = 460,
	   },
      {
         name  = "Фотоаппарат",
         swep  = "gmod_camera",
         model = "models/MaxOfS2D/camera.mdl",
         price = 600,
      },
  
      --[[{
         name = "Отмычка",
         swep = "lockpick",
         model = "models/weapons/w_crowbar.mdl",
         price = 660,
      },]]

      {
         name = "Сигарета",
         swep = "weapon_ciga_cheap",
         model = "models/mordeciga/mordes/oldcigshib.mdl",
         price = 660,
      },

      {
         name = "АК-74",
         swep = "cw_ak74",
         model = "models/weapons/w_rif_ak47.mdl",
         price = 800, -- 1300
      },

      {
         name = "КС-23",
         swep = "cw_ks23",
         model = "models/weapons/world/shotguns/ks23.mdl",
         price = 1000, -- 1360
      },

	   {
	      name = "АКМ",
		   swep = "cw_akm",
		   model = "models/weapons/w_rif_ak47.mdl",
		   price = 1200,
	   },
  
      {
         name =  "Ремкомплект (Обл)",
         swep =  "weapon_simrepair2",
         model = "models/props_c17/tools_wrench01a.mdl",
         price = 1260,
      },
 
      {
         name = "Аптечка",
         swep = "fas2_ifak",
         model = "models/weapons/w_ifak.mdl",
         price = 1260,
      },
 
      {
         name = "СВТ-40",
         swep = "cw_svt40",
         model = "models/weapons/w_dber_svt40.mdl",
         price = 1400,
      },

      {
         name = "СКС",
         swep = "cw_simsks",
         model = "models/weapons/w_dber_svt40.mdl", --"models/weapons/tfa_ins2/w_sks.mdl",
         price = 1460,
      },
 
      
      {
         name = "СВД",
         swep = "bo_aron_dragunov",
         model = "models/weapons/v_svd_prop.mdl",
         price = 1700,
      },


      {
         name = "МГ-42",
         swep = "cw_kks_doi_mg42",
         model ="models/weapons/cw2/w_kks_mg42.mdl",
         price = 1800, -- 3400 2200
      },



	  
      
      --- Донат оружие

      {
         name = "ППШ ★",
         swep = "weapon_pph41",
         model = "models/weapons/w_nik_ppsh1.mdl",
         price = 1800,
      },

      {
         name = "Мосинка ★",
         swep = "cw_mosin",
         model = "models/khrcw2/w_khri_mosinm91.mdl",
         price = 1800,
      },

      {
         name = "Thompson ★ ",
         swep = "cwc_thompson",
         model = "models/weapons/cwc_thompson/cwc_thompson_w.mdl",
         price = 3600,
      },

      {
         name = "MR73 ★ ",
         swep = "cw_mr96",
         model = "models/weapons/w_357.mdl",
         price = 2600,
      },

      {
         name = "Desert Eagle ★",
         swep = "cw_deagle",
         model = "models/weapons/w_pist_deagle.mdl",
         price = 3200,
      },

      {
         name = "STG-44 ★",
         swep = "cw_stg44",
         model = "models/weapons/bob/w_stg44.mdl",
         price = 3600,
      },

      {
         name = "M620 ★ ",
         swep = "cw_m620",
         model = "models/khrcw2/w_khri_stevenm62.mdl",
         price = 3800,
      },

	},  

	["Взрывное"] = {
      {
         name = "Граната",
         swep = "cw_frag_grenade",
         model = "models/weapons/w_eq_fraggrenade.mdl",
         price = 300,
      },
 
	   {
         name = "Дымовая",
         swep = "cw_smoke_grenade",
         model = "models/weapons/w_eq_smokegrenade.mdl",
         price = 400,
      },
      {
         name = "Слеповая",
         swep = "cw_flash_grenade",
         model = "models/weapons/w_eq_flashbang.mdl",
         price = 500,
      },
      {
         name = "Мина",
         swep = "weapon_simmines",
         model = "models/blu/mine.mdl",
         price = 560, -- 760
      },

      {
         name = "Пояс Деда",
         swep = "weapon_musel",
         model = "models/props_junk/gascan001a.mdl",
         price = 600, -- 860 700
      },

      {
         name = "Газовая Граната",
         swep = "weapon_ttt_shortgasgrenade",
         model = "models/weapons/w_eq_smokegrenade.mdl",
         price = 900, -- 2000
      },

      {
         name = "РПГ-7",
         swep = "ins2_atow_rpg7",
         model = "models/khrcw2/w_ins2rpg7.mdl",
         price = 1200, -- 1900 2150
      },

      {
         name = "Миномет",
         swep = "cw_kk_ofrp_lgi",
         model = "models/bsoldiers/cw_kk_weapons/w_lgi.mdl",
         price = 1300, -- 2000
      },

      --[[{
         name = "C4",
         swep = "z_bomb_rewrite",
         model = "models/weapons/w_c4_planted.mdl",
         price = 1400, -- 2200 3800
      },]]

      {
         name = "FIM-92 «Стингер»",
         swep = "weapon_fim_92_stinger",
         model = "models/jessev92/weapons/hl2/stinger_w.mdl",
         price = 2200, -- 5100  2800
      },

 

	},   






}


local assault = {
      --cmaxspeed="140",
      --cmaxpl="4",
      --cmaxpl="4",


   {
      sname = "sim_fphys_pwtrabant",
      model = "models/blu/trabant/trabant.mdl",
      cname = "Трабант",
      price = 700,
      speed = "80",
      health = "1212",
      mplayer = "2",
      angle = Angle(0,0,0),
   },
   
   
  {
      sname = "sim_fphys_pwtrabant02",
      model = "models/blu/trabant/trabant02.mdl",
      cname = "Трабант Универсалы",
      price = 960,
      speed = "82",
      health = "1212",
      mplayer = "4",
      angle = Angle(0,0,0),
   },
 
   

   {
      donate = "Baggy",
      cname = "Багги",
      sname = "sim_fphys_v8elite",
      model = "models/vehicles/buggy_elite.mdl",
      price = 1000,  
      speed = "90",
      health = "1425",
      mplayer = "2",
   }, 
   

    {
      sname = "sim_fphys_pwzaz",
      model = "models/blu/zaz/zaz.mdl",
      cname = "Запорожец",
      price = 1060,
      speed = "116",
      health = "1050",
      mplayer = "4",
      angle = Angle(0,0,0),
   },
 

   {
      sname = "sim_fphys_pwavia",
      model = "models/blu/avia/avia.mdl",
      cname = "Авия (rAk)",
      price = 1160,
      speed = "110",
      health = "1625",
      mplayer = "2",
      angle = Angle(0,0,0),
   },


   {
      sname = "sim_fphys_vaz_2103",
      model = "models/vehicles/vaz2103/vaz2103.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "ВАЗ-2103 (1500s)",
      price = 1400,
      speed = "142",
      health = "1246",
      mplayer = "5",
      angle = Angle(0,0,0),
      col = true,
   },  
 
 

   {
      sname = "sim_fphys_zil130",
      model = "models/vehicles/zil130/zil130.mdl",
      cname = "Зил-130",
      price = 1400,  
      speed = "90",
      health = "2225",
      mplayer = "2",
      SpawnAngle = "90",
      angle = Angle(0,0,0),
   }, 
  

   {
      sname = "sim_fphys_pwvan",
      model = "models/blu/van/pw_van.mdl",
      cname = "Микроавтобус (Ван)",
      price = 1460,
      speed = "118",
      health = "1625",
      mplayer = "6",
      angle = Angle(0,0,0),
   },


   {
      sname = "sim_fphys_vaz_2121",
      model = "models/sim_fphys_vaz_2121/vaz_2121.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "ВАЗ-2121 «Нива»",
      price = 1500,
      speed = "132",
      health = "1400",
      mplayer = "5",
      angle = Angle(0,0,0),
      col = true,
   }, 

 
   {
      sname = "sim_fphys_uaz_3151o_dux",
      model = "models/vehicles/uaz_3151/uaz_3151o_dux.mdl",
      cname = "Уаз (Без Крыши)",
      price = 1600,
      speed = "127", -- 127
      health = "1237",
      mplayer = "7",
      angle = Angle(0,0,0),
   },

   {
      sname = "sim_fphys_uaz_3151c_dux",
      model = "models/vehicles/uaz_3151/uaz_3151c_dux.mdl",
      cname = "Уаз",
      price = 1600,
      speed = "127",
      health = "1237",
      mplayer = "7",
      angle = Angle(0,0,0),
   },


   {
      sname = "sim_fphys_uaz_2206",
      model = "models/vehicles/uaz_2206/uaz2206.mdl", --"models/vehicles/civ_lada.mdl",
      cname = "Уаз 2206 (Буханка)",
      price = 1660,
      speed = "125",
      health = "1503",
      mplayer = "6",
      angle = Angle(0,0,0)
   },

    {
      sname = "sim_fphys_zil130_covered",
      model = "models/vehicles/zil130/zil130_covered.mdl",
      cname = "Зил-130 (брезентовый)",
      price = 1700,  
      speed = "90",
      health = "2225",
      mplayer = "10",
      SpawnAngle = "90",
      angle = Angle(0,0,0),
   }, 
 
  
   --[[{
      sname = "sim_fphys_kamaz",
      model = "models/vehicles/kamaz/zamak/kamaz1.mdl",
      cname = "Камаз",
      price = 900, -- 1250
      speed = "90",
      health = "2000",
      mplayer = "19",
      skin = "1",
      SpawnAngle = "90",
      angle = Angle(0,0,0),
   },]]
 
  
   {
      donate = "Volga",
      cname = "Волга",
      sname = "sim_fphys_pwvolga",
      model = "models/blu/volga/volga.mdl",
      price = 1700,  
      speed = "90",
      health = "1337",
      mplayer = "4",
   }, 


   {
      sname = "avx_passat",
      model = "models/avx/passat.mdl",
      cname = "Volkswagen Passat 1973",
      price = 1700, -- 1900
      speed = "160",
      health = "1300",
      mplayer = "4",
      color = "1",
      angle = Angle(0,0,0),
      col = true,
   },

   {
      sname = "avx_passat_vbied",
      model = "models/avx/passat.mdl",
      cname = "Volkswagen Passat 1973 c Бомбой",
      price = 1800, -- 1625 за обычную 
      speed = "160",
      health = "1300",
      mplayer = "4",
      angle = Angle(0,0,0),
      col = true,
   },

    
  
   {
      sname = "avx_minibus",
      model = "models/avx/minibus.mdl",
      cname = "Микроавтобус",
      price = 1800, -- 2100
      speed = "110",
      health = "2450",
      mplayer = "8",
      angle = Angle(0,0,0),
      col = true,
   },
   
   {
      sname = "avx_minibus_vbied",
      model = "models/avx/minibus.mdl",
      cname = "Микроавтобус c Бомбой",
      price = 1900, -- 1800 за обычную
      speed = "110",
      health = "1675",
      mplayer = "8",
      angle = Angle(0,0,0),
      col = true,
   },
   
   ----------

   --[[{
      sname = "avx_technical_unarmed",
      model = "models/avx/technical_unarmed.mdl",
      cname = "Пикап",
      price = 2200, -- 2200 
      speed = "125",
      health = "2250",
      mplayer = "10",
      angle = Angle(0,0,0),
      col = true,
   },
   
   {
      sname = "avx_technical_hmg",
      model = "models/avx/technical_hmg.mdl",
      cname = "Пикап (Пулемётный)",
      price = 2060, -- 2560
      speed = "122",
      health = "2250",
      mplayer = "5",
      angle = Angle(0,0,0),
      col = true,
   }, 

   {
      sname = "sim_fphys_uaz_3151_spg",
      model = "models/vehicles/uaz_3151/uaz_3151o.mdl",
      cname = "УАЗ с СПГ",
      price = 2100,  -- 2900 2500
      speed = "170",
      health = "1337",
      mplayer = "5",
      angle = Angle(0,0,0),
   },
 

   {
      sname = "avx_technical_mlrs",
      model = "models/avx/technical_mlrs.mdl",
      cname = "Пикап (Ракетный)",
      price = 2260, -- 2760
      speed = "122",
      health = "2250",
      mplayer = "5",
      angle = Angle(0,0,0),
      col = true,
   },]] 
 

   {
      sname = "sim_fphys_hilux",
      model = "models/vehicles/hilux/coyota.mdl",
      cname = "Toyota Helux",
      price = 1600,  
      speed = "145",
      health = "2250-2700",
      mplayer = "8",
      angle = Angle(0,0,0),
      col = false,
   },


   {
      sname = "sim_fphys_hilux_sup",
      model = "models/vehicles/hilux/coyota.mdl",
      cname = "Toyota Helux Снабжения",
      price = 1900,  
      speed = "145",
      health = "2250-2700",
      mplayer = "4",
      angle = Angle(0,0,0),
      col = false,
   },

   {
      sname = "sim_fphys_hilux_dshkm",
      model = "models/vehicles/hilux/coyota.mdl",
      cname = "Toyota Helux c ДШК",
      price = 2100,  
      speed = "140",
      health = "2250-2700",
      mplayer = "9",
      angle = Angle(0,0,0),
      col = false,
   },

   {
      sname = "sim_fphys_hilux_m2b",
      model = "models/vehicles/hilux/coyota.mdl",
      cname = "Toyota Helux c M2 Browning",
      price = 2100,  
      speed = "140",
      health = "2250-2700",
      mplayer = "9",
      angle = Angle(0,0,0),
      col = false,
   },

   {
      sname = "sim_fphys_hilux_spg",
      model = "models/vehicles/hilux/coyota.mdl",
      cname = "Toyota Helux c СПГ-9",
      price = 2400,  
      speed = "140",
      health = "2250-2700",
      mplayer = "9",
      angle = Angle(0,0,0),
      col = false,
   },

   {
      sname = "sim_fphys_hilux_ags",
      model = "models/vehicles/hilux/coyota.mdl",
      cname = "Toyota Helux c АГС-17",
      price = 3100, -- 2800  
      speed = "140",
      health = "2250-2700",
      mplayer = "9",
      angle = Angle(0,0,0),
      col = false,
   },

   {
      sname = "sim_fphys_hilux_atgm",
      model = "models/vehicles/hilux/coyota.mdl",
      cname = "Toyota Helux c РСЗО",
      price = 3400, -- 2900
      speed = "140",
      health = "2250-2700",
      mplayer = "8",
      angle = Angle(0,0,0),
      col = false,
   },





   --------------------------
 
   --[[ {
      sname = "simphys_BTR70",
      model = "models/vehicles/btr70/btr70.mdl",
      cname = "БТР-70",
      price = 5200, 
      speed = "80",
      health = "4500",
      mplayer = "10",
      angle = Angle(0,0,0),
   },]]

     --------------------------

   --[[{
      donate = "Baggy",
      cname = "Багги",
      sname = "sim_fphys_v8elite",
      model = "models/vehicles/buggy_elite.mdl",
      price = 300,  
      speed = "90",
      health = "1425",
      mplayer = "2",
   }, ]]
  

 
   {
      donate = "mrsdsw123",
      cname = "Mercedes W123",
      sname = "avx_mercedes",
      model = "models/avx/mercedes.mdl",
      price = 700,  
      speed = "160",
      health = "1400",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "avx_mercedes2",
      cname = "Mercedes W124",
      sname = "simfphys_mercedes_W124",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 700,  
      speed = "175",
      health = "1450",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "dukes",
      cname = "Dodge Charger R/T",
      sname = "sim_fphys_dukes",
      model = "models/blu/gtav/dukes/dukes.mdl",
      price = 800,  
      speed = "203",
      health = "1425",
      mplayer = "4",
      col = true,
   },



   --[[{
      donate = "mrsdsw123be",
      cname = "Premium Mercedes W123",
      sname = "avx_mercedes_Black_Edition",
      model = "models/avx/mercedes.mdl",
      price = 900,  
      speed = "120",
      health = "3450",
      mplayer = "4",
      col = true,
   }, 

   {
      donate = "mrsdsw124be",
      cname = "Premium Mercedes W124",
      sname = "simfphys_mercedes_W124_BE",
      model = "models/vehicles/mercedes/civ_mercedes.mdl",
      price = 900,  
      speed = "145",
      health = "3000",
      mplayer = "4",
      col = true,
   }, 

   {
      donate ="avx_technical_unarmed_be",
      cname = "Premium Пикап",
      sname = "avx_technical_unarmed_BE",
      model = "models/avx/technical_unarmed.mdl",
      price = 1200,  
      speed = "115",
      health = "4250",
      mplayer = "10",
      col = true,
   }, ]]


   

}

return assault
