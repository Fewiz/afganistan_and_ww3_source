
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/sh_swep_config_4.lua ~

]]

-- ["разрешения"] = "40-ые","",""
VendorNPC4 = istable(VendorNPC4) and VendorNPC4 or {}
VendorNPC4.config = {  
 
["Оружие / Предметы"] = {
       
      --[[{
         name = "Дубинка",
         swep = "stun_baton",
         model = "models/weapons/c_stunstick.mdl",
         price = 90,
      },]]
    
      {
         name = "Флаер",
         swep = "weapon_vj_flaregun_r",
         model = "models/vj_weapons/w_flaregun.mdl",
         price = 460,
      },

   }  






}


local assault = {
      --cmaxspeed="140",
      --cmaxpl="4",
      --cmaxpl="4",


   {
      WACname = "wac_hc_mi8",
      model = "models/vehicles/mi8.mdl",
      cname = "Ми-8",
      price = 1000, -- 1200 900
      speed = "0 шт.",
      health = "0 пт.",
      mplayer = "15 ч.",

      r1 = "4 злп.",
      r2 = "0 шт.",
      angle = Angle(0,0,0)
   },

   {
      WACname = "wac_hc_mi8+",
      model = "models/vehicles/mi8v.mdl",
      cname = "Ми-8 МТ",
      price = 2000, -- 2000 1400 1500
      speed = "68 шт.",
      health = "200 пт.",
      mplayer = "15 ч.",

      r1 = "8 злп.",
      r2 = "0 шт.",
      angle = Angle(0,0,0)
   },
   

     {
      WACname = "wac_hc_mi24",
      model = "models/vehicles/mi24.mdl",
      cname = "Ми-24",
      price = 2800, -- 2200 1800 2400
      speed = "68 шт.",
      health = "250 пт.",
      mplayer = "10 ч.",

      r1 = "16 злп.",
      r2 = "4 шт.",
      angle = Angle(0,0,0)
   },
   
   
    
   
  

}

return assault