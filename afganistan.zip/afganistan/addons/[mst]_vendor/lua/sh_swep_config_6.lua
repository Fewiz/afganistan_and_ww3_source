
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_vendor/lua/sh_swep_config_6.lua ~

]]

-- ["разрешения"] = "40-ые","",""
VendorNPC6 = istable(VendorNPC6) and VendorNPC6 or {}
VendorNPC6.config = {  
 
["Оружие / Предметы"] = {
       
      --[[{
         name = "Дубинка",
         swep = "stun_baton",
         model = "models/weapons/c_stunstick.mdl",
         price = 90,
      },]]
    
      {
         name = "Флаер",
         swep = "weapon_vj_flaregun_r",
         model = "models/vj_weapons/w_flaregun.mdl",
         price = 460,
      },

   }  



}


local assault = {
      --cmaxspeed="140",
      --cmaxpl="4",
      --cmaxpl="4",

   {
      WACname = "wac_hc_littlebird_mh6",
      model = "models/flyboi/littlebird/littlebird_fb.mdl",
      cname = "MH-6 «Little Bird»",
      price = 2000, -- 3000 2600 2200
      speed = "0 шт.",
      health = "0 пт.",
      mplayer = "4 ч.",

      r1 = "0 злп.",
      r2 = "0 шт.",
      angle = Angle(0,0,0)
   },

   {
      WACname = "wac_hc_littlebird_ah6",
      model = "models/flyboi/littlebird/littlebirda_fb.mdl",
      cname = "AH-6 «Little Bird»",
      price = 3200, -- 4200 3800 3200  3500
      speed = "14 шт.",
      health = "800 пт.",
      mplayer = "2 ч.",

      r1 = "0 злп.",
      r2 = "16 шт.",
      angle = Angle(0,0,0)
   },

   {
      WACname = "wac_hc_ah64d_longbow",
      model = "models/sentry/apache.mdl",
      cname = "Boeing AH-64D Longbow",
      price = 4800, -- 4200 4400
      speed = "38 шт.",
      health = "700 пт.",
      mplayer = "2 ч.",

      r1 = "0 злп.",
      r2 = "24 шт.",
      angle = Angle(0,0,0)
   },


}



return assault