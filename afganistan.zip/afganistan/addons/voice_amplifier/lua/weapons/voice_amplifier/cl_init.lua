
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/voice_amplifier/lua/weapons/voice_amplifier/cl_init.lua ~

]]

include("shared.lua")

SWEP.PrintName = "Голосовой Передатчик" -- "Voice Amplifier"
SWEP.Author = "Dannelor"
SWEP.Purpose = "Amplifies the distance a players voice can be heard."
SWEP.Instructions = "Select swep and change settings"

SWEP.BobScale = 0
SWEP.SwayScale = 0
SWEP.BounceWeaponIcon = false

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.slot = 5
SWEP.WepSelectIcon = surface.GetTextureID("VGUI/entities/voice_amplifier")

function SWEP:PostDrawViewModel(vm,wep,ply)
  cam.Start3D()
    local dis = math.sqrt(self:GetDistance())
    local AllTalk = self:GetAllTalk()
    render.SetColorMaterial()
    render.DrawSphere(ply:GetPos(),AllTalk and -200 or -dis,20,20,AllTalk and Color(255,0,0,40) or Color(0,255,0,40))
  cam.End3D()
end
