
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_hlib/lua/autorun/client/cl_optimiz.lua ~

]]

--
local hook, ents, timer, ipairs, LocalPlayer = hook, ents, timer, ipairs, LocalPlayer
  
local _cvars = {
	['cl_interp'] = 0.116700, -- 0.116700,
	['cl_interp_ratio'] = 2,
	['cl_updaterate'] = 16,
	['cl_cmdrate'] = 16,
	['cl_phys_props_enable'] = 0,
	['cl_phys_props_max'] = 0,
	['props_break_max_pieces'] = 0,
	['r_propsmaxdist'] = 1,
	['violence_agibs'] = 0,
	['violence_hgibs'] = 0,
	--['cl_threaded_bone_setup'] = 1,
	['cl_threaded_client_leaf_system'] = 1,
	['r_threaded_client_shadow_manager'] = 1,
	['r_threaded_particles'] = 1,
	['r_threaded_renderables'] = 1,
	['r_queued_ropes'] = 1,
	['studio_queue_mode'] = 1,
	['mat_queue_mode'] = -1,
	['r_decals'] = 512, -- 25 100
	['mat_specular'] = 0,
	['mat_disable_bloom'] = 1,
	['r_WaterDrawReflection'] = 0,
	--['r_drawmodeldecals'] = 0,
	['m9kgaseffect'] = 0,
	['cl_smooth'] = 0,
	--['mat_parallaxmap'] = 0,
	['mat_hdr_level'] = 0,
	['r_propsmaxdist'] = 100,
}

hook.Add('Initialize', 'hlib.player.Initialize', function()
	hook.Remove('Initialize', 'hlib.player.Initialize')
	for k, v in pairs(_cvars) do
		RunConsoleCommand(k, v)
	end
	
	_cvars = nil
end)


local hooks = {
	{'PostDrawEffects', 'RenderWidgets'},
	{'PlayerTick', 'TickWidgets'},
	{'PlayerInitialSpawn', 'PlayerAuthSpawn'},
	{'RenderScene', 'RenderStereoscopy'},
	{'LoadGModSave', 'LoadGModSave'}
}

hook.Add('Initialize', 'hlib.widgets', function()
	hook.Remove('Initialize', 'hlib.widgets')
	
	for k, v in ipairs(hooks) do
		hook.Remove(v[1], v[2])
	end
	
	widgets.PlayerTick = nil
	timer.Remove("HostnameThink")
	hooks = nil
end)


------------------------------------------------
 

 ////////////////////////////////////////////////


-- A list of entity classes that need to have a nameplate drawn on them
DaddyDev = {}
DaddyDev._Kernel = DaddyDev._Kernel or {}
DaddyDev._Kernel.DrawHookCallbacks = {}
DaddyDev._Kernel.EnterRangeCallback = {}
DaddyDev._Kernel.EntitiesInRange = {} -- Entities in range with callbacks registered
local DEFAULT_ENT_MAX_DISTANCE = 90000

CreateConVar( "DaddyDev_ClientRenderDistance", "1", FCVAR_ARCHIVE, "Don't edit this, you will crash." )
local RENDER_DISTANCE_CLIENT_SETTING = math.Clamp( cvars.Number("DaddyDev_ClientRenderDistance", 1), 0.4, 2 )
cvars.AddChangeCallback( "DaddyDev_ClientRenderDistance", function( sCvar, sOldVal, sNewVal )
	RENDER_DISTANCE_CLIENT_SETTING = math.Clamp( tonumber( sNewVal ), 0.4, 2  )
end )

function DaddyDev._Kernel:AddCachedEntityDrawCallback( sHookName, sEntClassName, nMaxDistance, fCallback )
	if type( sEntClassName ) != type("") then
		error("ERROR: Attempted to add entity ui class subscription but passed invalid ent class. String expected got: " .. type(sEntClassName))
		return
	end

	-- Make max distance an optional param
	if fCallback == nil and type( nMaxDistance ) == "function" then
		fCallback = nMaxDistance
		nMaxDistance = DEFAULT_ENT_MAX_DISTANCE
	end
	DaddyDev._Kernel.DrawHookCallbacks[ sEntClassName ] = DaddyDev._Kernel.DrawHookCallbacks[ sEntClassName ] or {}
	DaddyDev._Kernel.DrawHookCallbacks[ sEntClassName ][ sHookName ] = DaddyDev._Kernel.DrawHookCallbacks[ sEntClassName ][ sHookName ] or {}
	table.insert( DaddyDev._Kernel.DrawHookCallbacks[ sEntClassName ][ sHookName ], { maxDistance = nMaxDistance, callback = fCallback } )
end

--[[
	Registers a callback to be called when an entity enters the range of the entity range cache
	sCallbackUID - A unique string id for this callback
	sEntClassName - The class of the entity to subscribe to
--]]
function DaddyDev._Kernel:AddEntityEnterRangeCallback( sCallbackUID, sEntClassName, fCallback )

	if type( sEntClassName ) != type("") then
		error("ERROR: Attempted to add entity enter range subscription but passed invalid ent class. String expected got: " .. type(sEntClassName))
		return
	end


	DaddyDev._Kernel.EnterRangeCallback[ sEntClassName ] = DaddyDev._Kernel.EnterRangeCallback[ EnterRangeCallback ] or {}
	DaddyDev._Kernel.EnterRangeCallback[ sEntClassName ][ sCallbackUID ] = fCallback
end

local ENTITY_DISCOVERY_DISTANCE = 1024 -- How large of a radius to look for entites around the player
local ENTITY_DISCOVERY_INTERVAL = 2 -- How often to search for entites in range of the player
local ENTITY_DISTANCE_REFRESH_INTERVAL = 0.4 -- How often to update the distance a player is from an entity

local AllEntitiesInRange = {} -- Cache of entities found near the player even ones that don't have draw callbacks, this is indexed by the entities for quick lookup

-- Checks whether the passed entity is within the players render range
function DaddyDev._Kernel:EntityIsInRangeOfClient( eEnt )
	return AllEntitiesInRange[ eEnt ]
end

local flLastRefresh = CurTime()
local flLastDistanceRefresh = CurTime()
-- Searches for entities nearby and updates the cache
local function updateEntityRangeCache( )
	if ( flLastRefresh or 0 ) + ENTITY_DISCOVERY_INTERVAL > CurTime() then return end
	DaddyDev._Kernel.EntitiesInRange = {} -- dump the old table
	local tCurrentEntitiesInRange = {}


	local eLocalPlayer = LocalPlayer()
	local vPlayerPosition = eLocalPlayer:GetPos()
	local tEntsInRange = ents.FindInSphere( vPlayerPosition, ENTITY_DISCOVERY_DISTANCE * RENDER_DISTANCE_CLIENT_SETTING )

	for index = 1, #tEntsInRange do
		local ent = tEntsInRange[ index ]
		if not IsValid(ent) then continue end

		local sEntClass = ent:GetClass()

		tCurrentEntitiesInRange[ ent ] = true
		-- Check if the entity was in range before. If not call the enter range callback if one exists
		local tCallbacks = DaddyDev._Kernel.EnterRangeCallback[ sEntClass ]
		if not AllEntitiesInRange[ ent ] and tCallbacks then
			-- Run any callbacks subscribed to this entity coming into range
			for sCallbackUID, fCallback in pairs( tCallbacks ) do
				if fCallback then fCallback( ent ) end
			end
		end

		local sEntClass = ent:GetClass()
		if not DaddyDev._Kernel.DrawHookCallbacks[ sEntClass ] then continue end

		nEntDistance = vPlayerPosition:DistToSqr( ent:GetPos() )
		table.insert( DaddyDev._Kernel.EntitiesInRange, { ent_class = sEntClass, ent_distance = nEntDistance, ent = ent } )
	end

	AllEntitiesInRange = tCurrentEntitiesInRange

	local flCurTime = CurTime()
	flLastRefresh = flCurTime
	flLastDistanceRefresh = flCurTime
end

-- Updates the distances of all entities in the cache
local function updateEntityDistances( )
	if ( flLastDistanceRefresh or 0 ) + ENTITY_DISTANCE_REFRESH_INTERVAL > CurTime() then return end

	local vPlayerPosition = LocalPlayer():GetPos()

	for index = 1, #DaddyDev._Kernel.EntitiesInRange do
		local tEntData = DaddyDev._Kernel.EntitiesInRange[ index ]
		if IsValid( tEntData.ent ) then
			tEntData.ent_distance = vPlayerPosition:DistToSqr( tEntData.ent:GetPos() )
		end
	end

	flLastDistanceRefresh = CurTime()
end


local function runHooks( sHookName, tEntData )
	local tHooks = DaddyDev._Kernel.DrawHookCallbacks[ tEntData.ent_class ][ sHookName ]
	if not tHooks then return end
	for j=1, #tHooks do
		local tEntry = tHooks[ j ]
		if tEntData.ent_distance <= tEntry.maxDistance * RENDER_DISTANCE_CLIENT_SETTING then
			tEntry.callback( tEntData.ent )
		end
	end
end

hook.Add( "PostDrawTranslucentRenderables", "DaddyDev._Kernel.CachedPostDrawTrans", function()
	updateEntityRangeCache()
	updateEntityDistances()

	-- Call the DrawEntityUI hook on all valid ents in the cache.
	for index = 1, #DaddyDev._Kernel.EntitiesInRange do
		local tEntData = DaddyDev._Kernel.EntitiesInRange[ index ]
		if tEntData and IsValid( tEntData.ent ) then
			runHooks( "PostDrawTranslucentRenderables", tEntData ) -- Runs any callbacks subscribed to this ent type on this hook, if any exist
		end
	end
end)

hook.Add( "PostPlayerDraw", "DaddyDev._Kernel.CachedPostPlayerDraw", function()
	-- Call the DrawEntityUI hook on all valid ents in the cache.
	for index = 1, #DaddyDev._Kernel.EntitiesInRange do
		local tEntData = DaddyDev._Kernel.EntitiesInRange[ index ]
		if tEntData and IsValid( tEntData.ent ) then
			runHooks( "PostPlayerDraw", tEntData ) -- Runs any callbacks subscribed to this ent type on this hook, if any exist
		end
	end
end)

hook.Add( "PostDrawOpaqueRenderables", "DaddyDev._Kernel.CachedPostDrawOpaqueRenderables", function()
	-- Call the DrawEntityUI hook on all valid ents in the cache.
	for index = 1, #DaddyDev._Kernel.EntitiesInRange do
		local tEntData = DaddyDev._Kernel.EntitiesInRange[ index ]
		if tEntData and IsValid( tEntData.ent ) then
			runHooks( "PostDrawOpaqueRenderables", tEntData ) -- Runs any callbacks subscribed to this ent type on this hook, if any exist
		end
	end
end)


---------------------

local eyepos = Vector()
local eyeangles = Angle()
local eyefov = 90
local eyevector = Vector()

hook.Add("RenderScene", "Eye", function(origin, angles, fov)
	eyepos = origin
	eyeangles = angles
	eyefov = fov
	eyevector = angles:Forward()
end)

local meta = FindMetaTable('Entity')
function meta:ShouldHide()
	local pos = self:GetPos()
	return self ~= LocalPlayer() && (eyevector:Dot(pos - eyepos) < 1.5 || pos:DistToSqr(eyepos) > 9000000)
end

function meta:NotInRange()
	local pos = self:GetPos()
	return pos:DistToSqr(eyepos) > 9000000
end

function EyePos() return eyepos end
function EyeAngles() return eyeangles end
function EyeFov() return eyefov end
function EyeVector() return eyevector end

hook.Remove("RenderScreenspaceEffects", "RenderColorModify")
hook.Remove("RenderScreenspaceEffects", "RenderBloom")
hook.Remove("RenderScreenspaceEffects", "RenderToyTown")
hook.Remove("RenderScreenspaceEffects", "RenderTexturize")
hook.Remove("RenderScreenspaceEffects", "RenderSunbeams")
hook.Remove("RenderScreenspaceEffects", "RenderSobel")
hook.Remove("RenderScreenspaceEffects", "RenderSharpen")
hook.Remove("RenderScreenspaceEffects", "RenderMaterialOverlay")
hook.Remove("RenderScreenspaceEffects", "RenderMotionBlur")
hook.Remove("RenderScene", "RenderStereoscopy")
hook.Remove("RenderScene", "RenderSuperDoF")
hook.Remove("GUIMousePressed", "SuperDOFMouseDown")
hook.Remove("GUIMouseReleased", "SuperDOFMouseUp")
hook.Remove("PreventScreenClicks", "SuperDOFPreventClicks")
hook.Remove("PostRender", "RenderFrameBlend")
hook.Remove("PreRender", "PreRenderFrameBlend")
hook.Remove("Think", "DOFThink")
hook.Remove("RenderScreenspaceEffects", "RenderBokeh")
hook.Remove("NeedsDepthPass", "NeedsDepthPass_Bokeh")
hook.Remove("PostDrawEffects", "RenderWidgets")

local GM = GAMEMODE
local CalcMainActivity = GM.CalcMainActivity
local UpdateAnimation = GM.UpdateAnimation
local PrePlayerDraw = GM.PrePlayerDraw
local DoAnimationEvent = GM.DoAnimationEvent
local PlayerFootstep = GM.PlayerFootstep
local PlayerStepSoundTime = GM.PlayerStepSoundTime
local TranslateActivity = GM.TranslateActivity

function GM:CalcMainActivity(pl, ...)
	if pl:ShouldHide() then return pl.CalcIdeal, pl.CalcSeqOverride end
	return CalcMainActivity(self, pl, ...)
end

function GM:UpdateAnimation(pl, ...)
	if pl:ShouldHide() then return end
	return UpdateAnimation(self, pl, ...)
end

function GM:PrePlayerDraw(pl, ...)
	if pl:ShouldHide() then return true end
	return PrePlayerDraw(self, pl, ...)
end

function GM:DoAnimationEvent(pl, ...)
	if pl:ShouldHide() then return pl.CalcIdeal end
	return DoAnimationEvent(self, pl, ...)
end

function GM:PlayerFootstep(pl, ...)
	if pl:NotInRange() then return true end
	PlayerFootstep(self, pl, ...)
end

function GM:PlayerStepSoundTime(pl, ...)
	if pl:NotInRange() then return 350 end
	return PlayerStepSoundTime(self, pl, ...)
end

function GM:TranslateActivity(pl, ...)
	if pl:ShouldHide() then return ACT_HL2MP_IDLE end
	return TranslateActivity(self, pl, ...)
end

function render.SupportsHDR() return false end
function render.SupportsPixelShaders_2_0() return false end
function render.SupportsPixelShaders_1_4() return false end
function render.SupportsVertexShaders_2_0() return false end
function render.GetDXLevel() return 80 end