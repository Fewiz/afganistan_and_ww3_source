
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_molotov_cocktail/lua/weapons/weapon_molotov_c/shared.lua ~

]]


SWEP.ViewModelFOV	= 75
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/v_molotov.mdl"
SWEP.WorldModel		= "models/weapons/w_grenade.mdl"

SWEP.ReloadSound	= ""

SWEP.Slot = 4
SWEP.SlotPos = 1

SWEP.DrawWorldModel = false
SWEP.DrawViewModel 	= true
SWEP.DrawShadow		= true

SWEP.HoldType		= "grenade"

SWEP.Spawnable		= true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize		= 1
SWEP.Primary.DefaultClip	= 1
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "grenade"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false	
SWEP.Secondary.Ammo			= "none"

function SWEP:Initialize()
	self.Weapon:SetWeaponHoldType(self.HoldType)
	util.PrecacheSound("WeaponFrag.Throw")
	util.PrecacheModel("models/props_junk/garbage_glassbottle003a.mdl")
	util.PrecacheModel(self.ViewModel)
	util.PrecacheSound("physics/glass/glass_largesheet_break1.wav")
	util.PrecacheSound("physics/glass/glass_largesheet_break2.wav")
	util.PrecacheSound("physics/glass/glass_largesheet_break3.wav")
end

function SWEP:Deploy()
	self.Owner:GetPreviousWeapon()
end

function SWEP:PrimaryAttack()
	if !self:CanPrimaryAttack() then return end
	self:SetNextPrimaryFire(CurTime() + 0.5)
	self:SetWeaponHoldType(self.HoldType)
	self.Owner:EmitSound("WeaponFrag.Throw", 100, 100)
	self:SendWeaponAnim(ACT_VM_THROW)
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	if (CLIENT) then return end

	local ent = ents.Create("ent_molotov_c")
	ent:SetPos(self.Owner:EyePos() + (self.Owner:GetAimVector() * 16))
	ent:SetAngles(self.Owner:GetAngles())
	ent:SetOwner(self.Owner) -- !
	ent:Spawn()
	
	local entobject = ent:GetPhysicsObject()
	entobject:ApplyForceCenter(self.Owner:GetAimVector():GetNormalized() * math.random(1500,2000))
	
	--self.Owner:GetPreviousWeapon()
	--self:Remove()	
	 
	--self:TakePrimaryAmmo(1)
 	self.Owner:StripWeapon("weapon_molotov_c")

end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
	self.Weapon:DefaultReload(ACT_VM_DRAW)
end

function SWEP:Think()

end
