
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_binoculars/lua/weapons/weapon_rpw_binoculars_nvg/cl_init.lua ~

]]

include( "shared.lua" )

language.Add("weapon_rpw_binoculars_nvg", "NV Binoculars")

surface.CreateFont( "rangefindernvg", {														
	font = "Arial",
	extended = false,
	size = 32,
	weight = 600,
	blursize = 1,
	scanlines = 2,
	antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )																					


surface.CreateFont( "rangefindernvg_26", {	-- WAC											
	font = "Arial",
	extended = false,
	size = 26,
	weight = 520,
	blursize = 1,
	scanlines = 2,
	antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )	

surface.CreateFont( "rangefindernvg_24", {	-- WAC											
	font = "Arial",
	extended = false,
	size = 24,
	weight = 450,
	blursize = 1,
	scanlines = 2,
	antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )	


surface.CreateFont( "rangefindernvg_16", {														
	font = "Arial",
	extended = false,
	size = 16,
	weight = 300,
	blursize = 1,
	scanlines = 2,
	antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )	

SWEP.PrintName 				= "Спец Бинокль" -- Биноколь ночного видения
SWEP.Slot 					= 2
SWEP.SlotPos 				= 1
SWEP.DrawAmmo 				= false
SWEP.DrawCrosshair 			= false
SWEP.ViewModelFlip 			= false

SWEP.WepSelectIcon 			= surface.GetTextureID("vgui/swepicons/weapon_rpw_binoculars_nvg")
SWEP.DrawWeaponInfoBox		= false
SWEP.BounceWeaponIcon 		= false 

SWEP.ViewModelFOV			= 65

local mat_bino_overlay = Material( "vgui/hud/rpw_binoculars_overlay" )
local mat_color = Material( "pp/colour" )
local mat_noise = Material( "vgui/hud/nvg_noise" )

local target = ents.FindByClass("player*")  



local CW20_MA85_MW3_IRFX_SETTING = 
	{
		[ "$pp_colour_addr" ] 		= 0,
		[ "$pp_colour_addg" ] 		= 0,
		[ "$pp_colour_addb" ] 		= 0,
		[ "$pp_colour_brightness" ] = 0.01,
		[ "$pp_colour_contrast" ]	= 1,
		[ "$pp_colour_colour" ] 	= 0,
		[ "$pp_colour_mulr" ] 		= 0,
		[ "$pp_colour_mulg" ] 		= 0,
		[ "$pp_colour_mulb" ] 		= 0
	}

	local function CW20_MA85_MW3_IRFX()
		local ply = LocalPlayer()
		local wep = ply:GetActiveWeapon()
		
		if not IsValid(wep) or not wep.CW20Weapon then
			return
		end
		
		UCT = UnPredictedCurTime()
		local simpleTelescopics = wep.SimpleTSAcquired or not wep:canUseComplexTelescopics()
		
		local hasZoom = (wep.SimpleTelescopicsFOV)
		local canUseIR = (wep.ThermalAcquired)
		
		if not (canUseIR and UCT > wep.AimTime and wep.dt.State == CW_AIMING) then
			return
		end
				
		render.SuppressEngineLighting(true)
		
		FT = FrameTime()
		
		for _, ent in pairs(ents.GetAll()) do
			if ent:IsNPC() or ent:IsPlayer() or ent:IsVehicle() or ent:IsWeapon() then
				if not ent:IsEffectActive(EF_NODRAW) then
					render.SuppressEngineLighting(true)
					render.MaterialOverride( Material("hf_icons/Other/white") )
					render.SetBlend( 1 )
					ent:DrawModel()
					render.SetBlend( 0 )
					render.MaterialOverride( nil )
					render.SuppressEngineLighting(false)
				end
			end
		end
		
		DrawColorModify(CW20_MA85_MW3_IRFX_SETTING)
		DrawBloom( 0.65, 2.5, 10, 10, 1, 1, 1, 1, 1 )
		
		render.SuppressEngineLighting(false)
	end

function SWEP:DrawHUD()
	if (self.Zoom_InZoom) then																-- This part is for drawing the overlay and night vision.
		local w = ScrW()
		local h = ScrH()
		local nvon = self:GetNWBool( "nvon", true )
		local alpha = math.abs( math.cos( CurTime() * 3 ) )	

		--for _, e in pairs(target) do
    	--	if not IsValid(e) then return end
    	--	e:SetColor(Color(255,255,255))
    	--end 	
		

		if (nvon) then
			//local dlight = DynamicLight(self:EntIndex())
			//dlight.r = 255
			//dlight.g = 255
			//dlight.b = 255
			//dlight.minlight = 0
			//dlight.style = 0
			//dlight.Brightness = 0.1
			//dlight.Pos = EyePos()
			//dlight.Size = 2048
			//dlight.Decay = 10000
			//dlight.DieTime = CurTime() + 0.1
		
			render.UpdateScreenEffectTexture()
			
			mat_color:SetTexture( "$fbtexture", render.GetScreenEffectTexture() )

			-- [ "$pp_colour_addr" ] 		= 0,
			-- [ "$pp_colour_addg" ] 		= 0,
			-- [ "$pp_colour_addb" ] 		= 0,
			-- [ "$pp_colour_brightness" ] = 0.01,
			-- [ "$pp_colour_contrast" ]	= 1,
			-- [ "$pp_colour_colour" ] 	= 0,
			-- [ "$pp_colour_mulr" ] 		= 0,
			-- [ "$pp_colour_mulg" ] 		= 0,
			-- [ "$pp_colour_mulb" ] 		= 0

			-- mat_color:SetFloat( "$pp_colour_addr", 1 ) --  -255 
			-- mat_color:SetFloat( "$pp_colour_addg", 1 )
			-- mat_color:SetFloat( "$pp_colour_addb", 1) -- -255 
			-- mat_color:SetFloat( "$pp_colour_mulr", 0 )
			-- mat_color:SetFloat( "$pp_colour_mulg", 0 )
			-- mat_color:SetFloat( "$pp_colour_mulb", 0 )
			-- mat_color:SetFloat( "$pp_colour_brightness", 1 ) -- 0.01 
			-- mat_color:SetFloat( "$pp_colour_contrast", 0 ) -- 5
			-- mat_color:SetFloat( "$pp_colour_colour", 1 )

			mat_color:SetFloat( "$pp_colour_addr", 0 ) --  -255 
			mat_color:SetFloat( "$pp_colour_addg", 0 )
			mat_color:SetFloat( "$pp_colour_addb", 0) -- -255 
			mat_color:SetFloat( "$pp_colour_mulr", 0 )
			mat_color:SetFloat( "$pp_colour_mulg", 0 )
			mat_color:SetFloat( "$pp_colour_mulb", 0 )
			mat_color:SetFloat( "$pp_colour_brightness", 0.01  ) -- 0.01 
			mat_color:SetFloat( "$pp_colour_contrast", 1 ) -- 5
			mat_color:SetFloat( "$pp_colour_colour", 0 )

			--render.SetMaterial( mat_color )
			--render.DrawScreenQuad()
			
			for _, e in pairs(target) do
	    		if not IsValid(e) then return end
	    		if team.GetName( e:Team() ) == "Администратор/Ивентолог" then return end 
	    		--print(target)
	    		--print(e:GetName())
	    		--e:SetColor(Color(255,255,255))

	    		obpos = e:GetPos()
	    		scr = obpos:ToScreen()	
				X = scr.x +math.Rand(-1,1) 
				Y = scr.y +math.Rand(-1,1) 
				surface.SetDrawColor(Color(200,200,200,200*alpha))
		 		surface.DrawOutlinedRect(X-20, Y-20, 40, 40)

		 		--surface.SetFont( "rangefindernvg" )
				--surface.SetTextColor(team.GetColor( e:Team() ))
				--surface.SetTextPos( X, Y-50 ) 
		 		--surface.DrawText(team.GetName( e:Team() ))
    		end 
    		print("222")
	    	for _, ent in pairs(ents.GetAll()) do
				if ent:IsNPC() or ent:IsPlayer() or ent:IsVehicle() or ent:IsWeapon() then
					--if not ent:IsEffectActive(EF_NODRAW) then
					print("123123")
						render.SuppressEngineLighting(true)
						render.MaterialOverride( Material("hf_icons/Other/white") )
						render.SetBlend( 1 )
						ent:DrawModel()
						render.SetBlend( 0 )
						render.MaterialOverride( nil )
						render.SuppressEngineLighting(false)
					--end
				end
			end

			surface.SetMaterial( mat_noise )
			surface.SetDrawColor( 0, 255, 0, 125 ) -- 100
			surface.DrawTexturedRect( 0+math.Rand(-128,128), 0+math.Rand(-128,128), w, h )
			
			surface.SetMaterial( mat_noise )
			surface.SetDrawColor( 0, 255, 0, 125 ) -- 100
			surface.DrawTexturedRect( 0+math.Rand(-64,64), 0+math.Rand(-64,64), w, h )
		end
		
		surface.SetMaterial( mat_bino_overlay )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect( 0 ,-(w-h)/2 ,w ,w )
		
		if (nvon) then
			DrawBloom(0.5,1,10,10,2,1,1,1,1)
		end
 
		local tr = self.Owner:GetEyeTrace()
		local range = (math.ceil(10*(tr.StartPos:Distance(tr.HitPos)*0.024))/10)
		
		if tr.HitSky then
			range = "-"
		else
			range = range.."М"
		end
		
		surface.SetTextColor( 255, 255, 255, 255 )
		
		if (nvon) then
			surface.SetTextColor( 255, 255, 0, 255 )
		end
		
		surface.SetFont( "rangefindernvg" )
		surface.SetTextPos( (w*0.165), (h/2) + 16 )
		surface.DrawText( "Дальность: "..range )
		
		local zoom = math.ceil((90/self.Owner:GetFOV())*10)/10
		
		surface.SetTextPos( (w*0.165), (h/2) + 42 )
		surface.DrawText( "Зум: "..zoom.."x" )
		
		local text = "NV OFF"
		if (nvon) then
			--text = "Ночной режим: ВКЛ"
		end
		
		surface.SetTextPos( (w*7/10), (h*2)/3 )
		surface.DrawText( text )
	end
end

function SWEP:AdjustMouseSensitivity()
	if (self.Zoom_InZoom) then
		local zoom = 90/self.Owner:GetFOV()
		local adjustedsens = 1 / zoom
		return adjustedsens
	end
end
