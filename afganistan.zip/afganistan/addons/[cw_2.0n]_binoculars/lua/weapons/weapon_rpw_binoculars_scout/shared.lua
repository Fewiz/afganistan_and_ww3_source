
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_binoculars/lua/weapons/weapon_rpw_binoculars_scout/shared.lua ~

]]

SWEP.ANIMPOSTDELAY			= 0.1

if (SERVER) then
	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5
	SWEP.AutoSwitchTo		= true
	SWEP.AutoSwitchFrom		= true
end

SWEP.Category 				= "Бинокли" 

SWEP.Base					= "weapon_rpw_binoculars"

SWEP.Spawnable     			= true
SWEP.AdminSpawnable  		= true

SWEP.UseHands				= true
SWEP.ViewModel				= "models/weapons/c_binoculars_usa.mdl"
SWEP.WorldModel				= "models/weapons/w_binoculars_usa.mdl"

SWEP.HoldType				= "slam"
SWEP.HoldTypeRaised			= "camera"

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Ammo 			= "none"
SWEP.Primary.Automatic		= false

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Ammo 		= false
SWEP.Secondary.Automatic 	= true

SWEP.Zoom_Interval			= 1
SWEP.Zoom_Current			= 0
SWEP.Zoom_Min				= 1
SWEP.Zoom_Max				= 4
SWEP.Zoom_Delta				= 0.7
SWEP.Zoom_Zooming			= false
SWEP.Zoom_InZoom			= false

SWEP.Zoom_TransitionTime	= nil

SWEP.Zoom_Sound_In				= "weapons/sniper/sniper_zoomin.wav"
SWEP.Zoom_Sound_Out				= "weapons/sniper/sniper_zoomout.wav"
SWEP.Zoom_Sound_Cloth			= "foley/alyx_hug_eli.wav"

SWEP.HasNightVision			= false

SWEP.WalkSpeed				= 250
SWEP.RunSpeed				= 500

SWEP.WalkSpeedMod			= 250

SWEP.SpeedMult				= 0.6

SWEP.UUID					= nil