
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_binoculars/lua/autorun/rpw_binoculars_pack_autorun.lua ~

]]

if (GetConVar( "rpw_binoculars_hold" ) == nil) then	CreateConVar( "rpw_binoculars_hold", 1, FCVAR_ARCHIVE, "0 or 1, whether or not binoculars are toggle-to-use rather than hold-to-use." )endfunction rpw_PopulateOptionsMenu_Binoculars( CPanel )		--CPanel:AddControl( "Checkbox", { Label = "Hold to Aim", Command = "rpw_binoculars_hold" } )endhook.Add( "PopulateToolMenu", "rpw_PopulateOptionsMenu_Binoculars", function()	--spawnmenu.AddToolMenuOption( "Options", "RPW", "RPW_Binoculars", "Binoculars", "", "", rpw_PopulateOptionsMenu_Binoculars )end )