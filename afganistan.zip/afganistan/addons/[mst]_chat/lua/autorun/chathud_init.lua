
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_chat/lua/autorun/chathud_init.lua ~

]]

if CLIENT then	local cl_legacy_chathud = CreateClientConVar("cl_legacy_chathud", "0", true, false)	local function match(func)		return debug.getinfo(func).source:find("chathud/")	end	local function nukeHooks()		for hookName, hookTable in pairs(hook.GetTable()) do			for key, func in pairs(hookTable) do				if match(func) then					hookTable[key] = nil				end			end		end	end	local function load(nonuke)		if nonuke~=true then			nukeHooks()		end				--local int = cl_legacy_chathud:GetInt()				--		--if int==1 then		--	include("chathud/_legacy.lua")		--elseif int==2 then		--	include("chathud/_legacy2.lua")		--else			hook.Add("HUDPaint", "chathud_init", function()				include("chathud/utf8.lua")				include("chathud/pretty_text.lua")				include("chathud/expression.lua")				include("chathud/markup.lua")				include("chathud/chathud.lua")				include("chathud/tradingcard_emotes.lua")				hook.Remove("HUDPaint", "chathud_init")			end)		--end	end	cvars.AddChangeCallback("cl_legacy_chathud", load)	load(true)endif SERVER then	AddCSLuaFile("chathud/utf8.lua")	AddCSLuaFile("chathud/pretty_text.lua")	AddCSLuaFile("chathud/expression.lua")	AddCSLuaFile("chathud/markup.lua")	AddCSLuaFile("chathud/chathud.lua")	AddCSLuaFile("chathud/tradingcard_emotes.lua")	include("chathud/utf8.lua")	--AddCSLuaFile("chathud/_legacy2.lua")	resource.AddFile("resource/fonts/DejaVuSans.ttf")end