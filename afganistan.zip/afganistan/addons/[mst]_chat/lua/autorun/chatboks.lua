
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_chat/lua/autorun/chatboks.lua ~

]]

local Chat = {}
local net=table.Copy(net)
local Tag = 'chatik'
util.IsURL = function( word )
    return string.Left( word, 7 ) == "http://" or string.Left( word, 8 ) == "https://"
end
net.Receive( Tag, function()
	local Table = net.ReadTable()
	hook.Run('OnPlayerChat',Table.pl,Table.text,false,!Table.pl:Alive())
end)
if SERVER then
	util.AddNetworkString(Tag)
	local tbl={}
	local player_GetAll=player.GetAll
	
	net.Receive(Tag,function(_,ply)
		ply.zaebal_chat=(ply.zaebal_chat or 0)+1
		if ply.zaebal_chat > 50 then return end
		local str=net.ReadString() or ""
		if str=="" then return end
		hook.Run('PlayerSay',ply,str,false)
		tbl.pl=ply
		tbl.text =  str
		--net.Start(Tag)
		--net.WriteTable(tbl)
		--net.Broadcast()
	end)
	
	timer.Create("otebal_chat",5,0,function()
		for k,v in pairs(player_GetAll()) do
			v.zaebal_chat=0
		end
	end)
	return
end

Chat.Create = function()
	local SH = ScrH()
	local bounds
	local x, y, w, h = 20,SH-400,512,300 
	
	if file.Exists( "Solly_chat_pos.txt", "DATA" ) then
		bounds = file.Read('Solly_chat_pos.txt')
		local da = string.Explode( " ", bounds )
		x, y, w, h = da[1],da[2],da[3],da[4]
	end

	Chat.Main = vgui.Create('DFrame')
	Chat.Main.m_iMinWidth = 300
	Chat.Main.m_iMinHeight = 200
	Chat.Main:SetPos( x, y )
	Chat.Main:SetSize( w, h )
	Chat.Main:SetTitle( "" )
	Chat.Main:SetSizable(true)
	Chat.Main:SetDraggable(true)
	Chat.Main.Paint = function( self, w, h )
		surface.SetDrawColor(25,25,31) -- background  -- Внешка   45, 44, 44, 155
		surface.DrawRect( 0, 0, w, h )
		
		surface.SetDrawColor(0,0,0)
		
		surface.DrawOutlinedRect(0,0,w,h)
	end
	Chat.Main:MakePopup()
	Chat.Main:Hide()
	
	Chat.Main.btnMaxim:Hide()
	Chat.Main.btnMinim:Hide()
	Chat.Main.btnClose:Hide()
	 
	Chat.Main.Think = function( self )
		
		local mousex = math.Clamp( gui.MouseX(), 1, ScrW() - 1 )
		local mousey = math.Clamp( gui.MouseY(), 1, ScrH() - 1 )

		if ( self.Dragging ) then
			local x = mousex - self.Dragging[1]
			local y = mousey - self.Dragging[2]

			-- Lock to screen bounds if screenlock is enabled
			if ( self:GetScreenLock() ) then

				x = math.Clamp( x, 0, ScrW() - self:GetWide() )
				y = math.Clamp( y, 0, ScrH() - self:GetTall() )

			end

			self:SetPos( x, y )
		end

		if ( self.Sizing ) then
			local x = mousex - self.Sizing[1]
			local y = mousey - self.Sizing[2]
			local px, py = self:GetPos()

			if ( x < self.m_iMinWidth ) then x = self.m_iMinWidth elseif ( x > ScrW() - px && self:GetScreenLock() ) then x = ScrW() - px end
			if ( y < self.m_iMinHeight ) then y = self.m_iMinHeight elseif ( y > ScrH() - py && self:GetScreenLock() ) then y = ScrH() - py end

			self:SetSize( x, y )
			self.BClose:SetPos( x - self.BClose:GetWide() , 0)
			Chat.Write:SetPos( 10, y - 30 )
			Chat.Write:SetSize( x - 20, 20 )
			
			Chat.Text:SetSize( x - 20, y - 55 )
			self:SetCursor( "sizenwse" )
			return
		end

		if ( self.Hovered && self.m_bSizable && mousex > ( self.x + self:GetWide() - 20 ) && mousey > ( self.y + self:GetTall() - 20 ) ) then
			self:SetCursor( "sizenwse" )
			return
		end

		if ( self.Hovered && self:GetDraggable() && mousey < ( self.y + 24 ) ) then
			self:SetCursor( "sizeall" )
			return
		end

		self:SetCursor( "arrow" )

		if ( self.y < 0 ) then
			self:SetPos( self.x, 0 )
		end
	end
	
	local RedColor = Color(255,0,0)
	Chat.Main.BClose = vgui.Create('DButton', Chat.Main ) -- ето кнопкочка
	Chat.Main.BClose:SetSize(25, 14)
	Chat.Main.BClose:SetPos( w - Chat.Main.BClose:GetWide(), 0)
	Chat.Main.BClose.Paint = function(self, w, h) -- DermaDefault
		draw.SimpleTextOutlined('X', 'DermaDefault', w/2, h/2, RedColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		return true
	end
	
	Chat.Main.BClose.DoClick = function()
		RememberCursorPosition()
		Chat.Close()
	end
	Chat.Main.OnMouseReleased = function(self)
		local x, y, w, h = self:GetBounds()
		file.Write("Solly_chat_pos.txt", x.." "..y.." "..w.." "..h.." ")

		self.Dragging = nil
		self.Sizing = nil
		self:MouseCapture( false )
	end

	 
	--=Pisalka=--
	Chat.Write = vgui.Create( 'DTextEntry', Chat.Main )
	Chat.Write:SetPos( 10, h-30 )
	Chat.Write:SetSize( w-20, 20 )
	Chat.Write:SetFont( 'DermaDefault' )  -- simfphysfont3
	Chat.Write:SetTextColor(color_white) -- текст цвета
	Chat.Write:SetHighlightColor( Color(0, 0, 255) ) -- цвет подсветки когда обводишь текст
	Chat.Write:SetDrawBorder(false)
	Chat.Write:SetHistoryEnabled(true)
	Chat.Write:SetDrawBackground( false )
	Chat.Write:SetCursorColor( Color(0, 0, 255) ) -- пиликалка цвет которая показывае где ты блят сечас пишешь
	Chat.Write:RequestFocus()
	Chat.Write:SetText( "" )
	
	Chat.Write.OnTextChanged = function(self)
		hook.Call("ChatTextChanged", GAMEMODE, self:GetValue())
		if self:GetValue() == self.History[self.HistoryPos] then return end
		self.HistoryPos = 0
	end 
	
	Chat.Write.Paint = function( self, w, h )
		surface.SetDrawColor(36,37,43) -- ето вот тут полоска где писать   40, 40, 40,150)
		surface.DrawRect( 0, 0, w, h )
		
		surface.SetDrawColor(0,0,0)
		
		surface.DrawOutlinedRect(0,0,w,h)
		derma.SkinHook( "Paint", "TextEntry", self, w, h )
	end
	
	Chat.Write.OnKeyCodeTyped = function( self, code )

		if code == KEY_ESCAPE then
			Chat.Close()
			gui.HideGameUI()
		elseif code == KEY_BACKQUOTE  then
			gui.HideGameUI()
		elseif code == KEY_TAB then

			timer.Simple( 0.01, function() Chat.Write:RequestFocus() end)

			local str = string.TrimRight(self:GetValue())
			local LastWord
			
			for word in string.gmatch( str, "[^ ]+" ) do
				LastWord = word
			end
			
			if ( LastWord == nil ) then return str end
			
			for k, v in pairs( player.GetAll() ) do
				local nickname = v:Nick()
				if ( string.len( LastWord ) < string.len( nickname ) && string.find( string.lower( nickname ), string.lower( LastWord ), 0, true ) == 1 ) then
					str = string.sub( str, 1, ( string.len( LastWord ) * -1 ) - 1 )
					str = str .. nickname
					self:SetText( str ) 
					hook.Call("ChatTextChanged", GAMEMODE, self:GetValue())
					return
				end
			end
			
			self:SetText( str )
			
		elseif code == KEY_ENTER then
		
			local cmd = self:GetValue()
			if cmd:len() == 0 then Chat.Close() return end
			if not self.History or self.History[#self.History] ~= cmd then self:AddHistory(self:GetValue()) end
			
			net.Start(Tag)
			net.WriteString(cmd)
			net.SendToServer()
			Chat.Close()
			
		elseif ( code == KEY_UP ) then
		
			self.HistoryPos = self.HistoryPos - 1
			self:UpdateFromHistory()
			self:SetCaretPos( utf8.len(self:GetValue()) )
			
		elseif ( code == KEY_DOWN ) then
		
			self.HistoryPos = self.HistoryPos +	1
			self:UpdateFromHistory()
			self:SetCaretPos( utf8.len(self:GetValue()) )
			
		end
	end
	
	--=Textik=--
	Chat.Text = vgui.Create( "RichText", Chat.Main )
	Chat.Text:SetSize( w - 20, h - 55 )
	Chat.Text:SetPos( 10, 20 )
	Chat.Text.Paint = function( self, w, h )
	
		surface.SetDrawColor(36,37,43) -- фон текста  40, 40, 40,150 
		surface.DrawRect( 0, 0, w, h )
		
		surface.SetDrawColor(0,0,0)
		
		surface.DrawOutlinedRect(0,0,w,h)
	end
	
	Chat.Text.PerformLayout = function( self )
		self:SetFontInternal("DermaDefault")
		self:SetFGColor( color_black )
	end
end


Chat.Open = function()
	local SH = ScrH()
	Chat.Main:Show()
	
	Chat.Main:MakePopup()
	Chat.Write:RequestFocus()
	
	gamemode.Call( "StartChat" )
end

Chat.Close = function()
	Chat.Write.HistoryPos = 0
	Chat.Main:Hide()
	gamemode.Call( "FinishChat" )

	Chat.Write:SetText( "" )
	gamemode.Call( "ChatTextChanged", "" )
end

	_G.chat.Close = Chat.Close
	_G.chat.Open = Chat.Open
	
	oldAddText = oldAddText or _G.chat.AddText
function chat.AddText( ... )
	local clr
	if !IsValid(Chat.Main) then
		Chat.Create()
	end
	Chat.Text:AppendText( "\n" )
	local args = { ... } -- Create a table of varargs
	for _, obj in pairs( args ) do
		if type( obj ) == "table" then 
			clr = true
			Chat.Text:InsertColorChange( obj.r, obj.g, obj.b, 255 )
		elseif type( obj ) == "string" then 
			--ZpChat.Text:AppendText( obj )
			
			local msgtable = string.Explode( " ", obj )
			local concat = {}

			local wasUrl = false
			for k,word in pairs(msgtable) do
				if util.IsURL( word ) && k != 1 then
					Chat.Text:InsertColorChange( 255, 255, 255, 255 )
					Chat.Text:AppendText( (wasUrl and " " or "") .. table.concat( concat, " " ) .. " " )
					Chat.Text:InsertClickableTextStart( word )
					Chat.Text:AppendText( word )
					Chat.Text:InsertClickableTextEnd()
					
					wasUrl = true
					table.Empty( concat )
				else
					concat[#concat + 1] = word
				end
			end
			if #concat ~= 0 then
				Chat.Text:AppendText( (wasUrl and " " or "") .. table.concat( concat, " " ) )
			end
			
		elseif obj:IsPlayer() then
			local col = GAMEMODE:GetTeamColor( obj ) 
			Chat.Text:InsertColorChange( col.r, col.g, col.b, 255 ) 
			Chat.Text:AppendText( obj:Nick() )
		end
	end

	-- Call the original function
	if chathud then chathud.AddText ( ... ) end
	oldAddText(...)
	
end

local function chat_open( ply, bind, pressed )
    if bind == "messagemode" or bind == 'messagemode2' then else return end
    
    if !IsValid( Chat.Main ) then
        Chat.Create()
    end
    
    Chat.Open()

    return true 
end 

hook.Add( "PlayerBindPress", "chatopen", chat_open)
hook.Add("ChatText","ChatTextKostil",function( playerindex, playername, text, filter )
if ( filter == "joinleave" ) then return true end
if ( filter == "namechange" ) then return true end
if filter == "none" then
chat.AddText( Color( 151, 211, 255 ), text ) return true
end

end)
