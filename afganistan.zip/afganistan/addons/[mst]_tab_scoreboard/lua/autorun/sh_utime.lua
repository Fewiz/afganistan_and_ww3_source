
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_tab_scoreboard/lua/autorun/sh_utime.lua ~

]]

-- Written by Team Ulysses, http://ulyssesmod.net/
AddCSLuaFile( "autorun/sh_utime.lua" )
AddCSLuaFile( "autorun/cl_utime.lua" )

module( "Utime", package.seeall )

local meta = FindMetaTable( "Player" )
if not meta then return end

function meta:GetUTime()
	return self:GetNWInt( "TotalUTime" )
end

function meta:SetUTime( num )
	self:SetNWInt( "TotalUTime", num )
end

function meta:GetUTimeStart()
	return self:GetNWInt( "UTimeStart" )
end

function meta:SetUTimeStart( num )
	self:SetNWInt( "UTimeStart", num )
end

function meta:GetUTimeSessionTime()
	return CurTime() - self:GetUTimeStart()
end

function meta:GetUTimeTotalTime()
	return self:GetUTime() + CurTime() - self:GetUTimeStart()
end

function timeToStr( time )
	local tmp = time
	local s = tmp % 60
	tmp = math.floor( tmp / 60 )
	local m = tmp % 60
	tmp = math.floor( tmp / 60 )
	local h = tmp % 24
	tmp = math.floor( tmp / 24 )
	local d = tmp % 7
	local w = math.floor( tmp / 7 )

	return string.format( "%02iw %id %02ih %02im %02is", w, d, h, m, s )
end
