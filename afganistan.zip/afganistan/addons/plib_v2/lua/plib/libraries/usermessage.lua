
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/plib_v2/lua/plib/libraries/usermessage.lua ~

]]

if (SERVER) then
	local message 	= {}
	local pooled 	= {}

	util.AddNetworkString 'umsg.SendLua'
	util.AddNetworkString 'umsg.UnPooled'

	function SendUserMessage(name, pl, ...)
		umsg.Start(name, pl)
		for k, v in pairs({...}) do
			local t = type(v)
			if (t == 'string') then
				umsg.String(v)
			elseif IsEntity(v) then
				umsg.Entity(v)
			elseif (t == 'number') then
				umsg.Long(v)
			elseif (t == 'Vector') then
				umsg.Vector(v)
			elseif (t == 'Angle') then
				umsg.Angle(v)
			elseif (t == 'boolean') then
				umsg.Bool(v)
			else
				ErrorNoHalt('SendUserMessage: Couldn\'t send type ' .. t .. '\n')
			end
		end
		umsg.End()
	end

	function BroadcastLua(lua)
		net.Start 'umsg.SendLua'
			net.WriteString(lua)
		net.Broadcast()
	end

	debug.getregistry().Player.SendLua = function(self, lua)
		net.Start 'umsg.SendLua'
			net.WriteString(lua)
		net.Send(self)
	end	

	function umsg.PoolString(name)
		if (not pooled[name]) then
			util.AddNetworkString('umsg.' .. name)
			pooled[name] = true
		end
	end

	function umsg.Start(name, recipients)
		local t = type(recipients)

		if (t == 'CRecipientFilter') then
			message = recipients:GetPlayers()
		elseif (t == 'Player') or (t == 'table') then
			message = recipients
		else
			message = player.GetAll()
		end

		if pooled[name] then
			net.Start('umsg.' .. name)
		else
			umsg.PoolString(name)
			net.Start 'umsg.UnPooled'
			net.WriteString(name)
		end
	end

	function umsg.End()
		net.Send(message)
	end

	function umsg.Angle(value)
		net.WriteAngle(value)
	end

	function umsg.Bool(value)
		net.WriteBool(value)
	end

	function umsg.Char(value)
		net.WriteInt((isstring(value) and string.char(value) or value), 8)
	end

	function umsg.Entity(value)
		net.WriteEntity(value)
	end

	function umsg.Float(value)
		net.WriteFloat(value)
	end

	function umsg.Long(value)
		net.WriteInt(value, 32)
	end

	function umsg.Short(value)
		net.WriteInt(value, 16)
	end

	function umsg.String(value)
		net.WriteString(value)
	end

	function umsg.Vector(value)
		net.WriteVector(value)
	end

	function umsg.VectorNormal(value)
		net.WriteVector(value)
	end
else
	usermessage = {}
	local hooks = {}

	net.Receive('umsg.SendLua', function()
		RunString(net.ReadString())
	end)

	net.Receive('umsg.UnPooled', function(len, ...)
		usermessage.IncomingMessage(net.ReadString())
	end)

	function usermessage.Hook(name, callback, ...)
		if (SERVER) then
			umsg.PoolString(name)
			return
		end

		hooks[name] = {}
		hooks[name].Function = function(...)
			callback(usermessage, ...)
		end
		hooks[name].PreArgs	= {...}

		net.Receive('umsg.' .. name, function(len, ...)
			usermessage.IncomingMessage(name)
		end)
	end

	function usermessage.GetTable()
		return hooks
	end

	function usermessage.IncomingMessage(name)
		if hooks[name] then
			hooks[name].Function()
		else
			Msg('Warning: Unhandled usermessage \'' .. name .. '\'\n')
		end
	end

	function usermessage:ReadAngle()
		return net.ReadAngle()
	end

	function usermessage:ReadBool()
		return net.ReadBool()
	end

	function usermessage:ReadChar()
		return net.ReadInt(8)
	end

	function usermessage:ReadEntity()
		return net.ReadEntity()
	end

	function usermessage:ReadFloat()
		return net.ReadFloat()
	end

	function usermessage:ReadLong()
		return net.ReadInt(32)
	end

	function usermessage:ReadShort()
		return net.ReadInt(16)
	end

	function usermessage:ReadString()
		return net.ReadString()
	end

	function usermessage:ReadVector()
		return net.ReadVector()
	end

	function usermessage:ReadVectorNormal()
		return net.ReadVector():Normalize()
	end

	function usermessage:Reset()
		ErrorNoHalt('usermessage:Reset() is not supported!')
	end
end
