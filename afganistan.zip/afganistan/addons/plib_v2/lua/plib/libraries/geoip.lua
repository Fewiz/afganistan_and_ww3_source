
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/plib_v2/lua/plib/libraries/geoip.lua ~

]]

geoip 				= {}

local geoip 		= geoip
local http_fetch 	= http.Fetch
local json_to_table = util.JSONToTable

local failures		 = 0
local result_cache	 = {}


function geoip.Get(ip, cback)
	if result_cache[ip] then
		cback(result_cache[ip])
	else
		http_fetch('http://freegeoip.net/json/' .. ip, function(b)
			if (b == '404 page not found') then
				error('GeoIP: Failed to lookup ip: ' .. ip)
			else
				local res = json_to_table(b)
				failures = 0
				result_cache[ip] = res
				cback(res)
			end
		end, function()
			if (failures <= 5) then 
				failures = failures + 1
				geoip.Get(ip, cback)
			end
		end)
	end
end