
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/plib_v2/lua/plib/extensions/speedy.lua ~

]]

-- Many things in garrysmod could be implemented faster but not everything needs a complete recode like the hook library so we'll chuck it here.

-- Net
do 
	local IsValid 	= IsValid
	local Entity 	= Entity
	local Color 	= Color
	local WriteUInt = net.WriteUInt
	local ReadUInt 	= net.ReadUInt

	function net.WriteEntity(ent)
		if IsValid(ent) then 
			WriteUInt(ent:EntIndex(), 12)
		else
			WriteUInt(0, 12)
		end
	end

	function net.ReadEntity()
		local i = ReadUInt(12)
		if (not i) then return end
		return Entity(i)
	end

	function net.WriteColor(c)
		WriteUInt(c.r, 8)
		WriteUInt(c.g, 8)
		WriteUInt(c.b, 8)
		WriteUInt(c.a, 8)
	end

	function net.ReadColor()
		return Color(ReadUInt(8), ReadUInt(8), ReadUInt(8), ReadUInt(8))
	end
end


if (SERVER) then return end

-- Surface
do
	local SetFont 		= surface.SetFont
	local GetTextSize 	= surface.GetTextSize

	local Font 			= 'TargetID'
	local SizeCache 	= {}

	function surface.SetFont(font)
		Font = font
		return SetFont(font)
	end
	 
	function surface.GetTextSize(text)
		if (not SizeCache[Font]) then
			SizeCache[Font] = {}
		end
		   
		if (not SizeCache[Font][text]) then
			local x, y = GetTextSize(text)
			SizeCache[Font][text] = {
				x = x, 
				y = y
			}
			return x, y
		end
		   
		return SizeCache[Font][text].x, SizeCache[Font][text].y
	end
	 
	timer.Create('PurgeFontCache', 1200, 0, function()
		SizeCache = {}
	end)
end
