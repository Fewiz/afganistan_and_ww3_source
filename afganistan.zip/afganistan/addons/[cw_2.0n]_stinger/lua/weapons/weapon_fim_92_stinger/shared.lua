
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_stinger/lua/weapons/weapon_fim_92_stinger/shared.lua ~

]]

AddCSLuaFile("shared.lua")
--AddCSLuaFile("cl_init.lua")
AddCSLuaFile()

local soundData = {
	name				= "stinger.open",
	channel		= CHAN_WEAPON,
	volume				= 1,
	soundlevel	= 100,
	pitchstart	= 100,
	pitchend	= 100,
	sound		= "stinger/open.wav"
}
sound.Add(soundData)

SWEP.Category  		= "Взрывное оружие" 
SWEP.Base				= "bobs_gun_base"

if CLIENT then
	SWEP.Author = ""
	SWEP.WepSelectIcon		= surface.GetTextureID("HUD/swepicons/weapon_mw2_stinger") 
end
SWEP.PrintName = "FIM-92 «Стингер»"  --FIM-92 Стингер
 
 
SWEP.Slot			= 4						
SWEP.SlotPos		= 5					
SWEP.ViewModelFOV	= 70
SWEP.ViewModelFlip	= false
SWEP.ViewModel		=    "models/jessev92/weapons/hl2/hevmk4/stinger_v.mdl"
SWEP.WorldModel		= "models/jessev92/weapons/hl2/stinger_w.mdl"
SWEP.IronSightsPos = Vector(0.418, -2.902, 1.751)
SWEP.IronSightsAng = Vector(0.962, -26.222, 35.763)
SWEP.ShowViewModel = true
SWEP.ShowWorldModel = true
SWEP.UseHands = true
SWEP.RunSightsPos = Vector (2.4946, 1.5644, -0.699)
SWEP.RunSightsAng = Vector (-20.1104, 35.1164, -12.959)
SWEP.SightsPos	= Vector(0.418, -2.902, 1.751)
SWEP.SightsAng	= Vector(0.962, -26.222, 35.763)
SWEP.Secondary.IronFOV		= 40

SWEP.Damage			= 1850		-- Для продавца 

SWEP.Gun	= ("weapon_fim_92_stinger")

SWEP.HoldType 		= "rpg"

SWEP.Primary.Automatic		= false
SWEP.Primary.ClipSize	= 1
SWEP.Primary.DefaultClip	= 2

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= false

SWEP.IntRunDelay = true
SWEP.IronInAnim = true
SWEP.IronOutAnim = false

SWEP.LockedEnt = nil
SWEP.BeepDelay = CurTime()
SWEP.CheckPosDelay = CurTime()
SWEP.HitPos = nil
SWEP.LOCKD = 0
SWEP.ViewModelBoneMods = {
	["Stinger"] = { scale = Vector(1, 1, 1), pos = Vector(-5.354, -0.299, -0.131), angle = Angle(0, 0, 0) },
	["ValveBiped.Bip01_L_UpperArm"] = { scale = Vector(1, 1, 1), pos = Vector(0.128, -0.837, -4.155), angle = Angle(0, 0, 0) },
	["ValveBiped.Bip01_R_UpperArm"] = { scale = Vector(1, 1, 1), pos = Vector(0.494, -0.525, 5.791), angle = Angle(0, 0, 0) },
}



function SWEP:ResetVar()
	self.Weapon:SetJavHud(false)
	self.Weapon:SetRun(false)

	self.Weapon:SetNextAct(CurTime())
	self.Weapon:SetRunLoopDelay(CurTime())
	self.Weapon:SetLockStat(0)
	self.Weapon:SetLockedDelay(0)
	self.Weapon:SetNoLockMsg(CurTime())
	self.LOCKD = 0
end



function SWEP:SetupDataTables() 
	self.Weapon:NetworkVar( "Bool", 0, "JavHud" )
	self.Weapon:NetworkVar( "Bool", 1, "Run" )

	self.Weapon:NetworkVar("Int", 0, "WeaponBehave")
	self.Weapon:NetworkVar("Int", 1, "NextAct")
	self.Weapon:NetworkVar("Int", 2, "RunLoopDelay")
	self.Weapon:NetworkVar("Int", 3, "LockStat")
	self.Weapon:NetworkVar("Int", 4, "LockedDelay")
	self.Weapon:NetworkVar("Int", 5, "NoLockMsg")
end

function SWEP:Initialize()
	self:SetWeaponHoldType( self.HoldType )
	self:SetupDataTables()
	self:ResetVar()
end

function SWEP:Deploy()
		Vm = self.Owner:GetViewModel()
		self.Weapon:SendWeaponAnim(ACT_VM_DEPLOY);
		self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
		self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
		self:NextThink( CurTime() + self:SequenceDuration() )
		self:SetIronsights(false)
		self:Idle()
		Vm:SetPlaybackRate(1)
	return true
end

function SWEP:Holster()
	self.LockCount = 0
	self.LockedEnt = nil
	SWEP.HitPos = nil

	self.Owner:SetFOV(0,.3)
	self.Owner:SetNWBool("JavSights", false)
	if SERVER then
		self.Owner:DrawViewModel(true)
	end
	return true
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end

function SWEP:Precache()
end



function SWEP:PrimaryAttack()
	if self.Weapon:GetLockStat() == 2 and IsValid(self.LockedEnt) and self.Weapon:Clip1() >= 1 then
		-- Особого смысла тут нет этой проверки
		--if self.LockedEnt:GetPos().z < 450 then return end 
 		if self.LockedEnt:GetClass():lower() == "prop_physics" then return end
		if self.LockedEnt:GetClass():lower() == "gmod_sent_vehicle_fphysics_wheel" then return end
		if not self.LockedEnt:GetClass() == "wac_hc_mi24" or not self.LockedEnt:GetClass() == "wac_hc_mi8" or not self.LockedEnt:GetClass() == "wac_hc_mi8+" then return end	
 	
 		--if self.LOCKD < 11-4 then return end -- !
		--print(self.LockedEnt:GetClass())

		self:EmitSound("stinger/rocketfire1.wav")
		if SERVER then
			self:StingerFire()
			self.Weapon:SetClip1(0)
		end
		--self.Weapon:EmitSound("stinger/locked.wav")

		self.Weapon:SetLockStat(0)
		self.LockedEnt = nil
		self.Weapon:SetLockedDelay(0)
		tempent = nil
		self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
		self.Owner:SetAnimation(PLAYER_ATTACK1)
		util.ScreenShake( self:GetPos(), 10, 2, 0.1, 200 )
	elseif self.Weapon:GetLockStat() then
		--self.Owner:ChatPrint("Наведите на воздушную цель!")
		self.Weapon:SetNoLockMsg(CurTime() + 3)
	end

end

function SWEP:StingerFire()
		local Jav = ents.Create("sent_stinger_missile")
		local eye =  self.Owner:EyeAngles()
		local pos = self.Owner:GetShootPos()
		pos = pos + eye:Right() * 5 - eye:Up() + eye:Forward() * 50
		pos.z = pos.z + 0
		Jav:SetPos(pos)
		Jav:SetAngles(Angle(0,self.Owner:EyeAngles().y,self.Owner:EyeAngles().r))
		Jav:SetOwner(self.Owner)
		Jav:Spawn()
		Jav.LockedEnt = self.LockedEnt
		timer.Simple( 1, function() self:Reload() end )
		timer.Simple( 1, function() self:ExitIron() end )
end

function SWEP:SecondaryAttack()

end

function SWEP:ExitIron()
	self:SetIronsights(false)
end


function SWEP:Reload()
	if (self.Weapon:Clip1() <= 0) then
		self.Owner:SetFOV(0,.3)
		self.Weapon:SendWeaponAnim(ACT_VM_RELOAD)
		--timer.Simple( 1.35, function() self:ExplosivesAmmoCheck() end )
		if SERVER then
			self.Owner:DrawViewModel(true)
			self:Idle()
			
			//
			self.Owner:StripWeapon(self.Gun)
			self:ThrowStinger()
			//
		end
	end
end

function SWEP:ExplosivesAmmoCheck()
	if SERVER then
		if IsValid(self) then
			if IsValid(self.Owner) then
				self.Owner:StripWeapon(self.Gun)
				self:ThrowStinger()
			end
		end
	end
end

function SWEP:Think()
	self:IronSight()

	--
	--local Tar = {}
	--Tar.start = self.Owner:GetShootPos()
	--Tar.endpos = self.Owner:GetShootPos() + ( self.Owner:GetAimVector() * 100^10 )
	--Tar.filter = { self, self.Owner }
	--Tar.mins = Vector( -15,-15,-15 )
	--Tar.maxs = Vector( 15,15,15 )
	--Tar.mask = MASK_SOLID 
	--local tr = util.TraceHull( Tar )
	--print("Видно: ", self.Weapon:CanSee( tr.Entity ), " Само ентити: ", tr.Entity )
	--


	if self.Owner:KeyDown(IN_ATTACK2) and !self.Owner:KeyDown(IN_SPEED) and !self.Owner:KeyDown(IN_USE) then
		self:JavTargeting()
	else
		self.LockedEnt = nil
		self.HitPos = nil
		self.LOCKD = 0
	end
	if self.Owner:KeyPressed(IN_SPEED) and not (self.Weapon:GetNWBool("Reloading")) then            -- If you are running
		if self.Weapon:GetNextPrimaryFire() <= (CurTime()+0.3) then
				self.Weapon:SetNextPrimaryFire(CurTime()+0.3)                           -- Make it so you can't shoot for another quarter second
		end
		self.IronSightsPos = self.RunSightsPos                                  -- Hold it down
		self.IronSightsAng = self.RunSightsAng                                  -- Hold it down
		self:SetIronsights(true, self.Owner)                                    -- Set the ironsight true
		self.Owner:SetFOV( 0, 0.3 )
		self.DrawCrosshair = false
		end                                                            
 
		if self.Owner:KeyReleased (IN_SPEED) then       -- If you release run then
		self:SetIronsights(false, self.Owner)                                   -- Set the ironsight true
		self.DrawCrosshair = self.OrigCrossHair
	end

end


local target = ents.FindByClass("wac_hc_mi24")  


local tempent = nil
local temppos = nil
function SWEP:JavTargeting()
	
	local Tar = {}
	Tar.start = self.Owner:GetShootPos()
	Tar.endpos = self.Owner:GetShootPos() + ( self.Owner:GetAimVector() * 100^10 )
	Tar.filter = { self, self.Owner }
	Tar.mins = Vector( -15,-15,-15 )
	Tar.maxs = Vector( 15,15,15 )
	Tar.mask = MASK_SOLID 
	local tr = util.TraceHull( Tar )
	if IsValid(tr.Entity) and self.Weapon:Clip1() >= 1 then
		--if tr.Entity:IsNPC() or tr.Entity:IsPlayer() or tr.Entity:IsVehicle() or tr.Entity:IsValid()  then
		if tr.Entity:IsNPC() or tr.Entity:IsPlayer() or tr.Entity:IsVehicle() then return end
		--print(tr.Entity:GetPos().z)
		-- 
		--print(tr.Entity:GetClass())
		if tr.Entity:GetClass():lower() == "prop_physics" then return false end
		if tr.Entity:GetClass():lower() == "gmod_sent_vehicle_fphysics_wheel" or tr.Entity:GetClass():lower() == "prop_dynamic"  then return false end
		--if not tr.Entity:GetClass() == "wac_hc_mi24" or not tr.Entity:GetClass() == "wac_hc_mi8" or not tr.Entity:GetClass() == "wac_hc_mi8+" then return end	
		--print(tr.Entity:GetClass():lower()) -- prop_dynamic

		if tr.Entity:IsValid() then
			
			if self.Weapon:GetLockStat() == 0 then
				tempent = tr.Entity
				self.Weapon:SetLockStat(1)
			end

			if self.BeepDelay <= CurTime() then  -- and self.Weapon:GetLockStat() == 1 and IsFirstTimePredicted() then
				self.BeepDelay = CurTime() + .3

 			
				self.LOCKD = self.LOCKD + 1
				
				--if CLIENT or SERVER and game.SinglePlayer() and self.LOCKD <= 0 then
					if tr.Entity:GetPos().z < 500 then return false end
					self.Weapon:EmitSound("stinger/check1.wav") -- "stinger/check.wav")

					tr.Entity:EmitSound("stinger/check1.wav") -- Добавляем звук для вертушки
				--end
				if self.LOCKD > 11-4 then 
					self.Weapon:EmitSound("stinger/locked.wav")
				end 
			end


			if self.LOCKD >= 1 and self.Weapon:GetLockStat() == 1 then

				--self.LockedEnt = tr.Entity -- Переделываю!

				self.LockedEnt = tr.Entity
				self.Weapon:SetLockStat(2)
				--self.Weapon:EmitSound("stinger/locked.wav")
				--self.Weapon:EmitSound("stinger/check.wav")
			end


		end

	else
		self.Weapon:SetLockStat(0)
		self.LockedEnt = nil
		tempent = nil
		temppos = nil
		self.LOCKD = 0
	end


	--[[for _, e in pairs(target) do
		--PrintTable(target)
	   if not IsValid(e) then return end

	   obpos = e:GetPos()
	   scr = obpos:ToScreen()
	   PrintTable(scr)	
		self.LockedEnt = e
  	end 	]] 



end

--
function SWEP:CanSee( entity )
	local pos = entity:GetPos()
	
	local tr = util.TraceLine( {
		start = self.Owner:GetShootPos(),
		endpos = pos,
		filter = function( ent ) 
			if ent == self.Owner then 
				return false
			end
			
			return true
		end
		
	} )
	return (tr.HitPos - pos):Length() < 500
end

--

 function SWEP:ThrowStinger( )

end

--[[---------------------------------------------------------
   Name: SWEP:Holster( weapon_to_swap_to )
   Desc: This is based off of Spy's Holster code so some credit
   needs to go to him for this one
-----------------------------------------------------------]]



function SWEP:CanNextAction()
	return self.Weapon:GetNextAct() <= CurTime()
end

function SWEP:GetNextAction()
	return self.Weapon:GetNextAct()
end

function SWEP:SetNextAction(time)
	return self.Weapon:SetNextAct(time)
end



function SWEP:SetRunning(Bool)
	self.Weapon:SetRun(Bool)
	if Bool then -- things will happen if Bool is true

	else -- things will happen if bool is false
	end
end

function SWEP:IsRunning()
	if self.Weapon:GetRun() then
		return self.Weapon:GetRun()
	end
	return false
end


function SWEP:PlayHolster()
	self.Weapon:SendWeaponAnim(ACT_VM_HOLSTER)
end

function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	
	return true
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end


local function DrawCircle( X, Y, radius )
	local segmentdist = 360 / ( 2 * math.pi * radius / 2 )
	
	for a = 0, 360 - segmentdist, segmentdist do
		surface.DrawLine( X + math.cos( math.rad( a ) ) * radius, Y - math.sin( math.rad( a ) ) * radius, X + math.cos( math.rad( a + segmentdist ) ) * radius, Y - math.sin( math.rad( a + segmentdist ) ) * radius )
	end
end

---------------------------------
if CLIENT then 
	local alpha = math.abs( math.cos( CurTime() * 5 ) )
	local center = {x=ScrW()/2, y=ScrH()/2}
	local colRS = Color(200, 200, 200, 255)
end 

function SWEP:DrawHUD()
	alpha = math.abs( math.cos( CurTime() * 5 ) )
	center = {x=ScrW()/2, y=ScrH()/2}
	local ply = LocalPlayer()
	if ply:InVehicle() then return end
	


	for _, e in pairs(target) do
		--[[PrintTable(target)
	    if not IsValid(e) then return end

	   obpos = e:GetPos()
	   scr = obpos:ToScreen()	
		X = scr.x +math.Rand(-1,1) 
		Y = scr.y +math.Rand(-1,1) 
		surface.SetDrawColor(Color(200,200,200,200))
		surface.DrawOutlinedRect(X-20, Y-20, 40, 40)
		surface.DrawLine( scrW, scrH, X, Y )]]
   end 	
	-- self.LockedEnt 
	local ent = self.LockedEnt

	if not IsValid( ent ) then return end
	
	local dist = (ent:GetPos() - ply:GetPos()):Length() / 500
	local pos = ent:LocalToWorld( ent:OBBCenter() )
	
	local scr = pos:ToScreen()
	local scrW = ScrW() / 2
	local scrH = ScrH() / 2

	local X = scr.x +math.Rand(-1,1) 
	local Y = scr.y +math.Rand(-1,1) 
	
 
	--surface.DrawLine( scrW, scrH, X, Y )
	--DrawCircle( X, Y, ent:GetModelRadius() / dist )
	-------------
	--print(ent:GetPos().z)
	if ent:GetPos().z > 500 then 
		 -- квадрат
		if self.LOCKD < 7 then 
			surface.SetDrawColor(255,255,0,150 * alpha ) 
		else 
			surface.SetDrawColor(0,255,0,150 * alpha )  
		end 
	else
		surface.SetDrawColor(255,0,0,150 * alpha ) 
	end 
	--surface.DrawOutlinedRect(X-20, Y-20, 40, 40)
	--surface.DrawOutlinedRect(X-21, Y-21, 42, 42)
	DrawCircle( X, Y, 20 )
	if self.LOCKD < 7 then  
		DrawCircle( X, Y, 36-self.LOCKD*2)
	else 
		DrawCircle( X, Y, 21)
	end 
	--print(self.LOCKD)

	surface.DrawLine(center.x+20, center.y, center.x+40, center.y)  -- новые полоски от выкл.
	surface.DrawLine(center.x-40, center.y, center.x-20, center.y)
	surface.DrawLine(center.x, center.y+20, center.x, center.y+40)
	surface.DrawLine(center.x, center.y-40, center.x, center.y-20)


	surface.DrawLine( scrW, scrH, X, Y ) -- Наводка
	--local sndist = dist

	local trdistanceraw = tostring( self.Owner:GetPos( ):Distance( ent:GetPos() ) /39 )
	local trdistance =  math.Clamp( math.Round( trdistanceraw ), 0, 10000 )


	--for _, e in pairs(target) do
		--[[PrintTable(target)
	    if not IsValid(e) then return end

	   obpos = e:GetPos()
	   scr = obpos:ToScreen()	
		X = scr.x +math.Rand(-1,1) 
		Y = scr.y +math.Rand(-1,1) 
		surface.SetDrawColor(Color(200,200,200,200))
		surface.DrawOutlinedRect(X-20, Y-20, 40, 40)
		surface.DrawLine( scrW, scrH, X, Y )]]
   --end 	 	
	
	draw.Text({
		text = (
			math.floor(trdistance).." м."
		),
 
	
		font = "HudHintTextLarge",
		pos = {center.x, center.y+45},
		color = colRS,
		xalign = TEXT_ALIGN_CENTER
		

	})


end



--[[

function SWEP:DrawHUD()
	local ply = LocalPlayer()
	if ply:InVehicle() then return end

	surface.SetDrawColor(0,255,255,255)
	local center = {x=ScrW()/2, y=ScrH()/2}
	local alpha2 = math.abs( math.cos( CurTime() * 5 ) )

	if self.Weapon:GetLockStat() == 2 and IsValid(self.LockedEnt) and self.Weapon:Clip1() >= 1 then
		--if self.LockedEnt:GetClass():lower() == "gmod_sent_vehicle_fphysics_wheel" then return false end
		--if not self.LockedEnt:GetClass() == "wac_hc_mi24" or self.LockedEnt:GetClass() == "wac_hc_mi8" or self.LockedEnt:GetClass() == "wac_hc_mi8+" then return end	

		--local point = ent:GetPos() + ent:OBBCenter() -- Gets the position of the entity, specifically the center
		--local data2D = point:ToScreen() -- Gets the position of the entity on your screen
 
		local pos_r = self.LockedEnt:GetPos() -- :ToScreen()
		local pos = self:LocalToWorld( pos_r )

		--print(pos_r) 
	
		local scr = pos:ToScreen()
		local scrW = ScrW() / 2
		local scrH = ScrH() / 2


		PrintTable(scr)
		--print(self.LockedEnt)

		--local pos = self.LockedEnt:GetClass():LocalToWorld(self:GetTargetOffset()):ToScreen() -- DEF


		--local pos = self:LocalToWorld( self.LockedEnt:GetPos() )
		pos = {
			x = math.Clamp(scr.x-center.x+math.Rand(-1,1), -20, 20)+center.x,
			y = math.Clamp(scr.y-center.y+math.Rand(-1,1), -20, 20)+center.y
			--surface.SetDrawColor+math.Rand(25,255,0,150)  -- не работает же :D
		} 

		--PrintTable(pos )

		surface.SetDrawColor(0,255,0,150* alpha2 )  -- квадрат
		--surface.DrawOutlinedRect(scr.x-20, scr.y-20, 40, 40)
		--surface.DrawOutlinedRect(scr.x-21, scr.y-21, 42, 42)

		surface.DrawOutlinedRect(scr.x, scr.y, 42, 42)
	
		surface.DrawLine(center.x+20, center.y, center.x+40, center.y)  -- новые полоски от выкл.
		surface.DrawLine(center.x-40, center.y, center.x-20, center.y)
		surface.DrawLine(center.x, center.y+20, center.x, center.y+40)
		surface.DrawLine(center.x, center.y-40, center.x, center.y-20)
		--print(pos)
 
	end
 
end


]]
