
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_afg_radio/lua/entities/mst_radio/shared.lua ~

]]

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
  
ENT.Category = "Другое"
ENT.PrintName = "Радио Афгана"
ENT.Author = "dmitra"
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""
ENT.Model = Model( "models/props_lab/citizenradio.mdl" )

ENT.Spawnable = true
ENT.AdminSpawnable = true