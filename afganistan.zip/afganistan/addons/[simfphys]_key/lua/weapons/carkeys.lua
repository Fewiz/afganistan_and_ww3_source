
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[simfphys]_key/lua/weapons/carkeys.lua ~

]]

--[[-------------------------------------------------------------------------
Car Keys - A SWEP that lets players lock, unlock, buy and sell vehicles.
Copyright (C) 2017-2020 viral32111

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see https://www.gnu.org/licenses/.
---------------------------------------------------------------------------]]

include("autorun/shared/sh_carkeys_config.lua") -- Include our configuration file.

SWEP.PrintName = "Ключи от авто"	-- SWEP Name. -- Car Keys
SWEP.Category = "Другое" -- Spawnmenu Category. Car Keys
SWEP.Spawnable = true -- Show it in the spawnmenu.

SWEP.Author = "viral32111" -- Me, because I made it :P
SWEP.Contact = "https://viral32111.com" -- Where to contact me.
SWEP.Purpose = "Lock, unlock, buy and sell vehicles." -- Purpose of this.
SWEP.Instructions = "Left Click locks vehicle, Right Click unlocks vehicle, Reload buys/sells vehicle." -- Instructions on how to use it.

SWEP.Slot = 2 -- 1 -- Hotbar slot number.
SWEP.SlotPos = 0 -- 1 -- Hotbar slot position.
SWEP.DrawAmmo = false -- Disable drawing ammo on the screen.

SWEP.Damage = 0

-- Set primary ammo to none.
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

-- Set secondary ammo to none.
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

-- View Model & World Model
SWEP.ViewModelFOV = 70
SWEP.ViewModel = "models/sentry/pgkey.mdl"
SWEP.WorldModel = ""

-- Switching when player runs out of ammo.
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

-- Called when the SWEP is initilised for the first time.
function SWEP:Initialize()
	self:SetHoldType("normal") -- Set the hold type to "normal".
end

function SWEP:Deploy()
	if timer.Exists("KeyHandsCar") then timer.Remove("KeyHandsCar") end -- Fucking SWEP function order
	if not self.UseHands then self.UseHands = true end
	timer.Create("KeyHandsCar", 1, 1, function() self.UseHands = false end)
end

-- Called when the reload key is pressed.
--[[function SWEP:Reload()
	if (CLIENT) then return end

	if (timer.Exists("carKeysReloadTimer")) then
		timer.Adjust("carKeysReloadTimer", 0.1, 1, function() end)
		return
	else
		timer.Create("carKeysReloadTimer", 0.1, 1, function() end)
	end

	local ply = self.Owner
	local ent = ply:GetEyeTrace().Entity

	if (ent == nil or ent == NULL) or (carKeysVehicles[ent:GetClass()] == nil) or (carKeysVehicles[ent:GetClass()].valid == false) or (ply:GetPos():Distance(ent:GetPos()) >= 150) then return end  -- Stop execution if vehicle is invalid, or player is more than 150 units away.

	local owner = ent:GetNWEntity("carKeysVehicleOwner")
	local price = ent:GetNWInt("carKeysVehiclePrice")

	if (owner == NULL) then
		if (engine.ActiveGamemode() == "darkrp") then
			if (ply:CanAfford(price)) then -- canAfford
				ply:AddMoney(-price) -- addMoney
				ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Car Keys) \", Color(255, 255, 255), \"You've bought this vehicle for $\" .. tostring(LocalPlayer():GetEyeTrace().Entity:GetNWInt(\"carKeysVehiclePrice\")) .. \".\")")
				ent:SetNWEntity("carKeysVehicleOwner", ply)
				ent:EmitSound("ambient/machines/keyboard6_clicks.wav")
			else
				ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Car Keys) \", Color(255, 255, 255), \"You can't afford this vehicle! It costs $\" .. tostring(LocalPlayer():GetEyeTrace().Entity:GetNWInt(\"carKeysVehiclePrice\")) .. \".\")")
			end
		else
			ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Car Keys) \", Color(255, 255, 255), \"You have acquired this vehicle!\")")
			ent:SetNWEntity("carKeysVehicleOwner", ply)
			ent:EmitSound("ambient/machines/keyboard6_clicks.wav")
		end
	else
		if (owner:UniqueID() == ply:UniqueID()) then
			if (engine.ActiveGamemode() == "darkrp") then
				ply:AddMoney(price)
				ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Car Keys) \", Color(255, 255, 255), \"You've sold your vehicle for $\" .. tostring(LocalPlayer():GetEyeTrace().Entity:GetNWInt(\"carKeysVehiclePrice\")) .. \".\")")
			else
				ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Car Keys) \", Color(255, 255, 255), \"You no longer own this vehicle.\")")
			end

			ent:SetNWBool("carKeysVehicleLocked", false)
			ent:SetNWEntity("carKeysVehicleOwner", NULL)
			ent:EmitSound("buttons/lightswitch2.wav")

			if (ent:GetNWBool("carKeysVehicleAlarm")) then
				timer.Remove("carKeysLoopAlarm" .. ent:EntIndex())
				timer.Remove("carKeysAlarmLights" .. ent:EntIndex())
				ent:StopSound("carKeysAlarmSound")
				ent:SetNWBool("carKeysVehicleAlarm", false)
			end
		else
			ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Car Keys) \", Color(255, 255, 255), \"You can't purchase this vehicle, it's owned by \" .. LocalPlayer():GetEyeTrace().Entity:GetNWEntity(\"carKeysVehicleOwner\"):Nick() .. \".\")")
			ent:EmitSound("doors/handle_pushbar_locked1.wav")
		end
	end
end]]

-- Called when Left Click is pressed.
function SWEP:PrimaryAttack()
	if (CLIENT) or (not IsFirstTimePredicted()) then return end

	local ply = self.Owner
	local ent = ply:GetEyeTrace().Entity

	if (ply.cooldown==nil)then
		ply.cooldown=os.time()-0.75
	end 

	if (ply.cooldown + 0.75 >= os.time ()) then return false end
	ply.cooldown=os.time()

	if (ent == nil or ent == NULL) or (carKeysVehicles[ent:GetClass()] == nil) or (carKeysVehicles[ent:GetClass()].valid == false) or (ply:GetPos():Distance(ent:GetPos()) >= 150) then return end  -- Stop execution if vehicle is invalid, or player is more than 150 units away.

	local owner = ent:GetNWEntity("carKeysVehicleOwner")
	--local price = ent:GetNWInt("carKeysVehiclePrice")

	if (owner != NULL) and (owner:UniqueID() == ply:UniqueID()) then
		ent:EmitSound("npc/metropolice/gear" .. math.floor(math.Rand(1, 7)) .. ".wav")
		ent:SetNWBool("carKeysVehicleLocked", true)
		ent.VehicleLocked = true

		if not (ent:WaterLevel() >= 1) then
			timer.Simple(0.5, function()
				if (ent:IsValid()) then
					ent:EmitSound("carkeys/lock.wav")
				end
			end)
		end
		rp.Notify(self.Owner,NOTIFY_ERROR, 'Автомобиль закрыт')
	else                                               -- Car Keys                          You cannot lock this vehicle, you don't own it.
		--ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Авто) \", Color(255, 255, 255), \"Вы не можете закрыть эту машину, она не ваша.\")")
		rp.Notify(ply, NOTIFY_ERROR, 'Вы не можете закрыть эту машину, она не ваша!') 
		ent:EmitSound("doors/handle_pushbar_locked1.wav")
	end

	if not (timer.Exists("carKeysAnimationTimer")) then
		timer.Create("carKeysAnimationTimer", 2, 1, function() end)
		ply:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE, true)
		ply:SendLua("LocalPlayer():AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE, true)")
	end
end

-- Called when Right Click is pressed.
function SWEP:SecondaryAttack()
	if (CLIENT) or (not IsFirstTimePredicted()) then return end

	local ply = self.Owner
	local ent = ply:GetEyeTrace().Entity

	if (ply.cooldown==nil)then
		ply.cooldown=os.time()-0.75
	end 

	if (ply.cooldown + 0.75 >= os.time ()) then return false end
	ply.cooldown=os.time()

	if (ent == nil or ent == NULL) or (carKeysVehicles[ent:GetClass()] == nil) or (carKeysVehicles[ent:GetClass()].valid == false) or (ply:GetPos():Distance(ent:GetPos()) >= 150) then return end  -- Stop execution if vehicle is invalid, or player is more than 150 units away.

	local owner = ent:GetNWEntity("carKeysVehicleOwner")
	local price = ent:GetNWInt("carKeysVehiclePrice")

	if (owner != NULL) and (owner:UniqueID() == ply:UniqueID()) then
		if (ent:GetNWBool("carKeysVehicleAlarm")) then
			ent:SetNWBool("carKeysVehicleAlarm", false)
			ent:StopSound("carKeysAlarmSound")

			timer.Remove("carKeysLoopAlarm" .. ent:EntIndex())
			timer.Remove("carKeysAlarmLights" .. ent:EntIndex()) 
           
			--ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Авто) \", Color(255, 255, 255), \"Сирена выключена.\")") -- Car alarm stopped
			rp.Notify(ply, 'Сирена выключена') 
		end

		ent:EmitSound("npc/metropolice/gear" .. math.floor(math.Rand(1, 7)) .. ".wav")
		ent:SetNWBool("carKeysVehicleLocked", false)
		ent.VehicleLocked = false -- Fix
		rp.Notify(self.Owner, 'Автомобиль открыт')
	else
		--ply:SendLua("chat.AddText(Color(26, 198, 255), \"(Авто) \", Color(255, 255, 255), \"Вы не можете открыть эту машину, она не ваша.\")") -- You cannot unlock this vehicle, you don't own it
		rp.Notify(ply, NOTIFY_ERROR, 'Вы не можете закрыть эту машину, она не ваша!') 
		ent:EmitSound("doors/handle_pushbar_locked1.wav")
	end
	
	if not (timer.Exists("carKeysAnimationTimer")) then
		timer.Create("carKeysAnimationTimer", 2, 1, function() end)
		ply:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE, true)
		ply:SendLua("LocalPlayer():AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE, true)")
	end
end

-- Sets the view model position
function SWEP:GetViewModelPosition(position, angle)
	local owner = self.Owner

	if (IsValid(owner)) then                -- 11
		position = position + owner:GetRight()*8 + owner:GetAimVector()*12 -- 21
	end

	angle:RotateAroundAxis(angle:Up(), 210) -- 210
	angle:RotateAroundAxis(angle:Right(), 220)
	angle:RotateAroundAxis(angle:Forward(), 10)

	return position, angle
end

-- Custom HUD that shows the white text in the middle of the screen.
function SWEP:DrawHUD()
	local ply = LocalPlayer() -- Get the player
	local ent = ply:GetEyeTrace().Entity -- Get the entity the player is looking at
	
	if (ent == nil or ent == NULL) or (ply:InVehicle()) or (carKeysVehicles[ent:GetClass()] == nil) or (carKeysVehicles[ent:GetClass()].valid == false) or (ply:GetPos():Distance(ent:GetPos()) >= 150) then return end  -- Stop execution if vehicle is invalid, the player is in a vehicle, or player is more than 150 units away.

	local owner = ent:GetNWEntity("carKeysVehicleOwner") -- Get the vehicle's owner
	local price = ent:GetNWInt("carKeysVehiclePrice") -- Get the vehicle's price

	--[[if (owner != NULL) then -- Is the owner valid?
		draw.DrawText("Owned by " .. owner:Nick(), "TargetID", ScrW()/2, ScrH()/2+15, Color(255, 255, 255), TEXT_ALIGN_CENTER)
		
		if (ply:GetEyeTrace().Entity:GetNWBool("carKeysVehicleLocked")) then
			draw.DrawText("Vehicle is locked", "TargetIDSmall", ScrW()/2, ScrH()/2+35, Color(255, 255, 255), TEXT_ALIGN_CENTER)
		else
			draw.DrawText("Vehicle is unlocked", "TargetIDSmall", ScrW()/2, ScrH()/2+35, Color(255, 255, 255), TEXT_ALIGN_CENTER)
		end
	else
		draw.DrawText("Vehicle is unowned!", "TargetID", ScrW()/2, ScrH()/2+15, Color(255, 255, 255), TEXT_ALIGN_CENTER)
		
		if (engine.ActiveGamemode() == "darkrp") then -- Are we running DarkRP?
			draw.DrawText("Press R to buy it for $" .. price, "TargetIDSmall", ScrW()/2, ScrH()/2+35, Color(255, 255, 255), TEXT_ALIGN_CENTER)
		else
			draw.DrawText("Press R to acquire it", "TargetIDSmall", ScrW()/2, ScrH()/2+35, Color(255, 255, 255), TEXT_ALIGN_CENTER)
		end
	end]]
end

function SWEP:OnRemove()
	if timer.Exists("KeyHandsCar") then timer.Remove("KeyHandsCar") end
	
	if not IsValid(self.Owner) then return end
	
	local vm = self.Owner:GetViewModel()
	if IsValid(vm) then vm:SetMaterial("") end
end