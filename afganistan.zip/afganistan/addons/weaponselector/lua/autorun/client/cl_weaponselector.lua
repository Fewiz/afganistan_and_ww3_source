
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/weaponselector/lua/autorun/client/cl_weaponselector.lua ~

]]

--[[
gamemodes/rp_base/gamemode/core/hud/wepswitch_cl.lua
--]]
-- TODO: Dont ever touch this messy pile again

local categories = {

--	'Строительство',
'Вторичное',
--	'Ролеплей',
'RP',
--    'Оружие',
'Оружие',
--    'Прочее'
'Взрывное',
}



local weaponMap = {

	weapon_physgun = {

		Name = 'Физган',

		Slot = 1

	},
	
	weapon_bugbait = {
	
	Name = 'Дерьмо',
	
	Slot = 5 -- 2
	
	},

	weapon_fists = {

    Name = 'Кулаки',

    Slot = 2    

    },

	weapon_physcannon = {

		Name = 'Гравитиган',

		Slot = 1

	},

	itemstore_pickup = {

		Name = 'Инвентарь',

		Slot = 2

	},

	moneychecker = {

		Name = 'Чекер кошелька',

		Slot = 2

	},

	weapon_keypadchecker = {

		Name = 'Кейпад чекер',

		Slot = 2

	},

	sent_tablet = {

		Name = 'Планшет',

		Slot = 2

	},

	keys = {

		Name = 'Ключи',

		Slot = 2

	},

	lockpick = {

		Name = 'Отмычка',

		Slot = 4 -- 2

	},

	weaponchecker = {

		Name = 'Проверка на оружие',

		Slot = 3 -- 2

	},

	stun_baton = {

		Name = 'Демократизатор',

		Slot = 2

	},

	arrest_baton = {

		Name = 'Арестовать',

		Slot = 3 -- 2

	},

	unarrest_baton = {

		Name = 'Разарестовать',

		Slot = 3 -- 2

	},

	door_ram = {

		Name = 'Таран',

		Slot = 3 -- 2

	},

	med_kit = {

		Name = 'Аптечка',

		Slot = 2

	},


	weapon_rpg = {

		Name = 'RPG',

		Slot = 3

	},

	weapon_crossbow = {

		Name = 'Crossbow',

		Slot = 3

	},

	weapon_crowbar = {

		Name = 'Crowbar',

		Slot = 3

	},

	weapon_slam = {

		Name = 'SLAM',

		Slot = 3

	},

	weapon_stunstick = {

		Name = 'Stunstick',

		Slot = 3

	},
}



local function getWeaponSlot(wep)

	if (wep.GetSwitcherSlot) then

		wep.Slot = wep:GetSwitcherSlot()

	end



	local map = weaponMap[wep:GetClass()]

	return (wep.Slot and math.Clamp(wep.Slot, 1, 4)) or (map and map.Slot) or 2

end



local wepsCache = {}

local weaponsByCategory = {}

local weaponsByOrder = {}

local weaponsByClass = {}

local selectedWeapon = -1

local lastCache = CurTime()

local function ensureWeapons(force)

	local weps = LocalPlayer():GetWeapons()



	if (lastCache <= CurTime() or force) then

		wepsCache = weps



		table.Empty(weaponsByCategory)

		table.Empty(weaponsByOrder)

		table.Empty(weaponsByClass)

		for k, cat in ipairs(categories) do

			local wepSlot = k



			weaponsByCategory[wepSlot] = {}

			for _, wep in pairs(weps) do

				if (getWeaponSlot(wep) == wepSlot) then

					local ind = table.insert(weaponsByCategory[wepSlot], {

						ID = #weaponsByOrder + 1,

						Class = wep:GetClass(),

						Name = (weaponMap[wep:GetClass()] and weaponMap[wep:GetClass()].Name) or wep.PrintName or wep:GetClass(),

						Ent = wep

					})



					weaponsByOrder[#weaponsByOrder + 1] = weaponsByCategory[wepSlot][ind]

					weaponsByClass[wep:GetClass()] = weaponsByCategory[wepSlot][ind]

				end

			end

		end

	end



	if (selectedWeapon == 0 and IsValid(LocalPlayer():GetActiveWeapon()) and weaponsByClass[LocalPlayer():GetActiveWeapon():GetClass()]) then

		selectedWeapon = weaponsByClass[LocalPlayer():GetActiveWeapon():GetClass()].ID

	end



	lastCache = CurTime() + 0.25

end



local showTime = 0

local fadeTime = 0



local lastWep

local currentWep

local function switchWeapon(wep)

	wep = wep or weaponsByOrder[selectedWeapon]



	showTime = 0



	if not wep then

		return

	end



	lastWep = currentWep

	currentWep = wep



	if not IsValid(LocalPlayer():GetActiveWeapon()) or LocalPlayer():GetActiveWeapon() ~= wep.Ent then

		input.SelectWeapon(wep.Ent)

	else

		return

	end



	surface.PlaySound('buttons/lightswitch2.wav')

	return true

end



local color_white 		= ui.col.White

local color_flatblack 	= ui.col.FlatBlack

local color_background 	= ui.col.Background

local color_highlight 	= ui.col.TransWhite100

local color_sup 		= Color(231-30,28-5,92-15) -- ui.col.SUP -- Color(231,28,92) 

local color_red 		= ui.col.Red

local function draw_right()

	local st = SysTime()

	local w, h = 140, 35

	local x, y = (ScrW() - #categories * (w + 3)) * 0.5, 5



	if (showTime + 0.35 <= st) then return end

	ensureWeapons()



	if (showTime <= st) then

		surface.SetAlphaMultiplier(Lerp((st - showTime) / 0.1, 1, 1))

	else

		surface.SetAlphaMultiplier(Lerp((st - fadeTime) / 0.1, 0, 1))

	end



	for k, cat in ipairs(categories) do

		local x, y = x + ((k - 1) * (w + 3)), y

		local wepSlot = k

		draw.Box(x, y, w, h, color_flatblack)

		draw.SimpleText(wepSlot, 'CW_HUD22', x + 5, h - 20, color_sup, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) -- ui.17  , x + 3, h - 20, 

		draw.SimpleText(cat, 'KeyCaps_mini', x + (w * 0.5), y + (h * 0.5), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) -- 'ui.20'



		for i, wep in ipairs(weaponsByCategory[wepSlot]) do

			local y = y + (i * (h + 3))

			draw.Box(x, y, w, h, color_background) -- color_background



			if (wep.ID == selectedWeapon) then
               
                draw.Box(x, y, w, h, color_sup) 
			end



			draw.SimpleText(wep.Name, 'KeyCaps_mini_wep', x + 5, y + 3, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) -- 'ui.18'



			if (not IsValid(wep.Ent)) then continue end



			local clip1, maxClip1 = wep.Ent:Clip1(), wep.Ent:GetMaxClip1()

			local isUnlimited = (maxClip1 < 1) and (clip1 < 1)


																						--  (x + w) - 5, (y + h) - 3
			draw.SimpleText(isUnlimited and '∞' or (clip1 .. '/' .. maxClip1) , 'CW_HUD16', (x + w) - 5, (y + h), ((not isUnlimited) and (clip1 == 0)) and color_red or color_sup, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM) -- ui.17

		end

	end
end


local lastSnd = 0

hook('PlayerBindPress', 'rp.wepswitch.PlayerBindPress', function(pl, bind, pressed)

	if (!pressed) then return end

	if (!LocalPlayer():Alive()) then return end

	if (!IsValid(LocalPlayer():GetActiveWeapon())) then return end

	if (table.Count(LocalPlayer():GetWeapons()) <= 1) then return end

	if (LocalPlayer():InVehicle()) then return end



	local wep = pl:GetActiveWeapon()



	if IsValid(wep) and wep.SWBWeapon and wep.dt and (wep.dt.State == SWB_AIMING) and wep.AdjustableZoom then

		return

	end

	if istable(wep.dt) and not (type(wep.dt.State) == "nil") and wep.dt.State == CW_CUSTOMIZE then return end



	if hook.Call('SuppressWeaponSwitcher', nil, pl, bind, pressed) then return end



	if ((bind == 'invprev') or (bind == 'lastinv') or (bind == 'invnext') or (string.sub(bind, 1, 4) == 'slot')) and (not pl:KeyDown(IN_ATTACK)) then

		if (bind == 'lastinv') and lastWep and IsValid(lastWep.Ent) then

			switchWeapon(lastWep)

			selectedWeapon = currentWep.ID

		elseif (string.sub(bind, 1, 3) == 'inv') then

			if (showTime < SysTime()) then

				ensureWeapons(true)

				selectedWeapon = 0

			else

				local scroll = (bind == 'invprev') and -1 or 1



				selectedWeapon = selectedWeapon + scroll

				if (!weaponsByOrder[selectedWeapon]) then

					selectedWeapon = (scroll == 1 and 1) or #weaponsByOrder

				end

			end

		else -- using number keys

			if (showTime < SysTime()) then

				ensureWeapons(true)

				fadeTime = SysTime()

			end



			local slot = tonumber(string.sub(bind, -1))



			if (!categories[slot]) then return end



			if (weaponsByCategory[slot][1]) then

				local found = false

				for k, v in ipairs(weaponsByCategory[slot]) do

					if (v.ID == selectedWeapon) then

						found = true



						if (weaponsByCategory[slot][k + 1]) then

							selectedWeapon = v.ID + 1

						else

							selectedWeapon = weaponsByCategory[slot][1].ID

						end



						break

					end

				end



				if (!found) then

					selectedWeapon = weaponsByCategory[slot][1].ID

				end

			end

		end



		ensureWeapons(true)

		showTime = SysTime() + 1 -- + 2



		if (lastSnd < SysTime() - 0.05) then

			surface.PlaySound('garrysmod/ui_hover.wav')--buttons/blip1.wav')

			lastSnd = SysTime()

		end

	elseif (showTime > SysTime() and bind == '+attack') then

		showTime = 0

		if (IsValid(LocalPlayer():GetActiveWeapon()) and weaponsByOrder[selectedWeapon] and weaponsByClass[LocalPlayer():GetActiveWeapon():GetClass()] and selectedWeapon != weaponsByClass[LocalPlayer():GetActiveWeapon():GetClass()].ID) then

			switchWeapon()

		end

		return true

	elseif (bind == 'phys_swap') then

		showTime = 0

	end

end)

hook.Add("HUDPaint", "DrawWeaponSelection", draw_right)