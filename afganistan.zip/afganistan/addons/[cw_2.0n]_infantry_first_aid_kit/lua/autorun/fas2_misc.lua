
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_infantry_first_aid_kit/lua/autorun/fas2_misc.lua ~

]]

AddCSLuaFile()

local FAS_RS = {}

FAS_RS["FAS2_Bandage.Retrieve"] = "weapons/ifak/bandage_retrieve.wav"
FAS_RS["FAS2_Bandage.Open"] = "weapons/ifak/bandage_open.wav"
FAS_RS["FAS2_Hemostat.Retrieve"] = "weapons/ifak/hemostat_retrieve.wav"
FAS_RS["FAS2_Hemostat.Close"] = "weapons/ifak/hemostat_close.wav"
FAS_RS["FAS2_QuikClot.Loosen"] = "weapons/ifak/quikclot_loosen.wav"
FAS_RS["FAS2_QuikClot.Open"] = "weapons/ifak/quikclot_open.wav"
FAS_RS["FAS2_QuikClot.Retrieve"] = "weapons/ifak/quikclot_retrieve.wav"

local tbl = {channel = CHAN_STATIC,
	volume = 1,
	soundlevel = 50,
	pitchstart = 100,
	pitchend = 100}

for k, v in pairs(FAS_RS) do
	tbl.name = k
	tbl.sound = v
		
	sound.Add(tbl)
	
	if type(v) == "table" then
		for k2, v2 in pairs(v) do
			Sound(v2)
		end
	else
		Sound(v)
	end
end	