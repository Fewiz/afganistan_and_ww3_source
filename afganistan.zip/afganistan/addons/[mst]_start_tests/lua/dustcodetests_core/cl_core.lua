
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_start_tests/lua/dustcodetests_core/cl_core.lua ~

]]

local background = Color(45, 52, 54)
local background_hover = Color(45, 62, 54)
local title = Color(0,0,0,150)
local button = Color(79, 80, 84,230)
local button_hover = Color(79, 80, 84,240)
local questBackground = Color(0,0,0,100)
local lineColor = Color(99, 110, 114,200)
local checkedBox = Color(0,150,0,100,150)
local checkBoxBG = Color(0,0,0,0)
local questBG = Color(0,0,0,60)
local doneBtn = Color(0, 184, 148,50)
local doneBtn_hover = Color(0, 184, 148,100)

local panel
function _DUSTCODE_TESTS:OpenTests()
	if IsValid(panel) then panel:Remove() end

	panel = vgui.Create("DPanel")
	panel:SetSize(1200,800) -- 700,800
	panel:MakePopup()
	panel:SetAlpha(0)
	panel:AlphaTo(255,0.5)
	panel:DockPadding(0, 28, 0, 0)
	panel:Center()
	panel:TDLib()
		:ClearPaint()
		:Background(background)
		:SideBlock(title, 28, TOP)

	panel:On("Paint", function(w,h)
		draw.SimpleText("Тестирование - Осталось попыток: "..LocalPlayer():GetNWInt("dustcode:trys", _DUSTCODE_TESTS.trys), "DustCode_Small", 5, 5, color_white, TEXT_ALIGN_LEFT)
	end)

	local scroll = vgui.Create("DScrollPanel", panel)
	scroll:TDLib()
		:Stick(FILL, 1)
		--:HideVBar()

	local selected = {}
	for k, data in pairs(_DUSTCODE_TESTS.Questions) do
		local quest = scroll:Add("DPanel")
		quest:SetTall(200)
		quest:TDLib()
			:Stick(TOP,3)
			:ClearPaint()
			//:Background(questBG)
			:SideBlock(title, 4, BOTTOM)

		local questName = vgui.Create("DTextEntry", quest)
		questName:SetEditable(false)
		questName:Dock(TOP)
		questName:DockMargin(3, 3, 3, 3)
		questName:DockPadding(5,5,5,5)
		questName:SetTextColor(color_white)
		questName:SetTall(75)
		questName:SetText(data.title)
		questName:SetMultiline(true)
		questName:SetFont("DustCode_Small")
		questName:TDLib():ReadyTextbox()
			//:ClearPaint()
			:Background(Color(255,255,255,10))
			//:SideBlock(lineColor, 1, BOTTOM)

		local grid = vgui.Create("DGrid", quest)
		grid:SetCols( 2 )
		grid:SetColWide( panel:GetWide()/2-30 )
		grid:TDLib()
			:Stick(FILL, 10)
			//:Background(background)

		local boxes = {}
		selected[k] = 1
		for id, text in pairs(data.answers) do
			boxes[id] = vgui.Create( "DCheckBoxLabel" )
			boxes[id]:SetText( text )
			boxes[id]:SetFont("DustCode_Small")
			boxes[id].Button:TDLib()
				:ClearPaint()
				:SquareCheckbox(Color(225, 112, 85))
			boxes[id]:TDLib()
				:ClearPaint()
				:CircleCheckbox(checkedBox, checkBoxBG)

			boxes[id].OnChange = function(s, bVal)
				if bVal then
					selected[k] = id

					for i, but in pairs(boxes) do
						if selected[k] != i then but:SetChecked(false) continue end

						but:SetChecked(true)
					end
				else
					if selected[k] == id then
						s:SetChecked(true)
					end
				end
			end

			if selected[k] == id then
				boxes[id]:SetValue(true)
			end

			grid:AddItem( boxes[id] )
		end
	end

	local btn = vgui.Create("DButton", panel)
	btn:SetTall(40)
	btn:TDLib()
		:SetRemove(panel)
		:Stick(BOTTOM, 1)
		:ClearPaint()
		:Background(doneBtn)
		:CircleHover(doneBtn_hover)
		:Text("Готово", "DustCode_Small", color_white, TEXT_ALIGN_CENTER)

	btn:NetMessage("DustCodeTest:CheckTest", function() net.WriteTable(selected) end)
end

function _DUSTCODE_TESTS:OpenMenu()
	if IsValid(panel) then panel:Remove() end

	local isRead = false

	panel = vgui.Create("DFrame")
	panel:SetSize(500,120) -- 500,120
	panel:Center()
	panel:MakePopup()
	panel:SetAlpha(0)
	panel:AlphaTo(255,0.5)
	panel:SetTitle("Тестирование")
	panel:ShowCloseButton(false)
	panel:TDLib()
		:ClearPaint()
		:Background(background)
		:Blur(1)
		:SideBlock(title, 28, TOP)
		:Text("Перед прохождением теста прочтите правила сервера!", "DustCode_Small", color_white, TEXT_ALIGN_CENTER, 0, -20)

	local close = vgui.Create("DButton", panel)
	close:SetSize(28,22)
	close:SetPos(panel:GetWide()-close:GetWide()-3, 3)
	close:TDLib()
		:ClearPaint()
		:SetRemove(panel)
		:Background(background)
		:Text("✖", "DustCode_Small", color_white, TEXT_ALIGN_CENTER)
		:FadeHover(background_hover)

	local startBtn = vgui.Create("DButton", panel)
	startBtn:TDLib()
		:Stick(BOTTOM, 2)
		:Background(button)
		:FadeHover(button_hover)
		:Text("Начать тестирование", "DustCode_Small", color_white, TEXT_ALIGN_CENTER)

	startBtn:On("DoClick", function()
		--if !isRead then
		--	notification.AddLegacy( "Вы не прочитали правила сервера!", NOTIFY_ERROR, 4 )
		--else
			_DUSTCODE_TESTS:OpenTests()
		--end
	end)

	local rulesBtn = vgui.Create("DButton", panel)
	rulesBtn:TDLib()
		:Stick(BOTTOM, 2)
		:Background(button)
		:FadeHover(button_hover)
		:Text("Прочитать правила", "DustCode_Small", color_white, TEXT_ALIGN_CENTER)
		:SetOpenURL(_DUSTCODE_TESTS.Config.rulesURL)

	rulesBtn:On("DoClick", function()
		timer.Simple(5, function()
			isRead = true
		end)
	end)

end

net.Receive("dustcode:notify", function()
	local msg = net.ReadString()
	local isError = net.ReadBool()

	if isError then
		notification.AddLegacy( msg, NOTIFY_ERROR, 4 )
	else
		notification.AddLegacy( msg, NOTIFY_GENERIC, 4 )
	end
end)

net.Receive("dustcode:sendquests", function()
	local data = net.ReadTable()

	if data then
		_DUSTCODE_TESTS.Questions = data
	end
end)

net.Receive("DustCodeTest:CheckTest", _DUSTCODE_TESTS.OpenMenu)

net.Receive("dustcode:sendvknotice", function()
	Derma_Query( "Желаете вступить в нашу группу Вконтакте?", "Уведомление", "Да", function()
		gui.OpenURL(_DUSTCODE_TESTS.Config.GroupURL)
	end, "Позже")
end)