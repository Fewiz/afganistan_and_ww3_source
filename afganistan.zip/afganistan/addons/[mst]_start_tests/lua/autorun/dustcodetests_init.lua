
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_start_tests/lua/autorun/dustcodetests_init.lua ~

]]

hook.Add("PostGamemodeLoaded", "dustcodetests:Initilize", function()
	include("_dustcodetests_config.lua")

	if SERVER then
		AddCSLuaFile("dustcodetests_lib/tdlib.lua")
		AddCSLuaFile("_dustcodetests_config.lua")
		AddCSLuaFile("dustcodetests_core/cl_core.lua")

		include("_dustcodetests_mysql.lua")
		include("dustcodetests_core/sv_sql.lua")
		include("_dustcodetests_questions.lua")
		include("dustcodetests_core/sv_core.lua")
	else
		include("dustcodetests_lib/tdlib.lua")
		include("dustcodetests_core/cl_core.lua")
	end
end)