
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_start_tests/lua/_dustcodetests_config.lua ~

]]

_DUSTCODE_TESTS = _DUSTCODE_TESTS or {}

_DUSTCODE_TESTS.sqlType = "sqlite" // mysqloo or sqlite
_DUSTCODE_TESTS.trys = 3 // Количество выдаваемых попыток
_DUSTCODE_TESTS.maxQuestions = 8// Количество вопросов 12 8
_DUSTCODE_TESTS.Config = {}



local cmap = game.GetMap() 
--print(cmap)

_DUSTCODE_TESTS.SpawnPoints = { -- На всякий, если карта будет не из списка
	--Vector(-1523,-2093,-224), -- Обычные позы моей карты
	--Vector(-1300,-2064,-224), -- Обычные позы моей карты
	Vector(348,-449,-8191),
}

if cmap == "rp_afghanistan_v9" then
	_DUSTCODE_TESTS.SpawnPoints = {
		Vector(-1523,-2093,-224), 
		Vector(-1300,-2064,-224), 
	}
end 

if cmap == "rp_afghanistan_v4" then
	_DUSTCODE_TESTS.SpawnPoints = {
		Vector(10901,12693,288), 
	}
end 

if cmap:find("rp_mst") then  
	_DUSTCODE_TESTS.SpawnPoints = {
		Vector(348,-449,-8191),
		Vector(257,-504,-8191),
		Vector(251,-406,-8191),
	}
end  
 
--_DUSTCODE_TESTS.SpawnPoints = {
--	Vector(348,-449,-8191),
--}




if SERVER then return end

_DUSTCODE_TESTS.Config.rulesURL = "https://docs.google.com/document/d/1bjYaNaN8QDCtsIhmvp-b5Fq-mxo_-gwylj71DO3tLf8/edit"
_DUSTCODE_TESTS.Config.GroupURL = "https://vk.com/mst_gmod"

surface.CreateFont("DustCode_Small", {font = "Times New Roman", size = 18, weight = 300})
surface.CreateFont("DustCode_Normal", {font = "Times New Roman", size = 24, weight = 500})
