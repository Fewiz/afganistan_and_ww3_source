
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_equipment/lua/entities/sent_server/shared.lua ~

]]

ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName		= "Ретранслятор"
ENT.Author			= "NFS-NIK"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= "Нажать E для пополнения боезопаса."
ENT.Spawnable	= true 
ENT.AdminSpawnable	= true
ENT.Category = "Другое"

