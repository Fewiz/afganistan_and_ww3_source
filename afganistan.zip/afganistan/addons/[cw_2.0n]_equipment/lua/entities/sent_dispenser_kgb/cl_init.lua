
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_equipment/lua/entities/sent_dispenser_kgb/cl_init.lua ~

]]

include("shared.lua")
  
surface.CreateFont( "Font_Weapons", {
    font = "DermaLarge",
    size = 80,
    weight = 750
} )

-- Colors
local white = Color( 255, 255, 255, 255 )
local grey = Color( 130, 130, 130, 200 )
local white_grey = Color( 200, 200, 200, 235 )
local red = Color( 130, 30, 3, 235 )
local background = Color( 30, 30, 50, 245 )

--Pos
local frame_x = ScrW()*.19
local frame_y = ScrH()*.2
local frame_w = 800
local frame_h = 600

local get_button_x = frame_x*.002
local get_button_y = frame_y*.003
local get_button_w = 239
local get_button_h = 70

local select_button_x = 1
local select_button_y = 481
local select_button_w = frame_w*.998
local select_button_h = 118

IGS_NPC_HIDE_ON_DISTANCE = nil -- 100000
function ENT:Draw()

	local dist = EyePos():DistToSqr(self:GetPos())
	if IGS_NPC_HIDE_ON_DISTANCE and dist > IGS_NPC_HIDE_ON_DISTANCE then return end -- не отрисовывать

	self.Entity:DrawModel()
  
	local pos = self:GetPos() + (self:GetAngles():Forward() * -10) + (self:GetAngles():Up() * 35) -- 62.5 -- Высота
 	local ang = self:GetAngles()-------------* 0------ Вперед/Назад ------------------ Вверх/Низ

	ang:RotateAroundAxis(self:GetAngles():Forward(), 90) -- 
	ang:RotateAroundAxis(self:GetAngles():Up(), 90)  -- Боковой Наклон
	
 	cam.Start3D2D(pos, Angle(ang.p, ang.y, ang.r0), 0.113) -- Размер
	 if math.floor((LocalPlayer():GetPos():Distance(self:GetPos()))) < 500 then
		surface.SetDrawColor( 0, 0, 0, 150 )
		surface.DrawRect( -200, -60, 400, 100 ) -- ( -200, -100, 400, 178 )
		--surface.SetDrawColor( Color( 204,255,0 ))
		--surface.DrawOutlinedRect( -200, -60, 400, 100 )  -- ( -200, -100, 400, 178 )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( -200, 40, 400, 5 )  -- Белая линия

		draw.SimpleText( "Архив КГБ", "Font_Weapons", 1, -55, Color( 255,255,255 ), 1, 0 )
     end
	cam.End3D2D()

end
