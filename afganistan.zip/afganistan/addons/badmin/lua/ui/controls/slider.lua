
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ui/controls/slider.lua ~

]]

local PANEL = {}

function PANEL:Init()
	self.Button = ui.Create('DButton', self)
	self.Button.OnMousePressed = function(s, mb) if (mb == MOUSE_LEFT) then s:GetParent():StartDrag() end end
	self.Button:SetText('')
	self:SetValue(0.5)
end

function PANEL:PerformLayout()
	self:SetTall(16)
	self.Button:SetSize(16, 16)
	self.Button:SetPos(self.Value * (self:GetWide() - 16), 0)
end

function PANEL:Paint(w, h)
	derma.SkinHook('Paint', 'UISlider', self, w, h)
end

function PANEL:Think()
	if (self.Dragging) then
		local mx, my = self:CursorPos()
		mx = math.Clamp(mx - self.OffX, 0, self:GetWide() - 16)

		if (self.Button.x != mx) then
			self:SetValue(mx / (self:GetWide() - 16))
			self:OnChange(self.Value)
		end

		if (!input.IsMouseDown(MOUSE_LEFT)) then
			self:EndDrag()
		end
	end
end

function PANEL:StartDrag()
	self.Dragging = true
	self.OffX = self.Button:CursorPos(MOUSE_LEFT)
end

function PANEL:EndDrag()
	self.Dragging = false
end

function PANEL:OnChange(val)
end

function PANEL:SetValue(val)
	self.Value = val
	self.Button:SetPos(val * (self:GetWide() - 16), 0)
end

function PANEL:GetValue()
	return self.Value
end

vgui.Register('ui_slider', PANEL, 'Panel')