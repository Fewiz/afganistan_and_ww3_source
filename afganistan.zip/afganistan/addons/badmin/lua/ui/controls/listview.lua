
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ui/controls/listview.lua ~

]]

local PANEL = {}

Derma_Hook(PANEL, 'Paint', 'Paint', 'UIListView')

function PANEL:Init()
	self.Rows = {}
	self:SetPadding(-1)
end

function PANEL:AddRow(value, disabled)
	local row = ui.Create('DButton', function(self)
		self:SetText(tostring(value))
		if (disabled == true) then 
			self:SetDisabled(true)
		end
	end)
	self:AddItem(row)
	self.Rows[#self.Rows + 1] = row
	row.DoClick = function()
		row.Active = true
		if IsValid(self.Selected) then
			self.Selected.Active = false
		end
		self.Selected = row
	end
	return row
end

function PANEL:AddSpacer(value)
	return self:AddRow(value, true)
end

function PANEL:GetSelected()
	return self.Selected
end

vgui.Register('ui_listview', PANEL, 'ui_scrollpanel')