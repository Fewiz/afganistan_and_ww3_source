
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ui/controls/avatarbutton.lua ~

]]

local PANEL = {}

function PANEL:Init()
	self:SetText('')

	self.AvatarImage = ui.Create('AvatarImage', self)

	self.Button = ui.Create('DButton', self)
	self.Button:SetText('')
	self.Button.DoClick = function()
		self:DoClick()
	end
	self.Button.OnCursorEntered = function()
		self.Hovered = true
	end
	self.Button.OnCursorExited = function()
		self.Hovered = false
	end
	self.Button.PaintOver = function(_, w, h)
		derma.SkinHook('Paint', 'AvatarImage', self, w, h)
	end
	self.Button.Paint = function() end
end

function PANEL:PerformLayout()
	self.AvatarImage:SetPos(0,0)
	self.AvatarImage:SetSize(self:GetWide(), self:GetTall())

	self.Button:SetPos(0,0)
	self.Button:SetSize(self:GetWide(), self:GetTall())
end

function PANEL:DoClick()
	if IsValid(self.Player) then
		self.Player:ShowProfile()
	else
		gui.OpenURL('http://steamcommunity.com/profiles/' .. self.SteamID64)
	end
end

function PANEL:SetPlayer(pl)
	self.AvatarImage:SetPlayer(pl)
	self.SteamID64 = pl:SteamID64()
	self.Player = pl
end

vgui.Register('ui_avatarbutton', PANEL, 'DPanel')