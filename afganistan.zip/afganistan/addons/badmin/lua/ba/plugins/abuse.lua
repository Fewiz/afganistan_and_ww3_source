
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/plugins/abuse.lua ~

]]

ba.AddTerm('AbuseAdminUnjailedPlayer', '# вытащил из т.обмы #.')
ba.AddTerm('AbuseAdminJailedPlayer', '# посадил в тюрьму #.')
ba.AddTerm('AbusePlayerNotAlive', '# мёртвый!')
ba.AddTerm('AbuseAdminSlainPlayer', '# убил #.')

/*-------------------------------------------------
-- Jail
-------------------------------------------------
local jailPeices = {
	{pos = Vector(23,-84,-40),		ang = Angle(90,90,0)},
	{pos = Vector(23,-176.1,-40),	ang = Angle(90,90,0)},
    {pos = Vector(44,-152,-40),		ang = Angle(90,0,0)},
    {pos = Vector(-48.6,-152,-40),	ang = Angle(90,0,0)},
    {pos = Vector(23,-152,-64),		ang = Angle(0,0,0)},
    {pos = Vector(23,-152,28.1),	ang = Angle(0,0,0)},
}

local cmd = ba.cmd.Create('Jail', function(pl, args)
	if not args.target:Alive() then
		args.target:Spawn()
	end
		
	if args.target:InVehicle() then
		args.target:ExitVehicle()
	end

	if args.target:GetBVar('JailProps') then
		for k, v in ipairs(args.target:GetBVar('JailProps')) do 
			if IsValid(v) then
				v:Remove()
			end
		end
		args.target:GodDisable()
		args.target:SetBVar('CanNoclip', nil)
		args.target:SetBVar('JailProps', nil)
		args.target:SetBVar('JailPos', nil)

		for k, v in ipairs(args.target:GetBVar('PreJailWeps' or {})) do
			args.target:Give(v)
		end

		ba.notify_staff(ba.Term('AbuseAdminUnjailedPlayer'), pl, args.target)
		return
	end
	
	local pos = util.FindEmptyPos(pl:GetEyeTrace().HitPos)

	local weps = {}
	for _, wep in ipairs(args.target:GetWeapons()) do
		weps[#weps + 1] = wep:GetClass()
	end
	args.target:SetBVar('CanNoclip', false)
	args.target:SetBVar('PreJailWeps', weps)
	args.target:SetBVar('JailPos', args.target:GetPos())

	args.target:SetMoveType(MOVETYPE_WALK)
	args.target:StripWeapons()
	args.target:GodEnable()
	args.target:SetPos(pos + Vector(0,0,5))

	local jailprops = {}
	for k, v in ipairs(jailPeices) do
		local ent = ents.Create('prop_physics')
		ent:SetPos(pos + v.pos + Vector(0,125,65))
		ent:SetAngles(v.ang)
		ent:SetModel('models/props_phx/construct/windows/window2x2.mdl')
		ent:SetColor(Color(255,0,0,50))
		ent:SetMoveType(MOVETYPE_NONE)
		ent:Spawn()
		ent:Activate()
		ent:GetPhysicsObject():EnableMotion(false)
		
		jailprops[#jailprops + 1] = ent
	end

	args.target:SetBVar('JailProps', jailprops)

	ba.notify_staff(ba.Term('AbuseAdminJailedPlayer'), pl, args.target)
end)
cmd:AddParam('player_entity', 'target')
cmd:SetFlag('S')
cmd:SetHelp('Сажает в тюрьму и вытаскивает из тюрьмы игроков')

hook.Add('PlayerSpawn', 'ba.jail.PlayerSpawn', function(pl)
	if (pl:GetBVar('JailPos') ~= nil) then
		pl:SetPos(pl:GetBVar('JailPos'))
		pl:GodEnable()
		pl:StripWeapons()
	end
end)

hook.Add('PlayerDisconnected', 'ba.jail.PlayerDisconnected', function(pl)
	local props = pl:GetBVar('JailProps')
	if (props ~= nil) then
		for k, v in ipairs(props) do
			if IsValid(v) then
				v:Remove()
			end
		end
	end
end)

hook.Add('playerCanRunCommand', 'ba.jail.playerCanRunCommand', function(pl)
	if (pl:GetBVar('JailPos') ~= nil) and not pl:HasAccess('*') then
		return false, 'Вы в тюрьме и не сможете пользоваться командами!'
	end
end)*/

-------------------------------------------------
-- Slay
-------------------------------------------------
ba.cmd.Create('Slay', function(pl, args)
	if not args.target:Alive() then
		ba.notify_err(pl, ba.Term('AbusePlayerNotAlive'), args.target)
		return
	end

	args.target:SetVelocity(Vector(0, 0, 2048))
	timer.Simple(0.2, function()	
		local effect = EffectData()
		effect:SetOrigin(args.target:GetPos())
		effect:SetMagnitude(512)
		effect:SetScale(128)
		util.Effect('Explosion', effect)
		args.target:Kill()
	end)

	ba.notify_staff(ba.Term('AbuseAdminSlainPlayer'), pl, args.target)
end)
:AddParam('player_entity', 'target')
:SetFlag('D')
:SetHelp('Убивает игроков')
:SetIcon('icon16/bomb.png')