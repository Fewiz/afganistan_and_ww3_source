
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/core/module_loader.lua ~

]]

local modules 	 = {}
local gm_modules = {}
local mod_mt 	 = {}
mod_mt.__index 	 = mod_mt

function ba.Module(name)
	local m = {
		Name 		 = name,
		Files 		 = {},
		Dependancies = {}
	}
	setmetatable(m, mod_mt)
	modules[#modules + 1] = m
	return m
end

function mod_mt:Author(name)
	self.Creator = name
	return self
end

function mod_mt:SetGM(name)
	self.Gamemode = name:lower()
	return self
end

function mod_mt:CustomCheck(callback)
	self.CustomCheckFunc = callback
	return self
end

function mod_mt:Require(modules)
	if istable(modules) then
		for k, v in ipairs(modules) do
			self.Dependancies[#self.Dependancies + 1] = v
		end
	else
		self.Dependancies[#self.Dependancies + 1] = modules
	end
	return self
end

function mod_mt:Include(files)
	if istable(files) then
		for k, v in ipairs(files) do
			self.Files[#self.Files + 1] = v
		end
	else
		self.Files[#self.Files + 1] = files
	end
	return self
end

function mod_mt:Init()
	if (not self.CustomCheckFunc or self.CustomCheckFunc()) and (not self.Gamemode or (gmod.GetGamemode().Name:lower() == self.Gamemode)) then 
		/*for _, m in ipairs(self.Dependancies) do
			to do, make this work
		end*/ 

		for _, f in ipairs(self.Files) do
			ba.include(self.Directory .. f)
		end

		ba.print('> Модуль | ' .. self.Name)
	end
end


local _, dirs = file.Find('ba/modules/*', 'LUA')
for _, m in ipairs(dirs) do
	ba.include_sh('ba/modules/' .. m .. '/_module.lua')
	modules[#modules].Directory = 'ba/modules/' .. m .. '/'
end

hook.Add('PostGamemodeLoaded', function() -- it doesn't play nice if we load too soon
	for k, v in ipairs(modules) do
		v:Init()
	end
	hook.Call('BadminPlguinsLoaded')
end)