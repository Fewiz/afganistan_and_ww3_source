
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/core/ranks/setup_sh.lua ~

]]

-- We'll replace this some day.. maybe
ba.ranks.Create('Root', 10)
	:SetImmunity(10000)
	:SetRoot(true)

ba.ranks.Create('Admin+', 6)
	:SetImmunity(7500)
	:SetFlags('uvmas')
	:SetAdmin(true)
	
ba.ranks.Create('Admin', 5)
	:SetImmunity(6000)
	:SetFlags('uvma')
	:SetAdmin(true)

ba.ranks.Create('Moderator', 4)
	:SetImmunity(5000)
	:SetFlags('uvma') --  uvm
	:SetAdmin(true)

ba.ranks.Create('VIP+', 3)
	:SetImmunity(0)
	:SetFlags('uv')
	:SetVIP_Plus(true)

ba.ranks.Create('VIP', 2)
	:SetImmunity(0)
	:SetFlags('uv')
	:SetVIP(true)

ba.ranks.Create('User', 1)
	:SetImmunity(0)
	:SetFlags('u')



