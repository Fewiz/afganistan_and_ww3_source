
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/core/util/player/player_sh.lua ~

]]

function ba.GetStaff()
	return table.Filter(player.GetAll(), function(pl)
		return pl:IsAdmin()
	end)
end

function ba.IsPlayer(info)
	return (type(info) == 'Player')
end

function ba.IsSteamID(info)
	return (type(info) == 'string' and info:match('^STEAM_%d:%d:%d+$'))
end

function ba.FindPlayer(info) 
	if not info or info == '' then return nil end
	for k, pl in ipairs(player.GetAll()) do
		if info == pl:SteamID() or info == pl:SteamID64() then
			return pl
		end

		if string.find(string.lower(pl:Name()), string.lower(tostring(info)), 1, true) ~= nil then
			return pl
		end
	end
	return nil
end

function ba.InfoTo64(info)
	return (ba.IsPlayer(info) and info:SteamID64() or util.SteamIDTo64(info))
end

function ba.InfoTo32(info)
	return (ba.IsPlayer(info) and info:SteamID() or (ba.IsSteamID(info) and info or util.SteamIDFrom64(info)))
end

function PLAYER:NameID()
	return (self:Name() .. '(' .. self:SteamID() .. ')')
end

function PLAYER:SetBVar(var, val)
	if (self._ba == nil) then
		self._ba = {}
	end
	self._ba[var] = val
end

function PLAYER:GetBVar(var)
	if (self._ba == nil) then
		self._ba = {}
	end
	return self._ba[var]
end