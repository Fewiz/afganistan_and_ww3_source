
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/core/util/notifications/notify_cl.lua ~

]]

local notify_types = {
	[0] = Color(255,100,100),
	[1] = Color(255,30,30),
}

net.Receive('ba.NotifyString', function(len)
	chat.AddText(notify_types[net.ReadBit()], '| ', unpack(ba.ReadMsg()))
end)


net.Receive('ba.NotifyTerm', function(len)
	chat.AddText(notify_types[net.ReadBit()], '| ', unpack(ba.ReadTerm()))
end)