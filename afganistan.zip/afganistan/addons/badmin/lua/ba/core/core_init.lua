
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/core/core_init.lua ~

]]

-- Notifications
ba.include_dir 'core/util/notifications'
ba.include_sh 'terms_sh.lua'

-- Data
ba.include_sv 'data_sv.lua'

-- Util
ba.include_dir 'core/util'

-- Player
ba.include_sh 'player_sh.lua'

-- Ranks
ba.include_sh 'ranks/groups_sh.lua'
ba.include_sv 'ranks/groups_sv.lua'
ba.include_sh 'ranks/setup_sh.lua'

-- Commands
ba.include_sh 'commands/commands_sh.lua'
ba.include_sv 'commands/commands_sv.lua'
ba.include_sh 'commands/parser_sh.lua'

-- Bans
ba.include_sv 'bans_sv.lua'

-- UI
ba.include_cl 'ui/main_cl.lua'
ba.include_sh 'ui/main_sh.lua'

-- Logging
ba.include_sh 'logging/logs_sh.lua'
ba.include_sv 'logging/logs_sv.lua'
ba.include_cl 'logging/logs_cl.lua'

-- Modules
ba.include_sh 'module_loader.lua'

-- Plugins
ba.include_dir 'plugins'