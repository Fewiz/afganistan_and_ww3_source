
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/modules/darkrp/jail/jail_sh.lua ~

]]

nw.Register 'JailReason'
	:Write(net.WriteString)
	:Read(net.ReadString)
	:SetLocalPlayer()

nw.Register 'JailTime'
	:Write(net.WriteString)
	:Read(net.ReadString)
	:SetLocalPlayer()

ba.AddTerm('JailNotSet', 'Тюрьма не установлена!')
ba.AddTerm('MissingArgTime', 'Не введен параметр времени!')
ba.AddTerm('MissingArgReason', 'Не введён аргумент причины!')
ba.AddTerm('JailTimeRestriction', 'Вы не можете посадить дольше, чем на 10 минут!')
ba.AddTerm('AdminJailedPlayer', '# посадил # на срок #. Причина: #.')
ba.AddTerm('AdminJailedYou', '# посадил вас на срок #. Причина: #.')
ba.AddTerm('AdminUnjailedPlayer', '# отпустил из тюрьмы #.')
ba.AddTerm('AdminUnjailedYou', '# выпустил ваз из тюрьмы.')
ba.AddTerm('JailroomSet', 'Тюрьма была установлена в данной точке.')
ba.AddTerm('PlayerJailReleased', '# был выпущен из тюрьмы.')
ba.AddTerm('YouJailReleased', 'Вас выпустили из тюрьмы.')

function PLAYER:IsJailed()
	return ((SERVER) and (ba.jailedPlayers[self:SteamID()] ~= nil) or (self:GetNetVar('JailReason') ~= nil))
end

local cmd = ba.cmd.Create('Jail', function(pl, args)
	if not ba.svar.Get('jailroom') then
		ba.notify_err(pl, ba.Term('JailNotSet'))
		return
	end

	if not args.target:IsJailed() then
		if (args.time == nil) then
			ba.notify_err(pl, ba.Term('MissingArgTime'))
			return
		end

		if (args.reason == nil) then
			ba.notify_err(pl, ba.Term('MissingArgReason'))
			return
		end

		if (args.time > 600) and not pl:HasAccess('G') then
			ba.notify_err(pl, ba.Term('JailTimeRestriction'))
			return
		end

		ba.jailPlayer(args.target, args.time, args.reason)
		ba.notify_staff(ba.Term('AdminJailedPlayer'), pl, args.target, args.raw.time, args.reason)
		ba.notify(args.target, ba.Term('AdminJailedYou'), pl, args.raw.time, args.reason)
	else
		ba.unJailPlayer(args.target)
		ba.notify_staff(ba.Term('AdminUnjailedPlayer'), pl, args.target)
		ba.notify(args.target, ba.Term('AdminUnjailedYou'), pl)
	end
end)
cmd:AddParam('player_entity', 'target')
cmd:AddParam('time', 'time', 'optional')
cmd:AddParam('string', 'reason', 'optional')
cmd:SetFlag('M')
cmd:SetHelp('Сажает вас в тюрьму и выпускает из неё')
cmd:SetIcon('icon16/lock_add.png')

-------------------------------------------------
-- Set Admin Room
-------------------------------------------------
local cmd = ba.cmd.Create('SetJailRoom', function(pl, args)
	ba.svar.Set('jailroom', pon.encode({pl:GetPos()}))
	ba.notify(pl, ba.Term('JailroomSet'))
end)
cmd:SetFlag('*')
cmd:SetHelp('Устанавливает тюрьму в данной точке')


if (CLIENT) then
	local color_bg 			= Color(0,0,0,230)
	local color_outline	 	= Color(245,245,245)
	local color_black 		= Color(0,0,0)

	hook.Add('HUDPaint', 'jail.HUDPaint', function()
		if LocalPlayer():IsJailed() then
			draw.OutlinedBox(0, -1, ScrW(), 22, color_bg, color_outline)
			surface.SetFont('HudFont')
			local txt = 'Вы наказаны за: ' .. LocalPlayer():GetNetVar('JailReason') .. ' | Наказание истекает через: '..math.abs(math.floor(CurTime()-(LocalPlayer():GetNetVar('JailTime') or 0)))
			local txtsize = surface.GetTextSize(txt) + 10
			surface.DrawOutlinedRect(0, -1, txtsize, 22)
			draw.SimpleTextOutlined(txt, 'HudFont', txtsize/2, 10, color_outline, 1, 1, 1, color_black)
			return false
		end
	end)
end