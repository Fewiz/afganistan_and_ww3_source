
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/badmin/lua/ba/modules/steam_group/init_cl.lua ~

]]

local function OpenMenu()
	local fr = ui.Create('ui_frame', function(self)
		self:SetSize(520, 90)
		self:SetTitle('Заходите в нашу группу стим!')
		self:MakePopup()
		self:Center()
		self:RequestFocus()
	end)

	ui.Create('DLabel', function(self, p) 
		self:SetText('Если вы подпишитесь на неё, то получите 300 монет на нашем DarkRP сервере!')
		self:SetFont('ba.ui.24')
		self:SetTextColor(ui.col.Close)
		self:SizeToContents()
		self:SetPos((p:GetWide() - self:GetWide()) / 2, 32)
	end, fr)

	ui.Create('DButton', function(self, p)
		self:SetText('Забирай нас тут')
		self:SetPos(5, 60)
		self:SetSize(p:GetWide()/2 - 7.5, 25)
		function self:DoClick()
			gui.OpenURL('http://steamcommunity.com/gid/103582791434605559/')
			timer.Simple(30, function()
				RunConsoleCommand('sgr', 'request')
			end)
		end
	end, fr)

	ui.Create('DButton', function(self, p)
		self:SetText('No thanks')
		self:SetPos(p:GetWide()/2 + 2.5, 60)
		self:SetSize(p:GetWide()/2 - 7.5, 25)
		function self:DoClick()
			p:Close()
			LocalPlayer():ChatPrint('Ты всегда можешь написать !steam чтобы вернуться сюда!')
		end
	end, fr)
end

local function Request()
	timer.Simple(30, function()
		http.Fetch('http://superiorservers.co/portal/steamgroup.php?id=' .. LocalPlayer():SteamID64(), function(body, len, headers, code)
			if (body == '1') then
				OpenMenu()
			elseif (body == '0') then
				RunConsoleCommand('sgr', 'request')
			end
		end, Request)
	end)
end

hook.Add('InitPostEntity', function()
	Request()
end)