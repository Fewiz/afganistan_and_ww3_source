
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[vjbase]_chicken/lua/autorun/vj_echickensnpcs_autorun.lua ~

]]

/*--------------------------------------------------
	=============== Autorun File ===============
	*** Copyright (c) 2012-2018 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
--------------------------------------------------*/
------------------ Addon Information ------------------
local PublicAddonName = "[VJ] More Chicken SNPCs"
local AddonName = "[VJ] More Chicken SNPCs"
local AddonType = "SNPCs"
local AutorunFile = "autorun/vj_as_autorun.lua"
-------------------------------------------------------
local VJExists = file.Exists("lua/autorun/vj_base_autorun.lua","GAME")
if VJExists == true then
	include('autorun/vj_controls.lua')

	local vCat = "Курицы" -- Category, you can also set a category individually by replacing the vCat with a string value
	
	 
VJ.AddNPC("Курица Братишки","npc_vj_brat_chicken",vCat)
VJ.AddNPC("Курица А НУ ИДИ","npc_vj_brat2_chicken",vCat)
 

	-- ConVars --
VJ.AddConVar("vj_dum_dummy_h",100) -- Example 1
VJ.AddConVar("vj_dum_dummy_d",20) -- Example 2
	
VJ.AddNPC("Killer Chicken","npc_vj_killerchicken",vCat) -- Adds a NPC to the spawnmenu
VJ.AddNPC("Fast Killer Chicken","npc_vj_fast_kchicken",vCat)
VJ.AddNPC("Zombie Chicken","npc_vj_zombiechicken",vCat)
VJ.AddNPC("Demonic Chicken","npc_vj_demon_chicken",vCat)
VJ.AddNPC("Combine Chicken","npc_vj_combine_chicken",vCat)
VJ.AddNPC("WTF Chicken","npc_vj_mistake_chicken",vCat)
VJ.AddNPC("Friendly Killer Chicken","npc_vj_f_killerchicken",vCat)
VJ.AddNPC("Minecraft Killer Chicken","npc_vj_mcraft_kchicken",vCat)
VJ.AddNPC("Friendly Minecraft Killer Chicken","npc_vj_f_mcraft_kchicken",vCat)
VJ.AddNPC("Terrorist Chicken","npc_vj_bomber_chicken",vCat)
VJ.AddNPC("Flying Killer Chicken","npc_vj_flying_kchicken",vCat)
VJ.AddNPC("Super Chicken","npc_vj_super_chicken",vCat)
VJ.AddNPC("Hell Chicken","npc_vj_hell_chicken",vCat)
VJ.AddNPC("Angry Chicken","npc_vj_angry_chicken",vCat)
VJ.AddNPC("Killer Rooster","npc_vj_k_rooster",vCat)
VJ.AddNPC("Golden Chicken","npc_vj_goldenchicken",vCat)
VJ.AddNPC("Military Chicken","npc_vj_military_chicken",vCat)
VJ.AddNPC("Friendly Military Chicken","npc_vj_f_military_chicken",vCat)
VJ.AddNPC("Big Chicken","npc_vj_big_chicken",vCat)
VJ.AddNPC("Big Minecraft Chicken","npc_vj_big_mcchicken",vCat)
VJ.AddNPC("Big Golden Chicken","npc_vj_big_goldchicken",vCat)
VJ.AddNPC("Chicken Boss","npc_vj_chicken_boss",vCat)
VJ.AddNPC("Hell Chicken Boss","npc_vj_hellchicken_boss",vCat)
VJ.AddNPC("WTF Chicken Boss","npc_vj_c_absolute_mistake",vCat)
VJ.AddNPC("Micro Chicken","npc_vj_microchicken",vCat)
VJ.AddNPC("Text To Speech Chicken","npc_vj_ttschicken",vCat)
VJ.AddNPC("Small Chicken","npc_vj_smallchicken",vCat)
VJ.AddNPC("Half Life 3 Chicken","npc_vj_hl3chicken",vCat)
VJ.AddEntity("Egg Grenade","obj_vj_eggnade","DrVrej",false,0,true,vCat)

	-- ConVars --
	VJ.AddConVar("vj_dum_dummy_h",100) -- Example 1
	VJ.AddConVar("vj_dum_dummy_d",20) -- Example 2

-- !!!!!! DON'T TOUCH ANYTHING BELOW THIS !!!!!! -------------------------------------------------------------------------------------------------------------------------
	AddCSLuaFile(AutorunFile)
	VJ.AddAddonProperty(AddonName,AddonType)
else
	if (CLIENT) then
		chat.AddText(Color(0,200,200),PublicAddonName,
		Color(0,255,0)," was unable to install, you are missing ",
		Color(255,100,0),"VJ Base!")
	end
	timer.Simple(1,function()
		if not VJF then
			if (CLIENT) then
				VJF = vgui.Create("DFrame")
				VJF:SetTitle("ERROR!")
				VJF:SetSize(790,560)
				VJF:SetPos((ScrW()-VJF:GetWide())/2,(ScrH()-VJF:GetTall())/2)
				VJF:MakePopup()
				VJF.Paint = function()
					draw.RoundedBox(8,0,0,VJF:GetWide(),VJF:GetTall(),Color(200,0,0,150))
				end
				
				local VJURL = vgui.Create("DHTML",VJF)
				VJURL:SetPos(VJF:GetWide()*0.005, VJF:GetTall()*0.03)
				VJURL:Dock(FILL)
				VJURL:SetAllowLua(true)
				VJURL:OpenURL("https://sites.google.com/site/vrejgaming/vjbasemissing")
			elseif (SERVER) then
				timer.Create("VJBASEMissing",5,0,function() print("VJ Base is Missing! Download it from the workshop!") end)
			end
		end
	end)
end