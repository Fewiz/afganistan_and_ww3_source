
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_kvesti/lua/entities/kvestor_1/shared.lua ~

]]

ENT.Type = "ai"
ENT.Base = "base_ai"
ENT.PrintName = "(1) СССР"
ENT.Category = "Квесты"
ENT.Spawnable = true
ENT.AutomaticFrameAdvance = true
ENT.AdminOnly = true

ENT.KVESTORID = 1
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
function ENT:SetupDataTables()
  self:NetworkVar("String", 1, "ThreeDeeTwoDee")
  self:NetworkVar("Bool", 2, "ThreeDeeStare")
end