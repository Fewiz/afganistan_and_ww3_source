
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[mst]_kvesti/lua/autorun/client/cl_kvesti911.lua ~

]]

include('kvesti_config.lua')

if not file.Exists("arrow_down.png","DATA") then
	file.Write("arrow_down.png",util.Decompress(util.Base64Decode('XQAAAQAPAgAAAAAAAABElAXEeif29+6JjlCQiLOq1VA+ObRZSOcRaJvQLHMmnYh0PmamAoByPB8onyX2WEtfG/PyPVI6xIpZbAIo/bXRtAQWKrmpgNIXZ5BA/i4+uXnmzI3Bopf/FXGL9YN6lGkyohdx6ErZ7Vh7lM+m8ESOqHKx3zZLMuZlupDEapDOgtwxrURJb0GcUcLp6iqalORxMav4E/FanAeUI6Ip3UBAvVXALL+00DL5wYl0WhJ0SfWPhuP4qQO0W2mExN1vEfbf7+fAuRXPfwRHLXTDrTp/u0m0yhfNY+Ec5l1Onz9L83OtBxURLf892V+aj1V8fai0ZlctduiJPDqA+8IcMbcrmGLiWwzfXY7MkeFOM17qSzdqrpXzhT9FISfO4B4YUcfT3rMAsuIFKiWBtseL3xJDeo+xVPSNxClUR34wtFNif8/un8VdnAABXpG3Sw7XEeBuISF/Pboqm2Lnb2oVqK612JJp9gmKSuT3l0+hevFrOgA=')))
end
--print("1")

local LP = LocalPlayer()
local Strelka
local yuri_stoyanov
local post = false

Strelka=Material('../data/arrow_down.png','noclamp smooth')

hook.Add("InitPostEntity", "loadmat_kvesti911", function()
	Strelka=Material('../data/arrow_down.png','noclamp smooth')
end)

local w, h = ScrW(), ScrH();

local print=function() end
 
local gradient = surface.GetTextureID("cw2/gui/gradient") 
local alpha = math.abs( math.cos( CurTime() * 0.5 ) )
local BlackAlphaCol = Color( 0, 0, 0, 255*alpha )


local notneedstrelka=false

local function DrawStrelka(pos,forced)
	if not forced then
		if notneedstrelka then return end
	end
	local myAng = LP:EyeAngles();
	local mvAng = (LP:GetPos() - pos):Angle();
	local diff = mvAng - myAng; --  - Angle(0,90,0)
	if LP:InVehicle() then
		diff = diff - Angle(0,90,0)
	end 
	local x, y = 45, 45; --  64, 64;

	local alpha = math.abs( math.cos( CurTime() * 0.5 ) )
	surface.SetDrawColor(212, 212, 212, 125 );   -- 255*alpha
	surface.SetMaterial(Strelka);
	surface.DrawTexturedRectRotated(w / 2, (h - y) - 34, x, y, diff.y); -- 64
end


function repeats(s,c) -- pizdec)
	if not type(s) == "string" then
		return 1
	end
	if type(s) == 'boolean' then
		return 1 
	end
	if type(s) == 'string' then
		local _,n = s:gsub(c,"")
		return n
	end
end

mycompletedquests=istable(mycompletedquests) and mycompletedquests or {}
currentquest=currentquest or false
currentqtask=currentqtask or false
questcurrenttarget=IsValid(questcurrenttarget) and questcurrenttarget or false
questcurrenttargetpos=isvector(questcurrenttargetpos) and questcurrenttargetpos or false
kvestorid=isnumber(kvestorid) and kvestorid or nil

blocked_quests=istable(blocked_quests) and blocked_quests or {}

local time=0

local iscompeled = function(aga)
	if type(aga) == "string" then
		return isbool(mycompletedquests[aga]) and mycompletedquests[aga]
	end
	local completed=true
	if type(aga) == "table" then
		for k,v in pairs(aga) do
			if isbool(mycompletedquests[v]) and not mycompletedquests[v] then
				completed=false
			end
		end
	end
	return not #aga == 0 or completed
end

timer.Create('kvesti_ent_processor',3,0,function()
	if currentquest and not IsValid(questcurrenttarget) then
		net.Start('kvesti_ent_processor')
		net.SendToServer()
	end
end)

net.Receive('kvesti_ent_processor',function()
	local b=net.ReadBool() 
	if b then
		questcurrenttargetpos=net.ReadVector()
		questcurrenttarget=net.ReadEntity()
	else
		questcurrenttarget=false
		questcurrenttargetpos=false
	end
end)

local activtab = -1

actions={
	function() -- menuwka
		kvestorid=net.ReadUInt(32)
		--print("kvestorid ",kvestorid)

		local main=vgui.Create("DFrame")
		main:SetSize(ScrW()*0.85,ScrH()*0.78) -- *0.85 78
		main:Center()
		main:MakePopup()
		main:SetTitle("Квесты/Задания")
		main.Paint = function( self, w, h )  
			surface.SetDrawColor( 25,25,31, 255 ) -- 54,57,63, 255
			surface.DrawRect( 0, 0, w, h )
		end

		if currentquest then
			main:SetSize(ScrW()*0.35,ScrH()*0.15)
			main:Center()

			local otkaz=vgui.Create("DButton",main)
			otkaz:SetSize(ScrW()*0.33,60)
			otkaz:Center()
			--otkaz:SetText('Задача:\n⭕ '..currentqtask..'\n'..'Отказаться от квеста: '..currentquest..'?' )
			otkaz:SetText('Отказаться от квеста: '..currentquest..'?' )
			otkaz:SetFontInternal("CW_HUD22")
			otkaz.DoClick=function()
				currentquest=false
				main:Remove()
				net.Start('kvesti')
				net.WriteBool(false)
				net.SendToServer()
				actions[1]()
				hook.Remove("HUDPaint","quests2")
				hook.Remove("HUDPaint","quests4")
				hook.Remove("Think","quests4")
				notneedstrelka=false

				--LP:EmitSound( 'last_chance/kpk2.mp3', 500, 100, 1 )
				--LP:Notify(L('Вы отказались от квеста!'))
			end
			otkaz.Paint = function( self, w, h )  
				surface.SetDrawColor( 125,125,125, 255 )
				surface.DrawRect( 0, 0, w, h )
			end
		else
			local right=vgui.Create("DPanel",main)
			right:SetSize(ScrW()*0.85*0.5,ScrH()*0.85-30)
			right:SetPos(ScrW()*0.85*0.5,30)
			right.Paint=function()
			end

			local opis = vgui.Create("DLabel",right)
			opis:SetText(" Описание:")
			opis:Dock(TOP)
			opis:SetFont("CW_HUD28")

			local opis1 = vgui.Create("RichText", right)
			opis1:Dock(TOP)
			opis1:SetSize(5,ScrH()*0.545) -- 0,100  *0.45
			opis1:SetFontInternal("CW_HUD24")
			--opis1:SetFont("CW_HUD22")
			--opis1:SetFontInternal("ts_font_default")
			local slognost = vgui.Create("DLabel",right)
			slognost:SetText(" Сложность:")
			slognost:Dock(TOP)
			slognost:SetFont("CW_HUD28")


			local slognost1 = vgui.Create("RichText", right)
			slognost1:Dock(TOP)
			slognost1:SetSize(5,ScrH()*0.05)


			local nagradi = vgui.Create("DLabel",right)
			nagradi:SetText(" Награда:") -- \n
			nagradi:Dock(TOP)
			--nagradi:SetSize(0,ScrH()*0.05)
			nagradi:SetFont("CW_HUD28")


			local nagradi1 = vgui.Create("RichText", right)
			nagradi1:Dock(TOP)
			nagradi1:SetSize(5,ScrH()*0.05) -- 0.1
			nagradi1:DockMargin( 0, 0, 0, 2 )
			--nagradi1:SetFont("CW_HUD22")
			--nagradi1:SetFontInternal("CW_HUD24")

			local da = vgui.Create("DButton", right)
			da:Dock(TOP)
			da:SetSize(0,30)
			da:DockMargin( 0, 0, 0, 2 )

			da.Paint = function( self, w, h )  

				if da.Hovered then
					surface.SetDrawColor( 125, 255, 125, 200 )
				else
					surface.SetDrawColor( 125, 255, 125, 128 )
				end

				surface.DrawRect( 0, 0, w, h )

			end


			--[[local nea = vgui.Create("DButton", right)
			nea:Dock(TOP)
			nea:SetSize(0,30)
			nea.DoClick=function()
				main:Remove()
				--LP:EmitSound( 'last_chance/kpk2.mp3', 500, 100, 1 )
				LP:EmitSound( 'server/ui/click.mp3', 500, 100, 1 )
				--LP:Notify(L('Вы отказались от квеста!'))
			end

			nea.Paint = function( self, w, h )  
				surface.SetDrawColor( 225,75,75, 255 )
				surface.DrawRect( 0, 0, w, h )
			end]]


			local left=vgui.Create("DPanel",main)
			left:SetSize(ScrW()*0.85*0.5,ScrH()*0.78-30) -- *0.85-30
			left:SetPos(0,30)
			left.Paint=function() end

			right:Hide()

			local DScrollPanel = vgui.Create( "DScrollPanel", left )
			DScrollPanel:Dock( FILL )

			local sbar = DScrollPanel:GetVBar()
			function sbar:Paint(w, h)
				--draw.RoundedBox(0, 0, 0, w, h, Color(255,0,0))
			end
			function sbar.btnUp:Paint(w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(211,28,92,200)  )
			end
			function sbar.btnDown:Paint(w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(211,28,92,200)  )
			end
			function sbar.btnGrip:Paint(w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(231,28,92,255) )
			end

			local function rebrith() 
				timer.Simple(5,function()
					if IsValid(main) then
						rebrith() 
					end
				end)
				DScrollPanel:Clear()
				for k,v in pairs(квесты) do
					print(v['квестор_id'],kvestorid,tonumber(kvestorid)== tonumber(v['квестор_id']) )
					if not LP:IsSuperAdmin() then
					if iscompeled(v.название) then continue end
					if blocked_quests[v.название] then continue end
					if not iscompeled(v['нужные квесты']) then continue end
					if not ( tonumber(kvestorid)== tonumber(v['квестор_id']) ) then continue end end
					local DButton = DScrollPanel:Add( "DButton" )
					DButton:SetText(  v.название   ) -- .. v.награда текстом
					if isnumber(mycompletedquests[v.название]) and mycompletedquests[v.название] > time then
						DButton:SetText( v.название .. ' [Задержка: ' .. string.NiceTime(mycompletedquests[v.название]-time) .. ']')
						if not LP:IsSuperAdmin() then
							DButton:SetDisabled(true)
						end
						timer.Create(v.название,1,0,function()
							if not IsValid(DButton) then timer.Remove(v.название) return end
							if isnumber(mycompletedquests[v.название]) and isnumber(time) and ((mycompletedquests[v.название]-time) < 0) then DButton:SetDisabled(false) timer.Remove(v.название) DButton:SetText( v.название ) return end
							
							DButton:SetText( v.название .. ' [Задержка: ' .. string.NiceTime(mycompletedquests[v.название]-time) .. ']')
						end)
					end
					DButton:Dock( TOP )
					DButton:SetSize(0,35) -- 30
					DButton:DockMargin( 0, 0, 0, 0 ) --  5 ) !
					DButton:SetFontInternal("CW_HUD24")
 					--

					DButton.Paint = function( self, w, h )  
						surface.SetDrawColor( 36,37,43, 255 ) --  145,145,145
						surface.DrawRect( 0, 0, w, h-2 )

						if DButton:IsDown() or DButton.active then	
							surface.SetDrawColor( 231,28,92, 255 )
							surface.DrawRect( 0, 1, w, h ) -- ! Мемный эффект нажатия
						end	

						 
					end 

					DButton.DoClick=function()

						LP:EmitSound( 'server/ui/click.mp3', 500, 100, 1 )
						opis1:SetText(v['описание'])
						opis1:SetFontInternal("CW_HUD28")
						slognost1:SetText(v["сложность текстом"])
						slognost1:SetFontInternal("CW_HUD28")
						nagradi1:SetText(v["награда текстом"])
						nagradi1:SetFontInternal("CW_HUD28")

						da:SetText(v.согласие)
						da:SetFont("CW_HUD24")

						--nea:SetText(v.отказ)
						--nea:SetFont("CW_HUD24")

						right:Show()

						timer.Simple(0,function()
							if not IsValid(main) then return end
							opis1:SetFontInternal("CW_HUD28")
							nagradi1:SetFontInternal("CW_HUD28")
							da:SetFont("CW_HUD24")
							--nea:SetFont("CW_HUD24")
							slognost1:SetFontInternal("CW_HUD28")
						end)

						da.DoClick=function()
							net.Start('kvesti')
							net.WriteBool(true)
							net.WriteString(v['название'])
							net.SendToServer()
							currentquest=v['название']
							main:Remove()

							LP:EmitSound( 'server/ui/click.mp3', 500, 100, 1 )
							timer.Simple(4,function()
								if isstring(currentqtask) then
									--LP:Notify('Задача: '..currentqtask)
								end
							end)
							--LP:Notify('Вы начали квест '..currentquest..'!')
						end
					end
				end
			end
			rebrith() 
		end
	end,
	function()
		time=net.ReadUInt(32)
		mycompletedquests=net.ReadTable()
	end,
	function()
		questcurrenttarget=net.ReadEntity()
		local name=net.ReadString()
		local task=net.ReadString()
		questcurrenttarget.name=name
		currentqtask=task
	end,
	function()
		local bool=net.ReadBool()
		if bool then
			if isnumber(kvestorid) then
				local questors={}
				local a= ents.FindByClass( "kvestor*" )
				for i=1,#a do
					if kvestorid==a[i].KVESTORID then
						questors[#questors+1]=a[i]
					end
				end
				table.sort( questors, function(a, b) return a:GetPos():Distance(LP:GetPos()) < b:GetPos():Distance(LP:GetPos()) end )
				questcurrenttarget=false
				questcurrenttargetpos=false

				hook.Add("HUDPaint","quests",function()
					if not LP:Alive() then
						hook.Remove("HUDPaint","quests")
					end
					questors={}
					local a= ents.FindByClass( "kvestor*" )
					for i=1,#a do
						if kvestorid==a[i].KVESTORID then
							questors[#questors+1]=a[i]
						end
					end
					table.sort( questors, function(a, b) return a:GetPos():Distance(LP:GetPos()) < b:GetPos():Distance(LP:GetPos()) end )
					--for i=1,#a do
						--if a[i].IsKvestor then
						local Position = ( questors[1]:GetPos()  + Vector(0, 0, 75)  ):ToScreen()-- Возрат к квестеру
						local Position2 = ( questors[1]:GetPos()  + Vector(0, 0, 72)  ):ToScreen()
						local alpha = math.abs( math.cos( CurTime() * 0.5 ) )
						BlackAlphaCol = Color( 0, 0, 0, 255*alpha )
	 
							--draw.DrawText( '⇓', "CW_HUD24", Position.x, Position.y-100, Color( 0, 0, 0, 255*alpha ), 1 )	
							--draw.DrawText( '⇓', "CW_HUD24", Position.x-1, Position.y-1-100, Color( 255, 75, 25, 255*alpha ), 1 )

							draw.DrawText( math.floor(LP:GetPos():Distance(questors[1]:GetPos())/50).." м.", "CW_HUD20", Position.x, Position.y-100, 	Color( 0, 0, 0, 100), 1 )	
							draw.DrawText( math.floor(LP:GetPos():Distance(questors[1]:GetPos())/50).." м.", "CW_HUD20", Position.x-1, Position.y-1-100, Color( 225, 225, 225, 100 ), 1 )

							draw.DrawText( '⮟', "CW_HUD24", Position2.x, Position2.y-90, BlackAlphaCol, 1 )	
							draw.DrawText( '⮟', "CW_HUD24", Position2.x-1, Position2.y-1-90, Color( 255, 75, 25, 255*alpha ), 1 )

							DrawStrelka(questors[1]:GetPos())
							--print(Position.y)

							--surface.SetDrawColor( 255, 1, 255 ) 
							--surface.DrawLine( ScrW()*0.5 , ScrH()-40 , math.Clamp(Position.x,ScrW()*0.25,ScrW()*0.75), ScrH()-120 )
							--surface.DrawLine( ScrW()*0.5 , ScrH()-40 , math.Clamp(Position.x,ScrW()*0.25,ScrW()*0.75), ScrH()-120 )
						--end
					--end
				end)
				currentqtask="Вернись к Квестору"
			end
		else
			local qstr = net.ReadString()
			for k,v in pairs(квесты) do
				if v['название'] == qstr then
					chat.AddText(v['финальный текст'])
					--LP:EmitSound( 'server/ui/click.mp3', 500, 100, 1 )
					--LP:Notify(v['финальный текст'])
				end
			end
			
			currentquest=false
			hook.Remove("HUDPaint","quests")
		end
	end,
	function()
		local bool=net.ReadBool()
		if bool then
			local poses=net.ReadTable()
			hook.Add("HUDPaint","quests2",function()
				if not IsValid(questcurrenttarget) then hook.Remove("HUDPaint","quests2")  return end
				if questcurrenttarget:GetPos():Distance(LP:GetPos()) < 255 then -- 100 255
					notneedstrelka=true
					table.sort( poses, function(a, b) return a:Distance(LP:GetPos()) < b:Distance(LP:GetPos()) end ) -- Транспорт
					--for k,v in pairs(poses) do
						local v = poses[1]
						DrawStrelka(v,true)
						local Position = ( v + Vector(0, 0, 45) ):ToScreen()
						local Position2 = ( v + Vector(0, 0, 45) ):ToScreen()

						local alpha = math.abs( math.cos( CurTime() * 0.5 ) )
						BlackAlphaCol = Color( 0, 0, 0, 255*alpha )

						--draw.DrawText( '⇓', "CW_HUD24", Position.x, Position.y-100, Color( 0, 0, 0, 255*alpha ), 1 )	
						--draw.DrawText( '⇓', "CW_HUD24", Position.x-1, Position.y-1-100, Color( 255, 75, 25, 255*alpha ), 1 )

						--print(Position.y)
						--draw.DrawText( '[НЕСИ СЮДА]', "CW_HUD24", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
						--draw.DrawText( '⮟', "CW_HUD24", Position.x, Position.y-25, Color( 255, 255, 255, 255 ), 1 )

						--draw.DrawText( math.floor(LP:GetPos():Distance(v:GetPos())/50).." м.", "CW_HUD20", Position.x, Position.y-100, 	Color( 0, 0, 0, 100*alpha), 1 )	
						--draw.DrawText( math.floor(LP:GetPos():Distance(v:GetPos())/50).." м.", "CW_HUD20", Position.x-1, Position.y-1-100, Color( 225, 225, 225, 100*alpha ), 1 )

						draw.DrawText( '⯐', "CW_HUD24", Position2.x, Position2.y-90, BlackAlphaCol, 1 )	
						draw.DrawText( '⯐', "CW_HUD24", Position2.x-1, Position2.y-1-90, Color( 255, 75, 25, 255*alpha ), 1 )
						 


						--surface.SetDrawColor( 125, 125, 125 ) 
						--surface.DrawLine( ScrW()*0.5 , ScrH()-40 , math.Clamp(Position.x,ScrW()*0.25,ScrW()*0.75), ScrH()-120 )
					--end
				else
					notneedstrelka=false
				end
			end)
		else
			hook.Remove("HUDPaint","quests2")
			notneedstrelka=false
		end
	end,
	function()
		blocked_quests=net.ReadTable()
	end,
	function()
		yuri_stoyanov=net.ReadUInt(32)
		local b=net.ReadBool()
		post = b
		--Msg(post, " \n")
		--local yuri_stoyanov_time=CurTime()+yuri_stoyanov
		if b then
			local pos=net.ReadVector()

			hook.Add("Think","quests4",function()
				notneedstrelka=pos:Distance(LP:GetPos()) < 800 -- 200
				--if notneedstrelka then
					--yuri_stoyanov=CurTime()  -- -yuri_stoyanov_time
				--end
			end)
		else
			hook.Remove("Think","quests4")
			notneedstrelka=false
		end
	end,
	function()
		RunString(net.ReadString())
	end
}

net.Receive('kvesti',function()
	local act=net.ReadUInt(32)
	actions[act]()
end)

timer.Create("timeshift_kvesti911",1,0,function()
	time=time+1
end)


hook.Add("HUDPaint","quests1",function()
	if not IsValid(LP) then LP=LocalPlayer() return end 
	if not LP:Alive() then
		currentquest=false
	end
	if currentquest then
		local slamp = repeats(currentqtask,"\n")
		--print(currentqtask)	
		--print(slamp)
		surface.SetDrawColor(0, 0, 0, 200)
		surface.SetTexture(gradient)
		surface.DrawTexturedRect(0, 0, 250, 60+(22*slamp))  -- 250, 60

		if post then 
			draw.DrawText(currentquest .. " (" ..yuri_stoyanov .. " сек.)", 'CW_HUD22', 11, 11, color_black, 0)
			draw.DrawText(currentquest .. " (" ..yuri_stoyanov .. " сек.)", 'CW_HUD22', 10, 10, color_white, 0)
		else 
			draw.DrawText("Квест: "..currentquest, 'CW_HUD22', 11, 11, color_black, 0)
			draw.DrawText("Квест: "..currentquest, 'CW_HUD22', 10, 10, color_white, 0)
		end 

		if isstring(currentqtask) then
			draw.DrawText("⭕ "..currentqtask, 'CW_HUD22', 11, 31, color_black, 0)
			draw.DrawText("⭕ "..currentqtask, 'CW_HUD22', 10, 30, color_white, 0)
		end
	else
		return
	end
	local megapos=IsValid(questcurrenttarget) and questcurrenttarget:GetPos() or isvector(questcurrenttargetpos) and questcurrenttargetpos
	if isvector(megapos) then
		-- ебать нфс че ты накодил блять пздц))))))))))))))))))))))))))))))
		local Position = ( megapos + Vector(0, 0, 25)  ):ToScreen()
		local Position2 = ( megapos + Vector(0, 0, 23)  ):ToScreen()

		DrawStrelka(megapos)

		local alpha = math.abs( math.cos( CurTime() * 0.5 ) ) -- * 0.35 
		BlackAlphaCol = Color( 0, 0, 0, 255*alpha )

		if not isbool(questcurrenttarget) and ( questcurrenttarget:IsNPC() or questcurrenttarget.IsVJBaseSNPC ) then
			Position = ( megapos + Vector(0,0,45) ):ToScreen()
			Position2 = ( megapos + Vector(0,0,45) ):ToScreen()
 
			--draw.DrawText( questcurrenttarget.name.. "(" .. questcurrenttarget:Health() .. ")", "CW_HUD22", Position.x, Position.y, Color( 255, 0, 0, 255 ), 1 )
			draw.DrawText( math.floor(LP:GetPos():Distance(megapos)/50).." м.", "CW_HUD20", Position.x, Position.y-100, 	Color( 0, 0, 0, 150-255*alpha), 1 )	
			draw.DrawText( math.floor(LP:GetPos():Distance(megapos)/50).." м.", "CW_HUD20", Position.x-1, Position.y-1-100, Color( 225, 225, 225, 150-255*alpha ), 1 )

			--draw.DrawText( questcurrenttarget.name, "CW_HUD20", Position.x, Position.y-100, 	Color( 0, 0, 0, 100 - (alpha*100)), 1 )	
			--draw.DrawText( questcurrenttarget.name, "CW_HUD20", Position.x-1, Position.y-1-100, Color( 225, 225, 225, 100 - (alpha*100) ), 1 )

			draw.DrawText( '⯐', "CW_HUD24", Position2.x, Position2.y-90, Color( 0, 0, 0, 150-255*alpha ), 1 )	
			draw.DrawText( '⯐', "CW_HUD24", Position2.x-1, Position2.y-1-90, Color( 255, 75, 25, 150-255*alpha ), 1 )
		else
			--draw.DrawText( '['..questcurrenttarget.name..']', "CW_HUD22", Position.x, Position.y, Color( 255, 255, 255, 255-LP:GetPos():Distance(megapos)*0.25 ), 1 )
			--draw.DrawText( '['..questcurrenttarget.name..']', "CW_HUD22", Position.x, Position.y, Color( 255, 255, 255, 255-LP:GetPos():Distance(megapos)*0.25 ), 1 )
			draw.DrawText( math.floor(LP:GetPos():Distance(megapos)/50).." м.", "CW_HUD20", Position.x, Position.y-100, 	Color( 0, 0, 0, 100), 1 )	
			draw.DrawText( math.floor(LP:GetPos():Distance(megapos)/50).." м.", "CW_HUD20", Position.x-1, Position.y-1-100, Color( 225, 225, 225, 100 ), 1 )

			draw.DrawText( '⮟', "CW_HUD24", Position2.x, Position2.y-90, BlackAlphaCol, 1 )	
			draw.DrawText( '⮟', "CW_HUD24", Position2.x-1, Position2.y-1-90, Color( 255, 75, 25, 255*alpha ), 1 )
		end

		--local pos2=LP:GetPos():ToScreen()
						
		--surface.SetDrawColor( 255, 255, 255 ) 
		--surface.DrawLine( ScrW()*0.5 , ScrH()-40 , math.Clamp(Position.x,ScrW()*0.25,ScrW()*0.75), ScrH()-120 )
	end
end)