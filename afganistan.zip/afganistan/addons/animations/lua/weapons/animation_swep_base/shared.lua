
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/animations/lua/weapons/animation_swep_base/shared.lua ~

]]

SWEP.Purpose				= "Base for animations"
SWEP.Instructions 			= "Click to play the animation"
SWEP.Category 				= "Animation"

SWEP.PrintName				= "Animation SWEP"
SWEP.Slot					= 2 -- 4
SWEP.SlotPos				= 5
SWEP.DrawAmmo				= false

SWEP.Spawnable				= false

SWEP.DefaultHoldType = "normal"

SWEP.ViewModel 				= "models/weapons/v_357.mdl"
SWEP.WorldModel 			= "models/weapons/w_357.mdl"

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.Weight					= 1
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false
SWEP.deactivateOnMove		= 5

function SWEP:DrawWorldModel()
end

function SWEP:PreDrawViewModel()
    render.SetBlend(0)
end

function SWEP:PostDrawViewModel()
    render.SetBlend(1)
end

function SWEP:Initialize()
	self:SetHoldType(self.DefaultHoldType)

	if CLIENT then
		AnimationSWEP.GestureAngles[self:GetClass()] = self:GetGesture()
	end

	if SERVER then

		if PlayerConfig and PlayerConfig.NoDropWeapons then
			table.insert(PlayerConfig.NoDropWeapons, self:GetClass())
		end
	end
end

if CLIENT then
	-- Should be overidden in child file.
	function SWEP:GetGesture()
		return {}
	end

	function SWEP:PrimaryAttack()
	end
	function SWEP:SecondaryAttack()
	end
end

if SERVER then
	function SWEP:PrimaryAttack()
	end

	function SWEP:SecondaryAttack()
	end

	function SWEP:OnRemove()
		local ply = self.Owner
		AnimationSWEP:Toggle(ply, false)
	end

	function SWEP:OnDrop()
		local ply = self.Owner
		AnimationSWEP:Toggle(ply, false)
	end

	function SWEP:Holster()
		local ply = self.Owner
		AnimationSWEP:Toggle(ply, false)
		return true
	end

	function SWEP:Think()
		ply = self.Owner
		if self.Owner:KeyDown(IN_ATTACK) then
			if not ply:Crouching() and ply:GetVelocity():Length() < 5 and not ply:InVehicle() then
				AnimationSWEP:Toggle(ply, true, self:GetClass(), self.deactivateOnMove)
			end
		else
			AnimationSWEP:Toggle(ply, false)
		end
	end
end
 