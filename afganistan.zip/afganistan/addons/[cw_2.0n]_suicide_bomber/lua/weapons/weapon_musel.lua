
--[[

~ yuck, anti cheats! ~

~ file stolen by ~
                __  .__                          .__            __                 .__               
  _____   _____/  |_|  |__ _____    _____ ______ |  |__   _____/  |______    _____ |__| ____   ____  
 /     \_/ __ \   __\  |  \\__  \  /     \\____ \|  |  \_/ __ \   __\__  \  /     \|  |/    \_/ __ \ 
|  Y Y  \  ___/|  | |   Y  \/ __ \|  Y Y  \  |_> >   Y  \  ___/|  |  / __ \|  Y Y  \  |   |  \  ___/ 
|__|_|  /\___  >__| |___|  (____  /__|_|  /   __/|___|  /\___  >__| (____  /__|_|  /__|___|  /\___  >
      \/     \/          \/     \/      \/|__|        \/     \/          \/      \/        \/     \/ 

~ purchase the superior cheating software at https://methamphetamine.solutions ~

~ server ip: 46.174.55.216_27015 ~ 
~ file: addons/[cw_2.0n]_suicide_bomber/lua/weapons/weapon_musel.lua ~

]]


AddCSLuaFile()

SWEP.PrintName	= "Пояс деда" -- Подрыв
SWEP.Category = "Взрывное оружие"
SWEP.Damage = 1250 -- Для продавца 250

SWEP.Author		= "gamerpaddy"
SWEP.Purpose	= "This SWEP will make you explode like a terrorist, alllakbar"

SWEP.Spawnable	= true
SWEP.UseHands	= true
SWEP.DrawAmmo	= false

--SWEP.ViewModel	= "models/weapons/v_slam.mdl" -- "models/weapons/v_slam.mdl"


SWEP.ViewModel 					= Model('models/weapons/v_hands.mdl')
SWEP.ViewModelFOV 				= 62


SWEP.WorldModel	= ""
SWEP.TraceLength = 500
SWEP.ViewModelFOV	= 52
SWEP.Slot			= 0
SWEP.SlotPos		= 5

SWEP.Effect                =  "c4_explosion"
SWEP.EffectAir             =  "c4_explosion_air" 

util.PrecacheModel( SWEP.ViewModel )

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.DefaultHoldType = "normal" -- !

local Explosion = {
	"ambient/explosions/explode_1.wav" ,
	"ambient/explosions/explode_2.wav" ,
	"ambient/explosions/explode_3.wav" ,
	"ambient/explosions/explode_4.wav" 
}
local MuselScream = {
	"allakbar1.mp3",
	"allakbar2.mp3" ,
	"allakbar3.mp3" 
}
SWEP.DamageDistance = 500 -- 1000


function SWEP:Initialize()

	--self:SetHoldType( "melee" )
	--self:SetHoldType( self.HoldType )
	self.CanPerformAttack = true

	--timer.Simple(0.05,function()
		--self:SendWeaponAnim(ACT_SLAM_DETONATOR_IDLE)
		--self.Owner:SetModel("models/player/afghanistan_rp/taliban_bomber.mdl")
	--end)

	--timer.Create("TimeToModel", 1, 15, function()
	--	if not IsValid(self.Owner) then timer.Remove("TimeToModel") return end
	--	self.Owner:SetModel("models/player/afghanistan_rp/taliban_bomber.mdl")
	--end)


	 
	
end

function SWEP:PreDrawViewModel( vm, wep, ply )

	--vm:SetMaterial( "engine/occlusionproxy" ) 
end



if CLIENT then
	SWEP.WepSelectIcon = surface.GetTextureID( "vgui/musel_swep" )
end



function SWEP:PrimaryAttack( right )


	if not self.CanPerformAttack then return false end
	self.CanPerformAttack = false
	--self.Owner:SetAnimation( PLAYER_ATTACK1 )

	--self.Owner:SetModel("models/player/kuma/taliban_bomber.mdl")
	self.Owner:SetModel("models/player/afghanistan_rp/taliban_bomber.mdl")
 
	local vm = self.Owner:GetViewModel()
	--vm:SendViewModelMatchingSequence( vm:LookupSequence( anim ) )
	self:EmitSound( MuselScream[math.floor(math.Rand(1,3))] )
	--sound.Play(MuselScream[math.floor(math.Rand(1,3))] , self:GetPos(), 180 , 100, 1 ) 

	timer.Simple(1.4,function() -- 1.1
		self.CanPerformAttack = true ---- !!!! true
			if not self.Owner:Alive() then return end
			--self:SendWeaponAnim(ACT_SLAM_DETONATOR_DETONATE)

			self:EmitSound( Explosion[math.floor(math.Rand(1,4))] )
			local pos = self.Owner:GetPos()
			local tracedata    = {}
				 tracedata.start    = pos
				 tracedata.endpos   = tracedata.start - Vector(0, 0, self.TraceLength)
				 tracedata.filter   = self.Entity
					
			 local trace = util.TraceLine(tracedata)
			 
			 if trace.HitWorld then
				 ParticleEffect(self.Effect,pos,Angle(0,0,0),nil)
			 else 
				 ParticleEffect(self.EffectAir,pos,Angle(0,0,0),nil) 
			 end
		if CLIENT then
			--self:EmitSound( Explosion[math.floor(math.Rand(1,4))] )
			 --sound.Play( , self:GetPos(), 180 , 100, 1 ) 
		elseif SERVER then

			--self.Owner:StripWeapon(self.Gun)

			util.BlastDamage(self, self.Owner, pos, self.DamageDistance, 300) -- 250  190 250 300
			
		end
	end)
end
function SWEP:SecondaryAttack()

end
function SWEP:OnRemove()
	
	if ( IsValid( self.Owner ) && CLIENT && self.Owner:IsPlayer() ) then
		local vm = self.Owner:GetViewModel()
		if ( IsValid( vm ) ) then vm:SetMaterial( "" ) end
	end
	
end

function SWEP:Holster( wep )

	self:OnRemove()

	return true

end

function SWEP:Deploy()


		
	return true

end

function SWEP:Think()
	
	--self.Owner:SetModel("models/player/kuma/taliban_bomber.mdl")
	
end
